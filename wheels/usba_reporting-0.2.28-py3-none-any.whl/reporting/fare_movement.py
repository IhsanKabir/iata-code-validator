"""
reporting.fare_movement - one home for the rules that link a route's FARE change to its CUSTOMERS'
movement, for any two periods.

Two consumers, so they cannot disagree:
  * scripts/build_route_fare_mart.py writes the tables the Power BI "Route Fare & Customers" page
    reads (the page's DAX mirrors the rule functions below one to one);
  * reporting/builders/route_fare_movement.py builds the Excel twin for a chosen period pair, which
    is also how the page's numbers are checked.

WHAT IS MEASURED (decided with the analyst, 2026-10-11)
    Sale date, never flight date: a fare change acts on the bookings made after it.
    Routes are directional itinerary LEGS (reporting.itinerary.route_legs_sql). A leg's money is an
    equal share of its ticket; the data has no per-coupon fare.
    Three fare bases, all per segment, Ticket payment rows only:
        base   fare before tax                          ("Total without taxe" / "Base fare in sale currency")
        gross  fare including tax                        ("Balance")
        net    fare x (1 - commission) + tax             (the DSR's ticket-payment net, before refunds)
    plus the DSR's money net per day (refunds, voids, penalties included, on their own dates).
    Volume: SOLD segments (the canonical count) and KEPT segments (tickets not later voided or
    refunded, as known on the data date: 2.3% of July 2026's tickets were voided, 4.1% refunded).
    Customers: an agency (sibling accounts folded by the dashboard's own agency_key) or one of the
    direct channels as a single customer (Web / Counter / App / Call centre / Other), so no
    individual's name is ever stored.

LIKE-FOR-LIKE PRICE (why the average fare lies)
    July to August 2026 the average base fare on CGP-DAC fell 13.9% while the price of the same
    seats fell 2.6%: the rest was WHICH seats sold. So a fare is compared only within a CELL of
    identical seats: route x itinerary type x journey type x booking lead band x booking class x
    sale currency. The price change is a Laspeyres index over the cells sold in BOTH periods,
    weighted by the before period's BDT revenue, with each cell's price change measured in its SALE
    currency, so an exchange-rate move is not read as a price change (29.5% of segments are sold in
    a foreign currency). The average BDT fare change then splits exactly into three parts:
        price (sale currency) + exchange rate (same cells, in BDT) + mix (everything else).
    Coverage = the share of the before period's segments that sit in matched cells.

MOVEMENT (no thresholds, by the analyst's decision)
    Per customer per route, segments PER DAY in each period (so periods of different length
    compare fairly):  both > 0 -> Up / Down / Same by sign;  before only -> Stopped;
    after only -> Back (sold this route before the before period) or New (never had).
    Each customer's contribution is after/day - before/day, so the statuses add up EXACTLY to the
    route's change: the waterfall cannot leak.
"""
from __future__ import annotations

import calendar
import datetime as dt
from dataclasses import dataclass

import pandas as pd

from .common import NET_CASE_SQL
from .itinerary import DOMESTIC_AIRPORTS, itinerary_domestic_sql, route_legs_sql

# ------------------------------------------------------------------------------------- labels
#: Transaction detail starts here (no Jan-Apr 2025 export exists). "First seen" can only look back to
#: this date, so New vs Back is unknowable until HISTORY_MONTHS later.
DATA_START = dt.date(2025, 5, 1)
HISTORY_MONTHS = 6

ITIN_DOM, ITIN_INTL = "Domestic itinerary", "International itinerary"
NO_ROUTE = "(no route)"

#: Booking lead time = flight date of the ticket's FIRST flight minus the sale date. Bands, not days,
#: so a like-for-like cell holds enough seats to have a price. Upper bounds are inclusive.
LEAD_BANDS: tuple[tuple[int | None, str], ...] = (
    (3, "0-3 days"), (7, "4-7 days"), (14, "8-14 days"), (30, "15-30 days"), (None, "31+ days"))
LEAD_UNKNOWN = "Unknown"

#: The direct channels become ONE customer each (no individual is ever named). Same labels as the
#: dashboard's masking step.
CHANNEL_LABEL = {"WEB": "Web", "OFFICE": "Counter", "MOBILE": "App", "CALL_CENTER": "Call centre"}
DIRECT_OTHER = "Other"

STATUSES = ("Up", "Down", "Same", "New", "Back", "Stopped")
CANCEL_TXNS = ("Ticket void", "Refund", "Cancel refund")


# ------------------------------------------------------------------------------------- windows
@dataclass(frozen=True)
class Window:
    """An inclusive range of SALE dates."""
    lo: dt.date
    hi: dt.date

    @property
    def days(self) -> int:
        return (self.hi - self.lo).days + 1

    def shifted(self, days: int) -> "Window":
        """The same window moved `days` earlier (positive = into the past)."""
        return Window(self.lo - dt.timedelta(days=days), self.hi - dt.timedelta(days=days))


def year_earlier(w: Window) -> Window:
    """The same dates a year earlier; a month-end stays a month-end and 29 Feb becomes 28 Feb."""
    def back(d: dt.date) -> dt.date:
        return d.replace(year=d.year - 1, day=min(d.day, calendar.monthrange(d.year - 1, d.month)[1]))
    hi = w.hi
    is_end = hi.day == calendar.monthrange(hi.year, hi.month)[1]
    hi_back = dt.date(hi.year - 1, hi.month, calendar.monthrange(hi.year - 1, hi.month)[1]) if is_end else back(hi)
    return Window(back(w.lo), hi_back)


def before_window(after: Window, mode: str, custom: Window | None = None) -> Window:
    """The comparison period. `mode`: 'previous' = the same number of days just before;
    'last_year' = the same dates a year earlier; 'custom' = `custom`. The page's three choices."""
    if mode == "previous":
        return after.shifted(after.days)
    if mode == "last_year":
        return year_earlier(after)
    if mode == "custom":
        if custom is None:
            raise ValueError("A custom comparison needs its own from and to dates.")
        if custom.hi >= after.lo:
            raise ValueError(f"The before period ({custom.lo} to {custom.hi}) must end before the "
                             f"after period starts ({after.lo}).")
        return custom
    raise ValueError(f"Comparison must be previous, last_year or custom; got {mode!r}.")


def lead_band(days: int | float | None) -> str:
    """Booking lead band for a number of days between sale and first flight."""
    if days is None or pd.isna(days) or days < 0:
        return LEAD_UNKNOWN
    for upper, label in LEAD_BANDS:
        if upper is None or days <= upper:
            return label
    return LEAD_UNKNOWN


def _lead_band_sql(col: str) -> str:
    """The same bands as lead_band(), in SQL (tests pin the two equal)."""
    whens = " ".join(f"WHEN {col} <= {u} THEN '{lbl}'" for u, lbl in LEAD_BANDS if u is not None)
    return (f"CASE WHEN {col} IS NULL OR {col} < 0 THEN '{LEAD_UNKNOWN}' {whens} "
            f"ELSE '{LEAD_BANDS[-1][1]}' END")


# ------------------------------------------------------------------------------------- the leg rows
def leg_rows_sql(src: str, rate_sql: str, lo: dt.date, hi: dt.date) -> str:
    """DuckDB SQL: curated sales rows sold between lo and hi (inclusive), once per itinerary leg,
    with every column the two Power BI tables need. `src` reads curated sales (hive-partitioned);
    `rate_sql` is the commission CASE (reporting.common.build_rate_sql), evaluated on the raw row.

    Airports: the row's own Departure / Arrival, else the itinerary's first leg (11,733 ticket rows
    in May-Aug 2025 carry a readable itinerary but no airports). Booking class: the fare basis
    coupon of THIS leg (coupon k = leg k; 99.74% of tickets have one coupon per leg, and 17% mix
    classes between legs); a one-coupon ticket on an unsplit row uses its only coupon; anything else
    is '?'. Journey: One-way / Return (A-B-A) / Multi-leg. Lead: first flight date - sale date.
    """
    ok = "regexp_full_match(rtg, '[A-Z]{3}(-[A-Z]{3})+')"
    base = f"""(
        SELECT *, {itinerary_domestic_sql('dep', 'arr', 'rtg')} AS itin_dom
        FROM (
            SELECT d, cid, txn, tkt, bal, fare, bal_cur, base_cur, rate, cur, fbs, ahead, rtg,
                   COALESCE(dep0, CASE WHEN {ok} THEN split_part(rtg, '-', 1) END) AS dep,
                   COALESCE(arr0, CASE WHEN {ok} THEN split_part(rtg, '-', 2) END) AS arr,
                   CASE WHEN NOT COALESCE({ok}, FALSE) OR len(string_split(rtg, '-')) = 2 THEN 'One-way'
                        WHEN len(string_split(rtg, '-')) = 3
                             AND split_part(rtg, '-', 1) = split_part(rtg, '-', 3) THEN 'Return'
                        ELSE 'Multi-leg' END                                          AS journey
            FROM (
                SELECT CAST("Date" AS DATE)                                              AS d,
                       regexp_replace(CAST("Customer ID" AS VARCHAR), '[.]0+$', '')     AS cid,
                       CAST("Transaction" AS VARCHAR)                                   AS txn,
                       CAST("Ticket number" AS VARCHAR)                                 AS tkt,
                       CAST("Balance (base currency)" AS DOUBLE)                        AS bal,
                       CAST("Total without taxe (base currency)" AS DOUBLE)             AS fare,
                       CAST("Balance" AS DOUBLE)                                        AS bal_cur,
                       CAST("Base fare in sale currency" AS DOUBLE)                     AS base_cur,
                       ({rate_sql})                                                     AS rate,
                       COALESCE(NULLIF(TRIM(CAST("Sale currency" AS VARCHAR)), ''), '?') AS cur,
                       regexp_extract_all(CAST("Fare basis list" AS VARCHAR), ':([A-Z0-9]+)', 1) AS fbs,
                       date_diff('day', CAST("Date" AS DATE), TRY_CAST("Flight date" AS DATE)) AS ahead,
                       NULLIF(TRIM(CAST("Departure airport" AS VARCHAR)), '')           AS dep0,
                       NULLIF(TRIM(CAST("Arrival airport" AS VARCHAR)), '')             AS arr0,
                       upper(TRIM(CAST("Routing information" AS VARCHAR)))              AS rtg
                FROM {src}
                WHERE "year" > 0 AND CAST("Date" AS DATE) BETWEEN DATE '{lo}' AND DATE '{hi}'
            ) _r
        ) _a
    )"""
    return f"""
        SELECT d, cid, txn, tkt, bal, fare, bal_cur, base_cur, rate, cur, journey, itin_dom, leg_share,
               CASE WHEN dep IS NULL OR arr IS NULL OR dep = arr THEN '{NO_ROUTE}' ELSE route END AS route,
               CASE WHEN leg_no IS NOT NULL AND len(fbs) = n_legs THEN fbs[leg_no][1]
                    WHEN leg_no IS NULL AND len(fbs) = 1 THEN fbs[1][1]
                    ELSE '?' END                                                       AS rbd,
               {_lead_band_sql('ahead')}                                               AS lead
        FROM {route_legs_sql(base, keep_leg_no=True)}"""


# ------------------------------------------------------------------------------------- customers
def customer_frame(dim_agency: pd.DataFrame) -> pd.DataFrame:
    """account -> customer_key, customer_id (one representative account per customer, for the
    dashboard's relationship to dim_agency), customer_label, customer_type.

    `dim_agency` is curated/dim_agency/dim_agency.parquet (customer_id, agency_key, agency_name,
    channel, is_ota, is_gds_pseudo). Agencies keep their agency_key, so siblings fold exactly as on
    every other page; a direct channel becomes one customer named after the channel.
    """
    d = dim_agency.copy()
    d["customer_id"] = d["customer_id"].astype(str)
    is_agency = d["channel"].astype(str).str.upper().eq("AGENCY")
    chan = d["channel"].astype(str).str.upper().map(CHANNEL_LABEL).fillna(DIRECT_OTHER)
    out = pd.DataFrame({"cid": d["customer_id"]})
    out["customer_key"] = d["agency_key"].astype(str).where(is_agency, "CH:" + chan)
    out["customer_label"] = d["agency_name"].astype(str).where(is_agency, chan + " (all customers)")
    out["customer_type"] = ("Direct: " + chan).where(~is_agency, "Agency")
    out.loc[is_agency & d["is_ota"].fillna(False).astype(bool), "customer_type"] = "OTA"
    out.loc[is_agency & d["is_gds_pseudo"].fillna(False).astype(bool), "customer_type"] = "GDS pool"
    # one representative account per AGENCY key, so the fact can relate to dim_agency[customer_id];
    # the lowest id is as good as any, since agency_name is the same on every account of a key
    rep = out[is_agency].groupby("customer_key")["cid"].min()
    out["customer_id"] = out["customer_key"].map(rep).fillna(out["customer_key"])
    return out.drop_duplicates("cid")


def customer_frame_with_fallback(dim_agency: pd.DataFrame, dim_customer: pd.DataFrame) -> pd.DataFrame:
    """customer_frame(dim_agency), plus every account dim_agency lacks, read from dim_customer.

    dim_agency is built from gold; an account that only curated has (a sale newer than gold) would
    otherwise fall through to 'Account <id>', and if it is an individual that would put one person
    on the page. From dim_customer it is classified by its primary_channel instead, so an individual
    still folds into Web / Counter / App / Call centre / Other.
    """
    known = customer_frame(dim_agency)
    dc = dim_customer.copy()
    dc["customer_id"] = dc["customer_id"].astype(str).str.replace(r"\.0+$", "", regex=True)
    dc = dc[~dc["customer_id"].isin(set(known["cid"]))]
    if dc.empty:
        return known
    extra = customer_frame(pd.DataFrame({
        "customer_id": dc["customer_id"], "agency_key": dc["customer_id"],
        "agency_name": dc.get("customer_name", dc["customer_id"]).astype(str),
        "channel": dc["primary_channel"].fillna("OTHER"),
        "is_ota": dc.get("ota_status", pd.Series("", index=dc.index)).astype(str).str.upper().str.strip().eq("OTA"),
        "is_gds_pseudo": False}))
    return pd.concat([known, extra], ignore_index=True).drop_duplicates("cid")


# ------------------------------------------------------------------------------------- the tables
def build_tables(con, src: str, rate_sql: str, lo: dt.date, hi: dt.date,
                 customers: pd.DataFrame, country_map: dict[str, str]) -> dict[str, pd.DataFrame]:
    """The four tables for sales dated lo..hi. `con` is an open DuckDB connection.

    route_customer_day   date x customer x route x itinerary: segments sold / kept, tickets, the three
                         fares (BDT), the DSR money net. Rows with no usable route sit on NO_ROUTE so
                         the totals still reconcile with the DSR.
    route_lfl_day        date x like-for-like cell x customer type: segments and the three fares in the
                         SALE currency and in BDT (Ticket payment only).
    customer_route_first customer x route: first sale date and the usual gap between sale days.
    route_dim            route: origin, destination, countries, market, direction.
    """
    con.register("rfm_customers", customers[["cid", "customer_key", "customer_type"]])
    # tickets later voided or refunded (any date up to the data's end): kept segments leave them out
    con.execute(f"""CREATE OR REPLACE TEMP TABLE rfm_cancelled AS
        SELECT DISTINCT CAST("Ticket number" AS VARCHAR) AS tkt FROM {src}
        WHERE "year" > 0 AND CAST("Transaction" AS VARCHAR) IN {CANCEL_TXNS}
          AND CAST("Date" AS DATE) >= DATE '{lo}' AND "Ticket number" IS NOT NULL""")
    con.execute(f"""CREATE OR REPLACE TEMP TABLE rfm_legs AS
        SELECT l.*, COALESCE(c.customer_key, l.cid) AS customer_key,
               COALESCE(c.customer_type, 'Unknown') AS customer_type,
               (x.tkt IS NOT NULL) AS cancelled            -- a join, not IN: one hash pass
        FROM ({leg_rows_sql(src, rate_sql, lo, hi)}) l
        LEFT JOIN rfm_customers c ON c.cid = l.cid
        LEFT JOIN rfm_cancelled x ON x.tkt = l.tkt""")
    tp = "txn = 'Ticket payment'"
    net_sale = "(COALESCE(fare,0)*(1-rate) + (COALESCE(bal,0)-COALESCE(fare,0)))"
    net_sale_cur = "(COALESCE(base_cur,0)*(1-rate) + (COALESCE(bal_cur,0)-COALESCE(base_cur,0)))"
    itin = f"CASE WHEN itin_dom THEN '{ITIN_DOM}' WHEN NOT itin_dom THEN '{ITIN_INTL}' END"
    rcd = con.execute(f"""
        SELECT d AS date, customer_key, route AS leg_route, {itin} AS itinerary,
               COUNT(*) FILTER (WHERE {tp})                                    AS sold_segments,
               COUNT(*) FILTER (WHERE {tp} AND NOT cancelled)                  AS kept_segments,
               COUNT(DISTINCT tkt) FILTER (WHERE {tp})                         AS tickets,
               SUM(COALESCE(fare,0) * leg_share) FILTER (WHERE {tp})           AS base_bdt,
               SUM(COALESCE(bal,0) * leg_share) FILTER (WHERE {tp})            AS gross_bdt,
               SUM({net_sale} * leg_share) FILTER (WHERE {tp})                 AS net_bdt,
               SUM(({NET_CASE_SQL}) * leg_share)                               AS money_net
        FROM rfm_legs GROUP BY ALL""").df()
    lfl = con.execute(f"""
        SELECT d AS date, route AS leg_route, {itin} AS itinerary, journey, lead AS lead_band, rbd,
               cur AS currency, customer_type,
               -- the like-for-like cell: identical seats sold under identical terms (CELL_PARTS order)
               concat_ws('|', route, COALESCE({itin}, ''), journey, lead, rbd, cur) AS cell,
               COUNT(*)                                                        AS segments,
               SUM(COALESCE(base_cur,0) * leg_share)                           AS base_cur,
               SUM(COALESCE(bal_cur,0) * leg_share)                            AS gross_cur,
               SUM({net_sale_cur} * leg_share)                                 AS net_cur,
               SUM(COALESCE(fare,0) * leg_share)                               AS base_bdt,
               SUM(COALESCE(bal,0) * leg_share)                                AS gross_bdt,
               SUM({net_sale} * leg_share)                                     AS net_bdt
        FROM rfm_legs WHERE {tp} AND route <> '{NO_ROUTE}' GROUP BY ALL""").df()
    rcd = _attach_customers(rcd, customers)
    first = customer_route_first(rcd)
    routes = route_dim(sorted(set(rcd.leg_route) - {NO_ROUTE}), country_map)
    return {"route_customer_day": rcd, "route_lfl_day": lfl, "customer_route_first": first, "route_dim": routes}


def _attach_customers(rcd: pd.DataFrame, customers: pd.DataFrame) -> pd.DataFrame:
    """customer_id / label / type per customer_key (one row per key)."""
    per_key = customers.drop_duplicates("customer_key").set_index("customer_key")
    out = rcd.copy()
    for col in ("customer_id", "customer_label", "customer_type"):
        out[col] = out["customer_key"].map(per_key[col])
    # an account missing from dim_agency keeps its own id and is labelled as unknown, never dropped
    missing = out["customer_id"].isna()
    out.loc[missing, "customer_id"] = out.loc[missing, "customer_key"]
    out.loc[missing, "customer_label"] = "Account " + out.loc[missing, "customer_key"].astype(str)
    out.loc[missing, "customer_type"] = "Unknown"
    return out


#: What makes two seats "the same" for the price comparison, in the order the cell key joins them.
CELL_PARTS = ("leg_route", "itinerary", "journey", "lead_band", "rbd", "currency")


def customer_route_first(rcd: pd.DataFrame) -> pd.DataFrame:
    """customer x route: first sale day and the median gap (days) between its sale days, from the
    data's start. The gap is context for 'Stopped': a customer that normally buys a route every 40
    days is not alarming when absent from a 10-day period."""
    sold = rcd[(rcd.sold_segments > 0) & (rcd.leg_route != NO_ROUTE)][["customer_key", "leg_route", "date"]]
    # real datetimes, whatever came in (DuckDB gives datetime64, a caller may pass datetime.date)
    sold = sold.assign(date=pd.to_datetime(sold["date"]))
    sold = sold.drop_duplicates().sort_values(["customer_key", "leg_route", "date"])
    gaps = sold.groupby(["customer_key", "leg_route"])["date"].diff().dt.days
    out = (sold.assign(gap=gaps).groupby(["customer_key", "leg_route"])
               .agg(first_date=("date", "min"), sale_days=("date", "size"), usual_gap_days=("gap", "median"))
               .reset_index())
    return out


def route_dim(routes: list[str], country_map: dict[str, str]) -> pd.DataFrame:
    """route -> origin, destination, their countries, the MARKET and the DIRECTION.

    Market: the foreign end's country for an international leg (DAC-DXB, DAC-SHJ and DAC-AUH are all
    'United Arab Emirates'), the outstation for a domestic one (DAC-CXB and CGP-CXB are both 'CXB').
    Direction: 'Out of Bangladesh' / 'Into Bangladesh' / 'Abroad' / 'From Dhaka' / 'To Dhaka' /
    'Between outstations'. A customer that drops one route is checked against its OTHER routes in
    the same market and direction ('did it switch route, or leave?').
    """
    rows = []
    for r in routes:
        o, d = r.split("-", 1)
        o_dom, d_dom = o in DOMESTIC_AIRPORTS, d in DOMESTIC_AIRPORTS
        if o_dom and d_dom:
            market = d if o == "DAC" else o if d == "DAC" else d
            direction = "From Dhaka" if o == "DAC" else "To Dhaka" if d == "DAC" else "Between outstations"
            leg_type = "Domestic leg"
        else:
            foreign = d if o_dom else o if d_dom else d
            market = country_map.get(foreign) or foreign
            direction = "Out of Bangladesh" if o_dom else "Into Bangladesh" if d_dom else "Abroad"
            leg_type = "International leg"
        rows.append({"leg_route": r, "origin": o, "destination": d,
                     "origin_country": "Bangladesh" if o_dom else country_map.get(o, ""),
                     "destination_country": "Bangladesh" if d_dom else country_map.get(d, ""),
                     "market": market, "direction": direction, "leg_type": leg_type})
    return pd.DataFrame(rows, columns=["leg_route", "origin", "destination", "origin_country",
                                       "destination_country", "market", "direction", "leg_type"])


# ------------------------------------------------------------------------------------- the rules
def movement_status(before_per_day: float, after_per_day: float, first_date: dt.date | None,
                    before_lo: dt.date) -> str | None:
    """One customer on one route. No thresholds: the sign decides. None when it sold in neither."""
    b, a = before_per_day or 0.0, after_per_day or 0.0
    if b > 0 and a > 0:
        return "Up" if a > b else "Down" if a < b else "Same"
    if b > 0:
        return "Stopped"
    if a > 0:
        return "Back" if first_date is not None and first_date < before_lo else "New"
    return None


def history_is_long_enough(before_lo: dt.date) -> bool:
    """New and Back can only be told apart once HISTORY_MONTHS of data exist before the period."""
    y, m = DATA_START.year, DATA_START.month + HISTORY_MONTHS
    y, m = y + (m - 1) // 12, (m - 1) % 12 + 1
    return before_lo >= dt.date(y, m, 1)


def like_for_like(before: pd.DataFrame, after: pd.DataFrame, basis: str = "base") -> dict:
    """Price, exchange-rate and mix parts of the average fare change, for one fare basis.

    `before` / `after`: route_lfl_day rows of each period (any filter already applied), with
    columns cell, segments, <basis>_cur, <basis>_bdt. Returns avg_before, avg_after (BDT per segment),
    avg_change, price (sale currency, Laspeyres over matched cells, weights = before BDT value),
    fx (the same cells in BDT minus price), mix (avg_change - price - fx) and coverage (share of the
    before period's segments in matched cells). Values are None where they cannot be formed.
    """
    cur, bdt = f"{basis}_cur", f"{basis}_bdt"
    b = before.groupby("cell")[["segments", cur, bdt]].sum()
    a = after.groupby("cell")[["segments", cur, bdt]].sum()
    out = {"avg_before": None, "avg_after": None, "avg_change": None, "price": None, "fx": None,
           "mix": None, "coverage": None}
    if b.segments.sum() > 0:
        out["avg_before"] = b[bdt].sum() / b.segments.sum()
    if a.segments.sum() > 0:
        out["avg_after"] = a[bdt].sum() / a.segments.sum()
    if out["avg_before"] and out["avg_after"] is not None and out["avg_before"] > 0:
        out["avg_change"] = out["avg_after"] / out["avg_before"] - 1
    m = b.join(a, lsuffix="_b", rsuffix="_a", how="inner")
    # a cell needs a positive price in both periods to form a ratio (award / zero fares cannot)
    m = m[(m.segments_b > 0) & (m.segments_a > 0) & (m[f"{cur}_b"] > 0) & (m[f"{cur}_a"] > 0)
          & (m[f"{bdt}_b"] > 0) & (m[f"{bdt}_a"] > 0)]
    if b.segments.sum() > 0:
        out["coverage"] = m.segments_b.sum() / b.segments.sum()
    if m.empty:
        return out
    w = m[f"{bdt}_b"]
    rel_cur = (m[f"{cur}_a"] / m.segments_a) / (m[f"{cur}_b"] / m.segments_b)
    rel_bdt = (m[f"{bdt}_a"] / m.segments_a) / (m[f"{bdt}_b"] / m.segments_b)
    out["price"] = float((w * rel_cur).sum() / w.sum() - 1)
    out["fx"] = float((w * rel_bdt).sum() / w.sum() - 1) - out["price"]
    if out["avg_change"] is not None:
        out["mix"] = out["avg_change"] - out["price"] - out["fx"]
    return out


def switch_signal(route_change: float, other_routes_change: float) -> str:
    """A customer that bought LESS of a route (per day): did its other routes in the same market and
    direction grow (it moved there) or not (it bought less of the whole market from us)? We cannot
    see other airlines, so 'less of the market' is the most this can say."""
    if route_change >= 0:
        return ""
    return "Grew on other routes in the market" if other_routes_change > 0 else "Less of the whole market"


# ------------------------------------------------------------------------------------- one period pair
# These are the REFERENCE for the dashboard: the Excel twin prints them, and the page's measures
# must give the same numbers for the same two periods (the check strip on the page shows the totals).
VOLUMES = {"sold": "sold_segments", "kept": "kept_segments"}
BASES = ("base", "gross", "net")


def in_window(df: pd.DataFrame, w: Window) -> pd.DataFrame:
    # compare as timestamps: converting 1.4M values to datetime.date on every call cost 11 s a build
    d = pd.to_datetime(df["date"])
    return df[(d >= pd.Timestamp(w.lo)) & (d <= pd.Timestamp(w.hi))]


def statuses(before_per_day: pd.Series, after_per_day: pd.Series, first_date: pd.Series,
             before_lo: dt.date) -> pd.Series:
    """movement_status() for a whole column at once (a row-by-row loop took over two minutes on a
    month of data). Same rules; tests pin the two equal on every case."""
    import numpy as np
    b, a = before_per_day.fillna(0.0), after_per_day.fillna(0.0)
    earlier = pd.to_datetime(first_date) < pd.Timestamp(before_lo)          # NaT compares False -> New
    out = np.select([(b > 0) & (a > b), (b > 0) & (a > 0) & (a < b), (b > 0) & (a > 0) & (a == b),
                     (b > 0) & (a <= 0), (b <= 0) & (a > 0) & earlier, (b <= 0) & (a > 0)],
                    ["Up", "Down", "Same", "Stopped", "Back", "New"], default="")
    s = pd.Series(out, index=before_per_day.index, dtype=object)
    return s.where(s != "", None)                   # None (not NaN) where it sold in neither period


def customer_movement(rcd: pd.DataFrame, first: pd.DataFrame, route_dims: pd.DataFrame,
                      after: Window, before: Window, volume: str = "sold") -> pd.DataFrame:
    """One row per route x customer that sold the route in either period.

    Per day before / after (the chosen volume), status, contribution (= after/day - before/day, so a
    route's contributions add up to its change exactly), the base fare it paid per segment in each
    period, its sale days in each period, its usual gap, and - for a customer that bought less - its
    change on the OTHER routes of the same market and direction, with the switch signal.
    """
    vol = VOLUMES[volume]
    keep = ["leg_route", "customer_key"]
    # sold_segments always comes along: a FARE per segment divides by every segment sold, even when
    # the volume being compared is kept segments (dividing by kept ones inflated the fare)
    vals = list(dict.fromkeys([vol, "sold_segments", "base_bdt", "money_net"]))

    def side(w: Window) -> pd.DataFrame:
        x = in_window(rcd[rcd.leg_route != NO_ROUTE], w)
        g = x.groupby(keep)[vals].sum()
        g["sale_days"] = x[x.sold_segments > 0].groupby(keep)["date"].nunique()
        return g

    j = side(before).join(side(after), how="outer", lsuffix="_b", rsuffix="_a").fillna(0.0).reset_index()
    j["before_per_day"] = j[f"{vol}_b"] / before.days
    j["after_per_day"] = j[f"{vol}_a"] / after.days
    j = j[(j.before_per_day != 0) | (j.after_per_day != 0)].copy()
    # first sale and usual gap per customer x route, by a join (not a lookup per row)
    j = j.merge(first[["customer_key", "leg_route", "first_date", "usual_gap_days"]],
                on=["customer_key", "leg_route"], how="left")
    j["status"] = statuses(j.before_per_day, j.after_per_day, j.first_date, before.lo)
    if not history_is_long_enough(before.lo):
        j.loc[j.status.isin(["New", "Back"]), "status"] = "New or back"
    j["contribution"] = j.after_per_day - j.before_per_day
    j["fare_before"] = (j.base_bdt_b / j.sold_segments_b).where(j.sold_segments_b > 0)
    j["fare_after"] = (j.base_bdt_a / j.sold_segments_a).where(j.sold_segments_a > 0)
    # the switch test: the same customer's change on the OTHER routes of this route's market + direction
    mk = route_dims.set_index("leg_route")[["market", "direction"]]
    j = j.join(mk, on="leg_route")
    tot = j.groupby(["customer_key", "market", "direction"], dropna=False)["contribution"].transform("sum")
    j["other_routes_change"] = tot - j.contribution
    j["switch"] = ""
    j.loc[(j.contribution < 0) & (j.other_routes_change > 0), "switch"] = "Grew on other routes in the market"
    j.loc[(j.contribution < 0) & (j.other_routes_change <= 0), "switch"] = "Less of the whole market"
    labels = rcd.drop_duplicates("customer_key").set_index("customer_key")[["customer_label", "customer_type"]]
    return j.join(labels, on="customer_key")


def churn_baseline(rcd: pd.DataFrame, first: pd.DataFrame, route_dims: pd.DataFrame,
                   after: Window, before: Window, volume: str = "sold") -> pd.DataFrame:
    """The same comparison ONE PERIOD EARLIER (both periods moved back by the after period's length):
    how many customers stopped and started on each route then. About a third of a route's agencies
    stop each month anyway, so 'Stopped' means little until it is read against this."""
    shift = after.days
    m = customer_movement(rcd, first, route_dims, after.shifted(shift), before.shifted(shift), volume)
    out = m.groupby("leg_route")["status"].agg(
        stopped_earlier=lambda s: int((s == "Stopped").sum()),
        new_earlier=lambda s: int(s.isin(["New", "Back", "New or back"]).sum()))
    return out.reset_index()


def route_summary(rcd: pd.DataFrame, lfl: pd.DataFrame, moves: pd.DataFrame,
                  after: Window, before: Window, volume: str = "sold") -> pd.DataFrame:
    """One row per route: volume per day, the three average fares and their price / exchange / mix
    split, customers active, and each status's count and contribution."""
    vol = VOLUMES[volume]
    rb, ra = in_window(rcd, before), in_window(rcd, after)
    lb, la = in_window(lfl, before), in_window(lfl, after)
    idx = pd.Index(sorted(set(moves.leg_route)), name="leg_route")
    out = pd.DataFrame(index=idx)
    for side, x, w in (("before", rb, before), ("after", ra, after)):
        g = x.groupby("leg_route")[[vol, "money_net"]].sum().reindex(idx).fillna(0.0)
        out[f"{side}_per_day"] = g[vol] / w.days
        out[f"money_{side}_per_day"] = g.money_net / w.days
    out["volume_change"] = (out.after_per_day / out.before_per_day - 1).where(out.before_per_day > 0)
    for basis in BASES:
        parts = like_for_like_by(lb, la, basis).reindex(idx)
        for k in parts.columns:
            out[f"{basis}_{k}"] = parts[k]
    out["customers_before"] = (moves.before_per_day > 0).groupby(moves.leg_route).sum().reindex(idx).fillna(0).astype(int)
    out["customers_after"] = (moves.after_per_day > 0).groupby(moves.leg_route).sum().reindex(idx).fillna(0).astype(int)
    by_status = moves.groupby(["leg_route", "status"])["contribution"].agg(["size", "sum"])
    for s in STATUSES + ("New or back",):
        key = s.lower().replace(" ", "_")
        part = by_status.xs(s, level="status") if s in by_status.index.get_level_values("status") else None
        out[f"n_{key}"] = (part["size"] if part is not None else pd.Series(dtype=float)).reindex(idx).fillna(0).astype(int)
        out[f"c_{key}"] = (part["sum"] if part is not None else pd.Series(dtype=float)).reindex(idx).fillna(0.0)
    return out.reset_index()


def like_for_like_by(before: pd.DataFrame, after: pd.DataFrame, basis: str = "base",
                     by: str = "leg_route") -> pd.DataFrame:
    """like_for_like() for every group at once (one row per `by` value). Same rules; tests pin the
    two equal. Calling the single version once per route took 11 s on a month."""
    cur, bdt = f"{basis}_cur", f"{basis}_bdt"
    b = before.groupby([by, "cell"])[["segments", cur, bdt]].sum()
    a = after.groupby([by, "cell"])[["segments", cur, bdt]].sum()
    tb, ta = b.groupby(level=0).sum(), a.groupby(level=0).sum()
    out = pd.DataFrame(index=tb.index.union(ta.index))
    out["avg_before"] = (tb[bdt] / tb.segments).where(tb.segments > 0)
    out["avg_after"] = (ta[bdt] / ta.segments).where(ta.segments > 0)
    out["avg_change"] = (out.avg_after / out.avg_before - 1).where(out.avg_before > 0)
    m = b.join(a, lsuffix="_b", rsuffix="_a", how="inner")
    m = m[(m.segments_b > 0) & (m.segments_a > 0) & (m[f"{cur}_b"] > 0) & (m[f"{cur}_a"] > 0)
          & (m[f"{bdt}_b"] > 0) & (m[f"{bdt}_a"] > 0)]
    w = m[f"{bdt}_b"]
    m = m.assign(w=w, sb=m.segments_b,
                 wc=w * (m[f"{cur}_a"] / m.segments_a) / (m[f"{cur}_b"] / m.segments_b),
                 wb=w * (m[f"{bdt}_a"] / m.segments_a) / (m[f"{bdt}_b"] / m.segments_b))
    g = m.groupby(level=0)[["w", "wc", "wb", "sb"]].sum().reindex(out.index)
    out["price"] = g.wc / g.w - 1
    out["fx"] = g.wb / g.w - 1 - out.price
    out["mix"] = out.avg_change - out.price - out.fx
    # a route with before sales but no matched cell has coverage 0, not "unknown"
    out["coverage"] = (g.sb.fillna(0) / tb.segments.reindex(out.index)).where(tb.segments.reindex(out.index) > 0)
    return out


def class_ladder(lfl: pd.DataFrame, route: str, after: Window, before: Window) -> pd.DataFrame:
    """Booking classes on one route: share of segments and base fare per segment (BDT) in each
    period, so a shift toward cheaper or dearer classes is visible next to the price change."""
    def side(w: Window) -> pd.DataFrame:
        x = in_window(lfl[lfl.leg_route == route], w).groupby("rbd")[["segments", "base_bdt"]].sum()
        x["share"] = x.segments / x.segments.sum() if x.segments.sum() else 0.0
        x["fare"] = (x.base_bdt / x.segments).where(x.segments > 0)
        return x[["segments", "share", "fare"]]
    return side(before).join(side(after), how="outer", lsuffix="_before", rsuffix="_after").fillna(
        {"segments_before": 0, "segments_after": 0, "share_before": 0.0, "share_after": 0.0}).reset_index()
