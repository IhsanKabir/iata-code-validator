"""
reporting.builders.route_before_after - the top customers on every route, BEFORE beside AFTER.

WHAT IT ANSWERS
    "Who are the N biggest sellers on each route, and how did they do against an earlier period?"
    One block per DIRECTIONAL route (DAC-CGP and CGP-DAC are different markets), ranked by the
    AFTER window's net, with the BEFORE window's figures on the same row and the change beside them.

    It started as scripts/_build_ota_domestic_route_yoy.py (OTAs, domestic, this year vs last). It
    now lives in the package so the Travel Ops Console's Instant Reports tab can build it from an
    uploaded export too; that script is a thin command-line wrapper over generate() below, so the
    command and the desktop app cannot drift apart.

PARAMETERS (all optional; see parse_params, which validates them and explains any refusal)
    sector      'domestic' (default) | 'international' | 'all'
    routes      directional routes to keep, e.g. "DAC-CXB, CXB-DAC". Blank = every route.
    customers   'otas' (default) | 'agencies' | one or more Zenith customer ids ("10000277, 1166...")
    top         sellers listed per route (default 10, at most 100)
    after_from / after_to / before_from / before_to
                'YYYY-MM' (a whole month) or 'YYYY-MM-DD'. Blank AFTER = the last 4 COMPLETE months
                of the data; blank BEFORE = the same dates one year earlier.

DEFINITIONS (the pipeline's canonical ones; see CLAUDE.md)
    net        the DSR's basis: fare x (1 - commission) + tax on sales and reissues, balance on
               refunds / voids / cancel refunds / penalties, zero on commission and discount rows.
               The commission rate is the ONE shared rule table (reporting.common.build_rate_sql).
    route      PER ITINERARY LEG (reporting.itinerary.route_legs_sql). A return ticket is one row
               with its whole fare on the outbound leg, so grouping by Departure-Arrival would put
               the return money on the outbound route. Money is SUM(net x leg_share).
    tickets    tickets FLYING that route: a return ticket counts once on each direction, so a column
               of route tickets adds up to segments, never to the customer's ticket count.
    sector     decided by the whole ITINERARY: domestic = every airport on it is in Bangladesh.
               Gold's "sector" column reads only the row's first leg, so a ZYL-DAC-DOH through
               ticket looked domestic there (the "sector trap", ~10% of "domestic" net in 2026).
               Under 'international' the domestic feeder leg of such a ticket appears under its
               own route (ZYL-DAC), so the routes still add up to the sector's money.
    customers  OTA = reporting.ota.resolve_ota_ids (the analyst's OTA list OR the master's flag);
               agencies = dim_customer primary_channel AGENCY, minus GDS / test pseudo-accounts
               (judged per AGENCY: only when EVERY account's name is a pseudo name).
    merging    sibling ids (account migrations) fold through the audited merge map, so one agency
               ranks once with all its money, under its dominant (max-net) name.

THE LIKE-FOR-LIKE RULE
    Transaction detail starts 2025-05-01, and an uploaded export may hold only recent weeks. A
    BEFORE window with no data at all is REFUSED with a sentence; one that is only partly covered,
    an AFTER window that runs past the data, or two windows of different lengths are BUILT but
    printed in amber at the top of the summary, because each makes the change column misleading.

RUNS EVERYWHERE: reads curated/sales + dim_customer (both in the exe's Data Kit), never gold.

Public entry points: ``parse_params(params) -> Settings`` and ``generate(params, cfg) -> Path``.
"""
from __future__ import annotations

import calendar
import datetime as dt
import re
from dataclasses import dataclass, replace
from pathlib import Path

import duckdb
import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill

from ..common import NET_CASE_SQL, build_rate_sql
from ..config import Config, load_config
from ..itinerary import itinerary_domestic_sql, route_legs_sql
from ..ota import _sibling_groups, resolve_ota_ids
# shared with the agency x route report rather than copied a fifth time
from .agency_route_monthly import DOM, NON_AGENCY_RE, _c, _save_locktolerant

# ------------------------------------------------------------------------------------- constants
SECTORS = ("domestic", "international", "all")
DEFAULT_TOP = 10
MAX_TOP = 100
DEFAULT_MONTHS = 4                      # the zero-argument AFTER window: last 4 complete months
MAX_WINDOW_DAYS = 1100                  # ~36 months; longer is almost certainly a typo
ROUTE_RE = re.compile(r"^[A-Z]{3}-[A-Z]{3}$")
ID_RE = re.compile(r"^\d{3,12}$")       # Zenith customer ids are 8 digits; this only has to reject names

NAVY, BLUE, WHITE, AMBER, GREENL = "1F3864", "2E5E9E", "FFFFFF", "FFF2CC", "C6EFCE"
BLUEL, GREYT, RED_T, GREEN_T = "DDEBF7", "808080", "9C0006", "006100"
FL, FI, FP = "#,##0.00", "#,##0", "+0.0%;-0.0%;0.0%"
LAC = 1e5


# ------------------------------------------------------------------------------------- settings
@dataclass(frozen=True)
class Window:
    """An inclusive date range with a human label."""
    lo: dt.date
    hi: dt.date

    @property
    def days(self) -> int:
        return (self.hi - self.lo).days + 1

    @property
    def label(self) -> str:
        """'May-Aug 2026' for whole months, '1 May-15 Jun 2026' otherwise."""
        whole = self.lo.day == 1 and self.hi.day == calendar.monthrange(self.hi.year, self.hi.month)[1]
        if whole:
            if (self.lo.year, self.lo.month) == (self.hi.year, self.hi.month):
                return f"{self.hi:%b %Y}"
            if self.lo.year == self.hi.year:
                return f"{self.lo:%b}-{self.hi:%b %Y}"
            return f"{self.lo:%b %Y}-{self.hi:%b %Y}"
        if self.lo.year == self.hi.year:
            return f"{self.lo.day} {self.lo:%b}-{self.hi.day} {self.hi:%b %Y}"
        return f"{self.lo.day} {self.lo:%b %Y}-{self.hi.day} {self.hi:%b %Y}"


@dataclass(frozen=True)
class Settings:
    """Validated parameters. before/after are None until resolved against the data."""
    sector: str = "domestic"
    routes: tuple[str, ...] = ()
    customers: str = "otas"              # 'otas' | 'agencies' | 'ids'
    customer_ids: tuple[str, ...] = ()
    top: int = DEFAULT_TOP
    after: Window | None = None
    before: Window | None = None


def _month_end(y: int, m: int) -> dt.date:
    return dt.date(y, m, calendar.monthrange(y, m)[1])


def _parse_day(v, *, end: bool, what: str) -> dt.date | None:
    """'YYYY-MM' -> first (or last) day of that month; 'YYYY-MM-DD' -> that day; blank -> None."""
    if v is None or (isinstance(v, str) and not v.strip()):
        return None
    if isinstance(v, dt.datetime):
        return v.date()
    if isinstance(v, dt.date):
        return v
    s = str(v).strip()
    m = re.fullmatch(r"(\d{4})-(\d{1,2})", s)
    if m:
        y, mo = int(m.group(1)), int(m.group(2))
        if not 1 <= mo <= 12:
            raise ValueError(f"{what}: {s!r} is not a real month (use YYYY-MM, e.g. 2026-05).")
        return _month_end(y, mo) if end else dt.date(y, mo, 1)
    try:
        return dt.date.fromisoformat(s)
    except ValueError:
        raise ValueError(f"{what}: {s!r} is not a month (YYYY-MM) or a date (YYYY-MM-DD).") from None


def _window(lo_v, hi_v, name: str) -> Window | None:
    """Both ends or neither; never backwards; never absurdly long."""
    lo = _parse_day(lo_v, end=False, what=f"{name} from")
    hi = _parse_day(hi_v, end=True, what=f"{name} to")
    if lo is None and hi is None:
        return None
    if lo is None or hi is None:
        raise ValueError(f"The {name} window needs both a from and a to (or leave both blank).")
    if lo > hi:
        raise ValueError(f"The {name} window runs backwards: {lo} is after {hi}.")
    if (hi - lo).days + 1 > MAX_WINDOW_DAYS:
        raise ValueError(f"The {name} window is {(hi - lo).days + 1} days; the limit is about 36 months.")
    return Window(lo, hi)


def year_earlier(w: Window) -> Window:
    """The same dates one year earlier. A window ending on a month's last day keeps ending on one
    (Feb 2025 is 28 days, Feb 2024 is 29), and 29 February becomes 28 February."""
    def back(d: dt.date) -> dt.date:
        return d.replace(year=d.year - 1, day=min(d.day, calendar.monthrange(d.year - 1, d.month)[1]))
    hi = w.hi
    hi_back = (_month_end(hi.year - 1, hi.month)
               if hi.day == calendar.monthrange(hi.year, hi.month)[1] else back(hi))
    return Window(back(w.lo), hi_back)


def _parse_customers(v) -> tuple[str, tuple[str, ...]]:
    """'otas' / 'agencies' / a list of ids. Labels from the app's drop-down are accepted too."""
    s = str(v or "otas").strip()
    low = s.lower()
    if low in ("otas", "ota", "otas only"):
        return "otas", ()
    if low in ("agencies", "agency", "all agencies"):
        return "agencies", ()
    ids = tuple(dict.fromkeys(t for t in re.split(r"[,;\s]+", s) if t))
    bad = [t for t in ids if not ID_RE.fullmatch(t.removesuffix(".0"))]
    if not ids or bad:
        raise ValueError(f"Customers must be OTAs, All agencies, or Zenith customer ids; "
                         f"not understood: {', '.join(bad or [s])}.")
    return "ids", tuple(t.removesuffix(".0") for t in ids)


def _parse_routes(v) -> tuple[str, ...]:
    """'DAC-CXB, cxb-dac' -> ('DAC-CXB', 'CXB-DAC'). Directional, upper-cased, de-duplicated."""
    if v is None:
        return ()
    items = v if isinstance(v, (list, tuple)) else re.split(r"[,;\s]+", str(v))
    routes = tuple(dict.fromkeys(str(t).strip().upper() for t in items if str(t).strip()))
    for r in routes:
        if not ROUTE_RE.fullmatch(r) or r[:3] == r[4:]:
            raise ValueError(f"Route {r!r} is not a directional airport pair like DAC-CXB.")
    return routes


def parse_params(params: dict | None) -> Settings:
    """Validate everything the user typed, before any data is read. Raises ValueError with a
    sentence a colleague can act on; the app shows it in a dialog."""
    p = params or {}
    sector = str(p.get("sector") or "domestic").strip().lower()
    if sector not in SECTORS:
        raise ValueError(f"Sector must be one of {', '.join(SECTORS)}; got {sector!r}.")
    raw_top = p.get("top")
    try:
        # blank means the default; 0 does NOT (it is a typo to refuse, not a silent 10)
        top = DEFAULT_TOP if raw_top is None or str(raw_top).strip() == "" else int(str(raw_top).strip())
    except (TypeError, ValueError):
        raise ValueError(f"Top must be a whole number; got {p.get('top')!r}.") from None
    if not 1 <= top <= MAX_TOP:
        raise ValueError(f"Top must be between 1 and {MAX_TOP}; got {top}.")
    customers, ids = _parse_customers(p.get("customers"))
    after = _window(p.get("after_from"), p.get("after_to"), "after")
    before = _window(p.get("before_from"), p.get("before_to"), "before")
    if before is not None and after is None:
        raise ValueError("A before window was given without an after window; give both, or only the after.")
    if after is not None and before is None:
        before = year_earlier(after)
    if after is not None and before.hi >= after.lo:
        raise ValueError(f"The before window ({before.lo} to {before.hi}) must end before the after "
                         f"window starts ({after.lo}).")
    return Settings(sector=sector, routes=_parse_routes(p.get("routes")), customers=customers,
                    customer_ids=ids, top=top, after=after, before=before)


# ------------------------------------------------------------------------------------- windows
def default_after(max_day: dt.date, months: int = DEFAULT_MONTHS) -> Window:
    """The last `months` COMPLETE months up to the data's last day (a part month would read as a fall)."""
    y, m = max_day.year, max_day.month
    if max_day.day < calendar.monthrange(y, m)[1]:
        y, m = (y, m - 1) if m > 1 else (y - 1, 12)
    hi = _month_end(y, m)
    for _ in range(months - 1):
        y, m = (y, m - 1) if m > 1 else (y - 1, 12)
    return Window(dt.date(y, m, 1), hi)


def coverage_notes(s: Settings, data_lo: dt.date, data_hi: dt.date) -> list[str]:
    """Refuse a BEFORE window the data cannot see at all; return amber notes for the rest."""
    b, a = s.before, s.after
    if b.hi < data_lo or b.lo > data_hi:
        raise ValueError(f"The data covers {data_lo} to {data_hi}, so the before window ({b.label}) "
                         f"has no sales in it. Load exports that cover it, or choose a before window "
                         f"inside the data.")
    if a.lo > data_hi:
        raise ValueError(f"The data ends {data_hi}, so the after window ({a.label}) has no sales in it.")
    notes = []
    if b.lo < data_lo:
        notes.append(f"The data starts {data_lo}, so the first {(data_lo - b.lo).days} day(s) of the "
                     f"before window have no sales: its figures are LOW and every change reads high.")
    if a.hi > data_hi:
        notes.append(f"The data ends {data_hi}, so the last {(a.hi - data_hi).days} day(s) of the after "
                     f"window are not in yet: its figures are LOW and every change reads low.")
    if a.days != b.days:
        notes.append(f"The windows differ in length (after {a.days} days, before {b.days} days), so the "
                     f"change compares unequal periods.")
    return notes


# ------------------------------------------------------------------------------------- data
def _paths(cfg: Config) -> tuple[str, str]:
    sales = (cfg.data_root / "curated" / "sales" / "**" / "*.parquet").as_posix()
    dimf = cfg.data_root / "curated" / "dim_customer" / "dim_customer.parquet"
    if not dimf.is_file():
        raise FileNotFoundError("dim_customer.parquet missing: install or refresh the Data Kit.")
    return f"read_parquet('{sales}', hive_partitioning=1, union_by_name=1)", dimf.as_posix()


def data_span(con, src: str) -> tuple[dt.date, dt.date]:
    lo, hi = con.sql(f'SELECT MIN(CAST("Date" AS DATE)), MAX(CAST("Date" AS DATE)) '
                     f'FROM {src} WHERE "year" > 0').fetchone()
    if lo is None:
        raise ValueError("There are no sales in the data; load at least one sales export.")
    return lo, hi


def _itinerary_domestic_sql() -> str:
    """The shared rule (reporting.itinerary.itinerary_domestic_sql): domestic = no airport on the
    row, in its itinerary or its own Departure / Arrival, is outside Bangladesh."""
    return itinerary_domestic_sql("dep", "arr", "rtg", DOM)


def fetch(con, src: str, rate_sql: str, s: Settings) -> tuple[pd.DataFrame, pd.DataFrame]:
    """(rows, unplaced). rows: one per (window, customer id, route) with net / tickets / segments,
    already split per itinerary leg and cut to the sector and routes. unplaced: net per (window,
    customer id) that no route can be read from (no airports, or a leg starting where it ends)."""
    a, b = s.after, s.before
    # Airports: the row's own, else the itinerary's first leg. 11,733 ticket rows in May-Aug 2025
    # (1.4%; ~300 a month by 2026) carry a readable "Routing information" but no Departure /
    # Arrival airport, in gold as well as curated; reading only the row's airports dropped them.
    parses = "regexp_full_match(rtg, '[A-Z]{3}(-[A-Z]{3})+')"
    base = f"""(
        SELECT *, {_itinerary_domestic_sql()} AS itin_dom
        FROM (
        SELECT win, cid, cname, txn, tkt, bal, fare, rate, rtg,
               COALESCE(dep0, CASE WHEN {parses} THEN split_part(rtg, '-', 1) END) AS dep,
               COALESCE(arr0, CASE WHEN {parses} THEN split_part(rtg, '-', 2) END) AS arr
        FROM (
            SELECT CASE WHEN CAST("Date" AS DATE) BETWEEN DATE '{a.lo}' AND DATE '{a.hi}'
                        THEN 'after' ELSE 'before' END                       AS win,
                   regexp_replace(CAST("Customer ID" AS VARCHAR), '[.]0+$', '') AS cid,
                   CAST("Customer" AS VARCHAR)                               AS cname,
                   CAST("Transaction" AS VARCHAR)                            AS txn,
                   CAST("Ticket number" AS VARCHAR)                          AS tkt,
                   CAST("Balance (base currency)" AS DOUBLE)                 AS bal,
                   CAST("Total without taxe (base currency)" AS DOUBLE)      AS fare,
                   ({rate_sql})                                              AS rate,
                   NULLIF(TRIM(CAST("Departure airport" AS VARCHAR)), '')    AS dep0,
                   NULLIF(TRIM(CAST("Arrival airport" AS VARCHAR)), '')      AS arr0,
                   upper(TRIM(CAST("Routing information" AS VARCHAR)))       AS rtg
            FROM {src}
            WHERE "year" > 0
              AND (CAST("Date" AS DATE) BETWEEN DATE '{a.lo}' AND DATE '{a.hi}'
                   OR CAST("Date" AS DATE) BETWEEN DATE '{b.lo}' AND DATE '{b.hi}')
        ) _r
        ) _a
    )"""
    net = NET_CASE_SQL          # the DSR's net, on the columns it expects (txn, bal, fare, rate)
    con.execute(f"CREATE OR REPLACE TEMP TABLE rba_base AS SELECT * FROM {base}")
    sector_cut = {"domestic": "itin_dom", "international": "NOT itin_dom",
                  "all": "itin_dom IS NOT NULL"}[s.sector]
    route_cut = ("AND route IN (" + ", ".join(f"'{r}'" for r in s.routes) + ")") if s.routes else ""
    rows = con.execute(f"""
        SELECT win, cid, route, MAX(cname) AS cname,
               SUM(({net}) * leg_share)                                     AS net,
               COUNT(DISTINCT tkt) FILTER (WHERE txn = 'Ticket payment')    AS tickets,
               COUNT(*) FILTER (WHERE txn = 'Ticket payment')               AS segments
        FROM {route_legs_sql('(SELECT * FROM rba_base WHERE ' + sector_cut + ')')}
        -- a leg cannot start and end at the same airport: a round trip recorded with
        -- Departure = Arrival and an itinerary that does not parse. Counted as unplaced instead.
        WHERE split_part(route, '-', 1) <> split_part(route, '-', 2) {route_cut}
        GROUP BY win, cid, route
    """).df()
    unplaced = con.execute(f"""
        SELECT win, cid, MAX(cname) AS cname, SUM({net}) AS net
        FROM rba_base
        -- the same two cases the route query drops: no airports, or a leg that starts where it ends
        -- (a missing airport makes dep = arr NULL, which the COALESCE counts as unplaced)
        WHERE COALESCE(dep = arr, TRUE)
        GROUP BY win, cid
    """).df()
    return rows, unplaced


# ------------------------------------------------------------------------------------- customers
def _dim(dim_path: str) -> pd.DataFrame:
    """cid, dname, channel, ota_status. A column an older Data Kit lacks reads as blank rather than
    failing the build (resolve_ota_ids then simply relies on the analyst's OTA list)."""
    d = pd.read_parquet(dim_path)
    out = pd.DataFrame({"cid": d["customer_id"].astype(str).str.replace(r"\.0+$", "", regex=True)})
    for src, dst in (("customer_name", "dname"), ("primary_channel", "channel"), ("ota_status", "ota_status")):
        out[dst] = d[src].astype("string").fillna("") if src in d.columns else ""
    return out.drop_duplicates("cid")


def scope_ids(s: Settings, cfg: Config, dim: pd.DataFrame, groups: dict[str, str]) -> set[str]:
    """The customer ids in scope, siblings included (one agency is in or out as a whole)."""
    key_of = lambda c: groups.get(c, c)                                  # noqa: E731
    if s.customers == "ids":
        keys = {key_of(c) for c in s.customer_ids}
        return set(s.customer_ids) | {c for c, k in groups.items() if k in keys}
    if s.customers == "otas":
        con = duckdb.connect()
        con.register("dim_customer", dim.rename(columns={"cid": "customer_id"}))
        ids = resolve_ota_ids(cfg.data_root, con)
        con.close()
        return ids
    # all agencies: the AGENCY channel, minus GDS / test pseudo-pools judged per AGENCY - an agency
    # is a pseudo pool only when EVERY account's name is a pseudo name (CLAUDE.md, agency channel mix)
    ag = dim[dim.channel.str.upper().eq("AGENCY")].copy()
    ag["key"] = ag.cid.map(key_of)
    ag["pseudo"] = ag.dname.fillna("").str.lower().str.contains(NON_AGENCY_RE, regex=True)
    pseudo_keys = set(ag.groupby("key")["pseudo"].all().loc[lambda x: x].index)
    return set(ag.loc[~ag.key.isin(pseudo_keys), "cid"])


def fold(rows: pd.DataFrame, ids: set[str], groups: dict[str, str]) -> pd.DataFrame:
    """Keep the customers in scope, fold sibling ids onto one agency, and put the two windows side
    by side: key, route, name, ids, net/tickets/segments _after and _before."""
    cols = ["key", "route", "name", "ids"] + [f"{m}_{w}" for m in ("net", "tickets", "segments")
                                             for w in ("after", "before")]
    d = rows[rows.cid.isin(ids)].copy()
    if d.empty:
        return pd.DataFrame(columns=cols)
    d["key"] = d.cid.map(lambda c: groups.get(c, c))
    # dominant name: the name carrying the most net across both windows, so a stale spelling of a
    # migrated account cannot win; name is the tie-break so the result never depends on row order
    names = (d.groupby(["key", "cname"], as_index=False, dropna=False)["net"].sum()
               .sort_values(["net", "cname"], ascending=[False, True], kind="mergesort")
               .drop_duplicates("key").set_index("key")["cname"])
    members = d.groupby("key")["cid"].apply(lambda x: ", ".join(sorted(set(x))))
    g = d.groupby(["key", "route", "win"], as_index=False)[["net", "tickets", "segments"]].sum()
    wide = g.pivot_table(index=["key", "route"], columns="win", values=["net", "tickets", "segments"],
                         fill_value=0, aggfunc="sum")
    wide.columns = [f"{m}_{w}" for m, w in wide.columns]
    wide = wide.reset_index()
    for c in cols[4:]:
        if c not in wide:
            wide[c] = 0.0
    wide["name"] = wide.key.map(names).fillna("")
    wide["ids"] = wide.key.map(members)
    return wide[cols]


# ------------------------------------------------------------------------------------- sheet kit
def _cell(ws, r, c, v, *, wrap=False, align="center", **kw):
    x = _c(ws, r, c, v, align=align, **kw)
    if wrap:
        x.alignment = Alignment(horizontal=align, vertical="center", wrap_text=True)
    return x


def _band(ws, r, c1, c2, text, *, fill=NAVY, color=WHITE, size=10, bold=True, height=None):
    ws.merge_cells(start_row=r, start_column=c1, end_row=r, end_column=c2)
    x = ws.cell(r, c1, text)
    x.font = Font(bold=bold, size=size, color=color, name="Calibri")
    x.alignment = Alignment(horizontal="left", vertical="center", wrap_text=True)
    if fill:
        x.fill = PatternFill("solid", fgColor=fill)
    if height:
        ws.row_dimensions[r].height = height


def _widths(ws, widths: dict[str, float]) -> None:
    for col, w in widths.items():
        ws.column_dimensions[col].width = w


def _change(cur: float, pri: float) -> float | None:
    """Growth, or None when there is no positive base (a % there is infinity dressed as growth)."""
    return (cur / pri - 1) if pri > 0 else None


@dataclass(frozen=True)
class Labels:
    after: str
    before: str
    noun: str           # 'OTA' / 'Agency' / 'Customer'
    nouns: str          # 'OTAs' / 'agencies' / 'customers'
    scope: str          # 'DOMESTIC' / 'INTERNATIONAL' / 'ALL' (+ the named routes)


def labels_for(s: Settings) -> Labels:
    noun, nouns = {"otas": ("OTA", "OTAs"), "agencies": ("Agency", "agencies"),
                   "ids": ("Customer", "customers")}[s.customers]
    scope = s.sector.upper() + (f" ({', '.join(s.routes)})" if s.routes else "")
    return Labels(s.after.label, s.before.label, noun, nouns, scope)


def _ordered_routes(wide: pd.DataFrame) -> list[str]:
    """Routes biggest-first by AFTER net (name as tie-break), so the busy routes lead the sheet."""
    t = wide.groupby("route", as_index=False)["net_after"].sum()
    return list(t.sort_values(["net_after", "route"], ascending=[False, True], kind="mergesort").route)


# ------------------------------------------------------------------------------------- sheets
def write_route_sheet(ws, wide: pd.DataFrame, top: int, L: Labels) -> None:
    """One block per route: the top N of the AFTER window, the BEFORE window on the same row."""
    ws.sheet_view.showGridLines = False
    _widths(ws, {"A": 5, "B": 34, "C": 15, "D": 12, "E": 10, "F": 10, "G": 12, "H": 10, "I": 10,
                 "J": 11, "K": 10})
    _band(ws, 1, 1, 11, f"TOP {top} {L.nouns.upper()} ON EVERY ROUTE  -  {L.scope}  -  {L.after} vs {L.before}",
          size=12)
    _band(ws, 2, 1, 11, "Ranked by the after window's net on that route. Net after refunds and voids, in LAC, "
                        "shared across the itinerary's legs (a return ticket puts half on each direction). "
                        "Tickets are tickets flying that route, so they add up to segments.",
          fill=BLUEL, color=NAVY, size=9, bold=False, height=28)
    r = 4
    for route in _ordered_routes(wide):
        sub = wide[wide.route == route]
        blk = sub.sort_values(["net_after", "name"], ascending=[False, True], kind="mergesort").head(top)
        tot_a, tot_b = sub.net_after.sum(), sub.net_before.sum()
        chg = _change(tot_a, tot_b)
        _band(ws, r, 1, 11, f"{route}      all {L.nouns}: {tot_a/LAC:,.2f} lac  vs  {tot_b/LAC:,.2f} lac"
                            + (f"   ({chg*100:+.1f}%)" if chg is not None else "   (no sales before)"),
              fill=BLUE, size=10)
        r += 1
        heads = ["#", L.noun, "Zenith ID", f"{L.after}\nNet (lac)", "Tickets", "Net/tkt",
                 f"{L.before}\nNet (lac)", "Tickets", "Net/tkt", "Net\nchange", "Share of\nroute"]
        for j, h in enumerate(heads, 1):
            _cell(ws, r, j, h, bold=True, color=NAVY, fill=BLUEL, wrap=True)
        ws.row_dimensions[r].height = 26
        r += 1
        for i, x in enumerate(blk.itertuples(), 1):
            _route_row(ws, r, i, x, tot_a)
            r += 1
        r += 1                                                  # a blank row between routes


def _route_row(ws, r: int, i: int, x, route_total: float) -> None:
    chg = _change(x.net_after, x.net_before)
    _cell(ws, r, 1, i)
    _cell(ws, r, 2, str(x.name)[:42], align="left", color=NAVY)
    _cell(ws, r, 3, str(x.ids), color=GREYT)
    _cell(ws, r, 4, x.net_after / LAC, fmt=FL, bold=True)
    _cell(ws, r, 5, int(x.tickets_after), fmt=FI)
    _cell(ws, r, 6, (x.net_after / x.tickets_after) if x.tickets_after else 0, fmt=FI)
    _cell(ws, r, 7, x.net_before / LAC, fmt=FL)
    _cell(ws, r, 8, int(x.tickets_before), fmt=FI)
    _cell(ws, r, 9, (x.net_before / x.tickets_before) if x.tickets_before else 0, fmt=FI)
    if chg is None:
        _cell(ws, r, 10, "NEW", color=GREEN_T, fill=GREENL)
    else:
        _cell(ws, r, 10, chg, fmt=FP, color=GREEN_T if chg >= 0 else RED_T, fill=GREENL if chg >= 0 else None)
    _cell(ws, r, 11, (x.net_after / route_total) if route_total else 0, fmt="0.0%")


def _ranks(sub: pd.DataFrame, col: str) -> dict:
    """{key: 1-based rank} for one window, biggest first, name as a stable tie-break (otherwise two
    sellers on the same net could swap places between runs and report a move that never happened)."""
    ranked = sub[sub[col] > 0].sort_values([col, "name"], ascending=[False, True], kind="mergesort")
    return {k: i for i, k in enumerate(ranked.key, start=1)}


def write_rank_sheet(ws, wide: pd.DataFrame, top: int, L: Labels) -> None:
    """BEFORE's top N on the left, AFTER's on the right, per route: answers "who used to lead",
    which no single ranked list shows (a former #2 now outside the top N appears with OUT)."""
    ws.sheet_view.showGridLines = False
    _widths(ws, {"A": 5, "B": 30, "C": 11, "D": 9, "E": 9, "F": 3, "G": 5, "H": 30, "I": 11, "J": 9,
                 "K": 9, "L": 9})
    _band(ws, 1, 1, 12, f"TOP {top} {L.nouns.upper()} PER ROUTE  -  {L.scope}  -  {L.before} (before) vs "
                        f"{L.after} (after)", size=12)
    _band(ws, 2, 1, 12, f"Each side is its own ranking of that route. 'Now' and 'Then' give the same seller's "
                        f"place in the other window: OUT = still selling but outside the top {top}, GONE = no "
                        f"sales, NEW = none before. Move = places gained (+) or lost (-). Net in lac.",
          fill=BLUEL, color=NAVY, size=9, bold=False, height=28)
    r = 4
    for route in _ordered_routes(wide):
        sub = wide[wide.route == route]
        now, then = _ranks(sub, "net_after"), _ranks(sub, "net_before")
        by_key = sub.set_index("key")
        _band(ws, r, 1, 5, f"{route}   {L.before}", fill=BLUE)
        _band(ws, r, 7, 12, f"{route}   {L.after}", fill=BLUE)
        r += 1
        for j, h in ((1, "#"), (2, L.noun), (3, "Net (lac)"), (4, "Tickets"), (5, "Now"),
                     (7, "#"), (8, L.noun), (9, "Net (lac)"), (10, "Tickets"), (11, "Then"), (12, "Move")):
            _cell(ws, r, j, h, bold=True, color=NAVY, fill=BLUEL)
        r += 1
        then_top = sorted(then.items(), key=lambda kv: kv[1])[:top]
        now_top = sorted(now.items(), key=lambda kv: kv[1])[:top]
        for i in range(max(len(then_top), len(now_top))):
            if i < len(then_top):
                _then_cells(ws, r, then_top[i], by_key, now, top)
            if i < len(now_top):
                _now_cells(ws, r, now_top[i], by_key, then)
            r += 1
        r += 1


def _then_cells(ws, r, item, by_key, now: dict, top: int) -> None:
    key, pos = item
    x, here = by_key.loc[key], now.get(key)
    inside = bool(here and here <= top)
    _cell(ws, r, 1, pos)
    _cell(ws, r, 2, str(x["name"])[:38], align="left", color=NAVY)
    _cell(ws, r, 3, x.net_before / LAC, fmt=FL)
    _cell(ws, r, 4, int(x.tickets_before), fmt=FI)
    _cell(ws, r, 5, f"#{here}" if inside else ("OUT" if here else "GONE"),
          color=GREEN_T if inside else RED_T, fill=None if inside else AMBER)


def _now_cells(ws, r, item, by_key, then: dict) -> None:
    key, pos = item
    x, was = by_key.loc[key], then.get(key)
    move = (was - pos) if was else None                         # positive = climbed the table
    _cell(ws, r, 7, pos)
    _cell(ws, r, 8, str(x["name"])[:38], align="left", color=NAVY)
    _cell(ws, r, 9, x.net_after / LAC, fmt=FL, bold=True)
    _cell(ws, r, 10, int(x.tickets_after), fmt=FI)
    _cell(ws, r, 11, f"#{was}" if was else "NEW", color=GREEN_T if was is None else "000000",
          fill=GREENL if was is None else None)
    up = move is None or move > 0
    _cell(ws, r, 12, "NEW" if move is None else (f"+{move}" if move > 0 else str(move)), bold=True,
          color=GREEN_T if up else (RED_T if move < 0 else GREYT),
          fill=GREENL if up else (AMBER if move < 0 else None))


def write_summary_sheet(ws, wide: pd.DataFrame, s: Settings, L: Labels, info: dict) -> None:
    """Route totals across every seller in scope, the warnings, and how to read the workbook."""
    ws.sheet_view.showGridLines = False
    _widths(ws, {"A": 14, "B": 14, "C": 11, "D": 11, "E": 12, "F": 14, "G": 11, "H": 11, "I": 11})
    _band(ws, 1, 1, 9, f"{L.scope} ROUTES - ALL {L.nouns.upper()} IN SCOPE  -  {L.after} vs {L.before}", size=12)
    r = 2
    for note in info["warnings"]:                     # what makes the change column misleading
        _band(ws, r, 1, 9, "CHECK: " + note, fill=AMBER, color=RED_T, size=9, height=30)
        r += 1
    r += 1
    heads = ["Route", f"{L.after}\nNet (lac)", "Tickets", "Net/tkt", f"{L.nouns}\nselling",
             f"{L.before}\nNet (lac)", "Tickets", "Net/tkt", "Net\nchange"]
    for j, h in enumerate(heads, 1):
        _cell(ws, r, j, h, bold=True, color=NAVY, fill=BLUEL, wrap=True)
    ws.row_dimensions[r].height = 26
    r += 1
    g = (wide.groupby("route", as_index=False)
             .agg(net_after=("net_after", "sum"), tickets_after=("tickets_after", "sum"),
                  net_before=("net_before", "sum"), tickets_before=("tickets_before", "sum"),
                  sellers=("net_after", lambda x: int((x > 0).sum())))
             .sort_values(["net_after", "route"], ascending=[False, True], kind="mergesort"))
    for x in g.itertuples():
        _summary_row(ws, r, x.route, x.net_after, x.tickets_after, x.sellers, x.net_before, x.tickets_before)
        r += 1
    _summary_row(ws, r, "TOTAL", g.net_after.sum(), g.tickets_after.sum(), None, g.net_before.sum(),
                 g.tickets_before.sum(), total=True)
    _notes(ws, r + 2, s, L, info)


def _summary_row(ws, r, route, na, ta, sellers, nb, tb, *, total=False) -> None:
    kw = {"bold": True, "color": WHITE, "fill": NAVY} if total else {}
    chg = _change(na, nb)
    _cell(ws, r, 1, route, align="left", **(kw or {"color": NAVY, "bold": True}))
    _cell(ws, r, 2, na / LAC, fmt=FL, **(kw or {"bold": True}))
    _cell(ws, r, 3, int(ta), fmt=FI, **kw)
    _cell(ws, r, 4, (na / ta) if ta else 0, fmt=FI, **kw)
    _cell(ws, r, 5, "" if sellers is None else int(sellers), fmt=FI, **kw)
    _cell(ws, r, 6, nb / LAC, fmt=FL, **kw)
    _cell(ws, r, 7, int(tb), fmt=FI, **kw)
    _cell(ws, r, 8, (nb / tb) if tb else 0, fmt=FI, **kw)
    _cell(ws, r, 9, "NEW" if chg is None else chg, fmt=None if chg is None else FP,
          **(kw or {"color": GREEN_T if (chg is None or chg >= 0) else RED_T}))


def _notes(ws, r: int, s: Settings, L: Labels, info: dict) -> None:
    sector_rule = {
        "domestic": "Itineraries whose every airport is in Bangladesh. The domestic leg of an international "
                    "ticket (ZYL-DAC of ZYL-DAC-DOH) is NOT here: its money is part of an international fare.",
        "international": "Itineraries touching any airport outside Bangladesh. A domestic feeder leg of such a "
                         "ticket (ZYL-DAC of ZYL-DAC-DOH) shows under its own route, so the routes add up.",
        "all": "Every itinerary, domestic and international."}[s.sector]
    who = {"otas": f"{info['scope_ids']:,} customer ids from the analyst's OTA list or the master's OTA flag, "
                   "siblings included.",
           "agencies": f"{info['scope_ids']:,} agency-channel customer ids (GDS and test pseudo-pools left out).",
           "ids": f"The ids asked for, plus their sibling accounts: {info['scope_ids']:,} ids."}[s.customers]
    notes = [
        ("Windows", f"After {s.after.lo} to {s.after.hi} ({s.after.days} days); before {s.before.lo} to "
                    f"{s.before.hi} ({s.before.days} days). The data covers {info['data_lo']} to {info['data_hi']}."),
        ("Net", "After refunds and voids: fare x (1 - commission) + tax on sales and reissues, balance on refunds, "
                "voids and penalties, zero on commission and discount rows. The DSR's own basis."),
        ("Route money", "Shared across the itinerary's legs, so a return ticket puts half its fare on each "
                        "direction. Route totals still add up to the sector's total."),
        ("Tickets", "Tickets flying that route: a return ticket counts on both directions, so a column of "
                    "route tickets adds up to segments, not to a seller's ticket count."),
        ("Sector", sector_rule),
        ("Who is counted", who + " Multi-ID agencies are merged, so one agency ranks once with all its money."),
        ("Not on a route", f"{info['unplaced_after']/LAC:,.2f} lac (after) and {info['unplaced_before']/LAC:,.2f} "
                           f"lac (before) of these {L.nouns}' net has no usable route on the row (mostly refunds "
                           f"with no airports, across all sectors), so it is in no route above."),
    ]
    _band(ws, r, 1, 9, "HOW TO READ THIS", size=10)
    r += 1
    for head, text in notes:
        _cell(ws, r, 1, head, bold=True, color=NAVY, align="left")
        _band(ws, r, 2, 9, text, fill=None, color="000000", size=9, bold=False, height=30)
        r += 1


# ------------------------------------------------------------------------------------- main
def build(cfg: Config, s: Settings, progress=print) -> tuple[pd.DataFrame, Settings, dict]:
    """Resolve the windows against the data, fetch, scope and fold. Returns (wide, settings, info)."""
    src, dim_path = _paths(cfg)
    con = duckdb.connect()
    try:
        data_lo, data_hi = data_span(con, src)
        if s.after is None:
            after = default_after(data_hi)
            s = replace(s, after=after, before=year_earlier(after))
        warnings = coverage_notes(s, data_lo, data_hi)
        rows, unplaced = fetch(con, src, build_rate_sql(cfg), s)
    finally:
        con.close()
    groups = _sibling_groups(cfg.data_root)
    ids = scope_ids(s, cfg, _dim(dim_path), groups)
    if not ids:
        raise ValueError(f"No customers matched the {s.customers} scope: check the OTA list / the Data Kit.")
    wide = fold(rows, ids, groups)
    up = unplaced[unplaced.cid.isin(ids)].groupby("win")["net"].sum()
    info = {"warnings": warnings, "data_lo": data_lo, "data_hi": data_hi, "scope_ids": len(ids),
            "unplaced_after": float(up.get("after", 0.0)), "unplaced_before": float(up.get("before", 0.0))}
    for w in warnings:
        progress(f"  NOTE: {w}")
    progress(f"  {wide.key.nunique():,} {labels_for(s).nouns} on {wide.route.nunique():,} routes; "
             f"{s.after.label} {wide.net_after.sum()/LAC:,.2f} lac vs {s.before.label} "
             f"{wide.net_before.sum()/LAC:,.2f} lac")
    return wide, s, info


def generate(params: dict | None = None, cfg: Config | None = None) -> Path:
    s = parse_params(params)
    cfg = cfg or load_config(validate=True)
    wide, s, info = build(cfg, s)
    if wide.empty:
        raise ValueError("Nothing to report: no sales by these customers on these routes in either window.")
    L = labels_for(s)
    wb = Workbook()
    wb.active.title = "Routes summary"
    write_summary_sheet(wb.active, wide, s, L, info)
    write_rank_sheet(wb.create_sheet(f"Top {s.top} then vs now"), wide, s.top, L)
    write_route_sheet(wb.create_sheet(f"Top {s.top} by route"), wide, s.top, L)
    out_dir = Path((params or {}).get("out_dir") or cfg.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    tag = "_".join(s.routes) if s.routes else s.sector.capitalize()
    name = f"Route_BeforeAfter_{tag}_{L.nouns.capitalize()}_{L.after}_vs_{L.before}.xlsx"
    return _save_locktolerant(wb, out_dir / re.sub(r"[^A-Za-z0-9_.-]+", "", name.replace(" ", "")))


if __name__ == "__main__":                       # quick manual run: defaults, analyst data root
    print(generate())
