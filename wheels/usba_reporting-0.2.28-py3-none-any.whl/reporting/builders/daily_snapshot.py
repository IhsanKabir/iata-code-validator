"""
reporting.builders.daily_snapshot — the one-page "Daily Report".

WHAT IT PRODUCES
----------------
A single-sheet workbook the team can glance at every morning, in BOTH money bases
side-by-side (figures in BDT crore, 2 decimals):

                    |   GROSS (Ticket Payment)   |   NET (after commission)
    Sales           | Domestic | Intl | Total    | Domestic | Intl | Total
    Yesterday Total |  ...                         (ALL channels)
    Yesterday excl. Counter/Web/App                (agency-only view)
    Countries (top 8 by yesterday net, excl. Counter/Web/Mobile)
      1..8 + Others |  ...
    Counter         |  ...
    Web             |  ...
    Mobile          |  ...
    Month Till Date |  ...                         (ALL channels)
    MTD excl. Counter/Web/App                      (agency-only view)

    Top 5 OTA per COUNTRY (ranked by MTD net within each country): yesterday +
    MTD sales each, gross & net — countries ordered by their OTA MTD net.
    Movers: agencies ±20% vs LAST MONTH over the same day-count, with details.

"Direct channels" = Counter + Web + Mobile app; the excl. totals strip them so the
agency-driven number is visible at a glance (same convention as the June target's
excl-direct totals). Countries + Others + Counter + Web + Mobile = Yesterday Total.

MONEY DEFINITIONS (identical to the DSR / June-target engines — do NOT drift):
    GROSS = full balance of 'Ticket payment' rows only (topline, before commission).
    NET   = balance − commission:
              Ticket payment / Reissuance Adjustment -> fare*(1-rate) + (bal-fare)
              Refund / Ticket void / Cancel refund / Penalty -> bal  (negative nets out)
              everything else -> 0
    The commission rate is the time-versioned CASE from reference/commission_rates.xlsx
    via reporting.common.build_rate_sql(cfg).

SECTOR (same rule as june_target): a sale is 'Domestic' when BOTH airports are in the
domestic set, else 'International'.

"YESTERDAY" = the snapshot date: params["date"] if given, else the LATEST date present
in the warehouse (so a morning run after the nightly load shows the last loaded day,
and the label on the sheet always states which date that is — no silent staleness).
MTD = the 1st of that month through the snapshot date.

RUN (CLI):
    .venv/Scripts/python.exe scripts/_build_daily_snapshot.py            # latest data date
    .venv/Scripts/python.exe scripts/_build_daily_snapshot.py 2026-06-05 # explicit date
"""
from __future__ import annotations

from datetime import date, datetime, timedelta
from pathlib import Path

import duckdb
import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from ..common import build_rate_sql
from ..config import Config, load_config

# --- shared constants (match june_target / dsr exactly) ------------------------
DOM = "('DAC','CGP','CXB','ZYL','JSR','RJH','BZL','SPD')"   # domestic airport codes
TOP_COUNTRIES = 8
TOP_OTAS_PER_COUNTRY = 5      # the OTA block shows the top N per country (was: top 10 overall)
MOVER_PCT = 0.20              # movers section: ±20% vs last month, same day-count
MOVER_FLOOR = 1_000_000       # ≥ 10 lac net in either period — filters out noise jumps

# styling (same palette as the other builders)
NAVY = "1F3864"; BLUE_LIGHT = "D9E1F2"; GREY_L = "F2F2F2"; GREY_T = "7F7F7F"
WHITE = "FFFFFF"; BLACK = "000000"; GREEN_F = "E2EFDA"; RED_F = "FFC7CE"; AMBER_F = "FFEB9C"
THIN = Side(style="thin", color="BFBFBF"); BORDER = Border(THIN, THIN, THIN, THIN)
F_CR = "#,##0.00;[Red]-#,##0.00"    # CRORE, two decimals, negatives in red (analyst: whole report in Cr)


# ---------------------------------------------------------------------------
# pure helpers (unit-tested in tests/test_daily_snapshot.py)
# ---------------------------------------------------------------------------
def resolve_asof(param_date: str | None, max_data_date: date | None) -> date:
    """The snapshot date: explicit param wins; else the latest date in the data.

    Raises if neither is available (empty warehouse) — fail fast, never guess today.
    """
    if param_date:
        return date.fromisoformat(str(param_date))
    if max_data_date is None:
        raise ValueError("No sales data found and no 'date' param given.")
    return max_data_date


def split_top_countries(rows: list[tuple[str, float, float, float, float]],
                        top_n: int = TOP_COUNTRIES) -> tuple[list, tuple | None]:
    """Split country rows (already sorted by net total DESC) into the top-N list and
    an aggregated 'Others' remainder tuple (or None when nothing remains).

    Each row = (country, gross_dom, gross_int, net_dom, net_int).
    """
    top = list(rows[:top_n])
    rest = rows[top_n:]
    if not rest:
        return top, None
    others = ("Others",
              sum(r[1] for r in rest), sum(r[2] for r in rest),
              sum(r[3] for r in rest), sum(r[4] for r in rest))
    return top, others


# ---------------------------------------------------------------------------
# data gathering — one temp table, then small aggregations off it
# ---------------------------------------------------------------------------
def _build_snap_table(con: duckdb.DuckDBPyConnection, cfg: Config,
                      month_start: date, asof: date) -> None:
    """Materialize snap_sales: one row per sale row in [month_start, asof] with
    date, sector, gross, net, category and country — the same definitions as the
    DSR's dsr_sales_enriched, so every figure here ties to the DSR to the rupee.
    """
    rate_sql = build_rate_sql(cfg)
    con.sql(f"""
        CREATE OR REPLACE TEMPORARY TABLE snap_sales AS
        WITH s AS (
            SELECT
                "Date"::DATE                                          AS d,
                CAST("Transaction" AS VARCHAR)                        AS txn,
                CAST("Point of sales" AS VARCHAR)                     AS pos,
                CAST("Balance (base currency)" AS DOUBLE)             AS bal,
                CAST("Total without taxe (base currency)" AS DOUBLE)  AS fare,
                ({rate_sql})                                          AS rate,
                CASE WHEN CAST("Departure airport" AS VARCHAR) IN {DOM}
                      AND CAST("Arrival airport"  AS VARCHAR) IN {DOM}
                     THEN 'Domestic' ELSE 'International' END         AS sector,
                CASE WHEN CAST("Customer ID" AS VARCHAR) = 'BO-1 Central Reservation'
                     THEN '11246131'    -- POS-in-customer-id remap (same as DSR)
                     ELSE regexp_replace(CAST("Customer ID" AS VARCHAR), '[.]0$', '')
                END                                                   AS customer_id
            FROM read_parquet('{cfg.sales_glob}', hive_partitioning=1, union_by_name=1)
            WHERE "Date" IS NOT NULL
              AND "Date"::DATE BETWEEN DATE '{month_start.isoformat()}'
                                   AND DATE '{asof.isoformat()}'
        )
        SELECT
            s.d, s.sector, s.customer_id,
            -- GROSS: ticket-payment balance only (topline before commission)
            CASE WHEN s.txn = 'Ticket payment' THEN COALESCE(s.bal, 0) ELSE 0 END AS gross,
            -- NET: balance - commission — arm-for-arm IDENTICAL to the DSR's dsr_amount
            -- (Penalty kept as its OWN arm, like the DSR, so a future commission-rate
            -- change can never silently catch it in the wrong branch.)
            CASE WHEN s.txn IN ('Ticket payment', 'Reissuance Adjustment')
                     THEN COALESCE(s.fare, 0) * (1 - s.rate)
                          + (COALESCE(s.bal, 0) - COALESCE(s.fare, 0))
                 WHEN s.txn IN ('Refund', 'Ticket void', 'Cancel refund')
                     THEN COALESCE(s.bal, 0)
                 WHEN s.txn = 'Penalty'
                     THEN COALESCE(s.bal, 0)    -- penalty income flows through 100%
                 ELSE 0 END                                                       AS net,
            -- category: same precedence as the DSR's attach_customer_attrs
            CASE WHEN c.customer_name ILIKE 'CORP %'            THEN 'Corporate'
                 WHEN c.primary_channel = 'OFFICE'              THEN 'Counter'
                 WHEN c.primary_channel = 'CALL_CENTER'         THEN 'Counter'
                 WHEN c.agent_type = 'BSP'                      THEN 'BSP'
                 WHEN c.agent_type IN ('Non-IATA', 'Non BSP')   THEN 'Non-IATA'
                 WHEN c.primary_channel = 'AGENCY'
                      AND c.agent_type IS NULL                  THEN 'Non-IATA'
                 WHEN c.primary_channel = 'WEB'                 THEN 'Web'
                 WHEN c.primary_channel = 'MOBILE'              THEN 'Mobi App'
                 ELSE 'Others' END                                                AS category,
            -- country: geo_country, then POS-derived, then Bangladesh (same as DSR)
            COALESCE(
                c.geo_country,
                CASE WHEN substring(s.pos, 1, 3) IN ('DAC','CGP','CXB','ZYL','JSR','KHL','SPD','RJH','BZL')
                          THEN 'Bangladesh'
                     WHEN s.pos LIKE 'INT Doha%'         THEN 'Qatar'
                     WHEN s.pos LIKE 'INT Bangkok%'      THEN 'Thailand'
                     WHEN s.pos LIKE 'INT Kolkata%'      THEN 'India'
                     WHEN s.pos LIKE 'INT Chennai%'      THEN 'India'
                     WHEN s.pos LIKE 'INT Kuala Lumpur%' THEN 'Malaysia'
                     WHEN s.pos LIKE 'INT Singapore%'    THEN 'Singapore'
                     WHEN s.pos LIKE 'INT Muscat%'       THEN 'Oman'
                     WHEN s.pos LIKE 'INT Guangzhou%'    THEN 'China'
                     WHEN s.pos LIKE 'INT Dubai%'        THEN 'United Arab Emirates'
                     WHEN s.pos LIKE 'INT Sharjah%'      THEN 'United Arab Emirates'
                     WHEN s.pos LIKE 'INT Abu Dhabi%'    THEN 'United Arab Emirates'
                     WHEN s.pos LIKE 'INT Male%'         THEN 'Maldives'
                     WHEN s.pos LIKE 'INT Jeddah%'       THEN 'Saudi Arabia'
                     WHEN s.pos LIKE 'INT Riyadh%'       THEN 'Saudi Arabia'
                     WHEN s.pos = 'BO-1 Central Reservation' THEN 'Bangladesh'
                     WHEN s.pos = 'WEB'                  THEN 'Bangladesh'
                     WHEN s.pos = 'MOBIAPP'              THEN 'Bangladesh'
                     ELSE NULL END,
                'Bangladesh')                                                     AS country
        FROM s
        LEFT JOIN dim_customer c ON s.customer_id = c.customer_id
    """)


def _sector_totals(con: duckdb.DuckDBPyConnection, where: str) -> dict:
    """{'gross_dom', 'gross_int', 'net_dom', 'net_int'} for rows matching ``where``.

    SECURITY: ``where`` must be a TRUSTED fragment built inside this module
    (date.isoformat() / category literals) — never pass user input here. The token
    check below is a dev-time tripwire for that contract, NOT an injection defense —
    and it is a real ``raise`` (not ``assert``) so it survives ``python -O``.
    """
    if any(tok in where for tok in (";", "--", "/*")):
        raise ValueError(f"suspicious WHERE fragment (module contract broken): {where!r}")
    row = con.sql(f"""
        SELECT
            SUM(CASE WHEN sector='Domestic'      THEN gross ELSE 0 END),
            SUM(CASE WHEN sector='International' THEN gross ELSE 0 END),
            SUM(CASE WHEN sector='Domestic'      THEN net   ELSE 0 END),
            SUM(CASE WHEN sector='International' THEN net   ELSE 0 END)
        FROM snap_sales WHERE {where}
    """).fetchone()
    g_d, g_i, n_d, n_i = (v or 0.0 for v in row)
    return {"gross_dom": g_d, "gross_int": g_i, "net_dom": n_d, "net_int": n_i}


DIRECT_CATS = "('Counter', 'Web', 'Mobi App')"   # the direct channels stripped from "excl." totals


def _country_rows(con: duckdb.DuckDBPyConnection, asof: date) -> list[tuple]:
    """Yesterday's sales by country — agency/corporate business only (Counter, Web and
    Mobile are broken out as their own rows below the country block), sorted by net
    total DESC. Returns (country, gross_dom, gross_int, net_dom, net_int).
    """
    df = con.sql(f"""
        SELECT country,
               SUM(CASE WHEN sector='Domestic'      THEN gross ELSE 0 END) AS g_d,
               SUM(CASE WHEN sector='International' THEN gross ELSE 0 END) AS g_i,
               SUM(CASE WHEN sector='Domestic'      THEN net   ELSE 0 END) AS n_d,
               SUM(CASE WHEN sector='International' THEN net   ELSE 0 END) AS n_i
        FROM snap_sales
        WHERE d = DATE '{asof.isoformat()}' AND category NOT IN {DIRECT_CATS}
        GROUP BY country
        ORDER BY (n_d + n_i) DESC
    """).to_df()
    return [tuple(r) for r in df.itertuples(index=False)]


def _ota_rows(con: duckdb.DuckDBPyConnection, cfg: Config, asof: date) -> pd.DataFrame:
    """Top {TOP_OTAS_PER_COUNTRY} OTAs PER COUNTRY by MTD net: yesterday + MTD each.

    OTA membership = reference/ota_list.xlsx (same file the DSR's Top OTA sheet uses).
    Country = the OTA's own home country from dim_customer (geo first), so an OTA
    selling through several stations still appears once, under its own flag.
    Countries are ordered by their listed-OTA MTD net (biggest market first).
    """
    ota_file = cfg.reference / "ota_list.xlsx"
    if not ota_file.exists():
        # surface it to the operator too — the sheet shows a notice, but a silent
        # morning run shouldn't hide a missing reference file from the console.
        print(f"[WARN] OTA list not found: {ota_file} - OTA section will be empty.", flush=True)
        return pd.DataFrame()
    ota = pd.read_excel(ota_file)
    ota["customer_id"] = (ota["customer_id"].astype(str).str.strip()
                          .str.replace(r"\.0$", "", regex=True))
    con.register("ref_ota", ota[["customer_id"]])
    return con.sql(f"""
        WITH agg AS (
            SELECT COALESCE(NULLIF(TRIM(c.geo_country), ''),
                            NULLIF(TRIM(c.country), ''), '(Unknown)')       AS country,
                   COALESCE(c.customer_name, 'ID ' || s.customer_id)        AS ota,
                   SUM(CASE WHEN s.d = DATE '{asof.isoformat()}' THEN s.gross ELSE 0 END) AS y_gross,
                   SUM(CASE WHEN s.d = DATE '{asof.isoformat()}' THEN s.net   ELSE 0 END) AS y_net,
                   SUM(s.gross)                                             AS m_gross,
                   SUM(s.net)                                               AS m_net
            FROM snap_sales s
            JOIN ref_ota o USING (customer_id)
            LEFT JOIN dim_customer c ON s.customer_id = c.customer_id
            GROUP BY 1, 2
        )
        SELECT * FROM (
            SELECT agg.*,
                   ROW_NUMBER() OVER (PARTITION BY country ORDER BY m_net DESC) AS rk,
                   SUM(m_net)  OVER (PARTITION BY country)                      AS c_net
            FROM agg
        )
        WHERE rk <= {TOP_OTAS_PER_COUNTRY}
        ORDER BY c_net DESC, rk
    """).to_df()


def _zone_rows(con: duckdb.DuckDBPyConnection, asof: date) -> pd.DataFrame:
    """Net sale by ZONE (agency territories), day + MTD, ordered MTD-net desc.

    Zone comes from dim_customer (the salesperson territory, Zone-1..Zone-33);
    only AGENCY channel rows carry a zone. Shown as a side panel beside the
    Top-5-OTA-per-country block (analyst request 2026-06-14)."""
    return con.sql(f"""
        SELECT COALESCE(NULLIF(TRIM(c.zone), ''), '(Unmapped)')               AS zone,
               SUM(CASE WHEN s.d = DATE '{asof.isoformat()}' THEN s.net ELSE 0 END) AS y_net,
               SUM(s.net)                                                     AS m_net
        FROM snap_sales s
        LEFT JOIN dim_customer c ON s.customer_id = c.customer_id
        WHERE c.primary_channel = 'AGENCY'
        GROUP BY 1
        HAVING SUM(s.net) <> 0
        ORDER BY m_net DESC
    """).to_df()


def _mover_rows(con: duckdb.DuckDBPyConnection, cfg: Config,
                month_start: date, asof: date):
    """Agencies whose NET moved ±{MOVER_PCT:%} vs LAST MONTH over the SAME day-count.

    Comparison windows (analyst's choice 2026-06-12): month-to-date (1..asof.day)
    vs the previous month's days 1..asof.day — equal lengths, so the percentage is
    fair and tightens as the month progresses. Only real agencies
    (dim_customer.primary_channel = 'AGENCY'); NET uses the exact same transaction
    arms as snap_sales. Floor: ≥ MOVER_FLOOR net in EITHER period (noise filter);
    ALL qualifying rows are returned (no top-N cut — analyst's choice).

    Returns ``(gainers, decliners, prev_start, prev_end)``; frames carry
    customer_id, name, zone, sales_person, prev_net, cur_net, chg, pct
    (pct is None when the agency had no baseline — shown as NEW).
    """
    prev_month_end = month_start - timedelta(days=1)
    prev_start = prev_month_end.replace(day=1)
    # same NUMBER of days as the current MTD, capped at the month's real end
    prev_end = min(prev_start + timedelta(days=asof.day - 1), prev_month_end)
    rate_sql = build_rate_sql(cfg)
    df = con.sql(f"""
        WITH s AS (
            SELECT "Date"::DATE                                         AS d,
                   CAST("Transaction" AS VARCHAR)                       AS txn,
                   CAST("Balance (base currency)" AS DOUBLE)            AS bal,
                   CAST("Total without taxe (base currency)" AS DOUBLE) AS fare,
                   ({rate_sql})                                         AS rate,
                   CASE WHEN CAST("Customer ID" AS VARCHAR) = 'BO-1 Central Reservation'
                        THEN '11246131'
                        ELSE regexp_replace(CAST("Customer ID" AS VARCHAR), '[.]0$', '')
                   END                                                  AS customer_id
            FROM read_parquet('{cfg.sales_glob}', hive_partitioning=1, union_by_name=1)
            WHERE "Date" IS NOT NULL
              AND ("Date"::DATE BETWEEN DATE '{prev_start.isoformat()}' AND DATE '{prev_end.isoformat()}'
                OR "Date"::DATE BETWEEN DATE '{month_start.isoformat()}' AND DATE '{asof.isoformat()}')
        ), e AS (
            SELECT customer_id,
                   d >= DATE '{month_start.isoformat()}'                AS is_cur,
                   CASE WHEN txn IN ('Ticket payment', 'Reissuance Adjustment')
                            THEN COALESCE(fare, 0) * (1 - rate)
                                 + (COALESCE(bal, 0) - COALESCE(fare, 0))
                        WHEN txn IN ('Refund', 'Ticket void', 'Cancel refund')
                            THEN COALESCE(bal, 0)
                        WHEN txn = 'Penalty' THEN COALESCE(bal, 0)
                        ELSE 0 END                                      AS net
            FROM s
        )
        SELECT e.customer_id,
               COALESCE(c.customer_name, 'ID ' || e.customer_id)        AS name,
               COALESCE(c.zone, '')                                     AS zone,
               COALESCE(c.sales_person, '')                             AS sales_person,
               SUM(CASE WHEN NOT is_cur THEN net ELSE 0 END)            AS prev_net,
               SUM(CASE WHEN is_cur     THEN net ELSE 0 END)            AS cur_net
        FROM e
        LEFT JOIN dim_customer c ON e.customer_id = c.customer_id
        WHERE c.primary_channel = 'AGENCY'
        GROUP BY 1, 2, 3, 4
        HAVING GREATEST(SUM(CASE WHEN NOT is_cur THEN net ELSE 0 END),
                        SUM(CASE WHEN is_cur     THEN net ELSE 0 END)) >= {MOVER_FLOOR}
    """).to_df()

    df["chg"] = df["cur_net"] - df["prev_net"]
    # pct vs a real baseline only; an agency that appeared from ~nothing is "NEW"
    df["pct"] = [
        (chg / prev) if prev > 0 else None
        for chg, prev in zip(df["chg"], df["prev_net"])
    ]
    gainers = df[(df["pct"].isna() & (df["cur_net"] >= MOVER_FLOOR))
                 | (df["pct"].notna() & (df["pct"] >= MOVER_PCT))]
    gainers = gainers.sort_values("chg", ascending=False)
    decliners = df[df["pct"].notna() & (df["pct"] <= -MOVER_PCT)]
    decliners = decliners.sort_values("chg", ascending=True)
    return gainers, decliners, prev_start, prev_end


# ---------------------------------------------------------------------------
# Excel writer
# ---------------------------------------------------------------------------
def _cell(ws, r, c, v, *, fmt=None, bold=False, size=10, color=BLACK, fill=None,
          align="left", border=True):
    x = ws.cell(row=r, column=c, value=v)
    x.font = Font(bold=bold, size=size, color=color, name="Calibri")
    x.alignment = Alignment(horizontal=align, vertical="center")
    if fmt:
        x.number_format = fmt
    if fill:
        x.fill = PatternFill("solid", fgColor=fill)
    if border:
        x.border = BORDER
    return x


def _money_row(ws, r, label, t: dict, *, bold=False, fill=None, indent=False):
    """One snapshot row: label + GROSS dom/int/total + NET dom/int/total, in crore."""
    _cell(ws, r, 1, ("    " if indent else "") + label, bold=bold, fill=fill)
    for col, val in ((2, t["gross_dom"]), (3, t["gross_int"])):
        _cell(ws, r, col, val / CR, fmt=F_CR, align="right", bold=bold, fill=fill)
    _cell(ws, r, 4, (t["gross_dom"] + t["gross_int"]) / CR, fmt=F_CR, align="right",
          bold=bold, fill=fill)
    for col, val in ((6, t["net_dom"]), (7, t["net_int"])):
        _cell(ws, r, col, val / CR, fmt=F_CR, align="right", bold=bold, fill=fill)
    _cell(ws, r, 8, (t["net_dom"] + t["net_int"]) / CR, fmt=F_CR, align="right",
          bold=bold, fill=fill)


def _tup_to_dict(t: tuple) -> dict:
    return {"gross_dom": t[1], "gross_int": t[2], "net_dom": t[3], "net_int": t[4]}


CR = 1e7   # 1 crore = 100 lacs (headline figures shown in cr — easier to grasp)


def _headline(asof: date, yest: dict, mtd: dict, prev: dict | None, prev_day: date | None) -> str:
    """One plain-language sentence a non-technical reader gets in 3 seconds."""
    yg = (yest["gross_dom"] + yest["gross_int"]) / CR
    yn = (yest["net_dom"] + yest["net_int"]) / CR
    mg = (mtd["gross_dom"] + mtd["gross_int"]) / CR
    mn = (mtd["net_dom"] + mtd["net_int"]) / CR
    delta = ""
    if prev is not None and prev_day is not None:
        pn = prev["net_dom"] + prev["net_int"]
        if pn:
            chg = (yn * CR - pn) / abs(pn)
            arrow = "▲" if chg >= 0 else "▼"
            delta = f"   {arrow} {chg:+.0%} vs {prev_day:%d %b} (net)"
    return (f"Sold {yg:,.1f} cr gross · {yn:,.1f} cr net on {asof:%d %b}{delta}      |      "
            f"{asof:%B} so far: {mg:,.1f} cr gross · {mn:,.1f} cr net")


def _write_sheet(wb: Workbook, asof: date, month_start: date, yest: dict, yest_excl: dict,
                 mtd: dict, mtd_excl: dict, countries: list, others,
                 counter: dict, web: dict, mobile: dict, ota: pd.DataFrame,
                 movers: tuple | None = None,
                 prev: dict | None = None, prev_day: date | None = None,
                 zone_rows: "pd.DataFrame | None" = None):
    ws = wb.active
    ws.title = "Daily Report"
    ws.sheet_view.showGridLines = False
    widths = [38, 12, 13, 12, 2, 12, 13, 12]
    for j, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(j)].width = w

    _cell(ws, 1, 1, "USBA — Daily Report", bold=True, size=14, color=NAVY, border=False)
    _cell(ws, 2, 1, f"Sales date: {asof:%d %b %Y}   ·   all figures in BDT CRORE (Cr), 2 decimals   ·   "
                    f"GROSS = ticket value before agent commission · NET = after commission   ·   "
                    f"generated {datetime.now():%d %b %H:%M}",
          size=9, color=GREY_T, border=False)
    # the at-a-glance line — crore figures + change vs the previous day
    _cell(ws, 3, 1, _headline(asof, yest, mtd, prev, prev_day),
          bold=True, size=11, color=NAVY, border=False)

    # block headers (merged): GROSS | NET
    ws.merge_cells(start_row=4, start_column=2, end_row=4, end_column=4)
    ws.merge_cells(start_row=4, start_column=6, end_row=4, end_column=8)
    _cell(ws, 4, 2, "GROSS (Ticket Payment)", bold=True, color=WHITE, fill=NAVY, align="center")
    _cell(ws, 4, 6, "NET (after commission)", bold=True, color=WHITE, fill=NAVY, align="center")
    heads = ["Sales", "Domestic", "International", "Total", "", "Domestic", "International", "Total"]
    for j, h in enumerate(heads, 1):
        if h:
            _cell(ws, 5, j, h, bold=True, size=9.5, color=NAVY, fill=BLUE_LIGHT,
                  align="center" if j > 1 else "left")
    ws.freeze_panes = "A6"

    day_lbl = f"{asof:%d %b %Y}"        # the actual sales date, not the word "Yesterday"
    r = 6
    _money_row(ws, r, f"Total Sale — {day_lbl}", yest, bold=True, fill=GREEN_F); r += 1
    _money_row(ws, r, f"{asof:%d %b} excl. Counter/Web/App", yest_excl, bold=True, fill=GREY_L); r += 1
    _cell(ws, r, 1, f"Countries — top {TOP_COUNTRIES} by {asof:%d %b} net (excl. Counter/Web/Mobile)",
          size=9, color=GREY_T, fill=GREY_L)
    for j in range(2, 9):
        _cell(ws, r, j, "", fill=GREY_L)
    r += 1
    for i, t in enumerate(countries, 1):
        _money_row(ws, r, f"{i}. {t[0]}", _tup_to_dict(t), indent=True); r += 1
    if others is not None:
        _money_row(ws, r, "Others", _tup_to_dict(others), indent=True); r += 1
    _money_row(ws, r, "Counter", counter); r += 1
    _money_row(ws, r, "Web", web); r += 1
    _money_row(ws, r, "Mobile (app)", mobile); r += 1
    _money_row(ws, r, f"Month Till Date ({month_start:%d %b}–{asof:%d %b})", mtd,
               bold=True, fill=BLUE_LIGHT); r += 1
    _money_row(ws, r, "MTD excl. Counter/Web/App", mtd_excl, bold=True, fill=GREY_L); r += 2

    # ---- Top 5 OTA per country block ----------------------------------------
    ota_start = r          # remember the top row, so the zone panel sits beside it
    _cell(ws, r, 1, f"Top {TOP_OTAS_PER_COUNTRY} OTA per country — ranked by month-to-date net",
          bold=True, size=12, color=NAVY, border=False)
    r += 1
    # names live in the WIDE label column (A) so they are never cut off
    ota_heads = ["OTA", f"{asof:%d %b} Gross", f"{asof:%d %b} Net", "", "", "MTD Gross", "MTD Net"]
    for j, h in enumerate(ota_heads, 1):
        if h:
            _cell(ws, r, j, h, bold=True, size=9.5, color=NAVY, fill=BLUE_LIGHT,
                  align="center" if j > 1 else "left")
    r += 1
    if ota.empty:
        _cell(ws, r, 1, "No OTA list found (reference/ota_list.xlsx) or no OTA sales in period.",
              size=9, color=GREY_T)
        r += 1
    else:
        # countries arrive ordered by their OTA MTD net; one shaded sub-header each
        for country in ota["country"].drop_duplicates():
            block = ota[ota["country"] == country]
            _cell(ws, r, 1, str(country), bold=True, size=9.5, color=NAVY, fill=GREY_L)
            for j in range(2, 9):
                _cell(ws, r, j, "", fill=GREY_L)
            r += 1
            for row in block.itertuples(index=False):
                _cell(ws, r, 1, f"    {int(row.rk)}.  {row.ota}", size=9)
                _cell(ws, r, 2, row.y_gross / CR, fmt=F_CR, align="right", size=9)
                _cell(ws, r, 3, row.y_net / CR, fmt=F_CR, align="right", size=9)
                _cell(ws, r, 6, row.m_gross / CR, fmt=F_CR, align="right", size=9)
                _cell(ws, r, 7, row.m_net / CR, fmt=F_CR, align="right", size=9)
                r += 1
        _cell(ws, r, 1, f"TOTAL (all {len(ota)} listed)", bold=True, color=WHITE, fill=NAVY)
        for col, s in ((2, ota["y_gross"].sum()), (3, ota["y_net"].sum()),
                       (6, ota["m_gross"].sum()), (7, ota["m_net"].sum())):
            _cell(ws, r, col, s / CR, fmt=F_CR, align="right", bold=True, color=WHITE, fill=NAVY)
        r += 1

    # ---- Zone-wise panel (agencies), to the RIGHT of the OTA block (cols I–K) ----
    if zone_rows is not None and not zone_rows.empty:
        zc = 9                                   # start at column I, leaving H as a gap
        for off, w in ((0, 12), (1, 12), (2, 12)):
            ws.column_dimensions[get_column_letter(zc + off)].width = w
        zr = ota_start
        _cell(ws, zr, zc, "Zone-wise (agencies) — net Cr", bold=True, size=12, color=NAVY, border=False)
        zr += 1
        for j, h in enumerate(["Zone", f"{asof:%d %b} Net", "MTD Net"]):
            _cell(ws, zr, zc + j, h, bold=True, size=9.5, color=NAVY, fill=BLUE_LIGHT,
                  align="left" if j == 0 else "center")
        zr += 1
        for row in zone_rows.itertuples(index=False):
            _cell(ws, zr, zc, str(row.zone), size=9)
            _cell(ws, zr, zc + 1, row.y_net / CR, fmt=F_CR, align="right", size=9)
            _cell(ws, zr, zc + 2, row.m_net / CR, fmt=F_CR, align="right", size=9)
            zr += 1
        _cell(ws, zr, zc, "TOTAL", bold=True, color=WHITE, fill=NAVY)
        _cell(ws, zr, zc + 1, zone_rows["y_net"].sum() / CR, fmt=F_CR, align="right",
              bold=True, color=WHITE, fill=NAVY)
        _cell(ws, zr, zc + 2, zone_rows["m_net"].sum() / CR, fmt=F_CR, align="right",
              bold=True, color=WHITE, fill=NAVY)
        zr += 1
        r = max(r, zr)                           # movers block starts below BOTH panels

    # ---- Movers block: agencies ±20% vs last month, same day-count -----------
    if movers is None:
        return
    gainers, decliners, prev_start, prev_end = movers
    r += 1
    _cell(ws, r, 1, f"Movers — agencies ±{MOVER_PCT * 100:.0f}% net vs last month (same {asof.day} days)",
          bold=True, size=12, color=NAVY, border=False)
    r += 1
    _cell(ws, r, 1, f"{prev_start:%d %b}–{prev_end:%d %b} vs {month_start:%d %b}–{asof:%d %b} · NET in Cr · "
                    f"agencies with ≥ {MOVER_FLOOR / CR:.1f} cr in either period · all qualifying · "
                    f"NEW = no sales last month",
          size=9, color=GREY_T, border=False)
    r += 1
    mover_heads = ["Agency", "Zone", "Sales Person", f"{prev_start:%b} 1-{prev_end.day}", "",
                   f"{month_start:%b} 1-{asof.day}", "Δ (Cr)", "Δ %"]
    def _mover_block(title: str, fill: str, frame: pd.DataFrame, row0: int) -> int:
        rr = row0
        _cell(ws, rr, 1, title, bold=True, color=BLACK, fill=fill)
        for j in range(2, 9):
            _cell(ws, rr, j, "", fill=fill)
        rr += 1
        for j, h in enumerate(mover_heads, 1):
            if h:
                _cell(ws, rr, j, h, bold=True, size=9, color=NAVY, fill=BLUE_LIGHT,
                      align="center" if j > 1 else "left")
        rr += 1
        if frame.empty:
            _cell(ws, rr, 1, "None today.", size=9, color=GREY_T)
            return rr + 1
        for row in frame.itertuples(index=False):
            _cell(ws, rr, 1, f"{row.name}  ({row.customer_id})", size=9)
            _cell(ws, rr, 2, str(row.zone), size=9, align="center")
            _cell(ws, rr, 3, str(row.sales_person)[:18], size=9)
            _cell(ws, rr, 4, row.prev_net / CR, fmt=F_CR, align="right", size=9)
            _cell(ws, rr, 6, row.cur_net / CR, fmt=F_CR, align="right", size=9)
            _cell(ws, rr, 7, row.chg / CR, fmt=F_CR, align="right", size=9)
            if row.pct is None or pd.isna(row.pct):
                _cell(ws, rr, 8, "NEW", align="right", size=9, bold=True)
            else:
                _cell(ws, rr, 8, row.pct, fmt="+0%;-0%", align="right", size=9)
            rr += 1
        return rr
    r = _mover_block(f"▲ INCREASED ≥ +{MOVER_PCT * 100:.0f}%   ({len(gainers)})", GREEN_F, gainers, r)
    r += 1
    r = _mover_block(f"▼ DECREASED ≥ -{MOVER_PCT * 100:.0f}%   ({len(decliners)})", RED_F, decliners, r)


# ---------------------------------------------------------------------------
# entry point
# ---------------------------------------------------------------------------
def generate(params: dict | None = None, cfg: Config | None = None) -> Path:
    """Build the Daily Sales Snapshot and return its path.

    params: optional ``date`` = 'YYYY-MM-DD' (the snapshot/"yesterday" date);
    defaults to the latest date present in the sales data so the sheet always
    reflects the freshest loaded day and SAYS which day that is.
    """
    params = params or {}
    cfg = cfg or load_config(validate=True)
    # read_only keeps the warehouse file untouched; CREATE TEMPORARY TABLE still
    # works (temp tables live in process memory, not in the .duckdb file — DuckDB
    # >= 0.8 behaviour, which the pinned stack satisfies; don't downgrade duckdb).
    con = duckdb.connect(str(cfg.warehouse), read_only=True)

    max_d = con.sql(
        f"SELECT MAX(\"Date\"::DATE) FROM read_parquet('{cfg.sales_glob}', "
        f"hive_partitioning=1, union_by_name=1)").fetchone()[0]
    asof = resolve_asof(params.get("date"), max_d)
    month_start = asof.replace(day=1)

    _build_snap_table(con, cfg, month_start, asof)
    day = f"d = DATE '{asof.isoformat()}'"
    yest = _sector_totals(con, day)
    yest_excl = _sector_totals(con, f"{day} AND category NOT IN {DIRECT_CATS}")
    mtd = _sector_totals(con, "TRUE")
    mtd_excl = _sector_totals(con, f"category NOT IN {DIRECT_CATS}")
    counter = _sector_totals(con, f"{day} AND category = 'Counter'")
    web = _sector_totals(con, f"{day} AND category = 'Web'")
    mobile = _sector_totals(con, f"{day} AND category = 'Mobi App'")
    countries, others = split_top_countries(_country_rows(con, asof))
    ota = _ota_rows(con, cfg, asof)
    zone_rows = _zone_rows(con, asof)
    movers = _mover_rows(con, cfg, month_start, asof)
    # previous day (for the headline's "+x% vs 05 Jun") — only when it falls inside
    # the MTD window already materialised in snap_sales (skip on the 1st of the month)
    prev = prev_day = None
    if asof.day > 1:
        prev_day = asof - timedelta(days=1)
        prev = _sector_totals(con, f"d = DATE '{prev_day.isoformat()}'")

    wb = Workbook()
    _write_sheet(wb, asof, month_start, yest, yest_excl, mtd, mtd_excl,
                 countries, others, counter, web, mobile, ota,
                 movers=movers, prev=prev, prev_day=prev_day, zone_rows=zone_rows)

    out = cfg.output_dir / f"Daily_Report_{asof.isoformat()}.xlsx"
    out.parent.mkdir(parents=True, exist_ok=True)
    try:
        wb.save(out)
    except PermissionError:                       # file open in Excel -> sibling _v2
        out = out.with_name(out.stem + "_v2.xlsx")
        wb.save(out)
    return out
