"""
reporting.builders.route_fare_movement - the Excel twin of the Power BI "Route Fare & Customers" page.

For one AFTER period and one BEFORE period (any dates), route by route: how the fare moved (split
into price, exchange rate and mix), how the volume moved, and WHICH customers moved it (Up / Down /
Same / New / Back / Stopped, each with its contribution per day), whether a customer that bought less
grew on the other routes of the same market, and the seats operated around the same dates.

It prints exactly what the dashboard page shows for the same two periods, because both read the same
tables (curated/route_fare, built by scripts/build_route_fare_mart.py) and every rule lives in
reporting/fare_movement.py. That makes it the page's check: build the twin for a period pair, open
the page with the same pair, and the "check" figures on its Summary sheet must match the page's.
Where the tables have not been built (a colleague's machine), it builds them from curated sales.

PARAMETERS (parse_params validates and explains a refusal)
    after_from / after_to   YYYY-MM (a whole month) or YYYY-MM-DD; blank = the latest complete month
    before                  'previous' (same number of days just before; default), 'last_year', 'custom'
    before_from / before_to the custom before period
    volume                  'sold' (default) or 'kept' (leaves out tickets later voided or refunded)
    itinerary               'all' (default) / 'domestic' / 'international'
    customers               'all' (default) / 'agencies' (incl. OTAs) / 'otas' / 'direct'
    routes                  optional list of directional routes, e.g. "DAC-DXB, DAC-SHJ"
"""
from __future__ import annotations

import calendar
import datetime as dt
import re
from pathlib import Path

import pandas as pd
from openpyxl import Workbook

from .. import fare_movement as fm
from ..config import Config, load_config
from .agency_route_monthly import _save_locktolerant
from .route_before_after import (AMBER, BLUE, BLUEL, FI, FL, FP, GREEN_T, GREENL, GREYT, NAVY, RED_T,
                                 _band, _cell, _parse_day, _parse_routes, _widths)

CUSTOMER_SCOPES = {"all": None, "agencies": ("Agency", "OTA"), "otas": ("OTA",),
                   "direct": ("Direct: Web", "Direct: Counter", "Direct: App", "Direct: Call centre", "Direct: Other")}
ITINERARIES = {"all": None, "domestic": fm.ITIN_DOM, "international": fm.ITIN_INTL}
CAPACITY_AHEAD_DAYS = 30          # sales in a period mostly fly within the following month (median 7 days)
LAC = 1e5


# ------------------------------------------------------------------------------------- parameters
def parse_params(p: dict | None, latest_day: dt.date) -> dict:
    """Validated settings. Raises ValueError with a sentence a colleague can act on."""
    p = p or {}
    lo = _parse_day(p.get("after_from"), end=False, what="after from")
    hi = _parse_day(p.get("after_to"), end=True, what="after to")
    if lo is None and hi is None:                      # default: the latest COMPLETE month
        last = latest_day if latest_day.day == calendar.monthrange(latest_day.year, latest_day.month)[1] \
            else latest_day.replace(day=1) - dt.timedelta(days=1)
        lo, hi = last.replace(day=1), last
    if lo is None or hi is None or lo > hi:
        raise ValueError("The after period needs a from and a to, the from not later than the to.")
    after = fm.Window(lo, hi)
    mode = str(p.get("before") or "previous").strip().lower()
    custom = None
    if mode == "custom":
        clo = _parse_day(p.get("before_from"), end=False, what="before from")
        chi = _parse_day(p.get("before_to"), end=True, what="before to")
        if clo is None or chi is None or clo > chi:
            raise ValueError("A custom before period needs a from and a to, the from not later than the to.")
        custom = fm.Window(clo, chi)
    before = fm.before_window(after, mode, custom)
    out = {"after": after, "before": before, "mode": mode,
           "volume": str(p.get("volume") or "sold").lower(),
           "itinerary": str(p.get("itinerary") or "all").lower(),
           "customers": str(p.get("customers") or "all").lower(),
           "routes": _parse_routes(p.get("routes"))}
    for key, allowed in (("volume", fm.VOLUMES), ("itinerary", ITINERARIES), ("customers", CUSTOMER_SCOPES)):
        if out[key] not in allowed:
            raise ValueError(f"{key.capitalize()} must be one of {', '.join(allowed)}; got {out[key]!r}.")
    return out


def coverage_warnings(s: dict, data_lo: dt.date, data_hi: dt.date) -> list[str]:
    """Refuse a before period the data cannot see; return the notes that make a change misleading."""
    a, b = s["after"], s["before"]
    if b.hi < data_lo or b.lo > data_hi or a.lo > data_hi:
        raise ValueError(f"The data covers {data_lo} to {data_hi}; the before period ({b.lo} to {b.hi}) or the "
                         f"after period ({a.lo} to {a.hi}) has no sales in it.")
    notes = []
    if b.lo < data_lo:
        notes.append(f"The data starts {data_lo}: the first {(data_lo - b.lo).days} day(s) of the before period "
                     "have no sales, so its per-day figures are LOW.")
    if a.hi > data_hi:
        notes.append(f"The data ends {data_hi}: the last {(a.hi - data_hi).days} day(s) of the after period are "
                     "not in yet, so its per-day figures are LOW.")
    if a.days != b.days:
        notes.append(f"The periods differ in length (after {a.days} days, before {b.days}); volume is compared "
                     "per day, so this is fair, but a holiday inside one period is not.")
    if not fm.history_is_long_enough(b.lo):
        notes.append("The before period starts within 6 months of the data's start (May 2025), so New and Back "
                     "cannot be told apart: both read 'New or back'.")
    return notes


# ------------------------------------------------------------------------------------- data
def load_tables(cfg: Config, s: dict) -> tuple[dict[str, pd.DataFrame], dt.date, dt.date]:
    """The mart tables (the dashboard's own) when built, else built here from curated sales."""
    d = cfg.data_root / "curated" / "route_fare"
    names = ("route_customer_day", "route_lfl_day", "customer_route_first", "route_dim")
    if all((d / f"{n}.parquet").is_file() for n in names):
        t = {n: pd.read_parquet(d / f"{n}.parquet") for n in names}
    else:
        t = _build_from_curated(cfg, s)
    for n in ("route_customer_day", "route_lfl_day", "customer_route_first"):
        col = "first_date" if n == "customer_route_first" else "date"
        t[n][col] = pd.to_datetime(t[n][col])
    dates = t["route_customer_day"]["date"]
    return t, dates.min().date(), dates.max().date()


def _build_from_curated(cfg: Config, s: dict) -> dict[str, pd.DataFrame]:
    """Portable path (no mart on this machine): the same build_tables over the two periods only.
    Customer keys come from dim_agency when present, else from dim_customer alone."""
    import duckdb
    from ..common import build_rate_sql
    sales = (cfg.data_root / "curated" / "sales" / "**" / "*.parquet").as_posix()
    src = f"read_parquet('{sales}', hive_partitioning=1, union_by_name=1)"
    dim_a = cfg.data_root / "curated" / "dim_agency" / "dim_agency.parquet"
    dim_c = pd.read_parquet(cfg.data_root / "curated" / "dim_customer" / "dim_customer.parquet")
    empty = pd.DataFrame(columns=["customer_id", "agency_key", "agency_name", "channel", "is_ota", "is_gds_pseudo"])
    customers = fm.customer_frame_with_fallback(pd.read_parquet(dim_a) if dim_a.is_file() else empty, dim_c)
    lo = min(s["before"].lo, fm.DATA_START)          # from the data's start, so first-seen is right
    return fm.build_tables(duckdb.connect(), src, build_rate_sql(cfg), lo, s["after"].hi, customers, {})


def scoped(t: dict[str, pd.DataFrame], s: dict) -> tuple[pd.DataFrame, pd.DataFrame]:
    """The two fact tables cut to the chosen itinerary type, customer group and routes."""
    rcd, lfl = t["route_customer_day"], t["route_lfl_day"]
    itin, types = ITINERARIES[s["itinerary"]], CUSTOMER_SCOPES[s["customers"]]
    if itin:
        rcd, lfl = rcd[rcd.itinerary == itin], lfl[lfl.itinerary == itin]
    if types:
        rcd, lfl = rcd[rcd.customer_type.isin(types)], lfl[lfl.customer_type.isin(types)]
    if s["routes"]:
        rcd, lfl = rcd[rcd.leg_route.isin(s["routes"])], lfl[lfl.leg_route.isin(s["routes"])]
    return rcd, lfl


def capacity(cfg: Config, w: fm.Window) -> pd.DataFrame:
    """Seats per day and load factor per route on the flights these sales mostly fly on: flight
    dates from the period's start to CAPACITY_AHEAD_DAYS after its end. Empty when no loads file."""
    f = cfg.data_root / "curated" / "flight_loads" / "flight_loads.parquet"
    if not f.is_file():
        return pd.DataFrame(columns=["leg_route", "seats_per_day", "load"])
    fl = pd.read_parquet(f, columns=["flight_date", "leg_route", "capacity", "booked"])
    d = pd.to_datetime(fl.flight_date).dt.date
    hi = w.hi + dt.timedelta(days=CAPACITY_AHEAD_DAYS)
    x = fl[(d >= w.lo) & (d <= hi)].groupby("leg_route")[["capacity", "booked"]].sum()
    x["seats_per_day"] = x.capacity / ((hi - w.lo).days + 1)
    x["load"] = (x.booked / x.capacity).where(x.capacity > 0)
    return x[["seats_per_day", "load"]].reset_index()


def events(cfg: Config, w: fm.Window) -> str:
    """Holidays and events on flight dates inside the period (from the loads calendar)."""
    f = cfg.data_root / "curated" / "flight_loads" / "flight_loads.parquet"
    if not f.is_file():
        return ""
    fl = pd.read_parquet(f, columns=["flight_date", "event_name"])
    d = pd.to_datetime(fl.flight_date).dt.date
    names = fl[(d >= w.lo) & (d <= w.hi)].event_name.dropna().astype(str).str.strip()
    return ", ".join(sorted({n for n in names if n and n.lower() not in ("none", "nan")}))


# ------------------------------------------------------------------------------------- sheets
STATUS_ORDER = ("Up", "Down", "Same", "New", "Back", "New or back", "Stopped")


def _num(v):
    """None for a missing value, so a blank cell never pretends to be a measured zero."""
    return None if v is None or (isinstance(v, float) and pd.isna(v)) else v


def _label(s: dict) -> tuple[str, str]:
    def fmt(w: fm.Window) -> str:
        return f"{w.lo:%d %b %Y} - {w.hi:%d %b %Y}"
    return fmt(s["after"]), fmt(s["before"])


def write_summary(ws, s: dict, tot: dict, moves: pd.DataFrame, notes: list[str], ev: tuple[str, str]) -> None:
    """The headline figures, the fare split, the waterfall and the CHECK figures for the dashboard."""
    a_lbl, b_lbl = _label(s)
    ws.sheet_view.showGridLines = False
    _widths(ws, {"A": 38, "B": 18, "C": 18, "D": 14, "E": 14, "F": 14})
    _band(ws, 1, 1, 6, f"ROUTE FARE & CUSTOMERS  -  after {a_lbl}  vs  before {b_lbl}", size=12)
    _band(ws, 2, 1, 6, f"Volume = {s['volume']} segments per day. Itinerary: {s['itinerary']}. Customers: "
                       f"{s['customers']}. Routes: {', '.join(s['routes']) or 'all'}. Sale-date basis.",
          fill=BLUEL, color=NAVY, size=9, bold=False, height=28)
    r = 3
    for n in notes:
        _band(ws, r, 1, 6, "CHECK: " + n, fill=AMBER, color=RED_T, size=9, height=30)
        r += 1
    r += 1
    for j, h in enumerate(["", "Before", "After", "Change"], 1):
        _cell(ws, r, j, h, bold=True, color=NAVY, fill=BLUEL)
    rows = [("Segments per day", tot["before_per_day"], tot["after_per_day"], FL),
            ("Money net per day (lac)", tot["money_before_per_day"] / LAC, tot["money_after_per_day"] / LAC, FL),
            ("Customers active", tot["customers_before"], tot["customers_after"], FI)]
    for basis in fm.BASES:
        rows.append((f"{basis.capitalize()} fare per segment (BDT)",
                     tot[f"{basis}_avg_before"], tot[f"{basis}_avg_after"], FI))
    for label, b, a, fmt in rows:
        r += 1
        _cell(ws, r, 1, label, align="left", color=NAVY, bold=True)
        _cell(ws, r, 2, _num(b), fmt=fmt)
        _cell(ws, r, 3, _num(a), fmt=fmt)
        _cell(ws, r, 4, (a / b - 1) if b and a is not None else None, fmt=FP)
    r = _fare_split_block(ws, r + 2, tot)
    r = _waterfall_block(ws, r + 2, tot, moves)
    _band(ws, r + 2, 1, 6, f"Holidays and events in the after period: {ev[0] or 'none'}. Before: {ev[1] or 'none'}.",
          fill=None, color="000000", size=9, bold=False, height=30)


def _fare_split_block(ws, r: int, tot: dict) -> int:
    _band(ws, r, 1, 6, "WHY THE AVERAGE FARE MOVED  (price in the sale currency + exchange rate + mix = average)",
          fill=BLUE, size=10)
    r += 1
    for j, h in enumerate(["Fare basis", "Average change", "Price", "Exchange rate", "Mix", "Coverage"], 1):
        _cell(ws, r, j, h, bold=True, color=NAVY, fill=BLUEL)
    for basis in fm.BASES:
        r += 1
        _cell(ws, r, 1, basis.capitalize(), align="left", color=NAVY, bold=True)
        for j, part in enumerate(("avg_change", "price", "fx", "mix", "coverage"), 2):
            _cell(ws, r, j, _num(tot.get(f"{basis}_{part}")), fmt="0.0%" if part == "coverage" else FP)
    return r


def _waterfall_block(ws, r: int, tot: dict, moves: pd.DataFrame) -> int:
    """Before per day + each status's contribution = after per day, exactly (the check)."""
    _band(ws, r, 1, 6, "WHO MOVED THE VOLUME  (segments per day; the contributions add up to the change)",
          fill=BLUE, size=10)
    r += 1
    # counted per customer AND route: one agency that went up on three routes counts three times
    for j, h in enumerate(["", "Customer-routes", "Segments / day", "Share of change"], 1):
        _cell(ws, r, j, h, bold=True, color=NAVY, fill=BLUEL)
    change = tot["after_per_day"] - tot["before_per_day"]
    r += 1
    _cell(ws, r, 1, "Before", align="left", bold=True)
    _cell(ws, r, 3, tot["before_per_day"], fmt=FL, bold=True)
    for st in STATUS_ORDER:
        m = moves[moves.status == st]
        if m.empty:
            continue
        r += 1
        c = m.contribution.sum()
        _cell(ws, r, 1, st, align="left", color=GREEN_T if c > 0 else RED_T if c < 0 else GREYT)
        _cell(ws, r, 2, int(len(m)), fmt=FI)
        _cell(ws, r, 3, c, fmt=FL)
        _cell(ws, r, 4, (c / change) if change else None, fmt="0.0%")
    r += 1
    _cell(ws, r, 1, "After (CHECK: equals the dashboard)", align="left", bold=True, color="FFFFFF", fill=NAVY)
    _cell(ws, r, 3, tot["after_per_day"], fmt=FL, bold=True, color="FFFFFF", fill=NAVY)
    return r


def _col(status: str) -> str:
    return "c_" + status.lower().replace(" ", "_")


ROUTE_COLS = [
    ("Route", "leg_route", None, 11), ("Market", "market", None, 18), ("Before /day", "before_per_day", FL, 11),
    ("After /day", "after_per_day", FL, 11), ("Volume chg", "volume_change", FP, 10),
    ("Base fare before", "base_avg_before", FI, 11), ("Base fare after", "base_avg_after", FI, 11),
    ("Avg fare chg", "base_avg_change", FP, 10), ("Price", "base_price", FP, 9), ("Exch. rate", "base_fx", FP, 9),
    ("Mix", "base_mix", FP, 9), ("Coverage", "base_coverage", "0%", 9), ("Gross price", "gross_price", FP, 9),
    ("Net price", "net_price", FP, 9), ("Seats/day before", "seats_before", FI, 11),
    ("Seats/day after", "seats_after", FI, 11), ("Load before", "load_before", "0%", 9),
    ("Load after", "load_after", "0%", 9), ("Customers before", "customers_before", FI, 10),
    ("Customers after", "customers_after", FI, 10)] + [
    (f"{st} /day", _col(st), FL, 10) for st in STATUS_ORDER] + [
    ("Stopped (count)", "n_stopped", FI, 10), ("Stopped one period earlier", "stopped_earlier", FI, 12),
    ("New + back (count)", "n_new_back", FI, 10), ("New + back one period earlier", "new_earlier", FI, 12)]

CUST_COLS = [
    ("Route", "leg_route", None, 11), ("Customer", "customer_label", None, 34), ("Type", "customer_type", None, 14),
    ("Status", "status", None, 11), ("Before /day", "before_per_day", FL, 10), ("After /day", "after_per_day", FL, 10),
    ("Contribution /day", "contribution", FL, 12), ("Base fare before", "fare_before", FI, 11),
    ("Base fare after", "fare_after", FI, 11), ("Sale days before", "sale_days_b", FI, 9),
    ("Sale days after", "sale_days_a", FI, 9), ("Usual gap (days)", "usual_gap_days", FI, 10),
    ("Other routes in market /day", "other_routes_change", FL, 13), ("Did it switch?", "switch", None, 32)]


def _table(ws, cols: list, frame: pd.DataFrame, colour_col: str | None = None) -> None:
    """A plain filterable table: header row, one row per record, frozen first two columns."""
    ws.sheet_view.showGridLines = False
    for j, (h, _c, _f, w) in enumerate(cols, 1):
        ws.column_dimensions[ws.cell(1, j).column_letter].width = w
        _cell(ws, 1, j, h, bold=True, color=NAVY, fill=BLUEL, wrap=True)
    ws.row_dimensions[1].height = 30
    for i, x in enumerate(frame.itertuples(index=False), 2):
        rec = x._asdict()
        for j, (_h, col, fmt, _w) in enumerate(cols, 1):
            v = _num(rec.get(col))
            colour = "000000"
            if col == colour_col and v is not None:
                colour = GREEN_T if v > 0 else RED_T if v < 0 else GREYT
            _cell(ws, i, j, v, fmt=fmt, align="left" if fmt is None else "center", color=colour)
    ws.freeze_panes = "C2"
    ws.auto_filter.ref = f"A1:{ws.cell(1, len(cols)).column_letter}{max(len(frame) + 1, 2)}"


def write_routes(ws, routes: pd.DataFrame) -> None:
    """One row per route, biggest after-period volume first."""
    r = routes.assign(n_new_back=routes.n_new + routes.n_back + routes.n_new_or_back)
    _table(ws, ROUTE_COLS, r.sort_values(["after_per_day", "leg_route"], ascending=[False, True]))


def write_customers(ws, moves: pd.DataFrame) -> None:
    """Every route x customer: routes biggest first, the largest movers first inside each route."""
    size = moves.groupby("leg_route").after_per_day.sum()
    m = moves.assign(_size=moves.leg_route.map(size), _abs=moves.contribution.abs())
    m = m.sort_values(["_size", "leg_route", "_abs", "customer_label"], ascending=[False, True, False, True])
    _table(ws, CUST_COLS, m, colour_col="contribution")


def write_ladders(ws, lfl: pd.DataFrame, routes: pd.DataFrame, s: dict, top: int = 15) -> None:
    """Booking-class ladder for the busiest routes: a mix shift is visible beside the price change."""
    ws.sheet_view.showGridLines = False
    _widths(ws, {"A": 8, "B": 12, "C": 12, "D": 12, "E": 12, "F": 12, "G": 12})
    r = 1
    for route in routes.sort_values("after_per_day", ascending=False).leg_route.head(top):
        lad = fm.class_ladder(lfl, route, s["after"], s["before"])
        _band(ws, r, 1, 7, f"{route}  booking classes", fill=BLUE, size=10)
        r += 1
        for j, h in enumerate(["Class", "Seats before", "Share before", "Fare before", "Seats after",
                               "Share after", "Fare after"], 1):
            _cell(ws, r, j, h, bold=True, color=NAVY, fill=BLUEL)
        for x in lad.sort_values("fare_before", na_position="last").itertuples():
            r += 1
            vals = ((x.rbd, None), (x.segments_before, FI), (x.share_before, "0.0%"), (x.fare_before, FI),
                    (x.segments_after, FI), (x.share_after, "0.0%"), (x.fare_after, FI))
            for j, (v, fmt) in enumerate(vals, 1):
                _cell(ws, r, j, _num(v), fmt=fmt)
        r += 2


METHOD = [
    ("Basis", "Sale date. Routes are directional itinerary legs; a leg's money is an equal share of its ticket."),
    ("Fares", "Base = fare before tax; Gross = fare with tax; Net = fare x (1 - commission) + tax. All per segment, "
              "ticket sales only. Money net per day = the DSR's net (refunds, voids and penalties on their own dates)."),
    ("Price / exchange / mix", "Price compares the SAME seats (route, itinerary type, journey, booking lead band, "
                               "booking class, sale currency) in their own sale currency, weighted by the before "
                               "period's BDT revenue. Exchange rate = the same seats in BDT minus the price. "
                               "Mix = everything else."),
    ("Coverage", "Share of the before period's segments sold in a cell that also sold in the after period."),
    ("Status", "No thresholds. Per day: Up / Down / Same by sign; Stopped = before only; New = first ever sale of "
               "the route inside the after period; Back = sold it before the before period."),
    ("Switch", "For a customer buying less: its change on the other routes of the same market and direction. "
               "Other airlines are invisible, so 'less of the whole market' is the most this can say."),
    ("Capacity", f"Seats on flights from the period's start to {CAPACITY_AHEAD_DAYS} days after its end (where these "
                 "sales mostly fly); future flights are still filling."),
    ("Correlation", "These figures show what moved together, not what caused it: season, seats, holidays and "
                    "competitors move volume too."),
]


def write_method(ws) -> None:
    ws.sheet_view.showGridLines = False
    _widths(ws, {"A": 22, "B": 110})
    for r, (a, b) in enumerate(METHOD, 1):
        _cell(ws, r, 1, a, bold=True, color=NAVY, align="left")
        _cell(ws, r, 2, b, align="left", wrap=True)
        ws.row_dimensions[r].height = 32


# ------------------------------------------------------------------------------------- main
def totals(rcd: pd.DataFrame, lfl: pd.DataFrame, moves: pd.DataFrame, s: dict) -> dict:
    """The network figures for the Summary sheet (every route in scope together)."""
    vol = fm.VOLUMES[s["volume"]]
    placed = rcd[rcd.leg_route != fm.NO_ROUTE]
    rb, ra = fm.in_window(placed, s["before"]), fm.in_window(placed, s["after"])
    t = {"before_per_day": rb[vol].sum() / s["before"].days, "after_per_day": ra[vol].sum() / s["after"].days,
         "money_before_per_day": fm.in_window(rcd, s["before"]).money_net.sum() / s["before"].days,
         "money_after_per_day": fm.in_window(rcd, s["after"]).money_net.sum() / s["after"].days,
         "customers_before": int(moves[moves.before_per_day > 0].customer_key.nunique()),
         "customers_after": int(moves[moves.after_per_day > 0].customer_key.nunique())}
    lb, la = fm.in_window(lfl, s["before"]), fm.in_window(lfl, s["after"])
    for basis in fm.BASES:
        for k, v in fm.like_for_like(lb, la, basis).items():
            t[f"{basis}_{k}"] = v
    return t


def build(params: dict | None, cfg: Config) -> dict:
    """Every frame the workbook prints (also what a test or the dashboard check compares against)."""
    probe = parse_params(params, dt.date.today())          # validate the typing before any data is read
    t, data_lo, data_hi = load_tables(cfg, probe)
    s = parse_params(params, data_hi)                       # the default period needs the data's last day
    notes = coverage_warnings(s, data_lo, data_hi)
    # movement is computed on EVERY route of the scope first, so a customer's 'other routes in the
    # market' include routes outside a route filter (the dashboard does the same), then cut
    rcd_all, lfl_all = scoped(t, {**s, "routes": ()})
    moves = fm.customer_movement(rcd_all, t["customer_route_first"], t["route_dim"], s["after"], s["before"], s["volume"])
    rcd, lfl = scoped(t, s)
    if s["routes"]:
        moves = moves[moves.leg_route.isin(s["routes"])]
    if moves.empty:
        raise ValueError("Nothing to compare: no sales in either period for this selection.")
    routes = fm.route_summary(rcd, lfl, moves, s["after"], s["before"], s["volume"])
    routes = routes.merge(t["route_dim"][["leg_route", "market"]], on="leg_route", how="left")
    base = fm.churn_baseline(rcd, t["customer_route_first"], t["route_dim"], s["after"], s["before"], s["volume"])
    routes = routes.merge(base, on="leg_route", how="left")
    for side, w in (("before", s["before"]), ("after", s["after"])):
        cap = capacity(cfg, w).rename(columns={"seats_per_day": f"seats_{side}", "load": f"load_{side}"})
        routes = routes.merge(cap, on="leg_route", how="left")
    return {"settings": s, "notes": notes, "rcd": rcd, "lfl": lfl, "moves": moves, "routes": routes,
            "totals": totals(rcd, lfl, moves, s), "events": (events(cfg, s["after"]), events(cfg, s["before"]))}


def generate(params: dict | None = None, cfg: Config | None = None) -> Path:
    cfg = cfg or load_config()
    b = build(params, cfg)
    s = b["settings"]
    wb = Workbook()
    wb.active.title = "Summary"
    write_summary(wb.active, s, b["totals"], b["moves"], b["notes"], b["events"])
    write_routes(wb.create_sheet("Routes"), b["routes"])
    write_customers(wb.create_sheet("Customers"), b["moves"])
    write_ladders(wb.create_sheet("Class ladder"), b["lfl"], b["routes"], s)
    write_method(wb.create_sheet("Method"))
    out_dir = Path((params or {}).get("out_dir") or cfg.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    a, w = s["after"], s["before"]
    name = f"Route_Fare_Movement_{a.lo:%Y%m%d}-{a.hi:%Y%m%d}_vs_{w.lo:%Y%m%d}-{w.hi:%Y%m%d}.xlsx"
    return _save_locktolerant(wb, out_dir / name)
