"""
reporting.builders.data_kit — the dimension bundle that powers Instant Reports.

A manager's machine can ingest a raw sales export, but it can never rebuild the
mapping chain (Total Agency + MOCAT + IATA patches + dim_sales_person + ...).
This builder zips the PREBUILT outputs of that chain so client machines use the
analyst's latest mappings — one source of truth, refreshed with every morning
publish (it's in publish_reports.DEFAULT_SET).

CONTENTS (small — a few MB):
    curated/dim_customer/dim_customer.parquet     the full customer dimension
    reference/commission_rates.xlsx               time-versioned commission table
    reference/ota_list.xlsx                       OTA membership (Daily/DSR OTA blocks)
    reference/zone_managers.xlsx                  zone -> area/manager labels (DSR)
    reference/dim_zone.parquet                    zone geography
    reference/dim_sales_person.parquet            zone -> salesperson ownership

Deliberately NOT included: salesperson_emails.xlsx (colleague emails stay on the
analyst machine), raw agency masters, sales data of any kind.

Public entry point: ``generate(params, cfg) -> Path`` (returns the .zip).
"""
from __future__ import annotations

import zipfile
from pathlib import Path

from ..config import Config, load_config

# (source path inside the data root, required?) — relative, so the kit unzips
# into an instant work root with the exact same layout.
_KIT_FILES: list[tuple[str, bool]] = [
    ("curated/dim_customer/dim_customer.parquet", True),
    ("reference/commission_rates.xlsx", True),
    ("reference/ota_list.xlsx", False),
    ("reference/zone_managers.xlsx", False),
    ("reference/dim_zone.parquet", False),
    ("reference/dim_sales_person.parquet", False),
    # flight data (tiny, ~150 KB total) — unlocks Flight Load + the Target family
    # in Instant Reports (capacity/yield inputs; no zenith pull needed client-side)
    ("curated/flight_loads/flight_loads.parquet", False),
    ("curated/flight_history/flight_loads_history.parquet", False),
]


def generate(params: dict | None = None, cfg: Config | None = None) -> Path:
    """Zip the dimension bundle; return the zip path (published like any report)."""
    cfg = cfg or load_config(validate=True)
    out = cfg.output_dir / "Data_Kit.zip"
    out.parent.mkdir(parents=True, exist_ok=True)

    missing_required = [rel for rel, req in _KIT_FILES
                        if req and not (cfg.data_root / rel).is_file()]
    if missing_required:
        raise FileNotFoundError(f"Data kit blocked — required file(s) missing: {missing_required}")

    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zf:
        for rel, _req in _KIT_FILES:
            src = cfg.data_root / rel
            if src.is_file():
                zf.write(src, arcname=rel)
            else:
                print(f"[WARN] data kit: optional {rel} missing — skipped")
    print(f"data kit: {out} ({out.stat().st_size/1e6:.1f} MB)")
    return out
