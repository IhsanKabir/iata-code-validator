"""
reporting.instant — build reports ON THIS MACHINE from uploaded raw files ("Instant Reports").

The pipeline machine publishes finished workbooks; THIS module lets any exe user
(behind the same Reports password) rebuild them locally from:

  * one or more RAW Zenith sales exports (the daily xlsx), plus
  * the published **Data Kit** (Data_Kit_latest.zip on the share) — the analyst's
    prebuilt dimension masters (dim_customer, zones, commission rates, OTA list),
    so client machines never rebuild the heavy mapping chain.

HOW IT WORKS
------------
1. ``assemble_root(raw_files, kit_zip)`` lays out a synthetic data root under
   %LOCALAPPDATA%/USBA_InstantReports/work/ that LOOKS exactly like E:\\Analysis:
       curated/sales/year=*/month=*/day=*/*.parquet   <- ingested raw files
       curated/dim_customer/dim_customer.parquet      <- from the kit
       reference/...                                  <- from the kit
       warehouse.duckdb                               <- dim_customer table only
2. ``build_reports(keys, progress)`` points ANALYSIS_HOME at that root and runs
   the SAME builder code that publishes the official reports — one by one (the
   analyst's explicit preference), reporting progress per report.

The work root is a FIXED path reused per session and wiped on every assemble:
``builders.dsr`` resolves its data root at IMPORT time, so the path must never
change within one process.

INGEST: a faithful, self-contained subset of scripts/02_ingest_sales.py (sheet
auto-detect, required-column check, date coercion, object->string normalization,
hive partitioning). The full pipeline script remains the authority for the real
warehouse; this one only feeds the throwaway instant root.
"""
from __future__ import annotations

import os
import shutil
import zipfile
from pathlib import Path
from typing import Callable

# ---- layout ------------------------------------------------------------------
WORK_ROOT = Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "USBA_InstantReports" / "work"

# ---- ingest constants (mirrors scripts/pipeline_config.SalesIngestConfig) -----
SHEET_NAME_CANDIDATES = ("Sheet0", "Sheet1", "Sales", "Export")
COL_CUSTOMER_ID = "Customer ID"
COL_DATE = "Date"

# Reports the instant engine can build, in build order. The flight-data reports
# (Load / Target family) work because the Data Kit now ships the flight-loads +
# flight-history parquets. NOTE: target-family numbers are only as complete as
# the UPLOADED sales history (the cascade uses a 5-month trailing window) — use
# APPEND mode to accumulate months for full-accuracy targets.
INSTANT_REPORTS: dict[str, str] = {
    "daily": "Daily Report",
    "dsr": "DSR (month of the data)",
    "sales_person": "Sales-Person Gross",
    "load_report": "Flight Load",
    "june_target": "June Target (capacity)",
    "underperformers": "Underperformers",
    "salesperson_pack": "Sales-Person Target Packs (zip)",
    "iata_worklist": "IATA Worklist",
}


def _read_raw_sales(xlsx: Path):
    """One raw Zenith export -> cleaned DataFrame (date-typed, string-normalized)."""
    import pandas as pd
    from openpyxl import load_workbook

    wb = load_workbook(xlsx, read_only=True)
    try:
        names = wb.sheetnames
    finally:
        wb.close()      # read_only keeps the zip handle open -> would hold the user's
                        # upload locked ("file in use" on re-save) until garbage collection
    sheet = next((s for s in SHEET_NAME_CANDIDATES if s in names), names[0])
    df = pd.read_excel(xlsx, sheet_name=sheet, header=0)
    for col in (COL_CUSTOMER_ID, COL_DATE):
        if col not in df.columns:
            raise ValueError(f"{xlsx.name}: required column {col!r} missing "
                             f"(is this really a Zenith sales export?)")
    df = df[df[COL_CUSTOMER_ID].notna()].copy()
    df[COL_DATE] = pd.to_datetime(df[COL_DATE], errors="coerce")
    # rows with an unparseable Date keep flowing (year=0 sentinel, same as pipeline)
    df["year"] = df[COL_DATE].dt.year.fillna(0).astype("int32")
    df["month"] = df[COL_DATE].dt.month.fillna(0).astype("int32")
    df["day"] = df[COL_DATE].dt.day.fillna(0).astype("int32")
    df["source_file"] = xlsx.name
    # Some exports lack the per-row segment count; the DSR does
    # COALESCE(seg, 1), but the column must EXIST for the SQL to bind —
    # in the big pipeline union_by_name supplies it from other months.
    if "seg" not in df.columns:
        df["seg"] = pd.array([None] * len(df), dtype="Float64")
    # object -> nullable string so PyArrow never chokes on mixed-type columns
    for c in [c for c in df.columns if df[c].dtype == object]:
        df[c] = df[c].astype("string")
    return df


def assemble_root(raw_files: list[Path], kit_zip: Path,
                  progress: Callable[[str], None] = print,
                  append: bool = False) -> Path:
    """Build (or extend) the synthetic data root from kit + raw files.

    ``append=True`` KEEPS previously uploaded sales and merges the new files in —
    e.g. an earlier upload covered Jun 1-6 and today's file covers Jun 6-12: the
    result covers Jun 1-12. Days present in the NEW upload replace the same days
    from older uploads (the 6th is taken from the newer file, never double-counted).
    The dimension kit is refreshed from the share on every run either way.
    """
    import duckdb
    import pandas as pd

    progress(f"work root: {WORK_ROOT}")
    if WORK_ROOT.exists() and not append:
        shutil.rmtree(WORK_ROOT, ignore_errors=True)
    WORK_ROOT.mkdir(parents=True, exist_ok=True)

    progress(f"unpacking data kit: {Path(kit_zip).name}")
    with zipfile.ZipFile(kit_zip) as zf:
        for member in zf.infolist():                       # zip-slip guard
            dest = (WORK_ROOT / member.filename).resolve()
            if not dest.is_relative_to(WORK_ROOT.resolve()):
                raise ValueError(f"Unsafe path in data kit: {member.filename!r}")
        zf.extractall(WORK_ROOT)
    dim_parquet = WORK_ROOT / "curated" / "dim_customer" / "dim_customer.parquet"
    if not dim_parquet.is_file():
        raise FileNotFoundError("Data kit is missing dim_customer.parquet — "
                                "re-publish the kit from the pipeline machine.")

    sales_dir = WORK_ROOT / "curated" / "sales"
    sales_dir.mkdir(parents=True, exist_ok=True)
    frames = []
    for f in raw_files:
        progress(f"ingesting {Path(f).name} ...")
        frames.append(_read_raw_sales(Path(f)))
    allf = pd.concat(frames, ignore_index=True)

    if append:
        # newest upload wins per DAY: drop existing partitions for every (y,m,d)
        # the new data carries, so overlapping days are replaced, never doubled.
        new_days = allf[["year", "month", "day"]].drop_duplicates()
        replaced = 0
        for y, m, d in new_days.itertuples(index=False):
            part = sales_dir / f"year={y}" / f"month={m}" / f"day={d}"
            if part.is_dir():
                shutil.rmtree(part, ignore_errors=True)
                replaced += 1
        if replaced:
            progress(f"append: {replaced} overlapping day(s) replaced by the new upload")

    progress(f"{len(allf):,} sale rows -> parquet partitions"
             + (" (added to previous uploads)" if append else ""))
    allf.to_parquet(sales_dir, partition_cols=["year", "month", "day"], index=False)

    progress("building mini warehouse (dim_customer)")
    con = duckdb.connect(str(WORK_ROOT / "warehouse.duckdb"))
    try:
        con.execute(f"CREATE OR REPLACE TABLE dim_customer AS "
                    f"SELECT * FROM read_parquet('{dim_parquet.as_posix()}')")
    finally:
        con.close()
    lo, hi, n = data_coverage()
    progress(f"sales data now covers: {lo} – {hi}  ({n:,} rows)")
    return WORK_ROOT


def data_coverage() -> tuple[str, str, int]:
    """(first_date, last_date, row_count) of the sales currently in the work root."""
    import duckdb
    glob = (WORK_ROOT / "curated" / "sales").as_posix() + "/**/*.parquet"
    try:
        con = duckdb.connect()
        try:
            lo, hi, n = con.execute(
                f"SELECT MIN(\"Date\"::DATE), MAX(\"Date\"::DATE), COUNT(*) "
                f"FROM read_parquet('{glob}', hive_partitioning=1, union_by_name=1)"
            ).fetchone()
        finally:
            con.close()
        return (str(lo or "-"), str(hi or "-"), int(n or 0))
    except Exception:                                      # noqa: BLE001 — empty root
        return ("-", "-", 0)


def clear_data() -> None:
    """Forget all previous uploads (the next run starts fresh)."""
    shutil.rmtree(WORK_ROOT, ignore_errors=True)


def build_reports(keys: list[str],
                  progress: Callable[[str], None] = print) -> list[tuple[str, Path | None, str]]:
    """Run the chosen builders ONE BY ONE against the assembled root.

    Returns ``[(key, output_path_or_None, message)]``. ANALYSIS_HOME is pinned to
    WORK_ROOT before the builders are imported (dsr resolves its root at import).
    """
    os.environ["ANALYSIS_HOME"] = str(WORK_ROOT)
    from . import config as _config
    cfg = _config.load_config(validate=True)

    results: list[tuple[str, Path | None, str]] = []
    for key in keys:                                  # sequential by design
        label = INSTANT_REPORTS.get(key, key)
        progress(f"building {label} ...")
        try:
            params: dict = {}
            if key == "daily":
                from .builders import daily_snapshot as builder
            elif key == "dsr":
                from .builders import dsr as builder
                # the DSR is month-scoped: use the newest month in the uploaded data
                import duckdb as _duck
                with _duck.connect() as _c:
                    params["month"] = _c.execute(
                        f"SELECT strftime(MAX(\"Date\"::DATE), '%Y-%m') FROM "
                        f"read_parquet('{cfg.sales_glob}', hive_partitioning=1, "
                        f"union_by_name=1)").fetchone()[0]
            elif key == "sales_person":
                from .builders import salesperson_gross as builder
                params["split_individual"] = False    # one workbook, no per-person spray
            elif key == "load_report":
                from .builders import load_report as builder
            elif key == "june_target":
                from .builders import june_target as builder
            elif key == "underperformers":
                from .builders import underperformers as builder
            elif key == "salesperson_pack":
                from .builders import salesperson_pack as builder
                # keep the pack inside the instant root, not the user's Downloads
                params["pack_dir"] = WORK_ROOT / "logs" / "Sales Person Packs"
                params["zip_path"] = WORK_ROOT / "logs" / "Sales Person Packs.zip"
            elif key == "iata_worklist":
                from .builders import iata_worklist as builder
            else:
                raise ValueError(f"unknown instant report: {key}")
            out = builder.generate(params, cfg)
            progress(f"  [OK] {Path(out).name}")
            results.append((key, Path(out), "OK"))
        except Exception as exc:                       # noqa: BLE001 — surface per report,
            progress(f"  [FAIL] {label}: {exc}")       # keep building the rest (one-by-one)
            results.append((key, None, f"{type(exc).__name__}: {exc}"))
    return results


def output_dir() -> Path:
    """Where finished instant reports land (= the root's logs/ folder)."""
    return WORK_ROOT / "logs"
