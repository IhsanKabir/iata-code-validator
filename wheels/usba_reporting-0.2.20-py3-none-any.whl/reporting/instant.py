"""
reporting.instant — build reports ON THIS MACHINE from uploaded raw files ("Instant Reports").

The pipeline machine publishes finished workbooks; THIS module lets any exe user
(behind the same Reports password) rebuild them locally from:

  * one or more RAW Zenith sales exports (the daily xlsx), plus
  * the published **Data Kit** (Data_Kit_latest.zip on the share) — the analyst's
    prebuilt dimension masters (dim_customer, zones, commission rates, OTA list),
    so client machines never rebuild the heavy mapping chain.

HOW IT WORKS
------------
1. ``assemble_root(raw_files, kit_zip)`` lays out a synthetic data root under
   %LOCALAPPDATA%/USBA_InstantReports/work/ that LOOKS exactly like E:\\Analysis:
       curated/sales/year=*/month=*/day=*/*.parquet   <- ingested raw files
       curated/dim_customer/dim_customer.parquet      <- from the kit
       reference/...                                  <- from the kit
       warehouse.duckdb                               <- dim_customer table only
2. ``build_reports(keys, progress)`` points ANALYSIS_HOME at that root and runs
   the SAME builder code that publishes the official reports — one by one (the
   analyst's explicit preference), reporting progress per report.

The work root is a FIXED path reused per session and wiped on every assemble:
``builders.dsr`` resolves its data root at IMPORT time, so the path must never
change within one process.

INGEST: a faithful, self-contained subset of scripts/02_ingest_sales.py (sheet
auto-detect, required-column check, date coercion, object->string normalization,
hive partitioning). The full pipeline script remains the authority for the real
warehouse; this one only feeds the throwaway instant root.
"""
from __future__ import annotations

import os
import shutil
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

# ---- layout ------------------------------------------------------------------
WORK_ROOT = Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "USBA_InstantReports" / "work"

# ---- ingest constants (mirrors scripts/pipeline_config.SalesIngestConfig) -----
SHEET_NAME_CANDIDATES = ("Sheet0", "Sheet1", "Sales", "Export")
COL_CUSTOMER_ID = "Customer ID"
COL_DATE = "Date"

# Reports the instant engine can build, in build order. The flight-data reports
# (Load / Target family) work because the Data Kit now ships the flight-loads +
# flight-history parquets. NOTE: target-family numbers are only as complete as
# the UPLOADED sales history (the cascade uses a 5-month trailing window) — use
# APPEND mode to accumulate months for full-accuracy targets.
INSTANT_REPORTS: dict[str, str] = {
    "daily": "Daily Report",
    "dsr": "DSR (month of the data)",
    "sales_person": "Sales-Person Gross",
    "load_report": "Flight Load",
    "june_target": "June Target (capacity)",
    "underperformers": "Underperformers",
    "salesperson_pack": "Sales-Person Target Packs (zip)",
    "iata_worklist": "IATA Worklist",
    # needs the raw VISIT workbook (picked in the UI, or newest "Daily Agency Visit
    # Report*.xlsx" in Downloads). Rankings/MOCAT come from the Data Kit's rank packs,
    # NOT the uploaded sales — so they are complete regardless of upload coverage.
    "visit_tracking": "Agency Visit Tracking",
    # route x issuing-market mix — needs ONLY curated/sales (built from the uploaded raw
    # exports), so it is fully accurate on whatever date range the user uploaded/selects.
    "route_market_mix": "Route x Market Ticket Mix",
    "agency_route_monthly": "Agency x Route Monthly (per Sales Person)",
}


REQUIRED_COLS = (COL_CUSTOMER_ID, COL_DATE)


@dataclass(frozen=True)
class RawCheck:
    """Result of pre-flight-validating one picked file."""
    path: Path
    ok: bool
    sheet: str | None = None
    message: str = ""


_XLNS = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"


def _xlsx_header_cols(xlsx: Path) -> list[str]:
    """First worksheet's header row, stdlib-only — FAST and OFFLINE-safe.

    openpyxl read-only takes ~150s on a 13 MB export (it parses the whole
    shared-strings table on open); DuckDB's read_xlsx needs the `excel` extension
    that a disconnected client exe may not have. So we read the zip directly:
    the first <row> of the sheet, resolving ONLY the shared strings that row
    references (header strings sit at the front of the table, so we stop early).
    ~0.01s even on a 20 MB file.
    """
    import zipfile
    from xml.etree import ElementTree as ET

    with zipfile.ZipFile(xlsx) as z:
        names = z.namelist()
        sheet = ("xl/worksheets/sheet1.xml" if "xl/worksheets/sheet1.xml" in names
                 else next((n for n in names if n.startswith("xl/worksheets/sheet")
                            and n.endswith(".xml")), ""))
        if not sheet:
            return []
        cells: list[tuple[str, object]] = []        # ("s", idx) shared | ("t", text)
        with z.open(sheet) as fh:
            for _ev, el in ET.iterparse(fh, events=("end",)):
                if el.tag == _XLNS + "row":
                    for c in el.findall(_XLNS + "c"):
                        t = c.get("t")
                        if t == "s":
                            v = c.find(_XLNS + "v")
                            cells.append(("s", int(v.text) if v is not None and v.text else -1))
                        elif t == "inlineStr":
                            is_ = c.find(_XLNS + "is")
                            cells.append(("t", "".join(x.text or "" for x in is_.iter(_XLNS + "t")) if is_ is not None else ""))
                        else:
                            v = c.find(_XLNS + "v")
                            cells.append(("t", v.text if v is not None else ""))
                    break
        need = {i for k, i in cells if k == "s" and isinstance(i, int) and i >= 0}
        shared: dict[int, str] = {}
        if need and "xl/sharedStrings.xml" in names:
            hi = max(need)
            with z.open("xl/sharedStrings.xml") as fh:
                i = 0
                for _ev, el in ET.iterparse(fh, events=("end",)):
                    if el.tag == _XLNS + "si":
                        if i in need:
                            shared[i] = "".join(x.text or "" for x in el.iter(_XLNS + "t"))
                        el.clear()
                        if i >= hi:
                            break
                        i += 1
        out = [shared.get(v, "") if k == "s" else str(v or "") for k, v in cells]
    return [c.strip() for c in out]


def validate_raw_file(xlsx) -> RawCheck:
    """Fast, OFFLINE pre-flight: is this a usable Zenith sales export?

    The SINGLE authority for "valid sales file": the real ingest (_read_raw_sales)
    calls it too, so the UI's green/red check can never drift from what the build
    needs. Reads only the header row (see _xlsx_header_cols) — instant on a 20 MB
    export, so it can run the moment files are picked.
    """
    xlsx = Path(xlsx)
    if not xlsx.is_file():
        return RawCheck(xlsx, False, None, "file not found")
    if xlsx.suffix.lower() != ".xlsx":
        return RawCheck(xlsx, False, None, "not an .xlsx file")
    try:
        cols = {c for c in _xlsx_header_cols(xlsx) if c}
    except zipfile.BadZipFile:                      # locked/partial/not-a-real-xlsx
        return RawCheck(xlsx, False, None, "can't open as .xlsx — is it open in Excel, or not a real .xlsx?")
    except Exception as exc:                        # noqa: BLE001 — not a readable xlsx
        return RawCheck(xlsx, False, None, f"can't read as Excel ({type(exc).__name__})")
    if not cols:
        return RawCheck(xlsx, False, None, "no header row found")
    missing = [c for c in REQUIRED_COLS if c not in cols]
    if missing:
        return RawCheck(xlsx, False, None, f"not a sales export — missing: {', '.join(missing)}")
    return RawCheck(xlsx, True, None, f"valid · {len(cols)} columns")


def _read_raw_sales(xlsx: Path):
    """One raw Zenith export -> cleaned DataFrame (date-typed, string-normalized)."""
    import pandas as pd

    chk = validate_raw_file(xlsx)          # single source of truth for validity
    if not chk.ok:
        raise ValueError(f"{Path(xlsx).name}: {chk.message}")
    df = pd.read_excel(xlsx, sheet_name=0, header=0)   # first sheet = the data sheet
    df = df[df[COL_CUSTOMER_ID].notna()].copy()
    df[COL_DATE] = pd.to_datetime(df[COL_DATE], errors="coerce")
    # rows with an unparseable Date keep flowing (year=0 sentinel, same as pipeline)
    df["year"] = df[COL_DATE].dt.year.fillna(0).astype("int32")
    df["month"] = df[COL_DATE].dt.month.fillna(0).astype("int32")
    df["day"] = df[COL_DATE].dt.day.fillna(0).astype("int32")
    df["source_file"] = xlsx.name
    # Some exports lack the per-row segment count; the DSR does
    # COALESCE(seg, 1), but the column must EXIST for the SQL to bind —
    # in the big pipeline union_by_name supplies it from other months.
    if "seg" not in df.columns:
        df["seg"] = pd.array([None] * len(df), dtype="Float64")
    # object -> nullable string so PyArrow never chokes on mixed-type columns
    for c in [c for c in df.columns if df[c].dtype == object]:
        df[c] = df[c].astype("string")
    return df


def assemble_root(raw_files: list[Path], kit_zip: Path,
                  progress: Callable[[str], None] = print,
                  append: bool = False) -> Path:
    """Build (or extend) the synthetic data root from kit + raw files.

    ``append=True`` KEEPS previously uploaded sales and merges the new files in —
    e.g. an earlier upload covered Jun 1-6 and today's file covers Jun 6-12: the
    result covers Jun 1-12. Days present in the NEW upload replace the same days
    from older uploads (the 6th is taken from the newer file, never double-counted).
    The dimension kit is refreshed from the share on every run either way.
    """
    import duckdb
    import pandas as pd

    progress(f"work root: {WORK_ROOT}")
    if WORK_ROOT.exists() and not append:
        shutil.rmtree(WORK_ROOT, ignore_errors=True)
    WORK_ROOT.mkdir(parents=True, exist_ok=True)

    progress(f"unpacking data kit: {Path(kit_zip).name}")
    with zipfile.ZipFile(kit_zip) as zf:
        for member in zf.infolist():                       # zip-slip guard
            dest = (WORK_ROOT / member.filename).resolve()
            if not dest.is_relative_to(WORK_ROOT.resolve()):
                raise ValueError(f"Unsafe path in data kit: {member.filename!r}")
        zf.extractall(WORK_ROOT)
    dim_parquet = WORK_ROOT / "curated" / "dim_customer" / "dim_customer.parquet"
    if not dim_parquet.is_file():
        raise FileNotFoundError("Data kit is missing dim_customer.parquet — "
                                "re-publish the kit from the pipeline machine.")

    sales_dir = WORK_ROOT / "curated" / "sales"
    sales_dir.mkdir(parents=True, exist_ok=True)
    frames = []
    for f in raw_files:
        progress(f"ingesting {Path(f).name} ...")
        frames.append(_read_raw_sales(Path(f)))
    allf = pd.concat(frames, ignore_index=True)

    if append:
        # newest upload wins per DAY: drop existing partitions for every (y,m,d)
        # the new data carries, so overlapping days are replaced, never doubled.
        new_days = allf[["year", "month", "day"]].drop_duplicates()
        replaced = 0
        for y, m, d in new_days.itertuples(index=False):
            part = sales_dir / f"year={y}" / f"month={m}" / f"day={d}"
            if part.is_dir():
                shutil.rmtree(part, ignore_errors=True)
                replaced += 1
        if replaced:
            progress(f"append: {replaced} overlapping day(s) replaced by the new upload")

    progress(f"{len(allf):,} sale rows -> parquet partitions"
             + (" (added to previous uploads)" if append else ""))
    allf.to_parquet(sales_dir, partition_cols=["year", "month", "day"], index=False)

    progress("building mini warehouse (dim_customer)")
    con = duckdb.connect(str(WORK_ROOT / "warehouse.duckdb"))
    try:
        con.execute(f"CREATE OR REPLACE TABLE dim_customer AS "
                    f"SELECT * FROM read_parquet('{dim_parquet.as_posix()}')")
    finally:
        con.close()
    lo, hi, n = data_coverage()
    progress(f"sales data now covers: {lo} – {hi}  ({n:,} rows)")
    return WORK_ROOT


def data_coverage() -> tuple[str, str, int]:
    """(first_date, last_date, row_count) of the sales currently in the work root."""
    import duckdb
    glob = (WORK_ROOT / "curated" / "sales").as_posix() + "/**/*.parquet"
    try:
        con = duckdb.connect()
        try:
            lo, hi, n = con.execute(
                f"SELECT MIN(\"Date\"::DATE), MAX(\"Date\"::DATE), COUNT(*) "
                f"FROM read_parquet('{glob}', hive_partitioning=1, union_by_name=1)"
            ).fetchone()
        finally:
            con.close()
        return (str(lo or "-"), str(hi or "-"), int(n or 0))
    except Exception:                                      # noqa: BLE001 — empty root
        return ("-", "-", 0)


def clear_data() -> None:
    """Forget all previous uploads (the next run starts fresh)."""
    shutil.rmtree(WORK_ROOT, ignore_errors=True)


@dataclass(frozen=True)
class SnapshotInfo:
    """Result of exporting a portable base snapshot of the accumulated sales."""
    path: Path
    rows: int
    first_date: str
    last_date: str


# the engine adds these during ingest; a portable snapshot drops them so a re-ingest
# re-derives them cleanly instead of treating stale partition/source columns as data.
_DERIVED_COLS = ("source_file", "year", "month", "day")


def export_base_snapshot(dest_path, *, max_rows: int = 1_000_000) -> SnapshotInfo:
    """Export everything currently accumulated to one portable, re-ingestable .xlsx.

    The file is a clean raw-schema export (engine-derived columns dropped) that
    ``assemble_root`` reads straight back in as a BASE — so a user can keep "data
    through last week" as a single file and re-attach it next week, instead of
    relying on the invisible work root surviving "Clear stored data" or a new machine.
    Refuses an empty store or a dataset too large for one worksheet (rather than
    silently truncating).
    """
    import duckdb
    import pandas as pd

    glob = (WORK_ROOT / "curated" / "sales").as_posix() + "/**/*.parquet"
    con = duckdb.connect()
    try:
        df = con.execute(
            f"SELECT * FROM read_parquet('{glob}', hive_partitioning=1, union_by_name=1)"
        ).df()
    except duckdb.Error as exc:               # empty root -> friendly message below
        if "No files found" not in str(exc):
            raise
        df = pd.DataFrame()
    finally:
        con.close()

    rows = int(len(df))
    if rows == 0:
        raise ValueError("Nothing to save — no data is accumulated yet. Build once first.")
    if rows > max_rows:
        raise ValueError(f"Accumulated data is too large for one .xlsx snapshot "
                         f"({rows:,} rows > {max_rows:,}).")
    for col in REQUIRED_COLS:
        if col not in df.columns:
            raise ValueError(f"Accumulated data is missing the required '{col}' column.")

    out = df[[c for c in df.columns if c not in _DERIVED_COLS]]
    # Date is stored as real datetimes; take chronological extents, render ISO. Parse
    # dd/mm-first only on the off chance Date ever arrives as a string.
    date_col = out[COL_DATE]
    if not pd.api.types.is_datetime64_any_dtype(date_col):
        date_col = pd.to_datetime(date_col, errors="coerce", dayfirst=True)
    if date_col.notna().any():
        first_date = date_col.min().strftime("%Y-%m-%d")
        last_date = date_col.max().strftime("%Y-%m-%d")
    else:
        first_date = last_date = "-"

    dest_path = Path(dest_path)
    dest_path.parent.mkdir(parents=True, exist_ok=True)
    out.to_excel(dest_path, index=False)
    return SnapshotInfo(dest_path, rows, first_date, last_date)


def default_snapshot_name(last_date: str | None) -> str:
    """A friendly default filename for a saved base snapshot."""
    stamp = (last_date or "").replace("/", "-").strip() or "latest"
    return f"USBA_base_through_{stamp}.xlsx"


def build_reports(keys: list[str],
                  progress: Callable[[str], None] = print,
                  output_dir: Path | None = None,
                  visit_source: str | None = None) -> list[tuple[str, Path | None, str]]:
    """Run the chosen builders ONE BY ONE against the assembled root.

    Returns ``[(key, output_path_or_None, message)]``. ANALYSIS_HOME is pinned to
    WORK_ROOT before the builders are imported (dsr resolves its root at import).

    ``output_dir`` (optional) redirects every finished report into a folder the user
    chose: set via REPORT_OUTPUT_DIR (which config.output_dir honours) for the build
    and restored afterwards so it never leaks into other features. The salesperson
    pack — otherwise forced into the work root — is pointed there too so everything
    lands together.
    """
    os.environ["ANALYSIS_HOME"] = str(WORK_ROOT)
    pack_root = WORK_ROOT / "logs"
    _prior_out = None
    if output_dir is not None:
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        _prior_out = os.environ.get("REPORT_OUTPUT_DIR")
        os.environ["REPORT_OUTPUT_DIR"] = str(output_dir)
        pack_root = output_dir
    try:
        from . import config as _config
        cfg = _config.load_config(validate=True)

        results: list[tuple[str, Path | None, str]] = []
        for key in keys:                                  # sequential by design
            label = INSTANT_REPORTS.get(key, key)
            progress(f"building {label} ...")
            try:
                params: dict = {}
                if key == "daily":
                    from .builders import daily_snapshot as builder
                elif key == "dsr":
                    from .builders import dsr as builder
                    # the DSR is month-scoped: use the newest month in the uploaded data
                    import duckdb as _duck
                    with _duck.connect() as _c:
                        params["month"] = _c.execute(
                            f"SELECT strftime(MAX(\"Date\"::DATE), '%Y-%m') FROM "
                            f"read_parquet('{cfg.sales_glob}', hive_partitioning=1, "
                            f"union_by_name=1)").fetchone()[0]
                elif key == "sales_person":
                    from .builders import salesperson_gross as builder
                    params["split_individual"] = False    # one workbook, no per-person spray
                elif key == "load_report":
                    from .builders import load_report as builder
                elif key == "june_target":
                    from .builders import june_target as builder
                elif key == "underperformers":
                    from .builders import underperformers as builder
                elif key == "salesperson_pack":
                    from .builders import salesperson_pack as builder
                    # keep the pack with the other outputs (chosen folder, else work root)
                    params["pack_dir"] = pack_root / "Sales Person Packs"
                    params["zip_path"] = pack_root / "Sales Person Packs.zip"
                elif key == "iata_worklist":
                    from .builders import iata_worklist as builder
                elif key == "visit_tracking":
                    from .builders import visit_tracking as builder
                    if visit_source:                  # None -> builder auto-picks from Downloads
                        params["source"] = visit_source
                elif key == "route_market_mix":
                    from .builders import route_market_mix as builder
                elif key == "agency_route_monthly":
                    from .builders import agency_route_monthly as builder
                    # no date params -> the builder spans the whole UPLOADED range, which is
                    # exactly what the user assembled here (curated/sales only, no gold needed)
                else:
                    raise ValueError(f"unknown instant report: {key}")
                out = builder.generate(params, cfg)
                progress(f"  [OK] {Path(out).name}")
                results.append((key, Path(out), "OK"))
            except Exception as exc:                       # noqa: BLE001 — surface per report,
                progress(f"  [FAIL] {label}: {exc}")       # keep building the rest (one-by-one)
                results.append((key, None, f"{type(exc).__name__}: {exc}"))
        return results
    finally:
        if output_dir is not None:
            if _prior_out is None:
                os.environ.pop("REPORT_OUTPUT_DIR", None)
            else:
                os.environ["REPORT_OUTPUT_DIR"] = _prior_out


def output_dir() -> Path:
    """Where finished instant reports land (= the root's logs/ folder)."""
    return WORK_ROOT / "logs"
