"""
reporting.builders.route_market_mix — ROUTE / FLIGHT / ZONE x ISSUING-MARKET ticket mix.

Two sheets, both with a COUNT and SHARE (%) per MARKET (where the ticket was sold):
  1. "Route x Flight x Market"  — each route, with its FLIGHT rows indented beneath.
  2. "Zone x Route x Flight"    — each selling ZONE, its routes, and their flights.
Every child level is the same ticket population as its parent, so children always sum to it.

FLIGHT ROWS ARE LABELLED HONESTLY
    Tickets carry NO flight number (verified across every text column of the sales export), so a
    ticket can only be pinned to a specific flight when that route-day ran ONE flight — busy routes
    (DAC-CXB) run up to 9/day. Single-flight days show the real number (e.g. BS361); the rest read
    "N flights". We never split tickets across flights, because that would be invented data.

ZONE is the SELLING AGENCY's sales zone (dim_customer, shipped in the Data Kit). Customers with no
    zone are direct/walk-in (web, app, counter, call-centre) and form their own bucket.

WHY SALE CURRENCY DEFINES "MARKET"
    The market a ticket was ISSUED in is read from ``Sale currency`` (BDT -> Bangladesh,
    AED -> UAE, SAR -> Saudi, ...). That is the reliable signal: "Agency Country" is
    route-derived for direct/walk-in bookings (a passenger who merely FLEW to China gets
    stamped "China"), so grouping on it would misattribute issuance. Currency is where the
    money was taken, so it is the honest "sold in".

DATA SOURCE
    ``curated/sales`` only (never gold) — so this builds BOTH on the pipeline machine and
    inside the exe's Instant Reports engine, which assembles a curated/sales root from the
    uploaded raw exports + the Data Kit.

PARAMS
    date_from / date_to : 'YYYY-MM-DD' (inclusive). Omitted -> the full span present in the data.

Public entry point: ``generate(params, cfg) -> Path``.
"""
from __future__ import annotations

from pathlib import Path

import duckdb
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from ..config import Config, load_config

NAVY, GREY, WHITE, AMBER, BLUE = "1F3864", "D9E1F2", "FFFFFF", "FFF2CC", "2E5E9E"
BORDER = Border(*([Side(style="thin", color="BFBFBF")] * 4))

# sale currency -> the market the ticket was issued in
MARKET_OF = {
    "BDT": "Bangladesh", "AED": "UAE", "SAR": "Saudi Arabia", "MYR": "Malaysia",
    "SGD": "Singapore", "OMR": "Oman", "QAR": "Qatar", "INR": "India", "CNY": "China",
    "MVR": "Maldives", "THB": "Thailand", "GBP": "UK", "USD": "USD-sale",
}


def _case_sql(col: str = '"Sale currency"') -> str:
    whens = " ".join(f"WHEN '{c}' THEN '{m}'" for c, m in MARKET_OF.items())
    return f"CASE {col} {whens} ELSE COALESCE({col}, '(unknown)') END"


def _c(ws, r, col, v, *, bold=False, fill=None, fmt=None, color="000000", align="left", size=9):
    x = ws.cell(r, col, v)
    x.font = Font(bold=bold, size=size, color=color, name="Calibri")
    x.alignment = Alignment(horizontal=align, vertical="center")
    x.border = BORDER
    if fill:
        x.fill = PatternFill("solid", fgColor=fill)
    if fmt:
        x.number_format = fmt
    return x


# Residual buckets for tickets that cannot be pinned to one flight number. Named (not blank) so
# they read as a deliberate statement in the sheet, and sorted last by _flight_order().
AMBIG = "— 2+ flights that day (not attributable) —"
NOSCHED = "— no flight schedule for that date —"


def _flight_day_map(cfg: Config, con):
    """(route, flight_date) -> FLIGHT NUMBER, but only where that route-day ran exactly ONE flight.

    Ticket rows carry a flight DATE but no flight NUMBER (verified across every text column), and
    neither flight mart exposes a ticket/PNR key — so there is no join that resolves a ticket to a
    specific flight. The one case that IS certain is arithmetic rather than inference: if the route
    flew once that day, every ticket for that route-day was on that flight. That covers ~52% of
    tickets; busy routes (DAC-CXB runs 9/day) fall into AMBIG rather than being split on a guess.

    Returns a DataFrame [rt, fd, fkey] to JOIN in SQL — mapping in SQL (not pandas) keeps the
    COUNT(DISTINCT "Ticket number") honest at the new per-flight-number grain.
    """
    fl = cfg.data_root / "curated" / "flight_loads"
    if not fl.is_dir():
        return None
    try:
        return con.sql(f"""
            SELECT leg_route AS rt, CAST(flight_date AS DATE) AS fd,
                   CASE WHEN COUNT(DISTINCT flight_number) = 1
                        THEN MIN(flight_number) ELSE '{AMBIG}' END AS fkey
            FROM read_parquet('{(fl / "*.parquet").as_posix()}') GROUP BY 1, 2
        """).df()
    except Exception:                    # mart absent/unreadable -> every row lands in NOSCHED
        return None


def _flight_order(name: str) -> tuple:
    """Real flight numbers first (BS105, BS337 ...), residual buckets pinned to the bottom."""
    return (1, name) if name.startswith("—") else (0, name)


def fetch(cfg: Config, date_from: str | None, date_to: str | None, basis: str = "issue"):
    """basis='issue'  -> window filters the ISSUE date (tickets SOLD in the period).
       basis='flight' -> window filters the FLIGHT date (flights OPERATING in the period), which
       keeps the per-flight rows bounded (~5 dates/route vs ~43 when scoped by issue date)."""
    sales = (cfg.data_root / "curated" / "sales" / "**" / "*.parquet").as_posix()
    src = f"read_parquet('{sales}', hive_partitioning=1, union_by_name=1)"
    datecol = '"Flight date"' if basis == "flight" else '"Date"'
    con = duckdb.connect()
    span = con.sql(f"SELECT MIN(CAST({datecol} AS DATE)), MAX(CAST({datecol} AS DATE)) FROM {src}").fetchone()
    lo = str(date_from or span[0])[:10]
    hi = str(date_to or span[1])[:10]
    # canonical sector: Domestic only when BOTH endpoints are BD stations (the raw "Market" column
    # is unreliable — one stray row + MAX() flips a whole route, 'International' > 'Domestic').
    sector_sql = ("MAX(CASE WHEN \"Departure airport\" IN ('DAC','CGP','CXB','ZYL','JSR','RJH','BZL','SPD') "
                  "      AND \"Arrival airport\"   IN ('DAC','CGP','CXB','ZYL','JSR','RJH','BZL','SPD') "
                  "     THEN 'Domestic' ELSE 'International' END)")
    where = ('"Transaction" = \'Ticket payment\' AND "Ticket number" IS NOT NULL '
             'AND "Departure airport" IS NOT NULL AND "Arrival airport" IS NOT NULL '
             f"AND CAST({datecol} AS DATE) BETWEEN DATE '{lo}' AND DATE '{hi}'")
    rows = con.sql(f"""
        SELECT "Departure airport" || '-' || "Arrival airport" AS route,
               {sector_sql} AS sector, {_case_sql()} AS market,
               COUNT(DISTINCT "Ticket number") AS tkts
        FROM {src} WHERE {where} GROUP BY 1, 3
    """).df()
    # per-FLIGHT-NUMBER rows under each route — same ticket population, so sub-rows sum to the
    # route total. The LEFT JOIN onto fmap turns a flight DATE into a flight NUMBER wherever the
    # route-day was unambiguous; everything else falls into the two named residual buckets.
    fmap = _flight_day_map(cfg, con)
    if fmap is not None and len(fmap):
        con.register("fmap", fmap)
        fjoin = "LEFT JOIN fmap f ON f.rt = {a}\"Departure airport\" || '-' || {a}\"Arrival airport\" " \
                "AND f.fd = CAST({a}\"Flight date\" AS DATE)"
        fexpr = f"COALESCE(f.fkey, '{NOSCHED}')"
    else:                                          # no flight mart -> one honest bucket, no dates
        fjoin, fexpr = "", f"'{NOSCHED}'"
    legs = con.sql(f"""
        SELECT "Departure airport" || '-' || "Arrival airport" AS route,
               {fexpr} AS flight, {_case_sql()} AS market,
               COUNT(DISTINCT "Ticket number") AS tkts
        FROM {src} {fjoin.format(a='')}
        WHERE {where} AND "Flight date" IS NOT NULL GROUP BY 1, 2, 3
    """).df()

    # LOAD-FILE FACTS per flight number. The load file (curated/flight_loads, ingested from the
    # Zenith Flight Loads pull) carries `booked` per flight — real passenger counts even on days
    # with 9 departures, where tickets are NOT attributable. It has no currency/agency column, so
    # it can never supply a market split; it only tells us how big each flight was.
    #
    # Scoped to the SAME (route, flight-date) pairs the tickets touch, so "Seats Booked" and the
    # ticket columns describe the same days — otherwise an 'issue'-basis window (whose flight dates
    # run months ahead) would compare a full schedule against a partial ticket set.
    floads = None
    if fmap is not None and len(fmap):
        fdays = con.sql(f"""
            SELECT DISTINCT "Departure airport" || '-' || "Arrival airport" AS rt,
                   CAST("Flight date" AS DATE) AS fd
            FROM {src} WHERE {where} AND "Flight date" IS NOT NULL
        """).df()
        con.register("fdays", fdays)
        fl = (cfg.data_root / "curated" / "flight_loads" / "*.parquet").as_posix()
        try:
            floads = con.sql(f"""
                SELECT l.leg_route AS route, l.flight_number AS flight,
                       SUM(l.booked) AS booked, SUM(l.capacity) AS capacity,
                       COUNT(DISTINCT l.flight_date) AS days
                FROM read_parquet('{fl}') l
                JOIN fdays ON fdays.rt = l.leg_route AND fdays.fd = CAST(l.flight_date AS DATE)
                GROUP BY 1, 2
            """).df()
        except Exception:                          # load mart unreadable -> ticket columns only
            floads = None

    # ZONE x ROUTE x FLIGHT — zone is an AGENCY attribute, so it comes from dim_customer (shipped
    # in the Data Kit, so this still works in Instant Reports). "zone" is a DuckDB reserved word →
    # always quoted/aliased. Customers with no zone are direct/walk-in, kept as their own bucket.
    dim = cfg.data_root / "curated" / "dim_customer" / "dim_customer.parquet"
    zlegs = None
    if dim.is_file():
        D = f"read_parquet('{dim.as_posix()}')"
        join = ('regexp_replace(CAST(s."Customer ID" AS VARCHAR),\'[.]0+$\',\'\')'
                ' = CAST(d.customer_id AS VARCHAR)')
        zw = where.replace('"Transaction"', 's."Transaction"').replace('"Ticket number"', 's."Ticket number"') \
                  .replace('"Departure airport"', 's."Departure airport"') \
                  .replace('"Arrival airport"', 's."Arrival airport"') \
                  .replace('"Flight date"', 's."Flight date"').replace('"Date"', 's."Date"')
        zlegs = con.sql(f"""
            SELECT COALESCE(NULLIF(d."zone", ''), '(no zone - direct/walk-in)') AS zn,
                   s."Departure airport" || '-' || s."Arrival airport" AS route,
                   {fexpr} AS flight,
                   {_case_sql('s."Sale currency"')} AS market,
                   COUNT(DISTINCT s."Ticket number") AS tkts
            FROM {src} s LEFT JOIN {D} d ON {join} {fjoin.format(a='s.')}
            WHERE {zw} AND s."Flight date" IS NOT NULL
            GROUP BY 1, 2, 3, 4
        """).df()
        sp = con.sql(f"""SELECT COALESCE(NULLIF("zone", ''), '(no zone - direct/walk-in)') AS zn,
                                MIN(sales_person) AS sp FROM {D} GROUP BY 1""").df()
        zlegs = zlegs.merge(sp, on="zn", how="left")
    return lo, hi, rows, legs, zlegs, floads


def build(lo: str, hi: str, rows, legs=None, basis: str = "issue", zlegs=None,
          floads=None) -> Workbook:
    """Route rows (bold) with their FLIGHT rows indented beneath. Flight rows are the SAME ticket
    population split by flight date, so they always sum back to the route's total."""
    mkt_tot = rows.groupby("market").tkts.sum().sort_values(ascending=False)
    markets = list(mkt_tot.index)
    piv = rows.pivot_table(index="route", columns="market", values="tkts",
                           aggfunc="sum", fill_value=0)
    sector = rows.groupby("route").sector.max()
    piv["__total"] = piv.sum(axis=1)
    piv = piv.sort_values("__total", ascending=False)
    lpiv = None
    if legs is not None and len(legs):
        lpiv = legs.pivot_table(index=["route", "flight"], columns="market",
                                values="tkts", aggfunc="sum", fill_value=0)
        lpiv["__total"] = lpiv.sum(axis=1)

    wb = Workbook()
    ws = wb.active
    ws.title = "Route x Flight x Market"
    ws.sheet_view.showGridLines = False
    ncols = 6 + 2 * len(markets)
    scope = "FLIGHT date" if basis == "flight" else "ISSUE date"
    _c(ws, 1, 1, f"ROUTE x FLIGHT x ISSUING-MARKET TICKET MIX  ·  {lo} to {hi}  (window on {scope})",
       bold=True, fill=NAVY, color=WHITE, size=11)
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=ncols)
    _c(ws, 2, 1, "Tickets = distinct ticket numbers on 'Ticket payment' rows. MARKET = where the ticket was "
                 "ISSUED, from the SALE CURRENCY (reliable 'sold in'; Agency Country is route-derived for "
                 "direct bookings). % is of that row's own total. FLIGHT rows split the route by flight "
                 "NUMBER and sum back to it. Ticket rows carry a flight date but NO flight number, so a "
                 "ticket is pinned to a real flight (BS105, BS337 ...) only where that route-day flew once "
                 "— certain, not estimated. Days with 2+ flights are unknowable and sit in the labelled "
                 "residual row rather than being split on a guess. SEATS BOOKED / LF% come from the load "
                 "file and are real for EVERY flight (incl. unattributable days), but that file has no "
                 "currency column — so it can size a flight, never split its market. Seats = passengers, "
                 "Tickets = itineraries: the two columns are different units and will not match.",
       size=8, color="595959")
    ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=ncols)

    for j, h in enumerate(["Route", "Flight No.", "Sector", "Seats Booked", "LF %",
                           "Tickets (pinned)"], 1):
        _c(ws, 4, j, h, bold=True, fill=NAVY, color=WHITE, align="center")
    for k, m in enumerate(markets):
        _c(ws, 4, 7 + 2 * k, f"{m} #", bold=True, fill=NAVY, color=WHITE, align="center", size=8)
        _c(ws, 4, 8 + 2 * k, f"{m} %", bold=True, fill=NAVY, color=WHITE, align="center", size=8)
    for col, w in [("A", 12), ("B", 26), ("C", 13), ("D", 12), ("E", 8), ("F", 14)]:
        ws.column_dimensions[col].width = w
    for c in range(7, ncols + 1):
        ws.column_dimensions[get_column_letter(c)].width = 11

    def _mkt_cells(r, total, getter, *, fill=None, bold=False, color="000000"):
        for k, m in enumerate(markets):
            n = int(getter(m))
            _c(ws, r, 7 + 2 * k, n or None, fill=fill, bold=bold, color=color,
               fmt="#,##0", align="right")
            pct = (n / total) if total and n else None
            hot = fill if (fill or bold) else (AMBER if pct and pct >= 0.10 else None)
            _c(ws, r, 8 + 2 * k, pct, fill=hot, bold=bold, color=color, fmt="0.0%", align="right")

    # load facts keyed (route, flight number) -> (booked, capacity, days); empty when no load mart
    LD = {}
    if floads is not None and len(floads):
        LD = {(t.route, t.flight): (int(t.booked or 0), int(t.capacity or 0), int(t.days or 0))
              for t in floads.itertuples()}

    r = 5
    for route, row in piv.iterrows():
        total = int(row["__total"])
        rb = sum(v[0] for (rt, _f), v in LD.items() if rt == route)
        rc = sum(v[1] for (rt, _f), v in LD.items() if rt == route)
        _c(ws, r, 1, route, fill=GREY, bold=True)
        _c(ws, r, 2, "— all flights —", fill=GREY, size=8)
        _c(ws, r, 3, str(sector.get(route, "")), fill=GREY, align="center", size=8)
        _c(ws, r, 4, rb or None, fill=GREY, fmt="#,##0", align="right", bold=True)
        _c(ws, r, 5, (rb / rc) if rc else None, fill=GREY, fmt="0%", align="right", bold=True)
        _c(ws, r, 6, total, fill=GREY, fmt="#,##0", align="right", bold=True)
        _mkt_cells(r, total, lambda m: row.get(m, 0), fill=GREY, bold=True)
        r += 1

        # every flight the LOAD FILE says operated these days, plus any residual ticket buckets —
        # so a flight appears with its real seats even when its tickets aren't attributable
        sub = lpiv.xs(route, level=0) if (lpiv is not None
                                          and route in lpiv.index.get_level_values(0)) else None
        keys = {f for (rt, f) in LD if rt == route} | (set(sub.index) if sub is not None else set())
        for flight in sorted(keys, key=_flight_order):
            bk, cp, dy = LD.get((route, flight), (0, 0, 0))
            lrow = sub.loc[flight] if (sub is not None and flight in sub.index) else None
            ltot = int(lrow["__total"]) if lrow is not None else 0
            _c(ws, r, 1, "")
            _c(ws, r, 2, f"   {flight}" + (f"   ({dy}d)" if dy > 1 else ""), size=8)
            _c(ws, r, 3, "")
            # a flight with capacity but 0 booked is REAL (it flew empty) -> show 0, not blank;
            # blank is reserved for "the load file says nothing about this row"
            _c(ws, r, 4, bk if cp else None, fmt="#,##0", align="right")
            _c(ws, r, 5, (bk / cp) if cp else None, fmt="0%", align="right")
            _c(ws, r, 6, ltot or None, fmt="#,##0", align="right")
            if lrow is not None:
                _mkt_cells(r, ltot, lambda m: lrow.get(m, 0))
            else:                                  # flight flew, but no ticket is pinned to it
                for k in range(len(markets)):
                    _c(ws, r, 7 + 2 * k, None); _c(ws, r, 8 + 2 * k, None)
            r += 1

    gt = int(piv["__total"].sum())
    _c(ws, r, 1, "ALL ROUTES", bold=True, fill=NAVY, color=WHITE)
    for c_ in (2, 3, 4, 5):
        _c(ws, r, c_, "", fill=NAVY)
    _c(ws, r, 6, gt, bold=True, fill=NAVY, color=WHITE, fmt="#,##0", align="right")
    _mkt_cells(r, gt, lambda m: piv[m].sum() if m in piv else 0,
               fill=NAVY, bold=True, color=WHITE)
    ws.freeze_panes = "G5"
    ws.auto_filter.ref = f"A4:{get_column_letter(ncols)}{r-1}"
    if zlegs is not None and len(zlegs):
        _zone_sheet(wb, lo, hi, zlegs, markets, basis)
    return wb


def _zone_sheet(wb, lo, hi, zlegs, markets, basis) -> None:
    """Second sheet: ZONE -> ROUTE -> FLIGHT, each with the same market count/% columns.
    Every level is the same ticket population, so children always sum to their parent."""
    ws = wb.create_sheet("Zone x Route x Flight")
    ws.sheet_view.showGridLines = False
    ncols = 5 + 2 * len(markets)
    scope = "FLIGHT date" if basis == "flight" else "ISSUE date"
    _c(ws, 1, 1, f"ZONE x ROUTE x FLIGHT x ISSUING-MARKET  ·  {lo} to {hi}  (window on {scope})",
       bold=True, fill=NAVY, color=WHITE, size=11)
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=ncols)
    _c(ws, 2, 1, "ZONE = the SELLING AGENCY's sales zone (from dim_customer). Customers with no zone are "
                 "direct/walk-in (web, app, counter, call-centre) and are kept as their own bucket. Each "
                 "level sums to its parent. Flight rows carry a real flight number only where that "
                 "route-day flew once; days with 2+ flights are not attributable (tickets carry no "
                 "flight number) and sit in the labelled residual row.",
       size=8, color="595959")
    ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=ncols)
    for j, h in enumerate(["Zone", "Sales Person", "Route", "Flight No.", "Total Tickets"], 1):
        _c(ws, 4, j, h, bold=True, fill=NAVY, color=WHITE, align="center")
    for k, m in enumerate(markets):
        _c(ws, 4, 6 + 2 * k, f"{m} #", bold=True, fill=NAVY, color=WHITE, align="center", size=8)
        _c(ws, 4, 7 + 2 * k, f"{m} %", bold=True, fill=NAVY, color=WHITE, align="center", size=8)
    for col, w in [("A", 15), ("B", 24), ("C", 12), ("D", 24), ("E", 12)]:
        ws.column_dimensions[col].width = w
    for c in range(6, ncols + 1):
        ws.column_dimensions[get_column_letter(c)].width = 11

    def cells(r, total, get, *, fill=None, bold=False, color="000000"):
        for k, m in enumerate(markets):
            n = int(get(m))
            _c(ws, r, 6 + 2 * k, n or None, fill=fill, bold=bold, color=color, fmt="#,##0", align="right")
            pct = (n / total) if total and n else None
            _c(ws, r, 7 + 2 * k, pct, fill=fill, bold=bold, color=color, fmt="0.0%", align="right")

    def wide(df):                                    # market -> tickets for a slice
        s = df.groupby("market").tkts.sum()
        return (int(s.sum()), lambda m: s.get(m, 0))

    r = 5
    for zn, ztot in (zlegs.groupby("zn").tkts.sum().sort_values(ascending=False)).items():
        zdf = zlegs[zlegs.zn == zn]
        tot, get = wide(zdf)
        _c(ws, r, 1, zn, bold=True, fill=BLUE, color=WHITE)
        _c(ws, r, 2, str(zdf.sp.iloc[0] or "")[:30], fill=BLUE, color=WHITE, size=8)
        _c(ws, r, 3, "— all routes —", fill=BLUE, color=WHITE, size=8)
        _c(ws, r, 4, "", fill=BLUE)
        _c(ws, r, 5, tot, bold=True, fill=BLUE, color=WHITE, fmt="#,##0", align="right")
        cells(r, tot, get, fill=BLUE, bold=True, color=WHITE)
        r += 1
        for route, _rt in (zdf.groupby("route").tkts.sum().sort_values(ascending=False)).items():
            rdf = zdf[zdf.route == route]
            rtot, rget = wide(rdf)
            _c(ws, r, 1, ""); _c(ws, r, 2, "")
            _c(ws, r, 3, route, fill=GREY, bold=True)
            _c(ws, r, 4, "— all flights —", fill=GREY, size=8)
            _c(ws, r, 5, rtot, fill=GREY, bold=True, fmt="#,##0", align="right")
            cells(r, rtot, rget, fill=GREY, bold=True)
            r += 1
            for flight in sorted(rdf.flight.unique(), key=_flight_order):
                fdf = rdf[rdf.flight == flight]
                ftot, fget = wide(fdf)
                for c_ in (1, 2, 3):
                    _c(ws, r, c_, "")
                _c(ws, r, 4, f"   {flight}", size=8)
                _c(ws, r, 5, ftot, fmt="#,##0", align="right")
                cells(r, ftot, fget)
                r += 1
    ws.freeze_panes = "F5"
    ws.auto_filter.ref = f"A4:{get_column_letter(ncols)}{r-1}"


def _save_locktolerant(wb: Workbook, path: Path) -> Path:
    """Save the workbook, but never fail just because the previous copy is OPEN in Excel
    (a normal thing for a report a user rebuilds) — fall back to a '__new' suffixed name.
    Mirrors report_kit.save_locktolerant, reimplemented here so the wheel stays standalone."""
    try:
        wb.save(path)
        return path
    except PermissionError:
        for i in range(1, 50):
            alt = path.with_name(f"{path.stem}__new{'' if i == 1 else i}{path.suffix}")
            try:
                wb.save(alt)
                return alt
            except PermissionError:
                continue
        raise


def generate(params: dict | None = None, cfg: Config | None = None) -> Path:
    params = params or {}
    cfg = cfg or load_config(validate=True)
    basis = str(params.get("basis") or "issue").lower()
    lo, hi, rows, legs, zlegs, floads = fetch(cfg, params.get("date_from"),
                                              params.get("date_to"), basis)
    wb = build(lo, hi, rows, legs, basis, zlegs, floads)
    out_dir = Path(params.get("out_dir") or cfg.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    return _save_locktolerant(wb, out_dir / f"Route_Market_Mix_{lo}_to_{hi}.xlsx")
