"""
reporting.builders.visit_tracking — turn the per-salesperson "Daily Agency Visit Report"
workbook into one tracking report and tie it to actual agency sales from the gold.

INPUT: the visit workbook (one sheet per sales rep; each sheet has a header block then rows of
       Date | Sl | Name of Agent | Contact | Designation | Contact No | Location | Productivity |
       Most Selling Route). Column positions are detected from each sheet's own header row —
       the sheets are NOT uniform. `params["source"]` selects the workbook; when omitted the
       newest "Daily Agency Visit Report*.xlsx" in ~/Downloads is used (the analyst drops the
       fresh export there before the morning publish run).
OUTPUT (cfg.output_dir): Agency_Visit_Tracking_<MonYYYY>.xlsx with sheets:
   Summary · Day-wise · By Salesperson · Rep x Day · Rep Agency Detail ·
   Top 15 Domestic · Top 15 International · Data Quality · Visit Log.

Top-15 agents are ranked by 2026-YTD net sales per SECTOR from the gold (BD agencies), then
matched to the visit log by a NORMALISED-name fuzzy match (see _match for the rules — each one
fixes a real false-positive/-negative found in the Jun-2026 audit). The matched names are shown
in the sheet for eyeball verification, and every parser correction lands on the Data Quality
sheet so the numbers stay auditable.

Public entry point: ``generate(params, cfg) -> Path``.
CLI wrapper: ``scripts/_build_visit_tracking_report.py ["path\\to\\visit.xlsx"]``.
"""
from __future__ import annotations

import re
import sys
from difflib import SequenceMatcher
from pathlib import Path

import duckdb
import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from ..config import Config, load_config

DOWNLOADS = Path.home() / "Downloads"
RANK_START = "2026-01-01"          # rank top agents by 2026-YTD sales
CR = 1e7

NAVY, WHITE, GREEN, RED = "1F3864", "FFFFFF", "C6EFCE", "FFC7CE"
BORDER = Border(*[Side(style="thin", color="D9D9D9")] * 4)
# generic words dropped before name matching (keep the distinctive token(s))
GEN = set("LTD LIMITED PVT TOURS TOUR TRAVELS TRAVEL AIR INTERNATIONAL INTL AND OVERSEAS AVIATION "
          "SERVICES SERVICE HOLIDAYS COM BEST4FLY TRADING ENTERPRISE AGENCY TICKETING CORPORATION "
          "CO THE NON IATA COMPANY TOURISM LLC".split())
# Gulf sheets prefix agency names with the station country (AE Akbar..., OM Akbar...) — the same
# brand's Dubai and Muscat branches are DIFFERENT agencies, so a prefix mismatch vetoes the match
_CTRY_PFX = {"AE", "OM", "SA", "QA", "KW", "BH", "MY", "SG"}


def _norm(s) -> str:
    toks = [t for t in re.sub(r"[^A-Z0-9 ]", " ", str(s).upper()).split() if t and t not in GEN]
    # collapse initialism runs so 'T.A. Air Service' ('T','A') meets 'Ta Air' ('TA') as one token
    out: list[str] = []
    buf: list[str] = []
    for t in toks:
        if len(t) == 1:
            buf.append(t)
        else:
            if buf:
                out.append("".join(buf)); buf = []
            out.append(t)
    if buf:
        out.append("".join(buf))
    return " ".join(out)


# legal-suffix tokens stripped off the END of the full form (keeps generic words like AIR/TOURS
# so all-generic names — e.g. "International Travel Corporation" — still have something to match on)
_SUFFIX = {"LTD", "LIMITED", "PVT", "CO", "COMPANY", "IATA", "NON", "LLC"}


def _fullform(s) -> str:
    """Cleaned FULL name (generic words kept, trailing legal suffixes dropped)."""
    toks = re.sub(r"[^A-Z0-9 ]", " ", str(s).upper()).split()
    while toks and toks[-1] in _SUFFIX:
        toks.pop()
    return " ".join(toks)


def _vowel_typo(a: str, b: str) -> bool:
    """Same-length strings whose (1-2) differing characters are ALL vowels — the classic
    Bangla-name transliteration wobble (Shapon/Shopon), never a different brand."""
    if len(a) != len(b) or a == b:
        return False
    diffs = [(x, y) for x, y in zip(a, b) if x != y]
    return len(diffs) <= 2 and all(x in "AEIOU" and y in "AEIOU" for x, y in diffs)


def _match(target: str, vmap: dict) -> list[str]:
    """Visit-agent names matching `target`. vmap: raw name -> (_norm, _fullform).

    Rules (each fixes a real failure seen in the Jun-2026 audits):
      - norm equality: a SINGLE-token norm additionally needs full-name ratio>=0.75 OR a
        compact-fullform prefix ('TA AIR' <-> 'T.A. Air Service'), else 'The Star Travels'
        swallows Star Holidays / Air Star Travel (all norm to 'STAR').
      - 2+-token subset either way (Be Fresh Ltd <-> BE FRESH LIMITED).
      - norm ratio>=0.86 only when both norms are >=6 chars — 4-letter norms false-matched
        SUMA to SURMA Overseas (0.89). A 0.80-0.86 score still passes when the two norms
        differ ONLY in vowels (Shapon/Shopon = typo, 0.833) — consonant changes are a
        different name (Shapon vs ShaWon), vowel swaps are how these names get mistyped.
      - lead-initialism veto: when both norms START with a <=2-letter initialism they must
        agree — 'M A World' is not 'SM World' (collapsing initialisms made them 0.875-close).
      - compact prefix, VISIT-side only (>=6 chars): 'BdFare' abbreviates BDFAREBANGLADESH.
        The reverse direction is banned: a LONGER log name extending the target's stem is a
        different agency ('Jashore Exclusive' is not 'Jashore Air ...'; extra brand tokens
        distinguish, abbreviations don't).
      - all-generic fallback: when the norm is EMPTY (International Travel Corporation) match
        on the full form instead — equality / containment / ratio>=0.9.
    """
    tn, tf = _norm(target), _fullform(target)
    ts = set(tn.split())
    tc = tn.replace(" ", "")
    tfc = tf.replace(" ", "")
    t_pfx = tf.split()[0] if tf and tf.split()[0] in _CTRY_PFX else None
    out = []
    for raw, (an, af) in vmap.items():
        a = set(an.split())
        ac = an.replace(" ", "")
        afc = af.replace(" ", "")
        a_pfx = af.split()[0] if af and af.split()[0] in _CTRY_PFX else None
        if t_pfx and a_pfx and t_pfx != a_pfx:           # AE Akbar != OM Akbar (branch veto)
            continue
        t0 = tn.split()[0] if tn else ""
        a0 = an.split()[0] if an else ""
        if t0 and a0 and len(t0) <= 2 and len(a0) <= 2 and t0 != a0:
            continue                                     # initialism brands must agree (MA != SM)
        if not ts:                                       # all-generic target name
            if tf and af and (tf == af or tf in af or af in tf
                              or SequenceMatcher(None, tf, af).ratio() >= 0.9):
                out.append(raw)
            continue
        if not a:
            continue
        ok = False
        if tn == an:
            ok = (len(ts) >= 2 or SequenceMatcher(None, tf, af).ratio() >= 0.75
                  or (min(len(tfc), len(afc)) >= 4
                      and (tfc.startswith(afc) or afc.startswith(tfc))))
        if not ok and ((ts <= a and len(ts) >= 2) or (a <= ts and len(a) >= 2)):
            ok = True
        if not ok and min(len(tn), len(an)) >= 6:
            sim = SequenceMatcher(None, tn, an).ratio()
            ok = sim >= 0.86 or (sim >= 0.80 and _vowel_typo(tn, an))
        if not ok and min(len(tc), len(ac)) >= 6 and _vowel_typo(tc, ac):
            ok = True                                    # compact vowel typo (Shapon/Shopon one-worded)
        if not ok and min(len(tc), len(ac)) >= 6 and tc.startswith(ac):
            ok = True
        if ok:
            out.append(raw)
    return out


def _rep_name(raw, fallback: str) -> str:
    """The rep's real name from the 'Name:' label in the sheet header block; else the sheet name."""
    for _, hr in raw.head(5).iterrows():
        cells = hr.tolist()
        for k, cv in enumerate(cells):
            if isinstance(cv, str) and cv.strip().lower().startswith("name") and ":" in cv and "agent" not in cv.lower():
                after = cv.split(":", 1)[1].strip()
                if after:
                    return after
                for nx in cells[k + 1:]:
                    if isinstance(nx, str) and nx.strip():
                        return nx.strip()
    return fallback


def _col_map(raw) -> dict | None:
    """Locate the table header row ('Name of Agent') and map the columns per sheet.

    The sheets are NOT uniform: most put Date|Sl.|Name of Agent in cols 0|1|2, but some reps
    (e.g. an Sl.-first layout) put the agent in col 1 with no Date column at all — their date
    lives only in the day-block banner ('Date & Day: 22/6/2026'). Reading fixed positions
    counted contact persons as agencies there, so the map is derived from the header text.
    """
    for idx, r in raw.head(8).iterrows():
        cells = {j: str(v).strip().lower() for j, v in enumerate(r.tolist()) if isinstance(v, str)}
        agent = next((j for j, v in cells.items() if v == "name of agent"), None)
        if agent is None:
            continue
        return {"hdr_row": idx,
                "agent": agent,
                "date": next((j for j, v in cells.items() if v == "date"), None),
                "location": next((j for j, v in cells.items() if v == "location"), None),
                "route": next((j for j, v in cells.items() if "route" in v), None)}
    return None


def _clean_dates(col: pd.Series, month: pd.Timestamp, sheet: str = "", notes: list | None = None) -> pd.Series:
    """Parse a Date column defensively, forcing everything into the report month.

    Real-world junk this absorbs: Sl. integers (pd would read them as 1970 epoch dates),
    day-range strings like '23-28jun' (take the first day), and wrong-month typos like
    2026-01-25 in a June book (keep the day, remap the month). Anything else -> NaT.
    Every correction is appended to `notes` so the report can show its work (DQ sheet).
    """
    out = []
    for v in col:
        d = pd.NaT
        if isinstance(v, (pd.Timestamp,)) or type(v).__name__ == "datetime":
            d = pd.Timestamp(v)
        elif isinstance(v, str):
            m = re.match(r"\s*(\d{1,2})\s*[-–]", v)          # '23-28jun' day-range banner
            if m:
                d = month.replace(day=int(m.group(1)))
                if notes is not None:
                    notes.append({"sheet": sheet, "issue": "day-range banner",
                                  "detail": f"'{v}' -> all its visits attributed to {d:%b %d}"})
            else:
                d = pd.to_datetime(v, errors="coerce", dayfirst=True)
        if pd.notna(d) and (d.year, d.month) != (month.year, month.month):
            try:                                              # wrong-month typo: trust the day
                fixed = month.replace(day=d.day)
                if notes is not None:
                    notes.append({"sheet": sheet, "issue": "wrong-month date remapped",
                                  "detail": f"{d:%Y-%m-%d} -> {fixed:%Y-%m-%d}"})
                d = fixed
            except ValueError:
                d = pd.NaT
        out.append(d)
    return pd.Series(out, index=col.index)


def _banner_dates(raw, month: pd.Timestamp, sheet: str = "", notes: list | None = None) -> pd.Series:
    """Per-row dates from 'Date & Day:' block banners (sheets with no Date column)."""
    marks = pd.Series(pd.NaT, index=raw.index)
    for idx, r in raw.iterrows():
        vals = r.tolist()
        for k, v in enumerate(vals):
            if isinstance(v, str) and "date & day" in v.lower():
                nxt = next((x for x in vals[k + 1:] if pd.notna(x) and str(x).strip()), None)
                if nxt is not None:
                    marks.loc[idx] = _clean_dates(pd.Series([nxt]), month, sheet, notes).iloc[0]
                break
    return marks.ffill()


def parse_visits(path: Path) -> pd.DataFrame:
    """One row per visit across all rep sheets.

    The visit Date is written only on the FIRST row of each day-block; the agencies listed below it
    (blank Date, incrementing Sl.) belong to the SAME day. So we forward-fill the date down each
    sheet, then take every row that has a real agency name. (Requiring a date per row — the naive
    read — drops ~90% of the visits.) Column positions come from each sheet's own header row, and
    all dates are coerced into the report month (see _clean_dates for the junk this absorbs).
    """
    import warnings as _w
    _w.filterwarnings("ignore", category=UserWarning)
    allsh = pd.read_excel(path, sheet_name=None, header=None)   # one parse, all sheets

    # report month = the calendar month the workbook is about, taken as the mode over every
    # cell that is ALREADY a real datetime (typed cells can't be Sl. numbers or typo strings)
    stamps = [v for raw in allsh.values() for col in raw.columns
              for v in raw[col] if isinstance(v, pd.Timestamp) or type(v).__name__ == "datetime"]
    per = pd.Series([pd.Timestamp(t).to_period("M") for t in stamps])
    month = per.mode().iloc[0].to_timestamp() if len(per) else pd.Timestamp.today().replace(day=1)

    HDR = {"name of agent", "date", ""}
    rows, roster, notes = [], [], []
    for sh, raw in allsh.items():
        cmap = _col_map(raw)
        if cmap is None:              # empty / template sheet — no visit table at all
            roster.append({"salesperson": sh, "rep_name": sh, "has_table": False})
            notes.append({"sheet": sh, "issue": "no visit table",
                          "detail": "sheet is empty or has no 'Name of Agent' header"})
            continue
        rep = _rep_name(raw, sh)
        roster.append({"salesperson": sh, "rep_name": rep, "has_table": True})
        dates = (_clean_dates(raw[cmap["date"]], month, sh, notes).ffill() if cmap["date"] is not None
                 else _banner_dates(raw, month, sh, notes))
        for idx, r in raw.iterrows():
            if idx <= cmap["hdr_row"]:
                continue
            a = r.get(cmap["agent"])
            if not isinstance(a, str):
                continue
            an = a.strip()
            if not an or an.lower() in HDR or an.lower().startswith(("daily agency", "daily sales", "name of agent")):
                continue
            d = dates.loc[idx]
            if pd.isna(d):
                continue
            rows.append({"salesperson": sh, "rep_name": rep, "date": d.date(), "agent": an,
                         "location": r.get(cmap["location"]) if cmap["location"] is not None else None,
                         "route": r.get(cmap["route"]) if cmap["route"] is not None else None})
    return pd.DataFrame(rows), pd.DataFrame(roster), notes


def _cell(ws, row, col, val, *, bold=False, size=10, color=None, fill=None, align="center", fmt=None, wrap=False):
    c = ws.cell(row, col, val)
    c.font = Font(bold=bold, size=size, color=color or "000000")
    c.alignment = Alignment(horizontal=align, vertical="center", wrap_text=wrap)
    c.border = BORDER
    if fill:
        c.fill = PatternFill("solid", fgColor=fill)
    if fmt:
        c.number_format = fmt
    return c


def _headers(ws, row, heads, widths):
    for j, (h, w) in enumerate(zip(heads, widths), 1):
        _cell(ws, row, j, h, bold=True, color=WHITE, fill=NAVY, size=9, wrap=True)
        ws.column_dimensions[get_column_letter(j)].width = w
    ws.row_dimensions[row].height = 26


# tokens dropped when reducing a name to its compact BRAND key for the sibling merge.
# COMPACT (spaces removed) so 'GoZayaan LTD' and 'Go Zayaan Limited (Non IATA)' group.
_KEY_DROP = {"IATA", "NON", "LTD", "LIMITED", "PVT", "CO", "COMPANY", "LLC", "THE", "MERGED"}

# CANONICAL cross-zone merges (customer-id -> key). Name matching handles same-zone siblings,
# but these brands run accounts in DIFFERENT zones, so zone-scoped sheets need an explicit
# pairing; the merged row lands in the DOMINANT (higher-net) account's zone/KAM block.
CANON_MERGE = {"10502007": "GOZAYAAN", "12084060": "GOZAYAAN"}
CANON_NAME = {"GOZAYAAN": "Go Zayaan Limited (merged)"}


def _row_cids(row) -> list:
    """Member customer-IDs behind a row (survives repeated merge passes)."""
    v = row["cids"] if "cids" in row.index else None
    return v if isinstance(v, list) else [row.cid]


def _brand_key(nm) -> str:
    toks = re.sub(r"[^A-Z0-9 ]", " ", str(nm).upper()).split()
    return "".join(t for t in toks if t not in _KEY_DROP)


def _merge_siblings(df: pd.DataFrame, num_cols: list[str], gate_station: bool = True) -> pd.DataFrame:
    """Fold same-brand sibling accounts (IATA + Non-IATA) into one row.

    Same rules as the Top-Agents workbook: compact brand key, and (optionally) at most one
    distinct non-null Station — 'Al Amin' DAC vs BZL are different agencies in different
    cities. Keeps a `cids` list of member IDs (MOCAT lookups test every member).
    Sums must be exact: a booking lives in exactly one account.
    """
    df = df.copy()
    df["bkey"] = df.nm.map(_brand_key)
    out = []
    for _, g in df.groupby("bkey", sort=False):
        if len(g) == 1 or (gate_station and "stn" in g and g.stn.dropna().nunique() > 1):
            for _, row in g.iterrows():
                row = row.copy(); row["cids"] = _row_cids(row)
                out.append(row)
            continue
        dom = g.loc[g[num_cols[0]].fillna(0).idxmax()].copy()
        for c in num_cols:
            dom[c] = g[c].fillna(0).sum()
        dom["cids"] = [c for _, m in g.iterrows() for c in _row_cids(m)]
        base = str(dom.cid).split(" ")[0]              # dominant id, minus any earlier "(+n)" tag
        dom["cid"] = f"{base} (+{len(dom['cids']) - 1})" if len(dom["cids"]) > 1 else dom.cid
        if "(merged)" not in str(dom.nm):
            dom["nm"] = f"{dom.nm} (merged)"
        out.append(dom)
    return pd.DataFrame(out).drop(columns="bkey").reset_index(drop=True)


# ---- rank sources -----------------------------------------------------------------
# On the ANALYST machine the rankings come from gold. On a colleague's machine (the
# exe's Instant Reports) there is no gold and never will be — so the Data Kit ships
# small PRE-COMPUTED rank packs built from gold by build_rank_packs() at publish time.
# Both paths produce the SAME frame shape; every python-side step (name filters,
# sibling merges, ranking) is shared, so the two modes cannot drift.
RANK_AGENCY_PACK = "reference/visit_rank_agency.parquet"
RANK_KAMZONE_PACK = "reference/visit_rank_kamzone.parquet"
MOCAT_PACK = "reference/mocat_ids.parquet"


def _agency_sql(GOLD: str) -> str:
    return f"""
        WITH a AS (
          SELECT regexp_replace(CAST("Customer ID" AS VARCHAR), '[.]0+$', '') cid, ANY_VALUE("Customer") nm,
                 SUM("Balance (base currency)") FILTER (WHERE "sector"='Domestic')/{CR}      dom_cr,
                 SUM("Balance (base currency)") FILTER (WHERE "sector"='International')/{CR}  intl_cr,
                 MAX("Agency Country") ctry, MODE("Station") stn
          FROM {GOLD} WHERE "Channel"='AGENCY' AND "Pure Date" >= DATE '{RANK_START}' GROUP BY 1)
        SELECT cid, nm, dom_cr, intl_cr, stn FROM a WHERE (ctry IS NULL OR upper(ctry)='BANGLADESH')
    """


def _kamzone_sql(GOLD: str) -> str:
    return f"""
        SELECT "Sales Person" kam, "Zone" zn,
               regexp_replace(CAST("Customer ID" AS VARCHAR), '[.]0+$', '') cid,
               ANY_VALUE("Customer") nm,
               SUM("Balance (base currency)")/1e5 ytd_lac,
               SUM("Balance (base currency)") FILTER (
                   WHERE date_trunc('month',"Pure Date")=(SELECT date_trunc('month',max("Pure Date")) FROM {GOLD})
               )/1e5 mon_lac
        FROM {GOLD}
        WHERE "Channel"='AGENCY' AND "Pure Date" >= DATE '{RANK_START}'
          AND "Sales Person" IS NOT NULL AND "Zone" IS NOT NULL
          AND ("Customer" IS NULL OR "Customer" NOT ILIKE 'CORP %')
          AND ("Customer" IS NOT NULL AND NOT regexp_matches(lower("Customer"),
               'gds|galileo|sabre|abacus|travelsky|extranet|autogen| web|mobiapp|counter'))
        GROUP BY 1,2,3
    """


def _fetch_or_pack(con, cfg: Config, sql: str, pack_rel: str) -> pd.DataFrame:
    """Gold when this machine has it; the Data-Kit rank pack otherwise."""
    if (cfg.data_root / "gold" / "sales_bi.parquet").is_file():
        return con.execute(sql).df()
    pack = cfg.data_root / pack_rel
    if not pack.is_file():
        raise FileNotFoundError(
            f"no gold data and no rank pack ({pack_rel}) — refresh the Data Kit on the "
            f"share (publish_reports data_kit) and re-assemble.")
    return con.execute(f"SELECT * FROM read_parquet('{pack.as_posix()}')").df()


def build_rank_packs(cfg: Config | None = None) -> list[Path]:
    """ANALYST-side: materialise the rank packs + MOCAT ids for the Data Kit.

    Called by the data_kit builder on every publish, so colleague machines rank
    against yesterday's gold even though they only upload a few days of sales.
    """
    import duckdb as _duck
    cfg = cfg or load_config(validate=True)
    GOLD = f"read_parquet('{(cfg.data_root / 'gold' / 'sales_bi.parquet').as_posix()}')"
    con = _duck.connect()
    out: list[Path] = []
    for sql, rel in ((_agency_sql(GOLD), RANK_AGENCY_PACK), (_kamzone_sql(GOLD), RANK_KAMZONE_PACK)):
        dest = cfg.data_root / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        con.execute(sql).df().to_parquet(dest, index=False)
        out.append(dest)
    ids = _mocat_ids([])                              # from the Downloads zone lists
    if ids:
        dest = cfg.data_root / MOCAT_PACK
        pd.DataFrame({"customer_id": sorted(ids)}).to_parquet(dest, index=False)
        out.append(dest)
    return out


def top_by_sector(con, GOLD: str, cfg: Config) -> tuple[pd.DataFrame, pd.DataFrame]:
    ag = _fetch_or_pack(con, cfg, _agency_sql(GOLD), RANK_AGENCY_PACK)
    ag = ag[~ag.nm.astype(str).str.lower().str.contains(
        "gds|galileo|sabre|abacus|travelsky|extranet|autogen| web|mobiapp", regex=True, na=False)]
    ag = _merge_siblings(ag, ["dom_cr", "intl_cr"])   # one row per BRAND (Talon/BD Fare were listed twice)
    return (ag.sort_values("dom_cr", ascending=False).head(15).reset_index(drop=True),
            ag.sort_values("intl_cr", ascending=False).head(15).reset_index(drop=True))


def _mocat_ids(notes: list, cfg: Config | None = None) -> set[str] | None:
    """Customer IDs onboarded on MOCAT (the licensed-agency zone lists).

    Source: Downloads/ZONE/New folder/zones_output_Zone-*.xlsx (the analyst machine);
    falls back to the Data-Kit pack (reference/mocat_ids.parquet) on colleague machines.
    Returns None (column shows 'n/a') when neither exists, with a DQ note.
    """
    zone_dir = DOWNLOADS / "ZONE" / "New folder"
    files = [f for f in zone_dir.glob("zones_output_Zone*.xlsx") if not f.name.startswith("~$")]
    if not files:
        pack = (cfg.data_root / MOCAT_PACK) if cfg else None
        if pack and pack.is_file():
            return set(pd.read_parquet(pack)["customer_id"].astype(str))
        notes.append({"sheet": "(all)", "issue": "MOCAT lists not found",
                      "detail": f"no zones_output_Zone-*.xlsx under {zone_dir} and no data-kit "
                                f"mocat pack - MOCAT column shows n/a"})
        return None
    ids: set[str] = set()
    for f in files:
        try:
            df = pd.read_excel(f, sheet_name="DATA", dtype=str)
        except Exception:
            continue
        if "Zenith ID" in df.columns:
            ids |= {re.sub(r"\.0+$", "", str(x).strip()) for x in df["Zenith ID"].dropna()}
    return {i for i in ids if i.isdigit()}


def kam_zone_top10(con, GOLD: str, cfg: Config) -> pd.DataFrame:
    """Per (KAM, zone): the top-10 agencies by 2026-YTD net, with the activity columns.

    active = the agency sold in the report month (month net != 0); the month net is shown
    beside the flag so the cutoff is transparent. NULL-KAM zones (unmapped) are skipped.
    Same-brand siblings are merged WITHIN each zone (a brand split ACROSS zones stays
    per-zone — each KAM still sees only the account that belongs to their book).
    """
    a = _fetch_or_pack(con, cfg, _kamzone_sql(GOLD), RANK_KAMZONE_PACK)
    # canonical CROSS-ZONE merges first: collapse each CANON group onto its dominant
    # (highest-YTD) account's zone/KAM block, keeping every member id for MOCAT lookups
    canon = a[a.cid.isin(CANON_MERGE)]
    if len(canon):
        keep = []
        for key, g in canon.groupby(canon.cid.map(CANON_MERGE)):
            dom = g.loc[g.ytd_lac.fillna(0).idxmax()].copy()
            dom["ytd_lac"] = g.ytd_lac.fillna(0).sum()
            dom["mon_lac"] = g.mon_lac.fillna(0).sum()
            dom["nm"] = CANON_NAME.get(key, dom.nm)
            dom["cids"] = list(g.cid)
            dom["cid"] = f"{dom.cid} (+{len(g) - 1})" if len(g) > 1 else dom.cid
            keep.append(dom)
        a = pd.concat([a[~a.cid.isin(CANON_MERGE)], pd.DataFrame(keep)], ignore_index=True)

    parts = []                       # explicit loop: pandas' groupby.apply hides the key columns
    for (kam, zn), g in a.groupby(["kam", "zn"], sort=False):
        m = _merge_siblings(g, ["ytd_lac", "mon_lac"], gate_station=False)
        m["kam"], m["zn"] = kam, zn
        parts.append(m)
    merged = pd.concat(parts, ignore_index=True)
    merged["rk"] = merged.groupby(["kam", "zn"]).ytd_lac.rank(ascending=False, method="first").astype(int)
    merged = merged[merged.rk <= 10]
    ztot = merged.groupby(["kam", "zn"]).ytd_lac.transform("sum")
    return (merged.assign(_zt=ztot)
            .sort_values(["_zt", "kam", "zn", "rk"], ascending=[False, True, True, True])
            .drop(columns="_zt").reset_index(drop=True))


def generate(params: dict | None = None, cfg: Config | None = None) -> Path:
    """Build the visit-tracking workbook; return the written path.

    params["source"]: path to the visit workbook. Omitted/None -> newest
    "Daily Agency Visit Report*.xlsx" in ~/Downloads.
    """
    try:                                     # frozen exe redirects stdout; don't crash on it
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, OSError):
        pass
    params = params or {}
    cfg = cfg or load_config(validate=True)
    GOLD = f"read_parquet('{(cfg.data_root / 'gold' / 'sales_bi.parquet').as_posix()}')"

    if params.get("source"):
        src = Path(params["source"])
    else:
        cands = sorted(DOWNLOADS.glob("Daily Agency Visit Report*.xlsx"), key=lambda p: p.stat().st_mtime)
        if not cands:
            raise FileNotFoundError("no 'Daily Agency Visit Report*.xlsx' in Downloads — "
                                    "drop the month's visit workbook there (or pass source=<path>).")
        src = cands[-1]
    if not src.is_file():
        raise FileNotFoundError(f"visit workbook not found: {src}")
    print(f"[reading] {src.name}")

    v, roster, notes = parse_visits(src)
    if v.empty:
        raise ValueError(f"parsed 0 visits from {src.name} — is it the right workbook?")
    v["date"] = pd.to_datetime(v["date"])

    # exact duplicate rows (same rep, same day, same agency spelling) are copy-paste artefacts —
    # a whole 8-agency block appeared twice on one sheet in Jun-2026. Metrics use the deduped set;
    # what was dropped is disclosed on the Data Quality sheet.
    dup_mask = v.duplicated(["salesperson", "date", "agent"], keep="first")
    dupes = v[dup_mask].copy()
    v = v[~dup_mask].reset_index(drop=True)
    for r in dupes.groupby(["salesperson", "date", "agent"]).size().reset_index(name="extra").itertuples():
        notes.append({"sheet": r.salesperson, "issue": "duplicate rows dropped",
                      "detail": f"{r.agent} on {r.date:%b %d} listed {r.extra + 1}x -> counted once"})

    # cluster key so spelling variants ('Holiday Planner Travels' x3 casings) count as ONE agency
    v["akey"] = v.agent.map(lambda a: _norm(a).replace(" ", "") or _fullform(a))

    dmin, dmax = v.date.min(), v.date.max()
    tag = dmin.strftime("%b%Y")
    total = len(v)
    dw = v.groupby(v.date.dt.date).size()
    active = dw.shape[0]
    span = (dmax - dmin).days + 1
    # BD working week is Sun-Thu (Fri+Sat = weekend) — the fair per-day denominator
    workdays = sum(1 for d in pd.date_range(dmin, dmax) if d.weekday() not in (4, 5))
    vmap = {a: (_norm(a), _fullform(a)) for a in v.agent.unique()}

    con = duckdb.connect()
    top_dom, top_intl = top_by_sector(con, GOLD, cfg)

    def status(name):
        hits = _match(name, vmap)
        sub = v[v.agent.isin(hits)]
        return (len(sub), ", ".join(sorted(sub.agent.unique())[:4]),
                ", ".join(sorted(sub.date.dt.strftime("%b %d").unique())))

    dom_cov = sum(1 for r in top_dom.itertuples() if status(r.nm)[0] > 0)
    intl_cov = sum(1 for r in top_intl.itertuples() if status(r.nm)[0] > 0)

    wb = Workbook()

    # ---- Summary ----
    ws = wb.active; ws.title = "Summary"; ws.sheet_view.showGridLines = False
    _cell(ws, 1, 1, f"AGENCY VISIT TRACKING - {dmin:%b %Y}", bold=True, size=14, color=NAVY, align="left")
    ws.merge_cells("A1:C1")
    rows = [
        ("Report period", f"{dmin:%d %b} to {dmax:%d %b %Y}"),
        ("Total visits (deduped)", total),
        ("Active days", active),
        ("Avg visits / active day", round(total / active, 1)),
        ("Avg visits / working day (Sun-Thu)", round(total / workdays, 1)),
        ("Avg visits / calendar day", round(total / span, 1)),
        ("Distinct agencies visited (normalized)", v.akey.nunique()),
        ("  · raw spellings in the log", v.agent.nunique()),
        ("Sales reps with visits", v.salesperson.nunique()),
        ("  · sheets submitted (incl. zero-visit)", len(roster)),
        ("Top-15 DOMESTIC agents visited", f"{dom_cov} / 15"),
        ("Top-15 INTERNATIONAL agents visited", f"{intl_cov} / 15"),
        ("Duplicate rows dropped", len(dupes)),
    ]
    for i, (k, val) in enumerate(rows, 3):
        _cell(ws, i, 1, k, bold=True, align="left"); _cell(ws, i, 2, val, align="left")
    ws.column_dimensions["A"].width = 36; ws.column_dimensions["B"].width = 28

    # ---- Day-wise ----
    ws = wb.create_sheet("Day-wise"); ws.sheet_view.showGridLines = False
    _cell(ws, 1, 1, "VISITS BY DAY", bold=True, size=13, color=NAVY, align="left"); ws.merge_cells("A1:C1")
    _headers(ws, 3, ["Date", "Day", "Visits"], [14, 12, 10])
    rr = 4
    for d, n in dw.items():
        _cell(ws, rr, 1, pd.Timestamp(d).strftime("%Y-%m-%d")); _cell(ws, rr, 2, pd.Timestamp(d).strftime("%A"))
        _cell(ws, rr, 3, int(n)); rr += 1
    _cell(ws, rr, 1, "TOTAL", bold=True, fill="F2F2F2"); _cell(ws, rr, 2, "", fill="F2F2F2")
    _cell(ws, rr, 3, total, bold=True, fill="F2F2F2")

    repmap = v.groupby("salesperson")["rep_name"].first().to_dict()

    # ---- By Salesperson (summary) ----
    ws = wb.create_sheet("By Salesperson"); ws.sheet_view.showGridLines = False
    _cell(ws, 1, 1, "VISITS BY SALES REP", bold=True, size=13, color=NAVY, align="left"); ws.merge_cells("A1:F1")
    _headers(ws, 3, ["Sales rep", "Visits", "Active days", "Avg / active day", "Distinct agencies", "First to last"],
             [24, 9, 12, 15, 16, 18])
    rr = 4
    for sp, sub in sorted(v.groupby("salesperson"), key=lambda kv: -len(kv[1])):
        ad = sub.date.dt.date.nunique()
        _cell(ws, rr, 1, repmap.get(sp, sp), align="left"); _cell(ws, rr, 2, len(sub)); _cell(ws, rr, 3, ad)
        _cell(ws, rr, 4, round(len(sub) / ad, 1)); _cell(ws, rr, 5, sub.akey.nunique())
        _cell(ws, rr, 6, f"{sub.date.min():%b %d} to {sub.date.max():%b %d}", align="left"); rr += 1
    # reps who submitted a sheet but logged NO visits — previously they vanished from the report,
    # which hid exactly the people a visit-tracking report should surface
    seen = set(v.salesperson.unique())
    for r in roster.itertuples():
        if r.salesperson in seen:
            continue
        _cell(ws, rr, 1, r.rep_name if r.rep_name != r.salesperson else r.salesperson, align="left", fill=RED)
        _cell(ws, rr, 2, 0, fill=RED); _cell(ws, rr, 3, 0, fill=RED); _cell(ws, rr, 4, 0, fill=RED)
        _cell(ws, rr, 5, 0, fill=RED)
        _cell(ws, rr, 6, "no visits logged" if r.has_table else "empty sheet", align="left", fill=RED)
        rr += 1

    # ---- Rep x Day matrix (day-wise count + avg/day, per rep) ----
    ws = wb.create_sheet("Rep x Day"); ws.sheet_view.showGridLines = False
    _cell(ws, 1, 1, "VISITS BY REP × DAY", bold=True, size=13, color=NAVY, align="left")
    days = sorted(v.date.dt.date.unique())
    ct = pd.crosstab(v.salesperson, v.date.dt.date).reindex(columns=days, fill_value=0)
    ct = ct.loc[ct.sum(axis=1).sort_values(ascending=False).index]
    heads = ["Sales rep"] + [pd.Timestamp(d).strftime("%b %d") for d in days] + ["Total", "Days", "Avg/day"]
    _headers(ws, 3, heads, [22] + [6] * len(days) + [7, 6, 8])
    rr = 4
    for sp in ct.index:
        _cell(ws, rr, 1, repmap.get(sp, sp), align="left")
        vals = [int(ct.loc[sp, d]) for d in days]
        for j, val in enumerate(vals, 2):
            _cell(ws, rr, j, val if val else "")
        tot = sum(vals); ad = sum(1 for x in vals if x)
        _cell(ws, rr, 2 + len(days), tot, bold=True); _cell(ws, rr, 3 + len(days), ad)
        _cell(ws, rr, 4 + len(days), round(tot / ad, 1) if ad else 0)
        rr += 1
    _cell(ws, rr, 1, "TOTAL", bold=True, fill="F2F2F2")
    for j, d in enumerate(days, 2):
        _cell(ws, rr, j, int(ct[d].sum()), bold=True, fill="F2F2F2")
    _cell(ws, rr, 2 + len(days), total, bold=True, fill="F2F2F2")
    ws.freeze_panes = "B4"

    # ---- Rep -> Agency detail (which agencies each rep visited, how often) ----
    ws = wb.create_sheet("Rep Agency Detail"); ws.sheet_view.showGridLines = False
    _cell(ws, 1, 1, "WHICH AGENCIES EACH REP VISITED (frequency)", bold=True, size=13, color=NAVY, align="left")
    ws.merge_cells("A1:D1")
    _headers(ws, 3, ["Sales rep", "Agency", "# visits", "Visit dates"], [20, 34, 9, 26])
    rr = 4
    # group on the normalized key so 'Holiday Planner Travels/travels' count as one agency;
    # display the spelling the rep used most often
    det = v.groupby(["salesperson", "akey"]).agg(
        agent=("agent", lambda s: s.mode().iloc[0]),
        n=("date", "size"),
        dates=("date", lambda s: ", ".join(sorted(pd.to_datetime(s).dt.strftime("%b %d").unique())))).reset_index()
    for sp in ct.index:
        for r in det[det.salesperson == sp].sort_values("n", ascending=False).itertuples():
            _cell(ws, rr, 1, repmap.get(sp, sp), align="left"); _cell(ws, rr, 2, str(r.agent)[:60], align="left")
            _cell(ws, rr, 3, int(r.n)); _cell(ws, rr, 4, r.dates, align="left"); rr += 1
    ws.freeze_panes = "A4"

    # ---- KAM Zone Top 10 (per KAM: their zone's top-10 agencies + visit/activity status) ----
    ws = wb.create_sheet("KAM Zone Top 10"); ws.sheet_view.showGridLines = False
    _cell(ws, 1, 1, "KAM WISE - EACH ZONE'S TOP 10 AGENCIES: VISITS, SALES, ACTIVITY, MOCAT",
          bold=True, size=13, color=NAVY, align="left"); ws.merge_cells("A1:J1")
    _cell(ws, 2, 1, "Top 10 by 2026-YTD net per (KAM, zone). Active = sold in the report month "
                    "(month net shown). Visits counted from the whole visit log via name match. "
                    "MOCAT = agency ID present in the MOCAT licensed-agency zone lists.",
          align="left", size=9, color="7F7F7F"); ws.merge_cells("A2:J2")
    _headers(ws, 4, ["#", "Agency", "Customer ID", "YTD net (lac)", "Month net (lac)",
                     "Status", "Visits", "Visit dates", "Matched to (visit log)", "MOCAT"],
             [4, 34, 12, 12, 12, 10, 7, 22, 26, 10])
    mocat = _mocat_ids(notes, cfg)
    kz = kam_zone_top10(con, GOLD, cfg)
    rr = 5
    for (kam, zn), blk in kz.groupby(["kam", "zn"], sort=False):
        _cell(ws, rr, 1, f"{kam}   |   {zn}   |   zone top-10 YTD {blk.ytd_lac.sum()/100:,.1f} cr",
              bold=True, color=WHITE, fill="2E5E9E", align="left", size=10)
        ws.merge_cells(start_row=rr, start_column=1, end_row=rr, end_column=10)
        rr += 1
        for r in blk.itertuples():
            n, mname, dates = status(r.nm)
            is_active = (r.mon_lac or 0) != 0        # NB: do not shadow the outer `active` (days count)
            _cell(ws, rr, 1, int(r.rk)); _cell(ws, rr, 2, str(r.nm)[:55], align="left")
            _cell(ws, rr, 3, r.cid)
            _cell(ws, rr, 4, r.ytd_lac, fmt="#,##0.0")
            _cell(ws, rr, 5, r.mon_lac or 0, fmt="#,##0.0")
            _cell(ws, rr, 6, "Active" if is_active else "Inactive", bold=not is_active,
                  fill=GREEN if is_active else RED)
            _cell(ws, rr, 7, n, bold=n > 0)
            _cell(ws, rr, 8, dates, align="left")
            _cell(ws, rr, 9, mname, align="left")
            # merged rows carry every member ID in cids — onboarded if ANY member is listed
            members = getattr(r, "cids", None) or [r.cid]
            on = any(c in mocat for c in members) if mocat is not None else None
            _cell(ws, rr, 10, ("n/a" if on is None else ("Onboarded" if on else "Not onboarded")),
                  fill=(None if on is None else (GREEN if on else RED)))
            rr += 1
    ws.freeze_panes = "A5"

    # ---- Top 15 per sector ----
    for title, top, col in [("Top 15 Domestic", top_dom, "dom_cr"), ("Top 15 International", top_intl, "intl_cr")]:
        ws = wb.create_sheet(title); ws.sheet_view.showGridLines = False
        _cell(ws, 1, 1, f"{title.upper()} AGENTS - VISIT STATUS (ranked by 2026-YTD {('domestic' if 'Dom' in title else 'international')} net)",
              bold=True, size=12, color=NAVY, align="left"); ws.merge_cells("A1:G1")
        _headers(ws, 3, ["#", "Agency", "2026 net (cr)", "Visited?", "# visits", "Visit dates", "Matched to (visit log)"],
                 [4, 34, 13, 10, 9, 26, 32])
        rr = 4
        for i, r in enumerate(top.itertuples(), 1):
            n, mname, dates = status(r.nm)
            _cell(ws, rr, 1, i); _cell(ws, rr, 2, str(r.nm)[:60], align="left")
            _cell(ws, rr, 3, round(getattr(r, col), 1), fmt="#,##0.0")
            _cell(ws, rr, 4, "YES" if n else "NO", bold=True, fill=GREEN if n else RED)
            _cell(ws, rr, 5, n); _cell(ws, rr, 6, dates, align="left"); _cell(ws, rr, 7, mname, align="left")
            rr += 1

    # ---- Data Quality (every correction the parser made, so the numbers are auditable) ----
    ws = wb.create_sheet("Data Quality"); ws.sheet_view.showGridLines = False
    _cell(ws, 1, 1, "DATA QUALITY - CORRECTIONS APPLIED WHILE PARSING", bold=True, size=13, color=NAVY, align="left")
    ws.merge_cells("A1:C1")
    _headers(ws, 3, ["Sheet / rep", "Issue", "Detail"], [16, 26, 70])
    rr = 4
    for nte in notes:
        _cell(ws, rr, 1, nte["sheet"], align="left"); _cell(ws, rr, 2, nte["issue"], align="left")
        _cell(ws, rr, 3, nte["detail"], align="left"); rr += 1
    if not notes:
        _cell(ws, rr, 1, "clean parse - no corrections needed", align="left")

    # ---- Visit Log ----
    ws = wb.create_sheet("Visit Log"); ws.sheet_view.showGridLines = False
    _cell(ws, 1, 1, "VISIT LOG (all visits)", bold=True, size=13, color=NAVY, align="left"); ws.merge_cells("A1:E1")
    _headers(ws, 3, ["Date", "Sales rep", "Agency visited", "Location", "Most selling route"], [12, 14, 34, 18, 22])
    rr = 4
    for r in v.sort_values(["date", "salesperson"]).itertuples():
        _cell(ws, rr, 1, r.date.strftime("%Y-%m-%d")); _cell(ws, rr, 2, str(r.salesperson), align="left")
        _cell(ws, rr, 3, str(r.agent), align="left")
        _cell(ws, rr, 4, "" if pd.isna(r.location) else str(r.location), align="left")
        _cell(ws, rr, 5, "" if pd.isna(r.route) else str(r.route), align="left"); rr += 1
    ws.freeze_panes = "A4"

    out = cfg.output_dir / f"Agency_Visit_Tracking_{tag}.xlsx"
    out.parent.mkdir(parents=True, exist_ok=True)
    for suffix in ("", "__new", "__new2"):
        cand = out.with_name(out.stem + suffix + ".xlsx") if suffix else out
        try:
            wb.save(cand); out = cand; break
        except PermissionError:
            continue
    else:
        raise PermissionError(f"could not write {out} — is the file open in Excel?")
    print(f"[OK] {out}")
    print(f"     {total} visits (deduped, -{len(dupes)}) · {active} active days · "
          f"avg {total/active:.1f}/active day, {total/workdays:.1f}/working day · "
          f"top-15 visited: Dom {dom_cov}/15, Intl {intl_cov}/15")
    zero = [r.salesperson for r in roster.itertuples() if r.salesperson not in set(v.salesperson)]
    if zero:
        print(f"     zero-visit sheets: {', '.join(zero)}")
    if notes:
        print(f"     data-quality notes: {len(notes)} (see the Data Quality sheet)")
    return out
