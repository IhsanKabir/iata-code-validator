"""
reporting.builders.benefits_given — publish wrapper for the Benefits-Given report.

This report is ANALYST-MACHINE ONLY: it needs the revenue team's benefit workbooks
(reference/Benefits Given From Revenue → curated/benefits) plus gold. So it is NOT offered
in Instant Reports (colleagues can't build it); it is PUBLISHED to the share so the exe's
report center lists it for download, like the DSR.

The heavy logic lives in scripts/_build_benefits_given_report.py (it uses report_kit's
canonical defs + Excel kit). This wrapper just resolves that module at publish time and
points its output at cfg.output_dir. The scripts import is LAZY (inside generate) so merely
importing this module — e.g. when the wheel is packaged for a colleague exe — never drags in
report_kit / duckdb, which aren't on that machine.

Public entry point: ``generate(params, cfg) -> Path``.
"""
from __future__ import annotations

import sys
from pathlib import Path

from ..config import Config, load_config


def generate(params: dict | None = None, cfg: Config | None = None) -> Path:
    cfg = cfg or load_config(validate=True)
    scripts = cfg.data_root / "scripts"
    if not scripts.is_dir():
        raise FileNotFoundError(
            f"Benefits-Given is analyst-only — scripts/ not found under {cfg.data_root}. "
            f"It is built on the pipeline machine and downloaded from the report center.")
    if str(scripts) not in sys.path:
        sys.path.insert(0, str(scripts))
    import _build_benefits_given_report as builder    # lazy: pulls report_kit only here
    return builder.generate({"out_dir": str(cfg.output_dir)}, cfg)
