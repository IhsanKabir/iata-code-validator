"""
reporting.builders.incentive_file_emails — publish wrapper for the "incentive zip + emails" report.

This report is ANALYST-MACHINE ONLY: it rebuilds the revenue team's monthly incentive zip
(reference/Benefits Given From Revenue — the newest one) with Sales Person + Email columns
appended to every agency row, mapped from gold + dim_sales_person + salesperson_emails.xlsx.
Colleague machines have none of those inputs, so it is NOT in Instant Reports; it is PUBLISHED
to the share (like the Benefits-Given report) and listed in the exe's report center for download.

The heavy logic lives in scripts/_build_incentive_file_emails.py. The scripts import is LAZY
(inside generate) so importing this module on a colleague exe never drags in report_kit/duckdb.

Public entry point: ``generate(params, cfg) -> Path``.
"""
from __future__ import annotations

import sys
from pathlib import Path

from ..config import Config, load_config


def generate(params: dict | None = None, cfg: Config | None = None) -> Path:
    cfg = cfg or load_config(validate=True)
    scripts = cfg.data_root / "scripts"
    if not scripts.is_dir():
        raise FileNotFoundError(
            f"Incentive-With-Emails is analyst-only — scripts/ not found under {cfg.data_root}. "
            f"It is built on the pipeline machine and downloaded from the report center.")
    if str(scripts) not in sys.path:
        sys.path.insert(0, str(scripts))
    import _build_incentive_file_emails as builder    # lazy: pulls report_kit only here
    p = dict(params or {})
    p.setdefault("out_dir", str(cfg.output_dir))
    return builder.generate(p, cfg)
