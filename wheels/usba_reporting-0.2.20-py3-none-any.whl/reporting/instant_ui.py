"""
reporting.instant_ui — Tk windows for Instant Reports + the mail-list editor.

Both windows are opened from buttons that ReportsFrame shows ONLY AFTER the
rotating-password login (the analyst's requirement: "keep it under the report
showing password layer"). The module lazy-imports Tk and the heavy engine so
importing it costs nothing on machines/builds that never use it.

  InstantBuildWindow   pick raw sales xlsx file(s) -> reports build locally,
                       ONE BY ONE, from the published Data Kit. Pure client-side:
                       nothing is written to the share. Laid out as four boxes —
                       (1) raw files with instant pre-flight validation, (2) data
                       mode, (3) reports with presets, (4) build & per-report results.
  RecipientsWindow     edit reference/report_email_list.xlsx (Name | Email |
                       Reports) — the morning-mail recipient list.
"""
from __future__ import annotations

from pathlib import Path

NAVY = "#1F3864"; BLUE = "#2E5395"; GREY = "#7F7F7F"; WHITE = "#FFFFFF"
GREEN_BG = "#E2EFDA"; AMBER_BG = "#FFF2CC"
OK_FG = "#1D8A5E"; BAD_FG = "#C0392B"

# morning-mail report keys (mirrors scripts/email_reports_graph.REPORT_MENU)
MAIL_REPORT_KEYS = ["daily_report", "flight_load", "june_target", "sales_person",
                    "sales_person_packs", "iata_worklist", "dsr_current"]


def open_instant_build(parent, reports_dir: Path) -> None:
    """Instant Reports — four boxes: raw files (pre-flight validated), data mode,
    reports (with presets), and build & results. Sequential client-side builds."""
    import datetime as dt
    import os
    import queue
    import threading
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk

    try:
        from . import instant                      # needs duckdb/pandas in THIS app
    except ImportError as exc:
        messagebox.showinfo("Instant reports",
                            f"This build of the app doesn't include the report engine ({exc}).")
        return

    CORE = {"daily", "dsr", "sales_person"}
    PRESETS = {
        "Morning": ["daily", "dsr", "sales_person"],
        "Targets": ["june_target", "underperformers", "salesperson_pack"],
        "Everything": list(instant.INSTANT_REPORTS),
    }
    kit = Path(reports_dir) / "Data_Kit_latest.zip"

    # Remembered output folder lives OUTSIDE the work root (survives "Clear stored data").
    def _remembered_output_dir() -> Path:
        try:
            v = (instant.WORK_ROOT.parent / "weekly_output_dir.txt").read_text(encoding="utf-8").strip()
            if v:
                return Path(v)
        except OSError:
            pass
        return Path.home() / "Documents" / "USBA Reports"

    def _remember_output_dir(v: str) -> None:
        try:
            instant.WORK_ROOT.parent.mkdir(parents=True, exist_ok=True)
            (instant.WORK_ROOT.parent / "weekly_output_dir.txt").write_text(str(v), encoding="utf-8")
        except OSError:
            pass

    win = tk.Toplevel(parent); win.title("Build reports from raw data")
    win.geometry("720x760"); win.configure(bg=WHITE); win.grab_set()
    tk.Label(win, text="Instant Reports", bg=WHITE, fg=NAVY,
             font=("Segoe UI", 14, "bold")).pack(anchor="w", padx=16, pady=(12, 0))
    tk.Label(win, text=("Pick the raw Zenith sales export(s). Reports build ON THIS computer, "
                        "one by one, using the analyst's latest Data Kit — nothing is uploaded."),
             bg=WHITE, fg=GREY, font=("Segoe UI", 9), wraplength=680,
             justify="left").pack(anchor="w", padx=16, pady=(2, 4))

    def box(title: str):
        f = tk.LabelFrame(win, text=f" {title} ", bg=WHITE, fg=NAVY,
                          font=("Segoe UI", 10, "bold"), padx=10, pady=6)
        f.pack(fill="x", padx=16, pady=(8, 0))
        return f

    q: "queue.Queue" = queue.Queue()
    raw_files: list = []          # [(Path, RawCheck)] — this week's exports
    base_files: list = []         # [(Path, RawCheck)] — explicit "data through last week"
    out_dir_var = tk.StringVar(value=str(_remembered_output_dir()))
    log_holder: dict = {}         # holds the Text widget (created later, in box 4)

    def log_line(msg: str):
        log = log_holder.get("w")
        if not log:
            return
        log.config(state="normal"); log.insert("end", msg + "\n")
        log.see("end"); log.config(state="disabled")

    # ====== BOX 1 · raw files ======
    b1 = box("1 · Raw sales files")
    kit_ok = kit.is_file()
    if kit_ok:
        age = (dt.datetime.now() - dt.datetime.fromtimestamp(kit.stat().st_mtime)).days
        kit_txt = (f"Data Kit: OK — {kit.name}  ·  {age} day(s) old"
                   + ("   ⚠ stale — ask the analyst to republish" if age > 7 else ""))
    else:
        kit_txt = f"Data Kit NOT FOUND on the share ({kit}) — ask the analyst to publish it"
    tk.Label(b1, text=kit_txt, bg=(GREEN_BG if kit_ok else AMBER_BG), fg=NAVY, anchor="w",
             font=("Segoe UI", 9)).pack(fill="x", ipady=3, pady=(0, 6))
    pickrow = tk.Frame(b1, bg=WHITE); pickrow.pack(fill="x")
    summary_lbl = tk.Label(pickrow, text="No file selected.", bg=WHITE, fg=GREY, font=("Segoe UI", 9))
    files_frame = tk.Frame(b1, bg=WHITE)

    def update_summary():
        n_ok = sum(1 for _p, c in raw_files if c.ok)
        n_bad = len(raw_files) - n_ok
        if not raw_files:
            summary_lbl.config(text="No file selected.", fg=GREY)
        else:
            txt = f"{n_ok} valid" + (f", {n_bad} rejected" if n_bad else "")
            summary_lbl.config(text=txt, fg=(OK_FG if n_ok and not n_bad else
                                             (BAD_FG if not n_ok else GREY)))

    def render_files():
        for w in files_frame.winfo_children():
            w.destroy()
        for i, (p, c) in enumerate(raw_files):
            row = tk.Frame(files_frame, bg=WHITE); row.pack(fill="x", pady=1)
            tk.Label(row, text="●", bg=WHITE, fg=(OK_FG if c.ok else BAD_FG),
                     font=("Segoe UI", 9)).pack(side="left")
            tk.Label(row, text=p.name[:42], bg=WHITE, fg=NAVY, font=("Segoe UI", 9),
                     width=44, anchor="w").pack(side="left", padx=(4, 0))
            tk.Label(row, text=c.message, bg=WHITE, fg=(GREY if c.ok else BAD_FG),
                     font=("Segoe UI", 8), anchor="w").pack(side="left", padx=(4, 0))
            tk.Button(row, text="✕", bg=WHITE, fg=GREY, relief="flat", font=("Segoe UI", 8),
                      command=lambda i=i: remove_file(i)).pack(side="right")
        files_frame.pack(fill="x", pady=(6, 0))
        update_summary()

    def remove_file(i: int):
        del raw_files[i]; render_files()

    def pick_raw():
        picks = filedialog.askopenfilenames(title="Raw Zenith sales export(s)",
                                            filetypes=[("Excel", "*.xlsx")])
        if not picks:
            return
        raw_files.clear()
        for p in picks:                       # validate_raw_file is instant + offline
            raw_files.append((Path(p), instant.validate_raw_file(Path(p))))
        render_files()
        bad = [p.name for p, c in raw_files if not c.ok]
        if bad:
            log_line("rejected (not sales exports): " + ", ".join(bad))

    tk.Button(pickrow, text="Choose raw sales file(s)…", bg=BLUE, fg=WHITE, relief="flat",
              padx=12, pady=4, command=pick_raw).pack(side="left")
    summary_lbl.pack(side="left", padx=10)

    # ====== BOX 2 · data mode ======
    b2 = box("2 · Data mode")
    mode_var = tk.StringVar(value="fresh")
    cov_lbl = tk.Label(b2, bg=WHITE, fg=GREY, font=("Segoe UI", 9))

    def refresh_coverage():
        lo, hi, n = instant.data_coverage()
        cov_lbl.config(text=(f"Stored from previous uploads: {lo} – {hi}  ({n:,} rows)"
                             if n else "No previous uploads stored."))

    def clear_stored():
        instant.clear_data(); refresh_coverage(); log_line("stored uploads cleared."); render_base()

    # Explicit base file ("data through last week") — attach a saved snapshot or last
    # week's export; it seeds the build BEFORE this week's files (newest day wins). Or
    # save the currently-accumulated data to a portable snapshot to re-attach later.
    base_bar = tk.Frame(b2, bg=WHITE); base_bar.pack(fill="x")
    tk.Label(base_bar, text="Base file (data through last week):", bg=WHITE, fg=NAVY,
             font=("Segoe UI", 9)).pack(side="left")
    tk.Button(base_bar, text="Attach base…", bg=WHITE, fg=BLUE, relief="flat",
              font=("Segoe UI", 8), command=lambda: pick_base()).pack(side="left", padx=(8, 0))
    tk.Button(base_bar, text="Save base snapshot…", bg=WHITE, fg=BLUE, relief="flat",
              font=("Segoe UI", 8), command=lambda: save_snapshot()).pack(side="left", padx=(6, 0))
    base_summary = tk.Label(b2, text="No base attached (optional).", bg=WHITE, fg=GREY,
                            font=("Segoe UI", 9)); base_summary.pack(anchor="w")
    tk.Label(b2, text="Base = a raw Zenith export or a saved snapshot — not a finished report.",
             bg=WHITE, fg=GREY, font=("Segoe UI", 8), wraplength=660, justify="left").pack(anchor="w")
    base_files_frame = tk.Frame(b2, bg=WHITE)

    def render_base():
        for w in base_files_frame.winfo_children():
            w.destroy()
        if not base_files:
            base_summary.config(text="No base attached (optional).", fg=GREY)
            base_files_frame.pack_forget()
            return
        n_ok = sum(1 for _p, c in base_files if c.ok)
        base_summary.config(
            text=f"Base: {n_ok} valid" + (f", {len(base_files) - n_ok} rejected" if n_ok < len(base_files) else ""),
            fg=(OK_FG if n_ok == len(base_files) else BAD_FG))
        for i, (p, c) in enumerate(base_files):
            row = tk.Frame(base_files_frame, bg=WHITE); row.pack(fill="x", pady=1)
            tk.Label(row, text="●", bg=WHITE, fg=(OK_FG if c.ok else BAD_FG), font=("Segoe UI", 9)).pack(side="left")
            tk.Label(row, text=p.name[:42], bg=WHITE, fg=NAVY, font=("Segoe UI", 9),
                     width=44, anchor="w").pack(side="left", padx=(4, 0))
            tk.Label(row, text=c.message, bg=WHITE, fg=(GREY if c.ok else BAD_FG),
                     font=("Segoe UI", 8), anchor="w").pack(side="left", padx=(4, 0))
            tk.Button(row, text="✕", bg=WHITE, fg=GREY, relief="flat", font=("Segoe UI", 8),
                      command=lambda i=i: (base_files.pop(i), render_base())).pack(side="right")
        base_files_frame.pack(fill="x", pady=(2, 0))

    def pick_base():
        picks = filedialog.askopenfilenames(
            title="Attach base file (saved snapshot or last week's export)",
            filetypes=[("Excel", "*.xlsx")])
        if not picks:
            return
        base_files.clear()
        for p in picks:
            base_files.append((Path(p), instant.validate_raw_file(Path(p))))
        render_base()

    def save_snapshot():
        lo, hi, n = instant.data_coverage()
        if not n:
            messagebox.showinfo("Save base snapshot", "No data accumulated yet — build once first."); return
        dest = filedialog.asksaveasfilename(
            title="Save base snapshot", defaultextension=".xlsx",
            filetypes=[("Excel", "*.xlsx")], initialfile=instant.default_snapshot_name(hi))
        if not dest:
            return
        build_btn.config(state="disabled"); log_line("saving base snapshot ...")

        def _work():
            try:
                q.put(("snap_ok", instant.export_base_snapshot(Path(dest))))
            except Exception as exc:                       # noqa: BLE001
                q.put(("snap_err", f"{type(exc).__name__}: {exc}"))

        threading.Thread(target=_work, daemon=True).start()
        win.after(120, poll)

    mrow = tk.Frame(b2, bg=WHITE); mrow.pack(anchor="w")
    tk.Radiobutton(mrow, text="Start fresh (only the files above)", value="fresh",
                   variable=mode_var, bg=WHITE, fg=NAVY, font=("Segoe UI", 9)).pack(side="left")
    tk.Radiobutton(mrow, text="Add to previous uploads (extend the date range)", value="append",
                   variable=mode_var, bg=WHITE, fg=NAVY, font=("Segoe UI", 9)).pack(side="left", padx=(12, 0))
    crow = tk.Frame(b2, bg=WHITE); crow.pack(fill="x", pady=(2, 0))
    cov_lbl.pack(in_=crow, side="left")
    tk.Button(crow, text="Clear stored data", relief="flat", bg=WHITE, fg=GREY,
              font=("Segoe UI", 8), command=clear_stored).pack(side="right")
    tk.Label(b2, text="Target-family numbers reflect the UPLOADED months only — use Append to "
                      "accumulate the 5-month history.", bg=WHITE, fg=GREY, font=("Segoe UI", 8),
             wraplength=660, justify="left").pack(anchor="w", pady=(2, 0))

    # ====== BOX 3 · reports ======
    b3 = box("3 · Reports to build")
    vars_: dict = {}

    def apply_preset(keys):
        for k, v in vars_.items():
            v.set(k in keys)

    prow = tk.Frame(b3, bg=WHITE); prow.pack(anchor="w", pady=(0, 6))
    tk.Label(prow, text="Presets:", bg=WHITE, fg=GREY, font=("Segoe UI", 9)).pack(side="left")
    for name, keys in PRESETS.items():
        tk.Button(prow, text=name, relief="flat", bg=WHITE, fg=BLUE, font=("Segoe UI", 8),
                  command=lambda k=keys: apply_preset(k)).pack(side="left", padx=(6, 0))
    tk.Button(prow, text="None", relief="flat", bg=WHITE, fg=GREY, font=("Segoe UI", 8),
              command=lambda: apply_preset([])).pack(side="left", padx=(6, 0))
    cgrid = tk.Frame(b3, bg=WHITE); cgrid.pack(anchor="w")
    for i, (key, label) in enumerate(instant.INSTANT_REPORTS.items()):
        v = tk.BooleanVar(value=(key in CORE)); vars_[key] = v
        tk.Checkbutton(cgrid, text=label, variable=v, bg=WHITE, fg=NAVY, font=("Segoe UI", 10),
                       anchor="w").grid(row=i // 2, column=i % 2, sticky="w", padx=(0, 24))

    # Agency Visit Tracking needs its own RAW workbook (per-rep visit sheets, not a sales
    # export). Optional: left empty, the builder takes the newest "Daily Agency Visit
    # Report*.xlsx" in Downloads.
    visit_var = tk.StringVar(value="")
    vrow = tk.Frame(b3, bg=WHITE); vrow.pack(fill="x", pady=(6, 0))
    tk.Label(vrow, text="Visit workbook (for Agency Visit Tracking):", bg=WHITE, fg=GREY,
             font=("Segoe UI", 9)).pack(side="left")
    tk.Entry(vrow, textvariable=visit_var, font=("Segoe UI", 9)).pack(
        side="left", fill="x", expand=True, padx=(6, 4))

    def pick_visit():
        p = filedialog.askopenfilename(title="Daily Agency Visit Report workbook",
                                       filetypes=[("Excel", "*.xlsx")])
        if p:
            visit_var.set(p)

    tk.Button(vrow, text="Browse…", bg=WHITE, fg=BLUE, relief="flat", font=("Segoe UI", 8),
              command=pick_visit).pack(side="left")

    # ====== BOX 4 · build & results ======
    b4 = box("4 · Build & results")
    orow = tk.Frame(b4, bg=WHITE); orow.pack(fill="x", pady=(0, 4))
    tk.Label(orow, text="Save reports to:", bg=WHITE, fg=NAVY, font=("Segoe UI", 9)).pack(side="left")
    tk.Entry(orow, textvariable=out_dir_var, font=("Segoe UI", 9)).pack(
        side="left", fill="x", expand=True, padx=(6, 4))

    def pick_out():
        d = filedialog.askdirectory(title="Save reports to")
        if d:
            out_dir_var.set(d)

    tk.Button(orow, text="Browse…", bg=WHITE, fg=BLUE, relief="flat", font=("Segoe UI", 8),
              command=pick_out).pack(side="left")
    brow = tk.Frame(b4, bg=WHITE); brow.pack(fill="x")
    build_btn = tk.Button(brow, text="Build (one by one)", bg=NAVY, fg=WHITE,
                          font=("Segoe UI", 10, "bold"), relief="flat", padx=16, pady=6)
    build_btn.pack(side="left")
    open_btn = tk.Button(brow, text="Open output folder", relief="flat", bg=WHITE, fg=BLUE,
                         state="disabled",
                         command=lambda: os.startfile(out_dir_var.get().strip() or str(instant.output_dir())))
    open_btn.pack(side="left", padx=10)
    prog = ttk.Progressbar(brow, mode="determinate")
    prog.pack(side="left", fill="x", expand=True, padx=(10, 0))
    results_frame = tk.Frame(b4, bg=WHITE); results_frame.pack(fill="x", pady=(6, 0))
    log = tk.Text(b4, height=7, bg="#F8F9FB", fg="#222222", font=("Consolas", 9),
                  relief="flat", state="disabled")
    log.pack(fill="both", expand=True, pady=(6, 0))
    log_holder["w"] = log

    def render_results(results):
        for w in results_frame.winfo_children():
            w.destroy()
        for key, p, msg in results:
            row = tk.Frame(results_frame, bg=WHITE); row.pack(fill="x", pady=1)
            tk.Label(row, text="●", bg=WHITE, fg=(OK_FG if p else BAD_FG),
                     font=("Segoe UI", 9)).pack(side="left")
            tk.Label(row, text=instant.INSTANT_REPORTS.get(key, key), bg=WHITE, fg=NAVY,
                     font=("Segoe UI", 9), width=30, anchor="w").pack(side="left", padx=(4, 0))
            if p:
                tk.Button(row, text="Open", relief="flat", bg=WHITE, fg=BLUE, font=("Segoe UI", 8),
                          command=lambda fp=str(p): os.startfile(fp)).pack(side="left")
            else:
                tk.Label(row, text=str(msg)[:60], bg=WHITE, fg=BAD_FG, font=("Segoe UI", 8),
                         anchor="w").pack(side="left", padx=(4, 0))

    def worker(base, week, keys, append, output_dir, visit_source):
        try:
            # Ingest one file at a time: the base seeds the store (fresh), then everything
            # appends so overlapping days take the NEWEST file (no double-counting). With
            # no base attached, the first file honours the fresh/append radio.
            for i, f in enumerate(base + week):
                app = True if i > 0 else (False if base else append)
                instant.assemble_root([f], kit, progress=lambda m: q.put(m), append=app)
            results = instant.build_reports(keys, progress=lambda m: q.put(m),
                                            output_dir=output_dir, visit_source=visit_source)
            q.put(("done", results))
        except Exception as exc:                   # noqa: BLE001 — show, don't crash the app
            q.put(("done_err", f"{type(exc).__name__}: {exc}"))

    def poll():
        try:
            while True:
                item = q.get_nowait()
                if isinstance(item, str):
                    log_line(item)
                    if item.lstrip().startswith(("[OK]", "[FAIL]")):
                        prog.step(1)
                elif item[0] == "done":
                    render_results(item[1])
                    ok = sum(1 for _k, p, _m in item[1] if p)
                    log_line(f"— finished: {ok}/{len(item[1])} report(s) built —")
                    prog.config(value=prog["maximum"])
                    open_btn.config(state="normal"); build_btn.config(state="normal")
                    _remember_output_dir(out_dir_var.get())
                    refresh_coverage()
                    return
                elif item[0] == "snap_ok":
                    info = item[1]
                    log_line(f"saved base snapshot: {info.rows:,} rows "
                             f"({info.first_date} – {info.last_date})  ->  {info.path}")
                    build_btn.config(state="normal")
                    messagebox.showinfo("Save base snapshot", f"Saved base snapshot:\n{info.path}")
                    return
                elif item[0] == "snap_err":
                    log_line(f"[ERROR] {item[1]}")
                    build_btn.config(state="normal")
                    messagebox.showerror("Save base snapshot", item[1])
                    return
                else:
                    log_line(f"[ERROR] {item[1]}")
                    prog.config(value=0); build_btn.config(state="normal")
                    return
        except queue.Empty:
            pass
        win.after(120, poll)

    def start():
        if not kit.is_file():
            messagebox.showerror("Instant reports", "Data Kit not found on the share."); return
        valid = [p for p, c in raw_files if c.ok]
        base_valid = [p for p, c in base_files if c.ok]
        bad = [p for p, c in raw_files if not c.ok] + [p for p, c in base_files if not c.ok]
        if not valid and not base_valid:
            messagebox.showerror("Instant reports",
                                 "Pick at least one valid sales xlsx (base and/or this week)."
                                 + ("\n\nThe selected file(s) are not Zenith sales exports."
                                    if (raw_files or base_files) else "")); return
        keys = [k for k, v in vars_.items() if v.get()]
        if not keys:
            messagebox.showerror("Instant reports", "Tick at least one report."); return
        if bad and not messagebox.askyesno(
                "Skip invalid files?",
                f"{len(bad)} selected file(s) are not sales exports and will be skipped.\n\n"
                f"Build from the valid file(s)?"):
            return
        out = out_dir_var.get().strip()
        output_dir = Path(out) if out else None
        build_btn.config(state="disabled"); open_btn.config(state="disabled")
        prog.config(value=0, maximum=len(keys))
        for w in results_frame.winfo_children():
            w.destroy()
        log_line(f"building {len(keys)} report(s) from "
                 f"{len(base_valid)} base + {len(valid)} this-week file(s), one by one ...")
        threading.Thread(target=worker,
                         args=(base_valid, valid, keys, mode_var.get() == "append", output_dir,
                               visit_var.get().strip() or None),
                         daemon=True).start()
        win.after(120, poll)

    build_btn.config(command=start)
    refresh_coverage()
    render_files()
    render_base()


def open_recipients_editor(parent, reference_dir: Path) -> None:
    """Grid editor for the morning-mail recipient list (no hand-built Excel needed)."""
    import tkinter as tk
    from tkinter import messagebox, ttk

    xlsx = Path(reference_dir) / "report_email_list.xlsx"

    win = tk.Toplevel(parent); win.title("Morning-mail recipients")
    win.geometry("680x460"); win.configure(bg=WHITE); win.grab_set()
    tk.Label(win, text="Report e-mail recipients", bg=WHITE, fg=NAVY,
             font=("Segoe UI", 14, "bold")).pack(anchor="w", padx=18, pady=(14, 0))
    tk.Label(win, text=(f"Saved to {xlsx.name} — the morning Graph mail reads it directly. "
                        "Reports: " + ", ".join(MAIL_REPORT_KEYS)),
             bg=WHITE, fg=GREY, font=("Segoe UI", 9), wraplength=640,
             justify="left").pack(anchor="w", padx=18, pady=(2, 8))

    cols = ("name", "email", "reports")
    tv = ttk.Treeview(win, columns=cols, show="headings", height=9)
    for c, h, w in (("name", "Name", 150), ("email", "Email", 220), ("reports", "Reports", 260)):
        tv.heading(c, text=h); tv.column(c, width=w, anchor="w")
    tv.pack(fill="both", expand=True, padx=18)

    # preload current file so editing is round-trip safe
    if xlsx.is_file():
        try:
            import openpyxl
            wb = openpyxl.load_workbook(xlsx, read_only=True)
            try:
                rows = list(wb.active.iter_rows(values_only=True))[1:]
            finally:
                wb.close()      # read_only holds the file locked until closed — the
                                # mailer SAVES this same xlsx, so release it promptly
            for r in rows:
                if r and (r[1] or "").strip():
                    tv.insert("", "end", values=(str(r[0] or ""), str(r[1]), str(r[2] or "")))
        except Exception:                          # noqa: BLE001 — start empty on a bad file
            pass

    form = tk.Frame(win, bg=WHITE); form.pack(fill="x", padx=18, pady=(8, 0))
    e_name, e_mail, e_rep = (tk.Entry(form, width=18), tk.Entry(form, width=26),
                             tk.Entry(form, width=30))
    for i, (lbl, ent) in enumerate((("Name", e_name), ("Email", e_mail),
                                    ("Reports (comma)", e_rep))):
        tk.Label(form, text=lbl, bg=WHITE, fg=GREY, font=("Segoe UI", 8)).grid(row=0, column=i, sticky="w")
        ent.grid(row=1, column=i, padx=(0, 8))
    e_rep.insert(0, "daily_report")

    def add_row():
        mail, reps = e_mail.get().strip(), e_rep.get().strip()
        if "@" not in mail or not reps:
            messagebox.showerror("Recipients", "Need a valid Email and at least one report key."); return
        tv.insert("", "end", values=(e_name.get().strip(), mail, reps))
        e_name.delete(0, "end"); e_mail.delete(0, "end")

    def remove_sel():
        for iid in tv.selection():
            tv.delete(iid)

    def save():
        import openpyxl
        wb = openpyxl.Workbook(); ws = wb.active; ws.title = "recipients"
        ws.append(["Name", "Email", "Reports"])
        for iid in tv.get_children():
            ws.append(list(tv.item(iid, "values")))
        for col, w in zip("ABC", (24, 34, 46)):
            ws.column_dimensions[col].width = w
        try:
            wb.save(xlsx)
        except PermissionError:
            messagebox.showerror("Recipients", f"{xlsx.name} is open in Excel — close it and Save again.")
            return
        messagebox.showinfo("Recipients", f"Saved {len(tv.get_children())} recipient(s) -> {xlsx}")

    btns = tk.Frame(win, bg=WHITE); btns.pack(fill="x", padx=18, pady=(8, 14))
    tk.Button(btns, text="Add", bg=BLUE, fg=WHITE, relief="flat", padx=14, command=add_row).pack(side="left")
    tk.Button(btns, text="Remove selected", relief="flat", bg=WHITE, fg=GREY,
              command=remove_sel).pack(side="left", padx=8)
    tk.Button(btns, text="Save", bg=NAVY, fg=WHITE, font=("Segoe UI", 10, "bold"),
              relief="flat", padx=18, command=save).pack(side="right")
