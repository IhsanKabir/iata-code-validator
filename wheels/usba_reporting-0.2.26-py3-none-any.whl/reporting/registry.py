"""
reporting.registry — the catalog of available reports.

Each entry maps a stable report KEY to a title, description, and parameter schema,
so BOTH the CLI and the desktop "Reports" tab can list and run reports generically
(no hardcoded report list in the GUI).

MIGRATION (Phase 0 -> 1)
------------------------
Builders are migrated incrementally. While a report is still produced by its original
standalone script under ``scripts/``, its entry carries ``status="script"`` and the
``cli_script`` name. As each builder is moved into ``reporting/builders/<key>.py`` with
a ``generate(params, cfg) -> Path`` function, flip ``status`` to ``"package"`` and set
``builder`` to the import path. The registry shape stays the same, so nothing downstream
changes.
"""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class Report:
    key: str
    title: str
    description: str
    params: dict = field(default_factory=dict)   # name -> {"type": ..., "default": ...}
    status: str = "script"                        # "package" (migrated) | "script" (legacy)
    cli_script: str = ""                          # scripts/<file>.py for legacy entries
    builder: str = ""                             # "reporting.builders.<key>:generate" when migrated


REPORTS: dict[str, Report] = {
    "june_target": Report(
        key="june_target",          # stable key — the report itself now targets JULY 2026
        title="July 2026 Target (capacity-aware)",
        description="July capacity × 90% LF × June route fares (verified ~741 cr basis), "
                    "NET & GROSS, cascaded to zone / route / agent.",
        status="package",   # ✅ migrated (gather() engine now lives here; underperformers imports it)
        cli_script="_build_june2026_target_capacity.py",
        builder="reporting.builders.june_target:generate",
    ),
    "salesperson_gross": Report(
        key="salesperson_gross",
        title="Sales-Person Gross Report",
        description="Per sales person (+ Unmapped); gross & net; excl. Web/App/Mobile/Counter; last 3 months + June month-to-date.",
        status="package",   # ✅ migrated
        cli_script="_build_salesperson_gross_report.py",
        builder="reporting.builders.salesperson_gross:generate",
    ),
    "salesperson_pack": Report(
        key="salesperson_pack",
        title="Sales-Person Target Packs (zip)",
        description="One xlsx per sales person: agent sales (3mo+MTD), zone target vs "
                    "achievement, agency route-wise targets; + bulk-mailer Email_Manifest. "
                    "Published as a single .zip bundle.",
        status="package",
        builder="reporting.builders.salesperson_pack:generate",
    ),
    "data_kit": Report(
        key="data_kit",
        title="Data Kit (instant-reports dimensions)",
        description="Prebuilt dim_customer + reference masters bundled for the exe's "
                    "Instant Reports tab. Published as a .zip with every morning run.",
        status="package",
        builder="reporting.builders.data_kit:generate",
    ),
    "underperformers": Report(
        key="underperformers",
        title="Zone Underperformers",
        description="Zones behind pace versus the committed target.",
        status="package",   # ✅ migrated (engine gather() imported transitionally until june_target moves)
        cli_script="_build_underperformers.py",
        builder="reporting.builders.underperformers:generate",
    ),
    "dsr": Report(
        key="dsr",
        title="Daily Sales Report (DSR)",
        description="DSR for a given month / date range (8 sheets: Dashboard, Agent, City Top-20, Day Wise, Top OTA, Top Corp, Zone Wise, directory).",
        params={"month": {"type": "month", "default": "2026-06"}},
        status="package",   # ✅ migrated (last builder — Phase 0 complete)
        cli_script="08_generate_dsr.py",
        builder="reporting.builders.dsr:generate",
    ),
    "daily_snapshot": Report(
        key="daily_snapshot",
        title="Daily Report",
        description="Yesterday + MTD by sector (gross & net, BDT lacs): totals with & without Counter/Web/App, top-8 countries, Counter/Web/Mobile rows, Top-10 OTA.",
        params={"date": {"type": "date", "default": None}},   # None -> latest data date
        status="package",
        cli_script="_build_daily_snapshot.py",
        builder="reporting.builders.daily_snapshot:generate",
    ),
    "load_report": Report(
        key="load_report",
        title="Flight Load",
        description="Flight x day matrix (history + forward): capacity, sold, flown, no-show, utilization & LF, with route/daily summaries.",
        params={"start": {"type": "date", "default": None}, "end": {"type": "date", "default": None}},
        status="package",
        cli_script="_build_load_report.py",
        builder="reporting.builders.load_report:generate",
    ),
    "iata_worklist": Report(
        key="iata_worklist",
        title="IATA Agencies — need name",
        description="Auto-named agencies that have an IATA number, for lookup & patching.",
        status="package",   # ✅ migrated
        cli_script="_export_iata_agencies_needname.py",
        builder="reporting.builders.iata_worklist:generate",
    ),
    "benefits_given": Report(
        key="benefits_given",
        title="Benefits Given to Agencies",
        description="Per agency, month by month — Segment + PLB + flown-coupon commission, with "
                    "Net Sale and Total Benefit (BS). Incentive recipients only. Built on the "
                    "pipeline machine from the revenue team's benefit files + gold; published for download.",
        status="package",
        cli_script="_build_benefits_given_report.py",
        builder="reporting.builders.benefits_given:generate",
    ),
    "visit_tracking": Report(
        key="visit_tracking",
        title="Agency Visit Tracking",
        description="Per-rep field-visit workbook parsed into one tracker: day-wise counts, "
                    "rep×day matrix, top-15 Dom/Intl agent visit coverage (fuzzy-matched to gold "
                    "sales), data-quality audit trail. Needs the month's 'Daily Agency Visit "
                    "Report*.xlsx' in Downloads (or a source path).",
        params={"source": {"type": "path", "default": None}},   # None -> newest in Downloads
        status="package",
        cli_script="_build_visit_tracking_report.py",
        builder="reporting.builders.visit_tracking:generate",
    ),
    "agency_route_monthly": Report(
        key="agency_route_monthly",
        title="Agency x Route Monthly (per Sales Person)",
        description="Per sales person: each agency's last-6-months, month by month, across the top "
                    "route pairs — tickets, amount, or both (chosen at build). Inline inactive "
                    "flags + an Inactive & New sheet + pivot-ready data. Built for mailing each "
                    "sales person their own slice.",
        params={"metric": {"type": "choice", "default": "tickets",
                           "choices": ["tickets", "amount", "both"]},
                "date_from": {"type": "date", "default": None},   # None -> last 6 complete months
                "date_to": {"type": "date", "default": None}},
        status="package",
        builder="reporting.builders.agency_route_monthly:generate",
    ),
    "incentive_file_emails": Report(
        key="incentive_file_emails",
        title="Incentive File + Sales-Person Emails",
        description="The revenue team's newest monthly incentive zip (PLB / DOM SEG / INT SEG) "
                    "re-issued with Sales Person + Email appended to every agency row (agency id "
                    "-> gold dominant sales person, falling back to the sheet's Zone; addresses "
                    "from salesperson_emails.xlsx). Built on the pipeline machine; published "
                    "for download.",
        params={"zip": {"type": "path", "default": None}},   # None -> newest zip in the benefits folder
        status="package",
        cli_script="_build_incentive_file_emails.py",
        builder="reporting.builders.incentive_file_emails:generate",
    ),
    "pnr_history": Report(
        key="pnr_history",
        title="PNR History (agency lens vs airline lens)",
        description="The full life of a booking from BOTH sides: what the selling agency sees "
                    "(its own rows) against what the airline sees (every row on the PNR, "
                    "whoever made it) — plus a transaction timeline and the reissue ticket "
                    "chain. Scope it by PNR list, by customer id, or leave both blank for "
                    "EXCEPTION MODE: bookings that were serviced elsewhere, reissued or "
                    "cancelled. Reads curated/sales only, so it also builds in Instant Reports.",
        params={"pnrs": {"type": "list", "default": None},        # explicit Record Locators
                "customer": {"type": "text", "default": None},    # trace one agency
                "date_from": {"type": "date", "default": None},
                "date_to": {"type": "date", "default": None},
                # exception mode is uncapped in principle but a single month holds ~25,000;
                # the cap is printed on the sheet, never applied silently
                "max_pnrs": {"type": "int", "default": 3000}},
        status="package",
        cli_script="_build_pnr_history.py",
        builder="reporting.builders.pnr_history:generate",
    ),
    "route_market_mix": Report(
        key="route_market_mix",
        title="Route x Issuing-Market Ticket Mix",
        description="Per route: total tickets, plus the COUNT and SHARE (%) of those tickets issued in "
                    "each market. Market = SALE CURRENCY (the reliable 'sold in' — Agency Country is "
                    "route-derived for direct bookings). Reads curated/sales only, so it also builds in "
                    "Instant Reports. Date range is chosen by the user.",
        params={"date_from": {"type": "date", "default": None},   # None -> earliest date in the data
                "date_to": {"type": "date", "default": None},     # None -> latest date in the data
                # 'issue'  = window filters when the ticket was SOLD (right for an uploaded sales
                #            export: counts every ticket in the file; flight rows fan out to the
                #            future travel dates those sales are for).
                # 'flight' = window filters when the flight OPERATES (tidy ~5 flight rows/route).
                "basis": {"type": "choice", "default": "issue", "choices": ["issue", "flight"]}},
        status="package",
        builder="reporting.builders.route_market_mix:generate",
    ),
    "city_market": Report(
        key="city_market",
        title="City-wise Market Sheet",
        description="The 63-destination demographic sheet built from the CITED market-facts store: "
                    "SUBMISSION in the template's exact shape, plus an EVIDENCE copy carrying the "
                    "source, year and confidence beside every value. Values that rest only on an "
                    "unapproved estimate print blank rather than as an unsigned-off number.",
        status="package",
        cli_script="_build_city_market.py",
        builder="reporting.builders.city_market:generate",
    ),
}

def list_reports() -> list[Report]:
    """Reports in a stable display order."""
    return list(REPORTS.values())
