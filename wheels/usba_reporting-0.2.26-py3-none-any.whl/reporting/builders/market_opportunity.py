"""
reporting.builders.market_opportunity: where the Bangladeshis are, versus where we fly.

WHY THIS EXISTS
    The city-wise sheet answers a question someone else asked: how many Bangladeshis live in
    each of 63 places. That is an input, not a decision. This report joins it to OUR OWN sales
    and asks the question the network team actually has: which of those markets are we
    under-serving, which are we saturating, and which are not diaspora markets at all.

THE ONE RATIO THAT DRIVES IT
    tickets per resident Bangladeshi = BS tickets YTD / Bangladeshis living in that city.
    On genuine diaspora routes it sits in a tight band, 0.1 to 0.6. Two of our routes sit three
    orders of magnitude away: Guangzhou at ~98 and Chennai at ~85. That is not an error in the
    diaspora figure, it is proof those routes are TRADE and MEDICAL travel by people who do not
    live there. Reading the diaspora column as market size on those two would be badly wrong,
    and the ratio is what exposes it.

WHAT IT WILL NOT DO
    It will not rank a market we cannot measure. Where the diaspora figure is apportioned (a
    model, not a count) the row is labelled and kept out of the penetration ranking, because a
    ratio built on a modelled denominator is a modelled ratio.
"""
from __future__ import annotations

from datetime import datetime
from pathlib import Path

import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side

from ..config import Config, load_config
from .city_market import (CONF_LABEL, _measure_of, _publisher_of, assemble, bs_evidence,
                          load_store)

NAVY, BLUE, WHITE = "1F3864", "2E5395", "FFFFFF"
GREEN, AMBER, RED, GREY = "E2EFDA", "FFF2CC", "FCE4E4", "F2F2F2"
BORDER = Border(*([Side(style="thin", color="BFBFBF")] * 4))
FI, F2 = "#,##0", "#,##0.00"

# The band genuine diaspora routes occupy. Measured across our own network: every VFR-type
# route lands inside it, and only trade/medical routes escape it.
DIASPORA_BAND = (0.05, 2.0)


def _c(ws, r, col, v, *, bold=False, fill=None, fmt=None, color="000000", size=9, wrap=False,
       align=None):
    cell = ws.cell(row=r, column=col, value=v)
    cell.font = Font(bold=bold, color=color, size=size)
    cell.border = BORDER
    if fill:
        cell.fill = PatternFill("solid", fgColor=fill)
    if fmt:
        cell.number_format = fmt
    if wrap or align:
        cell.alignment = Alignment(wrap_text=wrap, vertical="top", horizontal=align or "general")
    return cell


def _head(ws, r, heads, widths):
    for j, (h, w) in enumerate(zip(heads, widths), start=1):
        _c(ws, r, j, h, bold=True, fill=BLUE, color=WHITE, wrap=True)
        ws.column_dimensions[ws.cell(row=r, column=j).column_letter].width = w
    ws.row_dimensions[r].height = 32


def build_frame(cfg: Config) -> pd.DataFrame:
    """One row per destination: the market, our presence in it, and how the two relate."""
    facts, cw, sources = load_store(cfg)
    df = assemble(facts, cw, cfg)
    bs = bs_evidence(cfg, cw)
    rows = []
    for x in df.to_dict("records"):
        e = bs.get(x["code"], {})
        cd = x.get("city_dia")
        conf = x.get("city_dia_conf") or ""
        tk = e.get("tickets") or 0
        rows.append(dict(
            code=x["code"], city=x["city"], country=x["country"], iso3=x["iso3"],
            city_pop=x.get("city_pop"), city_dia=cd, dia_conf=conf,
            dia_counted=(conf == "measured"),
            dia_src=_publisher_of(x.get("city_dia_src", "")),
            dia_measure=_measure_of(x.get("city_dia_src", ""), conf),
            country_dia=x.get("country_dia"),
            serves=bool(e.get("serves")), tickets=tk, net_cr=e.get("net_cr") or 0.0,
            tpr=(tk / float(cd) if (tk and cd) else None)))
    d = pd.DataFrame(rows)

    def verdict(r):
        if not r.serves:
            if pd.isna(r.city_dia):
                return "no route, market unmeasured"
            return "NO ROUTE"
        if r.tpr is None:
            return "we fly it, market unmeasured"
        if r.tpr > DIASPORA_BAND[1]:
            return "NOT a diaspora market"          # trade / medical / leisure
        if r.tpr < DIASPORA_BAND[0]:
            return "under-penetrated"
        return "diaspora market, served"

    d["verdict"] = d.apply(verdict, axis=1)
    return d


def _sheet_summary(wb, d: pd.DataFrame) -> None:
    ws = wb.create_sheet("Summary")
    ws.column_dimensions["A"].width = 42
    ws.column_dimensions["B"].width = 16
    ws.column_dimensions["C"].width = 88
    _c(ws, 1, 1, "MARKET OPPORTUNITY: where the Bangladeshis are, versus where we fly",
       bold=True, size=13, color=WHITE, fill=NAVY)
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=3)

    served = d[d.serves]
    unserved = d[~d.serves]
    measurable = served[served.tpr.notna() & served.dia_counted]
    rows = [
        ("Destinations on the template", len(d), "the network team's own list"),
        ("We fly", int(d.serves.sum()),
         f"{served.tickets.sum():,.0f} tickets YTD, {served.net_cr.sum():,.1f} cr"),
        ("We do not fly", len(unserved),
         f"of which {int(unserved.city_dia.notna().sum())} have a measurable Bangladeshi community"),
        ("Routes measurable on counted data", len(measurable),
         "penetration is only computed where the diaspora figure is COUNTED, never modelled"),
        ("NOT diaspora markets", int((d.verdict == "NOT a diaspora market").sum()),
         "tickets per resident far outside the 0.05-2.0 band: trade, medical or leisure traffic"),
        ("Under-penetrated", int((d.verdict == "under-penetrated").sum()),
         "we fly there but sell few tickets relative to the community size"),
    ]
    r = 3
    for a, b, c in rows:
        _c(ws, r, 1, a, bold=True, color=NAVY, align="left")
        _c(ws, r, 2, b, fmt=FI, bold=True)
        _c(ws, r, 3, c, wrap=True)
        ws.row_dimensions[r].height = 30
        r += 1

    r += 1
    _c(ws, r, 1, "HOW TO READ THE RATIO", bold=True, size=11, color=WHITE, fill=NAVY)
    ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=3)
    r += 1
    for a, c in [
        ("tickets per resident 0.05 - 2.0",
         "A genuine diaspora route. Nearly every VFR market we serve sits in this band."),
        ("far ABOVE the band",
         "Not a diaspora market. Guangzhou is trade, Chennai is medical: the travellers do not "
         "live there, so the community figure is not the market size and must not be used as it."),
        ("far BELOW the band",
         "A large community we are not converting. This is the opportunity list, but check the "
         "competition and the visa regime before reading it as demand we can simply take."),
        ("no ratio shown",
         "The diaspora figure is APPORTIONED, a model rather than a count, so a ratio built on "
         "it would inherit the model. Deliberately left blank."),
    ]:
        _c(ws, r, 1, a, bold=True, align="left")
        _c(ws, r, 3, c, wrap=True)
        ws.row_dimensions[r].height = 30
        r += 1


def _sheet_served(wb, d: pd.DataFrame) -> None:
    ws = wb.create_sheet("Where We Fly")
    _c(ws, 1, 1, "OUR 14 ROUTES: market size, our volume, and how hard we are working it",
       bold=True, size=12, color=WHITE, fill=NAVY)
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=9)
    _head(ws, 2, ["Destination", "Country", "BD in city", "Basis", "Tickets YTD", "Net cr",
                  "Tickets per resident", "Verdict", "Source of the community figure"],
          [22, 16, 13, 20, 12, 10, 13, 24, 34])
    r = 3
    for x in d[d.serves].sort_values("net_cr", ascending=False).to_dict("records"):
        fill = (RED if x["verdict"] == "NOT a diaspora market"
                else AMBER if x["verdict"] == "under-penetrated"
                else GREEN if x["verdict"] == "diaspora market, served" else None)
        for j, (v, fmt) in enumerate([
                (f"{x['city']} ({x['code']})", None), (x["country"], None),
                (x["city_dia"], FI), (CONF_LABEL.get(x["dia_conf"], ""), None),
                (x["tickets"], FI), (x["net_cr"], F2),
                (round(x["tpr"], 2) if x["tpr"] is not None else None, F2),
                (x["verdict"], None), (x["dia_src"], None)], start=1):
            _c(ws, r, j, v, fmt=fmt, fill=fill if j == 8 else None, wrap=(j == 9))
        r += 1
    ws.freeze_panes = "A3"


def _sheet_gap(wb, d: pd.DataFrame) -> None:
    ws = wb.create_sheet("Markets We Do Not Fly")
    _c(ws, 1, 1, "COMMUNITIES WE DO NOT SERVE, largest first. A route case starts here, it does "
                 "not end here: this says nothing about slots, rights, competition or visas.",
       bold=True, size=12, color=WHITE, fill=NAVY)
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=6)
    _head(ws, 2, ["Destination", "Country", "BD in city", "Basis", "City population",
                  "Source of the community figure"], [22, 18, 14, 22, 15, 40])
    r = 3
    g = d[(~d.serves) & d.city_dia.notna()].sort_values("city_dia", ascending=False)
    for x in g.to_dict("records"):
        counted = x["dia_conf"] == "measured"
        for j, (v, fmt) in enumerate([
                (f"{x['city']} ({x['code']})", None), (x["country"], None),
                (x["city_dia"], FI), (CONF_LABEL.get(x["dia_conf"], ""), None),
                (x["city_pop"], FI), (x["dia_src"], None)], start=1):
            _c(ws, r, j, v, fmt=fmt, fill=(GREEN if counted else GREY) if j == 4 else None,
               wrap=(j == 6))
        r += 1
    ws.freeze_panes = "A3"


def _sheet_method(wb, d: pd.DataFrame, sources: pd.DataFrame) -> None:
    ws = wb.create_sheet("Method & Sources")
    ws.column_dimensions["A"].width = 26
    ws.column_dimensions["B"].width = 104
    _c(ws, 1, 1, "WHERE EVERY NUMBER COMES FROM", bold=True, size=12, color=WHITE, fill=NAVY)
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=2)
    notes = [
        ("Community figures", "From the cited market store, the same values as the city-wise "
                              "submission. Each carries its own source, year, measure and "
                              "confidence; see the City_wise_data_EVIDENCE pack."),
        ("Our own volume", "gold/sales_bi.parquet, ticket-payment rows, arrival airport matched "
                           "through the geography crosswalk so metro codes resolve to real "
                           "airports. Year to date."),
        ("The ratio", "tickets / Bangladeshis living in that city. Computed ONLY where the "
                      "community figure is counted, never where it is apportioned."),
        ("What it excludes", "Slots, traffic rights, competitor capacity, visa regimes and "
                             "aircraft availability. This report sizes markets, it does not "
                             "plan a network."),
        ("The measures differ", "Community figures come from censuses, civil registers, work "
                                "permits and mission estimates, which count different "
                                "populations. Each row states which. Do not rank on this column "
                                "without reading the basis beside it."),
    ]
    r = 3
    for a, b in notes:
        _c(ws, r, 1, a, bold=True, color=NAVY, align="left")
        _c(ws, r, 2, b, wrap=True)
        ws.row_dimensions[r].height = 42
        r += 1
    r += 1
    _c(ws, r, 1, "SOURCES USED", bold=True, size=11, color=WHITE, fill=NAVY)
    ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=2)
    r += 1
    if len(sources):
        for x in sources.to_dict("records"):
            _c(ws, r, 1, str(x.get("source_id", "")), bold=True, align="left")
            _c(ws, r, 2, f"{x.get('publisher','')} - {str(x.get('notes',''))[:220]}", wrap=True)
            ws.row_dimensions[r].height = 30
            r += 1


def generate(params: dict | None = None, cfg: Config | None = None) -> Path:
    params = params or {}
    cfg = cfg or load_config(validate=False)
    print("[market-opportunity] joining the cited market store to our own sales ...")
    d = build_frame(cfg)
    _, _, sources = load_store(cfg)

    wb = Workbook()
    wb.remove(wb.active)
    _sheet_summary(wb, d)
    _sheet_served(wb, d)
    _sheet_gap(wb, d)
    _sheet_method(wb, d, sources)

    served = d[d.serves]
    print(f"    {len(d)} destinations - we fly {int(d.serves.sum())}, "
          f"{served.tickets.sum():,.0f} tickets, {served.net_cr.sum():,.1f} cr")
    for v in ("NOT a diaspora market", "under-penetrated", "diaspora market, served"):
        n = int((d.verdict == v).sum())
        if n:
            who = ", ".join(d[d.verdict == v].code.head(6))
            print(f"    {v:<26}{n:>3}  {who}")

    out_dir = Path(params.get("out_dir") or cfg.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    out = out_dir / f"Market_Opportunity_{datetime.now():%Y%m%d}.xlsx"
    try:
        wb.save(out)
    except PermissionError:                 # house convention: never lose a run to an open file
        out = out.with_name(out.stem + "__new.xlsx")
        wb.save(out)
        print("    [note] the previous workbook is open in Excel, wrote a __new sibling")
    print(f"[OK] -> {out}")
    return out
