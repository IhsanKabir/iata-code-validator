"""
reporting.builders.dsr_salesperson: one Agent sheet per sales person, ready to email.

WHY THIS EXISTS RATHER THAN SPLITTING THE DSR
    Bulk Mailer can split a workbook by an email column, but it rebuilds each recipient's file
    from cell VALUES: a fresh Workbook, headers appended, rows appended. That keeps the numbers
    and loses everything else, including the collapsed twelve-month group this sheet is built
    around. It also reads row 1 as the header row, and row 1 of the Agent sheet is the title
    banner, so it refuses outright.

    Slicing rows out of a finished sheet would be worse than losing the formatting. The Agent
    sheet's row-4 Total is a SUM over the data range and the Top-10 panel is an INDEX/MATCH over
    the current-month column: delete rows underneath them and both keep pointing at ranges that
    no longer hold what they think. The totals would still look like totals.

    So each person's workbook is BUILT, not cut. It goes through dsr._write_agent_sheet, the
    same writer the DSR itself uses, so every formula is scoped to that person's own rows: their
    Total is their total, their Top-10 ranks their own agencies, and the nine older months are
    grouped and collapsed exactly as on the parent sheet.

WHAT EACH PERSON GETS
    One workbook, one sheet, the Agent layout they already know: identity columns, twelve months
    of history with the oldest nine behind a plus sign, the current month, segments, and the
    year-on-year pair. Only their own agencies.

WHAT IS DELIBERATELY NOT IN IT
    The four synthetic channel rollup rows (Z-Counter, Z-Corporate, Z-Mobi App, Z-Web). They are
    channels, not agencies, and belong to no sales person. Their presence on the parent sheet is
    what makes it reconcile to Day Wise Sales; on a personal cut they would simply be somebody
    else's money.

NOBODY IS DROPPED
    Agencies whose Sales Manager is blank go to _UNASSIGNED.xlsx and the count is printed. A
    per-person split that quietly discards the unowned agencies would hide exactly the gap the
    assignment worklist exists to close.

RUN
    .venv/Scripts/python.exe scripts/report.py dsr-salesperson
    .venv/Scripts/python.exe scripts/report.py dsr-salesperson -- --month 2026-07
"""
from __future__ import annotations

import calendar
import re
import zipfile
from datetime import date
from pathlib import Path

import duckdb
import pandas as pd
from openpyxl import Workbook

from ..config import Config, load_config
from . import dsr

MANIFEST_NAME = "Email_Manifest.xlsx"
UNASSIGNED = "_UNASSIGNED"
_UNSAFE = re.compile(r'[\\/:*?"<>|]+')


def _safe_name(label: str, used: set[str]) -> str:
    """A filesystem-safe, unique stem. Sales-person labels carry commas and dots."""
    stem = _UNSAFE.sub("_", str(label).strip()).strip(". ") or "recipient"
    stem = re.sub(r"\s+", " ", stem)[:80]
    base, n = stem, 2
    while stem.lower() in used:
        stem = f"{base} ({n})"
        n += 1
    used.add(stem.lower())
    return stem


def members_of(label: str) -> list[str]:
    """The individual people named in a Sales Manager cell.

    The master stores a co-owned agency as one comma-joined cell, "Naymul Islam, Abdul Aziz,
    Tawfiq Uddyam". Those are three people, not one owner with a long name.
    """
    return [m.strip() for m in str(label or "").split(",") if m.strip()]


def split_people(agent: pd.DataFrame) -> dict[str, pd.DataFrame]:
    """PERSON -> every agency they own, whether alone or jointly.

    One file per PERSON, not per label. Six people own some agencies outright and co-own others,
    so bucketing by the raw label would hand them two workbooks each and two emails, and neither
    would be their actual book.

    The consequence, stated plainly because it matters when reading the totals: a jointly owned
    agency appears in EACH co-owner's file. That is correct, they both work it, but it means the
    files deliberately do NOT sum to the network total. generate() prints how much is counted
    more than once so nobody adds them up and wonders.
    """
    if agent.empty or "Sales Manager" not in agent.columns:
        return {}
    df = agent[~agent["Zenith ID"].astype(str).str.startswith("Z-")].copy()
    labels = df["Sales Manager"].fillna("").astype(str)

    out: dict[str, list[int]] = {}
    for pos, label in enumerate(labels):
        people = members_of(label) or [UNASSIGNED]
        for person in people:
            out.setdefault(person, []).append(pos)
    return {p: df.iloc[idx] for p, idx in sorted(out.items())}


def manifest_rows(people: dict[str, str], emails: dict[str, str],
                  cc: str = "") -> list[dict[str, str]]:
    """One row per person, one file each.

    A person with no address still gets a row with the Email cell blank, for the analyst to
    fill. Bulk Mailer only sends rows it considers valid, so a missing address costs one unsent
    mail rather than a silent hole in the run, and the blank is visible in the sheet.
    """
    out: list[dict[str, str]] = []
    for person, filename in people.items():
        if person == UNASSIGNED:
            continue                       # nobody to send it to, by definition
        addr = emails.get(person) or emails.get(person.lower(), "")
        # one address per row: an address cell holding two people's mailboxes would send one
        # mail to both rather than an individual mail to each
        for one in ([a.strip() for a in str(addr).replace(";", ",").split(",") if a.strip()]
                    or [""]):
            out.append({"Email": one, "Name": person, "File": filename,
                        "CC": cc, "BCC": ""})
    return out


def write_manifest(path: Path, rows: list[dict[str, str]]) -> Path:
    """Bulk Mailer's mapping sheet.

    The header MUST be on row 1 and MUST carry Email / Name / File / CC / BCC: the reader does
    `header = next(rows_iter)`, so a guidance banner above it becomes the header and both
    required columns read as missing. File is required too, because a blank one marks the row
    invalid and the GUI only sends valid rows, so a broadcast with no attachment sends nothing.
    """
    df = pd.DataFrame(rows, columns=["Email", "Name", "File", "CC", "BCC"])
    try:
        df.to_excel(path, sheet_name="mapping", index=False)
    except PermissionError:                # open in Excel, write beside it rather than fail
        path = path.with_name(path.stem + "_v2.xlsx")
        df.to_excel(path, sheet_name="mapping", index=False)
    return path


def _person_workbook(rows: pd.DataFrame, person: str, start: date, end: date,
                     cur_label: str) -> Workbook:
    """One person's workbook, through the DSR's own writer so the layout cannot drift."""
    wb = Workbook()
    wb.remove(wb.active)
    who = "unassigned agencies" if person == UNASSIGNED else person
    dsr._write_agent_sheet(wb, "Agent", rows.reset_index(drop=True), start, end,
                           cur_label, subtitle=f" ({who})")
    ws = wb["Agent"]
    dsr._size_agent_columns(ws)
    dsr._group_older_months(ws, start)     # after the sizing; see that helper
    return wb


def generate(params: dict | None = None, cfg: Config | None = None) -> Path:
    params = params or {}
    cfg = cfg or load_config(validate=False)
    month = str(params.get("month") or "").strip()
    if month:
        y, m = (int(x) for x in month.split("-")[:2])
    else:                                   # default: the most recent complete month
        t = date.today().replace(day=1)
        prev = t - pd.Timedelta(days=1)
        y, m = prev.year, prev.month
    start = date(y, m, 1)
    end = date(y, m, calendar.monthrange(y, m)[1])
    cur_label = f"{calendar.month_abbr[m]}-{str(y)[-2:]}"
    print(f"[dsr-sp] building the agent frame for {cur_label} ...")

    con = duckdb.connect(str(dsr.WAREHOUSE))
    try:
        dsr.create_sales_view(con, start, end, zone=None)
        dsr.attach_customer_attrs(con)
        agent = dsr.build_agent_sheet(con, start, end)
    finally:
        con.close()
    if agent.empty:
        raise RuntimeError(f"no agent rows for {cur_label}")

    people = split_people(agent)
    print(f"[dsr-sp] {len(agent):,} agent rows -> {len(people)} bucket(s)")

    out_dir = Path(params.get("out_dir") or cfg.output_dir)
    pack_dir = out_dir / f"DSR_by_salesperson_{cur_label}"
    pack_dir.mkdir(parents=True, exist_ok=True)
    for old in pack_dir.glob("*.xlsx"):     # a fresh folder each run, never a stale mix
        try:
            old.unlink()
        except OSError:
            pass

    emails = dsr._salesperson_emails()
    used: set[str] = set()
    written: dict[str, str] = {}
    for person, rows in people.items():
        wb = _person_workbook(rows, person, start, end, cur_label)
        fname = f"{_safe_name(person, used)} {cur_label}.xlsx"
        try:
            wb.save(pack_dir / fname)
        except PermissionError:
            fname = fname.replace(".xlsx", "_v2.xlsx")
            wb.save(pack_dir / fname)
        written[person] = fname
        net = rows[f"{cur_label} Sales"].sum() if f"{cur_label} Sales" in rows else 0
        print(f"    {person[:44]:<46} {len(rows):>5} agencies  {net/1e7:>9,.2f} cr")

    # HOW MUCH IS COUNTED TWICE. A jointly owned agency is in each co-owner's file on purpose,
    # so the files do not sum to the network total. Saying so with a number is the difference
    # between a known convention and a reconciliation nobody can close.
    sales_col = f"{cur_label} Sales"
    shared = agent[agent["Sales Manager"].fillna("").astype(str).str.contains(",")]
    shared = shared[~shared["Zenith ID"].astype(str).str.startswith("Z-")]
    if len(shared):
        extra = sum((len(members_of(r)) - 1) * v for r, v in
                    zip(shared["Sales Manager"], shared[sales_col].fillna(0)))
        print(f"[dsr-sp] {len(shared):,} agencies are jointly owned and appear in each "
              f"co-owner's file, so the files overlap by {extra/1e7:,.2f} cr. "
              f"They are NOT meant to add up to the network total.")

    mrows = manifest_rows(written, emails)
    mpath = write_manifest(pack_dir / MANIFEST_NAME, mrows)
    blank = [r["Name"] for r in mrows if not r["Email"]]
    if blank:
        print(f"[dsr-sp] no address on file for {len(blank)}: {', '.join(sorted(set(blank)))}")
        print("         their rows are in the manifest with Email blank; fill them or the "
               "mailer will skip those rows")
    if UNASSIGNED in written:
        n = len(people[UNASSIGNED])
        print(f"[dsr-sp] {n:,} agencies have NO sales manager: {written[UNASSIGNED]}. "
              f"They are NOT in the manifest because there is nobody to send them to. "
              f"Run report.py unzoned-agencies to assign them.")

    zip_path = out_dir / f"DSR_by_salesperson_{cur_label}.zip"
    try:
        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
            for f in sorted(pack_dir.glob("*.xlsx")):
                z.write(f, arcname=f.name)
    except PermissionError:
        zip_path = zip_path.with_name(zip_path.stem + "_v2.zip")
        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
            for f in sorted(pack_dir.glob("*.xlsx")):
                z.write(f, arcname=f.name)

    print(f"\n[OK] {len(written)} workbook(s) -> {pack_dir}")
    print(f"     manifest: {mpath.name}  ({len(mrows)} recipient row(s))")
    print(f"     zip:      {zip_path}")
    print("\nTO SEND: point Bulk Mailer's mapping at the manifest and its attachments folder "
          "at the pack folder. Each file is attached whole, so the plus sign still works.")
    return zip_path
