"""
08_generate_dsr.py
==================

Generate the monthly DSR (Daily Sales Report) workbook for any date range.

What it produces
----------------
A single Excel file with 7 sheets that match the company's standard DSR template:

  1. ``Day Wise Sales``           — Particulars (BSP/Non-IATA/Counter/Corporate
                                     by Country) × Day grid, in lacs
  2. ``City Wise Top 20 Agent``   — Top 20 BSP+Non-IATA agents per city, with
                                     last-3-month comparison
  3. ``Top OTA``                  — Top OTAs (list maintained in
                                     reference/ota_list.xlsx)
  4. ``Top Corp``                 — Top corporate accounts
  (Mobi App and Web are stacked at the bottom of Day Wise Sales, matching
   the company's standard DSR template — no separate sheet for them.)
  6. ``Zone Wise Sales``          — Zone-wise performance (all zones BD + overseas)
                                     with 3-month history
  7. ``Sheet1``                   — Static zone manager directory (placeholder)

Money is "Net after refund/voids" — i.e., Net Sales (after commission, only for
Ticket payment + Reissuance) minus Refunds/Voids/Cancel refund. Penalty income
flows through 100% (no commission). Other transaction types are NOT included
in DSR amounts.

Usage
-----
    python scripts/08_generate_dsr.py --start 2026-04-01 --end 2026-04-30 \\
                                       --output "E:/path/DSR USBA Apr26.xlsx"

The script also accepts ``--month YYYY-MM`` for convenience:

    python scripts/08_generate_dsr.py --month 2026-04 --output "..."

Runs in ~10-15 seconds against the warehouse.
"""

from __future__ import annotations

import argparse
import calendar
import sys
from datetime import date, datetime, timedelta
from pathlib import Path

import duckdb
import pandas as pd
from openpyxl import Workbook
from openpyxl.chart import LineChart, Reference
from openpyxl.formatting.rule import FormulaRule
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from ..config import load_config
from ..ota import resolve_ota_ids
from ..kam import (bucket as kam_bucket, is_shared_bucket, NO_KAM)

_CFG = load_config()                       # frozen-aware data root (ANALYSIS_HOME -> settings -> dev)
PROJECT_ROOT = _CFG.data_root              # all PROJECT_ROOT-derived paths + the per-function `glob` flow from here
WAREHOUSE = PROJECT_ROOT / "warehouse.duckdb"
COMMISSION_RATES_FILE = PROJECT_ROOT / "reference" / "commission_rates.xlsx"
OTA_LIST_FILE = PROJECT_ROOT / "reference" / "ota_list.xlsx"
ZONE_MGR_FILE = PROJECT_ROOT / "reference" / "zone_managers.xlsx"
_DIM_ZONE = (PROJECT_ROOT / "reference" / "dim_zone.parquet").as_posix()

# Country display order for the Day Wise Sales sheet's Particulars rows.
# Bangladesh first (home market), then other countries alphabetically.
COUNTRY_ORDER = [
    "Bangladesh",
    "India",
    "Malaysia",
    "Oman",
    "Qatar",
    "Singapore",
    "UAE",
    "United Arab Emirates",
    "China",
    "United Kingdom",
    "KSA",
    "Saudi Arabia",
    "Kuwait",
    "Thailand",
    "Nepal",
    "Maldives",
    "Sri Lanka",
]

LAC = 100_000.0  # 1 lac = 100,000 BDT. DSR shows everything in lacs.


# ---------------------------------------------------------------------------
# DSR colour palette — mirrors the company's "DSR USBA *.xlsx" template.
#
# These ARGB values were extracted from the source template's Office 2013-2022
# theme (xl/theme/theme1.xml). Reproducing them here lets us write a workbook
# that visually matches what the operations team is used to.
#
#   GOLD   = theme7 / accent4  -> primary title banner (Day Wise Sales row 1)
#   GREEN  = theme9 / accent6  -> "highest sales" pip and Zone Wise headers
#   ORANGE = theme5 / accent2  -> Sheet1 (zone manager) row headers
#   BLUE   = theme4 / accent1  -> Sheet1 font colour
#   CREAM  = #FFFAEB           -> Day Wise Sales date/day header rows
#   RED    = #FF0000           -> City Wise / Top OTA / Top Corp banner font
# ---------------------------------------------------------------------------

DSR_GOLD   = "FFC000"   # theme7 accent4 (kept for trend legend)
DSR_GREEN  = "70AD47"   # theme9 accent6 (kept for highest-of-day pip)
DSR_GREEN_BRIGHT = "00B050"   # used for Trend "Above 100%" legend
DSR_GREEN_LIGHT  = "92D050"   # Trend "Between 75-100%"
DSR_ORANGE = "ED7D31"   # theme5 accent2
DSR_BLUE   = "4472C4"   # theme4 accent1
DSR_CREAM  = "FFFAEB"
DSR_RED    = "FF0000"
DSR_BLACK  = "000000"
DSR_WHITE  = "FFFFFF"

# Corporate "USBA Dashboard" palette — matches the user's enhanced April DSR
DSR_NAVY        = "1F3864"   # primary brand colour (banners / titles)
DSR_BLUE_MED    = "2E5395"   # KPI sub-header backgrounds
DSR_BLUE_LIGHT  = "D9E1F2"   # navigation / accent fills
DSR_GREY_LIGHT  = "F2F2F2"   # alternate-row stripe
DSR_GREY_TEXT   = "7F7F7F"   # subtitle / footnote text
DSR_DARK_RED    = "C00000"   # "Weekend drag" / negative variance flag

# Number formats borrowed straight from the source template
FMT_LAC_ACC   = '0.00_);[Red](0.00)'          # 1234.56  -> 1234.56 ; -1234.56 in red
FMT_INT_ACC   = '#,##0_);[Red](#,##0)'         # 1,234,567 ; (1,234,567) in red
FMT_PERCENT   = '0.00%'
FMT_DATE_ABBR = 'mm-dd-yy'

# A single thin black border used for every body / header cell
_thin = Side(border_style="thin", color=DSR_BLACK)
DSR_BORDER = Border(left=_thin, right=_thin, top=_thin, bottom=_thin)


# ---------------------------------------------------------------------------
# Commission-rate SQL (mirrors 05_build_fact_customer_monthly.py)
# ---------------------------------------------------------------------------

def build_rate_sql() -> str:
    """
    Build the per-row CASE WHEN ... END that yields the commission rate,
    honoring the time-versioned schema (effective_from / effective_to).

    See target.py::build_rate_sql for the canonical docstring — this is the
    same logic in the DSR generator. When the rates file is edited (e.g. a
    rate change on 2026-06-01), simply re-run this script and historical
    months keep their original rates while new months use the updated rate.

    A half-finished rule in the spreadsheet is SKIPPED, not compiled. On 2026-09-02 a row was
    added with match_field "Counters", no match_values and no effective_from; it became
    `IN ('nan')` on a column that does not exist and the DSR stopped building entirely, for
    every month, with an error that named the phantom column instead of the row. See
    reporting.common.usable_rate_rules.
    """
    if not COMMISSION_RATES_FILE.exists():
        return "0.07"
    from ..common import rate_case_sql

    rates = pd.read_excel(COMMISSION_RATES_FILE, sheet_name="rates").sort_values("rule_order")
    # The column list is read from the sales source so a rule naming a column that does not
    # exist is REJECTED here, with the rule number and the field name, instead of compiling
    # into SQL that fails later against a phantom column. That is precisely how the 2026-09-02
    # row presented: an error about "Counters" and no clue that a spreadsheet row caused it.
    # Wrapped, because failing to read the schema must never be the reason a report cannot run.
    known = None
    try:
        import duckdb
        glob = (PROJECT_ROOT / "curated" / "sales").as_posix() + "/**/*.parquet"
        known = [r[0] for r in duckdb.connect().execute(
            f"DESCRIBE SELECT * FROM read_parquet('{glob}', hive_partitioning=1, "
            f"union_by_name=1) LIMIT 0").fetchall()]
    except Exception:                                              # noqa: BLE001
        pass
    return rate_case_sql(rates, indent="    ", known_columns=known)


# ---------------------------------------------------------------------------
# Sales view with "DSR amount" — net after refund/voids per row
# ---------------------------------------------------------------------------

# --------------------------------------------------------------------------- #
# Agency sibling merge (multi-ID agencies)
# --------------------------------------------------------------------------- #
def _sibling_primary(con) -> dict[str, str]:
    """cid -> the PRIMARY cid of its agency, for agencies trading under several Customer IDs.

    WHY the DSR needs this: an agency that migrated accounts (or holds an IATA + a Non-IATA
    code) appears in the source data under 2+ customer ids. Grouping by raw id therefore lists
    ONE agency as two separate agents — Be Fresh and Go Zayaan each showed up twice on the
    Agent sheet, and every ranking (Agent, City-wise Top 20, Top OTA, Zone-wise) split their
    volume, pushing them DOWN the tables. Remapping the id at the single source table
    (dsr_sales) makes every downstream sheet fold correctly with no other change.

    Groups come from the audited reference/agency_merge_map.csv (use=1 rows only — the analyst
    can veto a group by flipping that flag), PLUS the long-standing hardcoded sibling pairs.
    The SURVIVING id per group is the one with the most transactions in the window's own data,
    so the Zenith ID printed on the report is the agency's dominant, recognisable code;
    ties break on the id string so two runs never disagree.

    Absent map file (e.g. a colleague's exe, which has no reference/ folder) -> returns the
    hardcoded pairs only, and the DSR still builds exactly as before for everything else.
    """
    groups: dict[str, str] = {}          # cid -> group key
    weight: dict[str, float] = {}        # cid -> all-time size, for electing the survivor
    # (a) hardcoded IATA/Non-IATA sibling pairs. Their survivor is named OUTRIGHT rather than
    #     elected: these three are the agencies everyone recognises by a specific code, and a
    #     data-driven flip would rename them on the report for no good reason.
    HARD_PRIMARY = {"BEFRESH": "10000277", "TALON": "10000179", "GOZAYAAN": "12084060"}
    for cid, key in {"10000277": "BEFRESH", "11662412": "BEFRESH",
                     "10000179": "TALON",   "11731796": "TALON",
                     "10502007": "GOZAYAAN", "12084060": "GOZAYAAN"}.items():
        groups[cid] = key
    # (b) the generated, analyst-vetoable map
    f = _CFG.data_root / "reference" / "agency_merge_map.csv"
    if f.is_file():
        try:
            m = pd.read_csv(f, dtype=str)
            for r in m.itertuples():
                if str(getattr(r, "use", "")).strip() != "1":
                    continue
                cid = str(r.cid).strip()
                groups.setdefault(cid, f"NM:{r.merge_key}")   # hardcoded pairs win
                try:                                          # all-time net per id, from the map
                    weight[cid] = float(getattr(r, "net_lac", 0) or 0)
                except (TypeError, ValueError):
                    weight[cid] = 0.0
        except Exception as exc:                              # unreadable -> hardcoded only
            print(f"[dsr] WARN: could not read agency_merge_map.csv ({exc}); "
                  f"merging the hardcoded pairs only")
    if not groups:
        return {}

    # The surviving id must be one the Agent sheet can actually PRINT. That sheet lists only
    # customers matching dim_customer's agency predicate, so electing an id outside it moves the
    # agency's money onto a row the sheet never renders — the total silently drops (it cost
    # 29.4M BDT of July sales the first time). Load the displayable set and rank on it first.
    displayable: set[str] = set()
    try:
        dimf = PROJECT_ROOT / "curated" / "dim_customer" / "dim_customer.parquet"
        if dimf.is_file():
            dd = con.sql(f"""
                SELECT CAST(customer_id AS VARCHAR) AS cid
                FROM read_parquet('{dimf.as_posix()}')
                WHERE agent_type IN ('BSP', 'Non-IATA', 'Non BSP')
                   OR (primary_channel = 'AGENCY' AND agent_type IS NULL)
            """).df()
            displayable = set(dd.cid.astype(str))
    except Exception as exc:                                  # unreadable -> rank on size alone
        print(f"[dsr] WARN: could not read dim_customer for sibling election ({exc})")

    # Elect from ALL-TIME size (the map's own audited net_lac), NOT from row counts inside this
    # report's window.
    #
    # Why window-independence matters: a window-dependent election makes the SAME agency surface
    # under a different Zenith ID in different reports — June's DSR could print one id and
    # July's the other, and a 4-month report would disagree with the 1-month DSR on 16 groups.
    # Any join between two reports on Zenith ID then silently loses those agencies. All-time net
    # is a property of the agency, not of the window, so every consumer agrees.
    # Ties break on the id string, so two runs never disagree.
    primary: dict[str, str] = {}
    ids = sorted(groups)
    for key in set(groups.values()):
        members = sorted(c for c in ids if groups[c] == key)
        if key in HARD_PRIMARY and HARD_PRIMARY[key] in members:
            winner = HARD_PRIMARY[key]
        else:
            winner = sorted(
                members,
                key=lambda c: (0 if (not displayable or c in displayable) else 1,
                               -weight.get(c, 0.0), c))[0]
        for c in members:
            primary[c] = winner
    return {c: p for c, p in primary.items() if c != p}       # only real remaps


def create_sales_view(con: duckdb.DuckDBPyConnection, start: date, end: date,
                      zone: str | None = None) -> None:
    """
    Build a working view ``dsr_sales`` for the requested date range.

    If ``zone`` is given (e.g. 'Zone-4'), the base table is filtered to only
    customers in that zone, so EVERY downstream sheet (Day Wise, City Wise,
    Top OTA/Corp, Zone Wise, Agent, and the YoY history columns - which are
    scoped to this customer set) is automatically restricted to that zone.

    Per-row ``dsr_amount`` is the contribution of that row to "Net after
    refund/voids":

      Ticket payment / Reissuance Adjustment:
        fare * (1 - commission_rate) + tax_amount   (the "net sale" after commission)

      Refund / Ticket void / Cancel refund:
        balance                                       (already negative)

      Penalty:
        balance                                       (full, no commission)

      Everything else (Commission rows, ACM/ADM, etc.):
        0                                             (not counted in DSR)

    Sum ``dsr_amount`` over any (customer, date, particulars) slice to get the
    DSR cell value.
    """
    rate_sql = build_rate_sql()
    glob = (PROJECT_ROOT / "curated" / "sales").as_posix() + "/**/*.parquet"
    # TABLE (not VIEW) — materialize the date-range slice once so the seven
    # sheets that query off it don't each rescan 6M parquet rows. Cuts run
    # time from ~5 minutes to ~10 seconds.
    # Data-quality remap: some GDS export rows have the POS string in the
    # 'Customer ID' field instead of the numeric customer code. The most
    # common case is "BO-1 Central Reservation" (USBA's internal reservation
    # desk) which carries refunds belonging to AKBAR TRAVELS OF INDIA LLC
    # (real customer_id 11246131). Without this remap those rows pile up in
    # 'Others' as a giant negative bucket and skew the DSR by ~1,800 lacs.
    #
    # If you spot another POS-in-customer-id case, add a WHEN row here.
    con.sql(f"""
        CREATE OR REPLACE TEMPORARY TABLE dsr_sales AS
        SELECT
            CASE
                WHEN CAST("Customer ID" AS VARCHAR) = 'BO-1 Central Reservation'
                    THEN '11246131'                       -- AKBAR TRAVELS OF INDIA LLC
                ELSE regexp_replace(CAST("Customer ID" AS VARCHAR), '\\.0$', '')
            END AS customer_id,
            CAST("Transaction"                       AS VARCHAR)  AS txn,
            CAST("Point of sales"                    AS VARCHAR)  AS pos,
            CAST("Sale currency"                     AS VARCHAR)  AS currency,
            "Date"::DATE                                          AS date,
            CAST("Balance (base currency)"           AS DOUBLE)   AS balance,
            CAST("Total without taxe (base currency)" AS DOUBLE)  AS fare,
            CASE
                WHEN CAST("Transaction" AS VARCHAR) IN ('Ticket payment', 'Reissuance Adjustment') THEN
                    COALESCE(CAST("Total without taxe (base currency)" AS DOUBLE), 0)
                    * (1 - ({rate_sql}))
                    + (COALESCE(CAST("Balance (base currency)" AS DOUBLE), 0)
                       - COALESCE(CAST("Total without taxe (base currency)" AS DOUBLE), 0))
                WHEN CAST("Transaction" AS VARCHAR) IN ('Refund', 'Ticket void', 'Cancel refund') THEN
                    COALESCE(CAST("Balance (base currency)" AS DOUBLE), 0)
                WHEN CAST("Transaction" AS VARCHAR) = 'Penalty' THEN
                    COALESCE(CAST("Balance (base currency)" AS DOUBLE), 0)
                ELSE 0.0
            END AS dsr_amount
        FROM read_parquet('{glob}', hive_partitioning=1, union_by_name=1)
        WHERE "Date" IS NOT NULL
          AND "Date"::DATE BETWEEN DATE '{start.isoformat()}' AND DATE '{end.isoformat()}'
    """)

    # Fold multi-ID agencies onto one surviving id (see _sibling_primary). Done HERE, on the
    # single source table, so every downstream sheet — Agent, City-wise Top 20, Top OTA,
    # Top Corp, Zone-wise — inherits the merge automatically. Money is untouched: this only
    # relabels which agency a row belongs to, so all totals stay identical.
    _sib = _sibling_primary(con)
    if _sib:
        _pairs = ", ".join(f"('{c}','{p}')" for c, p in sorted(_sib.items()))
        con.sql(f"CREATE OR REPLACE TEMPORARY TABLE dsr_sibling(cid VARCHAR, primary_cid VARCHAR)")
        con.sql(f"INSERT INTO dsr_sibling VALUES {_pairs}")
        con.sql("""
            CREATE OR REPLACE TEMPORARY TABLE dsr_sales AS
            SELECT s.* EXCLUDE (customer_id),
                   COALESCE(m.primary_cid, s.customer_id) AS customer_id
            FROM dsr_sales s LEFT JOIN dsr_sibling m ON m.cid = s.customer_id
        """)
        print(f"[dsr] merged {len(_sib)} sibling customer id(s) onto their primary agency")

    # dsr_src — the FULL sales history (not just this window) with sibling ids folded.
    # A VIEW, not a table: it stays lazy, so the historical queries below (previous-3-months
    # columns, YoY blocks) cost exactly what they did before while still seeing merged agencies.
    # Without this, the current month would fold Be Fresh's two ids but the prior-month columns
    # beside it would still show them apart — the report would contradict itself across columns.
    _clean_cid = ("regexp_replace(CAST(\"Customer ID\" AS VARCHAR), '\\.0$', '')")
    if _sib:
        con.sql(f"""
            CREATE OR REPLACE TEMPORARY VIEW dsr_src AS
            SELECT r.* EXCLUDE ("Customer ID"),
                   COALESCE(m.primary_cid, {_clean_cid}) AS "Customer ID"
            FROM read_parquet('{glob}', hive_partitioning=1, union_by_name=1) r
            LEFT JOIN dsr_sibling m ON m.cid = {_clean_cid}
        """)
    else:
        con.sql(f"""
            CREATE OR REPLACE TEMPORARY VIEW dsr_src AS
            SELECT * FROM read_parquet('{glob}', hive_partitioning=1, union_by_name=1)
        """)

    # Optional single-zone filter: drop every row whose (cleaned) customer_id
    # is not in the requested zone. Done as a DELETE on the already-cleaned
    # customer_id so the BO-1 remap is respected.
    if zone:
        before = con.sql("SELECT COUNT(*) FROM dsr_sales").fetchone()[0]
        con.sql(f"""
            DELETE FROM dsr_sales
            WHERE customer_id NOT IN (
                SELECT CAST(customer_id AS VARCHAR) FROM dim_customer
                WHERE zone = '{zone}'
            )
        """)
        after = con.sql("SELECT COUNT(*) FROM dsr_sales").fetchone()[0]
        n_cust = con.sql(f"SELECT COUNT(*) FROM dim_customer WHERE zone = '{zone}'").fetchone()[0]
        print(f"  zone filter '{zone}': {n_cust} customers in zone; "
              f"kept {after:,} of {before:,} sales rows")


# ---------------------------------------------------------------------------
# Customer-level categorization (BSP / Non-IATA / Counter / Corporate / etc.)
# ---------------------------------------------------------------------------

def attach_customer_attrs(con: duckdb.DuckDBPyConnection) -> None:
    """
    Build ``dsr_sales_enriched`` — joins dim_customer for category + country.

    Category precedence (first match wins). This **matches the company DSR's
    Day Wise Sales layout**: an OTA that holds an IATA accreditation still
    appears on the BSP line; the Top OTA sheet is a separate ranked view of
    OTAs and does not change the Day Wise classification.

       1. customer_name starts with 'CORP'                     -> 'Corporate'
       2. primary_channel = 'OFFICE'                           -> 'Counter'
       3. agent_type = 'BSP'                                   -> 'BSP'
       4. agent_type IN ('Non-IATA', 'Non BSP')                -> 'Non-IATA'
       5. primary_channel = 'WEB'                              -> 'Web'
       6. primary_channel = 'MOBILE'                           -> 'Mobi App'
       7. else                                                 -> 'Others'

    Country fallback chain:
       1. dim_customer.geo_country (from zone master or IATA patch)
       2. For OFFICE / direct-channel transactions, derive from POS prefix
          (DAC/CGP/CXB/... -> Bangladesh; INT Doha -> Qatar; etc.)
       3. Default 'Bangladesh' (the dominant market — true for ~90% of unmapped)
    """
    # TABLE (not VIEW) for same materialization reason as dsr_sales.
    con.sql("""
        CREATE OR REPLACE TEMPORARY TABLE dsr_sales_enriched AS
        SELECT
            s.*,
            c.customer_name,
            c.iata_number,
            c.primary_channel,
            c.agent_type,
            c.zone,
            c.zone_city_code,
            CASE
                -- 'Corporate' is matched by "CORP " (with trailing SPACE) so
                -- the rule catches "CORP Abul Khair Group", "CORP BRAC" etc.
                -- without false-matching travel agencies named "CORPORATE
                -- TRAVEL MANAGEMENT" or "CORPORATE INFORMATION TRAVEL SDN BHD"
                -- (~18 such overseas agencies — they cascade into Non-IATA via
                -- the later AGENCY-no-agent_type rule).
                WHEN c.customer_name ILIKE 'CORP %'                  THEN 'Corporate'
                WHEN c.primary_channel = 'OFFICE'                   THEN 'Counter'
                -- USBA's own backup reservation desks (CALL_CENTER channel)
                -- behave like internal counter sales, not external agencies.
                WHEN c.primary_channel = 'CALL_CENTER'              THEN 'Counter'
                WHEN c.agent_type = 'BSP'                           THEN 'BSP'
                WHEN c.agent_type IN ('Non-IATA', 'Non BSP')        THEN 'Non-IATA'
                -- Defensive fallback: any AGENCY-channel customer whose
                -- agent_type hasn't been filled in yet (common for newly
                -- onboarded overseas agencies — e.g. Apr 2026 brought 351
                -- such rows worth 20 cr that silently fell to 'Others').
                -- Treat them as Non-IATA so the totals stay whole; patch
                -- their agent_type in customer_zone.xlsx when convenient.
                WHEN c.primary_channel = 'AGENCY'
                     AND c.agent_type IS NULL                       THEN 'Non-IATA'
                WHEN c.primary_channel = 'WEB'                      THEN 'Web'
                WHEN c.primary_channel = 'MOBILE'                   THEN 'Mobi App'
                ELSE 'Others'
            END AS category,
            -- Country: prefer geo_country; for Office/Direct rows fall back
            -- to POS-derived country; final default Bangladesh.
            COALESCE(
                c.geo_country,
                CASE
                    WHEN substring(s.pos, 1, 3) IN ('DAC','CGP','CXB','ZYL','JSR','KHL','SPD','RJH','BZL')
                        THEN 'Bangladesh'
                    WHEN s.pos LIKE 'INT Doha%'           THEN 'Qatar'
                    WHEN s.pos LIKE 'INT Bangkok%'        THEN 'Thailand'
                    WHEN s.pos LIKE 'INT Kolkata%'        THEN 'India'
                    WHEN s.pos LIKE 'INT Chennai%'        THEN 'India'
                    WHEN s.pos LIKE 'INT Kuala Lumpur%'   THEN 'Malaysia'
                    WHEN s.pos LIKE 'INT Singapore%'      THEN 'Singapore'
                    WHEN s.pos LIKE 'INT Muscat%'         THEN 'Oman'
                    WHEN s.pos LIKE 'INT Guangzhou%'      THEN 'China'
                    WHEN s.pos LIKE 'INT Dubai%'          THEN 'United Arab Emirates'
                    WHEN s.pos LIKE 'INT Sharjah%'        THEN 'United Arab Emirates'
                    WHEN s.pos LIKE 'INT Abu Dhabi%'      THEN 'United Arab Emirates'
                    WHEN s.pos LIKE 'INT Male%'           THEN 'Maldives'
                    WHEN s.pos LIKE 'INT Jeddah%'         THEN 'Saudi Arabia'
                    WHEN s.pos LIKE 'INT Riyadh%'         THEN 'Saudi Arabia'
                    WHEN s.pos = 'BO-1 Central Reservation' THEN 'Bangladesh'
                    WHEN s.pos = 'WEB'                    THEN 'Bangladesh'
                    WHEN s.pos = 'MOBIAPP'                THEN 'Bangladesh'
                    ELSE NULL
                END,
                'Bangladesh'
            ) AS country,
            COALESCE(c.geo_district, 'Unknown') AS district
        FROM dsr_sales s
        LEFT JOIN dim_customer c ON s.customer_id = c.customer_id
    """)


# ---------------------------------------------------------------------------
# Day Wise Sales sheet
# ---------------------------------------------------------------------------

def build_day_wise_sales(con, start: date, end: date) -> pd.DataFrame:
    """
    Pivot: rows = 'Particulars' (Category|Country), columns = each day,
    values = SUM(dsr_amount) in lacs.

    Only BSP / Non-IATA / Counter / Corporate appear here. Mobile / Web /
    Others go to a separate sheet.
    """
    # Day Wise Sales shows all six channels stacked, matching the company's
    # DSR template:
    #   BSP / Corporate / Counter / Non-IATA / Mobi App / Web
    # plus an explicit 'Others' bucket so unclassified customers are still
    # counted (rather than silently dropped).
    df = con.sql(f"""
        SELECT
            category,
            country,
            date,
            SUM(dsr_amount) AS amount
        FROM dsr_sales_enriched
        WHERE category IN ('BSP', 'Non-IATA', 'Counter', 'Corporate',
                           'Mobi App', 'Web', 'Others')
        GROUP BY 1, 2, 3
    """).to_df()

    if df.empty:
        return pd.DataFrame()

    # Convert to lacs and pivot to wide format
    df["amount_lac"] = df["amount"] / LAC
    df["particulars"] = df["category"] + "|" + df["country"]

    # Sort within each category by country order
    def country_sort_key(c: str) -> int:
        try:
            return COUNTRY_ORDER.index(c)
        except ValueError:
            return 999

    df["country_rank"] = df["country"].apply(country_sort_key)
    # Order matches the company's DSR: agency channels first, direct-digital
    # channels (Mobi App, Web) at the bottom, Others last for our use.
    category_order = {
        "BSP":       1,
        "Corporate": 2,
        "Counter":   3,
        "Non-IATA":  4,
        "Mobi App":  5,
        "Web":       6,
        "Others":    7,
    }
    df["cat_rank"] = df["category"].map(category_order).fillna(99)

    wide = df.pivot_table(
        index=["cat_rank", "country_rank", "particulars"],
        columns="date",
        values="amount_lac",
        aggfunc="sum",
        fill_value=0.0,
    )
    wide = wide.sort_index().reset_index(level=["cat_rank", "country_rank"], drop=True)

    # Normalize the columns to ``datetime.date`` — DuckDB returns DATE values
    # which pandas may wrap as Timestamp. We compare against pd.date_range(...).date
    # below, so they need to be the same type for the membership check.
    wide.columns = [
        c.date() if hasattr(c, "date") else c
        for c in wide.columns
    ]

    # Ensure every day in the range appears as a column even if zero
    every_day = list(pd.date_range(start, end).date)
    for d in every_day:
        if d not in wide.columns:
            wide[d] = 0.0
    wide = wide.reindex(columns=sorted(every_day))

    # Add Total column
    wide["Total"] = wide.sum(axis=1)
    return wide


# ---------------------------------------------------------------------------
# City Wise Top 20 Agents sheet
# ---------------------------------------------------------------------------

def _seg_by_customer(con, start: date, end: date,
                     customer_ids: list) -> pd.DataFrame:
    """Dom / Int / Total ticket segments per customer for the period.
    Domestic = both endpoints in BD_DOM_AIRPORTS. Returns a frame keyed by
    customer_id with integer 'Dom Seg' / 'Int Seg' / 'Total Seg' columns.
    Used to populate the per-agent segment block on the Top OTA / Top Corp /
    City Wise sheets (previously hardcoded to 0)."""
    if not customer_ids:
        return pd.DataFrame(columns=["customer_id", "Dom Seg", "Int Seg", "Total Seg"])
    glob = (PROJECT_ROOT / "curated" / "sales").as_posix() + "/**/*.parquet"
    dom_set = ", ".join(f"'{a}'" for a in BD_DOM_AIRPORTS)
    id_in = ", ".join("'" + str(c).replace("'", "''") + "'" for c in customer_ids)
    return con.sql(f"""
        WITH rows AS (
            SELECT
                CASE WHEN CAST("Customer ID" AS VARCHAR) = 'BO-1 Central Reservation'
                     THEN '11246131'
                     ELSE regexp_replace(CAST("Customer ID" AS VARCHAR), '\\.0$', '')
                END AS customer_id,
                CAST("seg" AS DOUBLE) AS seg,
                CAST("Departure airport" AS VARCHAR) AS dep,
                CAST("Arrival airport"   AS VARCHAR) AS arr
            FROM dsr_src
            WHERE "Date"::DATE BETWEEN DATE '{start.isoformat()}' AND DATE '{end.isoformat()}'
              AND CAST("Transaction" AS VARCHAR) = 'Ticket payment'
        )
        SELECT customer_id,
            CAST(SUM(COALESCE(seg,1)) FILTER (WHERE dep IN ({dom_set})
                  AND arr IN ({dom_set})) AS BIGINT) AS "Dom Seg",
            CAST(SUM(COALESCE(seg,1)) FILTER (WHERE NOT (dep IN ({dom_set})
                  AND arr IN ({dom_set}))) AS BIGINT) AS "Int Seg",
            CAST(SUM(COALESCE(seg,1)) AS BIGINT) AS "Total Seg"
        FROM rows
        WHERE customer_id IN ({id_in})
        GROUP BY 1
    """).to_df()


def _merge_segments(df: pd.DataFrame, con, start: date, end: date) -> pd.DataFrame:
    """Attach real Dom/Int/Total Seg to a ranked-block frame (keyed by
    customer_id), filling absent agents with 0."""
    seg = _seg_by_customer(con, start, end, df["customer_id"].tolist())
    df = df.merge(seg, on="customer_id", how="left")
    for c in ("Dom Seg", "Int Seg", "Total Seg"):
        df[c] = df[c].fillna(0).astype(int)
    return df


def build_city_top20(con, start: date, end: date) -> dict:
    """
    Per city (zone_city_code), top 20 BSP/Non-IATA agents by dsr_amount, in the
    same column layout as Top OTA / Top Corp:
      Position, Zenith Code, Agent Name, City,
      Dom Seg, Int Seg, Total,
      <cur> Sales, <prev3..1> Sales, Variance vs <prev1>, Variance vs <prev2>
    Plus a final 'Total' row per city summing the 20 agents.

    Returns dict[city_code] -> DataFrame.
    """
    df = con.sql("""
        SELECT
            zone_city_code,
            customer_id,
            customer_name,
            SUM(dsr_amount) AS total_sales
        FROM dsr_sales_enriched
        WHERE category IN ('BSP', 'Non-IATA')
          AND zone_city_code IS NOT NULL
        GROUP BY 1, 2, 3
    """).to_df()
    df["city_code"] = df["zone_city_code"]  # alias for the renaming step
    if df.empty:
        return {}

    prior = _last_three_months(start)
    cur_label = f"{calendar.month_abbr[start.month]}-{str(start.year)[-2:]}"

    out: dict[str, pd.DataFrame] = {}
    for city_code in sorted(df["zone_city_code"].dropna().unique()):
        city_rows = (df[df["zone_city_code"] == city_code]
                       .sort_values("total_sales", ascending=False)
                       .head(20)
                       .reset_index(drop=True))
        # History + variance using the same helper as Top OTA/Corp
        history = _fetch_history_for_ids(con, prior, city_rows["customer_id"].tolist())
        city_rows = _add_history_and_variance(city_rows, history)

        # Segments — real Dom/Int/Total ticket counts per agent.
        city_rows = _merge_segments(city_rows, con, start, end)
        city_rows.insert(0, "Position", range(1, len(city_rows) + 1))

        city_rows = city_rows.rename(columns={
            "customer_id":   "Zenith Code",
            "customer_name": "Agent Name",
            "city_code":     "City",
            "total_sales":   f"{cur_label} Sales",
        })
        history_cols  = [c for c in city_rows.columns
                          if (c.endswith("-25") or c.endswith("-26"))
                          and not c.startswith("Variance")
                          and c != f"{cur_label} Sales"]
        variance_cols = [c for c in city_rows.columns if c.startswith("Variance vs")]
        final_cols = ["Position", "Zenith Code", "Agent Name", "City",
                      "Dom Seg", "Int Seg", "Total Seg",
                      f"{cur_label} Sales",
                      *history_cols, *variance_cols]
        city_rows = city_rows[final_cols].copy()

        # Add a "Total" row at the bottom summing the numeric columns.
        # Defensive: dedup any duplicate column names from upstream SQL/joins
        # before reshaping.
        city_rows = city_rows.loc[:, ~city_rows.columns.duplicated()]
        totals = {col: city_rows[col].sum()
                   for col in city_rows.columns
                   if col in [f"{cur_label} Sales", *history_cols]}
        total_row = {col: "" for col in city_rows.columns}
        total_row["Position"]  = ""
        total_row["Agent Name"] = "Total"
        total_row.update(totals)
        total_df = pd.DataFrame([total_row], columns=list(city_rows.columns))
        city_rows = pd.concat([city_rows, total_df], ignore_index=True)

        # Drop the zone_city_code column if it slipped through
        if "zone_city_code" in city_rows.columns:
            city_rows = city_rows.drop(columns="zone_city_code")

        out[city_code] = city_rows
    return out


# The Agent sheet carries a YEAR of history, but only the most recent few months are on screen.
# The rest sit in a collapsed Excel outline group behind a plus sign, so the sheet opens at its
# familiar width and a full twelve-month read is one click away. Everything else on the workbook
# (Top OTA, Top Corp, City Wise) stays on three, which is what those templates are shaped for.
AGENT_HISTORY_MONTHS = 12
AGENT_VISIBLE_MONTHS = 3


def _last_n_months(d: date, n: int) -> list[tuple[int, int, str]]:
    """[(year, month, label), ...] for the n months before d, most recent FIRST."""
    months = []
    y, m = d.year, d.month
    for _ in range(n):
        m -= 1
        if m == 0:
            m = 12
            y -= 1
        months.append((y, m, f"{calendar.month_abbr[m]}-{str(y)[-2:]}"))
    return months


def _last_three_months(d: date) -> list[tuple[int, int, str]]:
    """The three months prior to d. Kept for Top OTA / Top Corp / City Wise."""
    return _last_n_months(d, 3)


def _month_window_sql(prior_months: list[tuple[int, int, str]]) -> str:
    """A single WHERE clause covering every month in the list.

    One query for twelve months rather than twelve queries for one month each. The old
    per-month loop cost a full scan of the sales parquet per month, so raising the history from
    three months to twelve would have quadrupled the slowest part of the DSR. Grouping by
    (year, month) inside one scan keeps twelve months roughly as cheap as three were.
    """
    if not prior_months:
        return "FALSE"
    lo = min((y, m) for y, m, _ in prior_months)
    hi = max((y, m) for y, m, _ in prior_months)
    return (f'"Date" >= DATE \'{lo[0]}-{lo[1]:02d}-01\' '
            f'AND "Date" < DATE \'{hi[0] + (1 if hi[1] == 12 else 0)}-'
            f'{1 if hi[1] == 12 else hi[1] + 1:02d}-01\'')


def _fetch_history_for_ids(con: duckdb.DuckDBPyConnection,
                            prior_months: list[tuple[int, int, str]],
                            customer_ids: list[str]) -> dict[str, pd.DataFrame]:
    """
    Generic version of _fetch_3month_history() that fetches sales for an
    explicit list of customer_ids (instead of filtering by category).
    Used by Top OTA / Top Corp / City Wise so we get history for the exact
    customers in each ranked table — including OTA customers that aren't
    classified as 'BSP'/'Non-IATA' in our master.
    """
    out: dict[str, pd.DataFrame] = {}
    if not customer_ids:
        for _, _, label in prior_months:
            out[label] = pd.DataFrame(columns=["customer_id", "sales"])
        return out
    glob = (PROJECT_ROOT / "curated" / "sales").as_posix() + "/**/*.parquet"
    rate_sql = build_rate_sql()
    id_in = ", ".join(f"'{cid}'" for cid in customer_ids)
    for y, m, label in prior_months:
        df = con.sql(f"""
            WITH rows AS (
                SELECT
                    CASE WHEN CAST("Customer ID" AS VARCHAR) = 'BO-1 Central Reservation'
                         THEN '11246131'
                         ELSE regexp_replace(CAST("Customer ID" AS VARCHAR), '\\.0$', '')
                    END AS customer_id,
                    CAST("Transaction" AS VARCHAR) AS txn,
                    CAST("Balance (base currency)" AS DOUBLE) AS balance,
                    CAST("Total without taxe (base currency)" AS DOUBLE) AS fare,
                    ({rate_sql}) AS commission_rate
                FROM dsr_src
                WHERE EXTRACT(YEAR  FROM "Date") = {y}
                  AND EXTRACT(MONTH FROM "Date") = {m}
            )
            SELECT
                customer_id,
                SUM(CASE
                    WHEN txn IN ('Ticket payment','Reissuance Adjustment') THEN
                        COALESCE(fare,0)*(1-commission_rate)
                        + (COALESCE(balance,0) - COALESCE(fare,0))
                    WHEN txn IN ('Refund','Ticket void','Cancel refund') THEN balance
                    WHEN txn = 'Penalty' THEN balance
                    ELSE 0.0
                END) AS sales
            FROM rows
            WHERE customer_id IN ({id_in})
            GROUP BY 1
        """).to_df()
        out[label] = df
    return out


def _add_history_and_variance(df: pd.DataFrame,
                                history: dict[str, pd.DataFrame],
                                current_col: str = "total_sales") -> pd.DataFrame:
    """
    Append three history columns (oldest -> newest) and two variance columns
    (current vs each of the two newest history months) to the ranked DataFrame.
    """
    # Company DSR displays history columns newest-first (Feb-26 / Jan-26 / Dec-25)
    # so we iterate the history dict in its natural order — _last_three_months()
    # already returns the most recent month first.
    for lbl in history.keys():
        df[lbl] = df["customer_id"].map(
            history[lbl].set_index("customer_id")["sales"]
        ).fillna(0)
    # Variance: current vs latest, current vs second-latest
    if len(history) >= 1:
        latest = list(history.keys())[0]
        df[f"Variance vs {latest}"] = (
            (df[current_col] - df[latest]) / df[latest].replace(0, pd.NA)
        )
    if len(history) >= 2:
        second = list(history.keys())[1]
        df[f"Variance vs {second}"] = (
            (df[current_col] - df[second]) / df[second].replace(0, pd.NA)
        )
    return df


def _fetch_3month_history(con, prior_months, categories=("BSP", "Non-IATA")) -> dict:
    """
    For each of the prior months, return a DataFrame of (customer_id, sales)
    for customers matching ``categories``. Uses the same DSR amount logic.
    Apply the commission rate INSIDE the rows CTE (where the original column
    names are still visible) rather than after the rename.
    """
    out: dict[str, pd.DataFrame] = {}
    glob = (PROJECT_ROOT / "curated" / "sales").as_posix() + "/**/*.parquet"
    rate_sql = build_rate_sql()

    # Build the category WHERE clause once. ``categories`` is something like
    # ('BSP', 'Non-IATA') — translate to the dim_customer filters.
    cat_predicates: list[str] = []
    if "BSP" in categories:
        cat_predicates.append("c.agent_type = 'BSP'")
    if "Non-IATA" in categories:
        cat_predicates.append("c.agent_type IN ('Non-IATA', 'Non BSP')")
    if "Corporate" in categories:
        cat_predicates.append("c.customer_name ILIKE 'CORP %'")
    if "Counter" in categories:
        cat_predicates.append("c.primary_channel = 'OFFICE'")
    if not cat_predicates:
        cat_predicates.append("TRUE")
    category_filter = "(" + " OR ".join(cat_predicates) + ")"

    for y, m, label in prior_months:
        df = con.sql(f"""
            WITH rows AS (
                SELECT
                    regexp_replace(CAST("Customer ID" AS VARCHAR), '\\.0$', '') AS customer_id,
                    CAST("Transaction" AS VARCHAR) AS txn,
                    CAST("Balance (base currency)" AS DOUBLE) AS balance,
                    CAST("Total without taxe (base currency)" AS DOUBLE) AS fare,
                    ({rate_sql}) AS commission_rate
                FROM dsr_src
                WHERE EXTRACT(YEAR  FROM "Date") = {y}
                  AND EXTRACT(MONTH FROM "Date") = {m}
            ),
            scored AS (
                SELECT
                    customer_id,
                    CASE
                        WHEN txn IN ('Ticket payment', 'Reissuance Adjustment') THEN
                            COALESCE(fare, 0) * (1 - commission_rate)
                            + (COALESCE(balance, 0) - COALESCE(fare, 0))
                        WHEN txn IN ('Refund', 'Ticket void', 'Cancel refund') THEN
                            COALESCE(balance, 0)
                        WHEN txn = 'Penalty' THEN
                            COALESCE(balance, 0)
                        ELSE 0.0
                    END AS amt
                FROM rows
            )
            SELECT
                s.customer_id,
                SUM(s.amt) AS sales
            FROM scored s
            JOIN dim_customer c ON s.customer_id = c.customer_id
            WHERE {category_filter}
            GROUP BY 1
        """).to_df()
        out[label] = df
    return out


# ---------------------------------------------------------------------------
# Top OTA sheet (uses external OTA list)
# ---------------------------------------------------------------------------

def build_top_ota(con, start: date, end: date) -> pd.DataFrame:
    """
    Top OTA agents with the same column layout as the company DSR:
      Position, Zenith Code, Agent Name, City,
      Dom Seg, Int Seg, Total,                             (segment block — zeros)
      <cur> Sales (BDT), % of OTA Sales, % of Airlines Sales,
      <prev3>, <prev2>, <prev1> Sales (BDT),               (3 month history)
      Variance vs <prev1>, Variance vs <prev2>             (% change)
    """
    if not OTA_LIST_FILE.exists():
        return pd.DataFrame([{
            "Note": f"Create {OTA_LIST_FILE} with a 'customer_id' column listing OTA customers, then re-run."
        }])

    ota = pd.read_excel(OTA_LIST_FILE)
    if "customer_id" not in ota.columns:
        return pd.DataFrame([{"Note": "ota_list.xlsx must have a 'customer_id' column."}])
    ota["customer_id"] = ota["customer_id"].astype(str).str.strip().str.replace(r"\.0$", "", regex=True)
    con.register("ref_ota", ota[["customer_id"]])

    df = con.sql("""
        SELECT
            s.customer_id,
            c.customer_name,
            c.zone_city_code AS city,
            SUM(s.dsr_amount) AS total_sales
        FROM dsr_sales_enriched s
        JOIN ref_ota o USING (customer_id)
        LEFT JOIN dim_customer c ON s.customer_id = c.customer_id
        GROUP BY 1, 2, 3
        ORDER BY total_sales DESC
    """).to_df()
    if df.empty:
        return df

    # % of total OTA sales (relative to peers on this sheet)
    total_ota = df["total_sales"].sum()
    df["% of OTA Sales"] = df["total_sales"] / total_ota if total_ota > 0 else 0

    # % of total airlines sales (relative to BSP+Non-IATA grand total)
    airlines_total = con.sql("""
        SELECT SUM(dsr_amount) FROM dsr_sales_enriched
        WHERE category IN ('BSP', 'Non-IATA')
    """).fetchone()[0] or 0
    df["% of Airlines Sales"] = df["total_sales"] / airlines_total if airlines_total > 0 else 0

    # 3-month history (oldest column first)
    prior = _last_three_months(start)
    history = _fetch_history_for_ids(con, prior, df["customer_id"].tolist())
    df = _add_history_and_variance(df, history)

    # Segments — real Dom/Int/Total ticket counts per OTA agent.
    df = _merge_segments(df, con, start, end)

    df.insert(0, "Position", range(1, len(df) + 1))

    cur_label = f"{calendar.month_abbr[start.month]}-{str(start.year)[-2:]}"
    df = df.rename(columns={
        "customer_id":  "Zenith Code",
        "customer_name": "Agent Name",
        "city":          "City",
        "total_sales":   f"{cur_label} Sales",
    })

    # Final column order matches the company DSR. Filter out variance columns
    # from the history check because they also end with "-26" / "-25".
    history_cols  = [c for c in df.columns
                      if (c.endswith("-25") or c.endswith("-26"))
                      and not c.startswith("Variance")
                      and c != f"{cur_label} Sales"]
    variance_cols = [c for c in df.columns if c.startswith("Variance vs")]
    final_cols = ["Position", "Zenith Code", "Agent Name", "City",
                  "Dom Seg", "Int Seg", "Total Seg",
                  f"{cur_label} Sales", "% of OTA Sales", "% of Airlines Sales",
                  *history_cols, *variance_cols]
    return df[final_cols]


# ---------------------------------------------------------------------------
# Top Corp sheet
# ---------------------------------------------------------------------------

def build_top_corp(con, start: date, end: date, top_n: int = 50) -> pd.DataFrame:
    """
    Top corporate customers — same column shape as Top OTA but without the
    two % columns (the company template leaves them blank for Top Corp).
    """
    df = con.sql(f"""
        SELECT
            s.customer_id,
            c.customer_name,
            c.zone_city_code AS city,
            SUM(s.dsr_amount) AS total_sales
        FROM dsr_sales_enriched s
        LEFT JOIN dim_customer c ON s.customer_id = c.customer_id
        WHERE c.customer_name ILIKE 'CORP %'
        GROUP BY 1, 2, 3
        ORDER BY total_sales DESC
        LIMIT {top_n}
    """).to_df()
    if df.empty:
        return df

    # 3-month history + variance
    prior = _last_three_months(start)
    history = _fetch_history_for_ids(con, prior, df["customer_id"].tolist())
    df = _add_history_and_variance(df, history)

    # Segments — real Dom/Int/Total ticket counts per corporate agent.
    df = _merge_segments(df, con, start, end)
    df.insert(0, "Position", range(1, len(df) + 1))

    cur_label = f"{calendar.month_abbr[start.month]}-{str(start.year)[-2:]}"
    df = df.rename(columns={
        "customer_id":   "Zenith Code",
        "customer_name": "Agent Name",
        "city":          "City",
        "total_sales":   f"{cur_label} Sales",
    })

    history_cols  = [c for c in df.columns
                      if (c.endswith("-25") or c.endswith("-26"))
                      and not c.startswith("Variance")
                      and c != f"{cur_label} Sales"]
    variance_cols = [c for c in df.columns if c.startswith("Variance vs")]
    final_cols = ["Position", "Zenith Code", "Agent Name", "City",
                  "Dom Seg", "Int Seg", "Total Seg",
                  f"{cur_label} Sales",
                  *history_cols, *variance_cols]
    return df[final_cols]


# ---------------------------------------------------------------------------
# DEPRECATED: build_direct_channels()
# ---------------------------------------------------------------------------
# Mobi App and Web are now stacked into the Day Wise Sales sheet (matching the
# company's standard DSR template), so this builder is no longer called from
# main(). Kept here for reference / quick rollback if needed.
# ---------------------------------------------------------------------------

def build_direct_channels(con, start: date, end: date) -> pd.DataFrame:
    """Legacy: pivot of Mobi App / Web sales per day. No longer used by main()."""
    df = con.sql("""
        SELECT
            category AS channel,
            date,
            SUM(dsr_amount) AS amount
        FROM dsr_sales_enriched
        WHERE category IN ('Mobi App', 'Web')
        GROUP BY 1, 2
    """).to_df()
    if df.empty:
        return pd.DataFrame()
    df["amount_lac"] = df["amount"] / LAC
    wide = df.pivot_table(index="channel", columns="date", values="amount_lac",
                          aggfunc="sum", fill_value=0.0).sort_index()
    # Same date-type normalisation as Day Wise Sales
    wide.columns = [c.date() if hasattr(c, "date") else c for c in wide.columns]
    every_day = list(pd.date_range(start, end).date)
    for d in every_day:
        if d not in wide.columns:
            wide[d] = 0.0
    wide = wide.reindex(columns=sorted(every_day))
    wide["Total"] = wide.sum(axis=1)
    return wide


# ---------------------------------------------------------------------------
# Year-over-year baseline lookup
# ---------------------------------------------------------------------------

HISTORICAL_AGENT_MONTHLY = (
    PROJECT_ROOT / "curated" / "historical_agent_monthly" / "historical_agent_monthly.parquet"
)


def _yoy_month_label(start: date) -> tuple[str, int, int]:
    """
    Given the DSR period start (e.g. 2026-04-01), return the labelled
    same-month-last-year identifiers used downstream:
        ('Apr-25', 2025, 4)
    """
    y = start.year - 1
    m = start.month
    label = f"{calendar.month_abbr[m]}-{str(y)[-2:]}"
    return label, y, m


def _fetch_yoy_baseline(con: duckdb.DuckDBPyConnection,
                         start: date) -> pd.DataFrame:
    """
    Per-customer net sales for the same calendar month one year before
    ``start``. Used by the Agent sheet to add a YoY column next to each
    agent's current-month total.

    Lookup strategy:
      1. ``curated/historical_agent_monthly/historical_agent_monthly.parquet``
         (built from the BI Analysis file — covers Jan 2025 - Feb 2026).
         This is the source of truth for Jan-Apr 2025 which the warehouse
         doesn't have, and is also fine for May 2025 onwards.
      2. Fallback: compute from raw parquet using the same DSR formula
         (only triggered if the curated reference file is missing).

    Returns a DataFrame with two columns: ``customer_id`` (text) and
    ``yoy_sales`` (float, BDT). Customers without prior-year data
    simply don't appear in the result — the caller is expected to LEFT
    JOIN, leaving missing customers with 0/NaN.
    """
    _label, y, m = _yoy_month_label(start)
    ym = f"{y}-{m:02d}"

    # --- Preferred path: curated reference -----------------------------
    if HISTORICAL_AGENT_MONTHLY.exists():
        path = HISTORICAL_AGENT_MONTHLY.as_posix()
        out = con.sql(f"""
            SELECT CAST(customer_id AS VARCHAR) AS customer_id,
                   CAST(sales AS DOUBLE) AS yoy_sales
            FROM read_parquet('{path}')
            WHERE year_month = '{ym}'
        """).to_df()
        if not out.empty:
            return _fold_yoy_siblings(con, out)

    # --- Fallback: compute from raw warehouse --------------------------
    rate_sql = build_rate_sql()
    glob = (PROJECT_ROOT / "curated" / "sales").as_posix() + "/**/*.parquet"
    fallback = con.sql(f"""
        WITH rows AS (
            SELECT
                regexp_replace(CAST("Customer ID" AS VARCHAR), '\\.0$', '') AS customer_id,
                CAST("Transaction" AS VARCHAR) AS txn,
                CAST("Balance (base currency)" AS DOUBLE) AS balance,
                CAST("Total without taxe (base currency)" AS DOUBLE) AS fare,
                ({rate_sql}) AS commission_rate
            FROM dsr_src
            WHERE EXTRACT(YEAR  FROM "Date") = {y}
              AND EXTRACT(MONTH FROM "Date") = {m}
        )
        SELECT customer_id,
               SUM(
                   CASE
                       WHEN txn IN ('Ticket payment','Reissuance Adjustment') THEN
                           COALESCE(fare,0) * (1 - commission_rate)
                           + (COALESCE(balance,0) - COALESCE(fare,0))
                       WHEN txn IN ('Refund','Ticket void','Cancel refund') THEN
                           COALESCE(balance, 0)
                       WHEN txn = 'Penalty' THEN
                           COALESCE(balance, 0)
                       ELSE 0.0
                   END
               ) AS yoy_sales
        FROM rows
        GROUP BY 1
    """).to_df()
    return _fold_yoy_siblings(con, fallback)


def _fold_yoy_siblings(con: duckdb.DuckDBPyConnection, df: pd.DataFrame) -> pd.DataFrame:
    """Move a merged sibling's LAST-YEAR sales onto the id that survives this year.

    The YoY baseline is keyed on the customer_id as it stood a year ago, so an agency that
    now trades under one id can still carry last year's revenue under the other. Without
    this fold the sibling's history is dropped along with its (now removed) row and the
    agency's YoY reads as growth that never happened — the merge must move BOTH years or
    neither. Depends on dsr_sibling, which only exists once a merge was applied; without it
    the frame is returned untouched.
    """
    if df.empty:
        return df
    try:
        sib = con.sql("SELECT cid, primary_cid FROM dsr_sibling").df()
    except Exception:                       # no merge this run -> nothing to fold
        return df
    if sib.empty:
        return df
    m = dict(zip(sib.cid.astype(str), sib.primary_cid.astype(str)))
    out = df.copy()
    out["customer_id"] = out["customer_id"].astype(str).map(lambda c: m.get(c, c))
    return out.groupby("customer_id", as_index=False)["yoy_sales"].sum()


def _fetch_category_yoy(con: duckdb.DuckDBPyConnection,
                         start: date) -> dict[str, float]:
    """
    Same-month-last-year totals AGGREGATED BY CATEGORY (Counter, Corporate,
    Mobi App, Web). Used by ``_build_channel_rollup_rows()`` so the 4
    rollup rows at the bottom of the Agent sheet also carry a YoY value
    in the new YoY column. Requires joining the per-customer YoY data
    to dim_customer to get the category bucket.
    """
    yoy = _fetch_yoy_baseline(con, start)
    if yoy.empty:
        return {}
    con.register("yoy_lookup_temp", yoy)
    out = con.sql("""
        SELECT
            CASE
                WHEN c.customer_name ILIKE 'CORP %'           THEN 'Corporate'
                WHEN c.primary_channel = 'OFFICE'             THEN 'Counter'
                WHEN c.primary_channel = 'CALL_CENTER'        THEN 'Counter'
                WHEN c.primary_channel = 'WEB'                THEN 'Web'
                WHEN c.primary_channel = 'MOBILE'             THEN 'Mobi App'
                ELSE NULL
            END AS category,
            SUM(y.yoy_sales) AS yoy_sales
        FROM yoy_lookup_temp y
        JOIN dim_customer c ON y.customer_id = c.customer_id
        GROUP BY 1
    """).to_df()
    con.unregister("yoy_lookup_temp")
    return dict(zip(out["category"], out["yoy_sales"]))


# ---------------------------------------------------------------------------
# Zone Wise Sales sheet
# ---------------------------------------------------------------------------

def _build_channel_rollup_rows(con: duckdb.DuckDBPyConnection,
                                start: date,
                                end: date,
                                prior_months: list) -> pd.DataFrame:
    """
    Build 4 synthetic aggregate rows (Counter, Corporate, Mobi App, Web)
    that summarise the non-agency channels.

    These rows get appended to the bottom of build_agent_sheet so the agent
    sheet's "current month sales" column reconciles to the Day Wise Sales
    total. Without them the agent sheet silently omits 25-60 cr/month of
    direct-channel and corporate revenue (~6-10% of monthly net sales).

    The returned DataFrame uses the same raw column names as the merged
    intermediate frame in build_agent_sheet (lowercase: customer_id,
    agent_name, ..., current_sales, dom_seg, int_seg, total_seg, plus one
    "<Mon YYYY> Sales" column per prior month). The caller concats it in
    BEFORE the rename + final-column-order step so it slots in cleanly.
    """
    glob = (PROJECT_ROOT / "curated" / "sales").as_posix() + "/**/*.parquet"
    rate_sql = build_rate_sql()
    dom_set = ", ".join(f"'{a}'" for a in BD_DOM_AIRPORTS)

    # The 4 synthetic rows we emit. Order = display order at bottom of sheet.
    rollup_meta = [
        ("Counter",   "Z-Counter",   "Counter Sales (USBA Offices + Call Center)"),
        ("Corporate", "Z-Corporate", "Corporate Accounts (CORP*)"),
        ("Mobi App",  "Z-Mobi App",  "Direct Sales - Mobile App"),
        ("Web",       "Z-Web",       "Direct Sales - Web"),
    ]

    # SQL fragment that maps a (customer_name, primary_channel) pair to one of
    # the 4 rollup categories — kept consistent with attach_customer_attrs().
    category_case = """
        CASE
            WHEN c.customer_name ILIKE 'CORP %'           THEN 'Corporate'
            WHEN c.primary_channel = 'OFFICE'            THEN 'Counter'
            WHEN c.primary_channel = 'CALL_CENTER'       THEN 'Counter'
            WHEN c.primary_channel = 'WEB'               THEN 'Web'
            WHEN c.primary_channel = 'MOBILE'            THEN 'Mobi App'
            ELSE NULL
        END
    """

    # ---- 1. Current-month sales per category ---------------------------
    # dsr_sales_enriched is already materialised for the current period,
    # so we just sum per category.
    cur = (
        con.sql("""
            SELECT category, SUM(dsr_amount) AS current_sales
            FROM dsr_sales_enriched
            WHERE category IN ('Counter', 'Corporate', 'Mobi App', 'Web')
            GROUP BY 1
        """)
        .to_df()
        .set_index("category")["current_sales"]
        .to_dict()
    )

    # ---- 2. Segments per category for the current period ---------------
    seg_df = con.sql(f"""
        WITH rows AS (
            SELECT
                CASE
                    WHEN CAST("Customer ID" AS VARCHAR) = 'BO-1 Central Reservation'
                        THEN '11246131'
                    ELSE regexp_replace(CAST("Customer ID" AS VARCHAR), '\\.0$', '')
                END AS customer_id,
                CAST("seg" AS DOUBLE) AS seg,
                CAST("Departure airport" AS VARCHAR) AS dep,
                CAST("Arrival airport"   AS VARCHAR) AS arr
            FROM dsr_src
            WHERE "Date"::DATE BETWEEN DATE '{start.isoformat()}' AND DATE '{end.isoformat()}'
              AND CAST("Transaction" AS VARCHAR) = 'Ticket payment'
        )
        SELECT
            {category_case} AS category,
            SUM(COALESCE(r.seg, 1)) FILTER (
                WHERE r.dep IN ({dom_set}) AND r.arr IN ({dom_set})
            ) AS dom_seg,
            SUM(COALESCE(r.seg, 1)) FILTER (
                WHERE NOT (r.dep IN ({dom_set}) AND r.arr IN ({dom_set}))
            ) AS int_seg,
            SUM(COALESCE(r.seg, 1)) AS total_seg
        FROM rows r
        JOIN dim_customer c USING (customer_id)
        WHERE {category_case} IS NOT NULL
        GROUP BY 1
    """).to_df().set_index("category")

    # ---- 3. Prior months' sales per category ---------------------------
    # One scan for every month in the window, grouped by (year, month). The Agent sheet now
    # asks for twelve months, and a query per month would have meant twelve full scans of the
    # sales parquet here and twelve more in build_agent_sheet.
    _hist = con.sql(f"""
        WITH rows AS (
            SELECT
                CASE
                    WHEN CAST("Customer ID" AS VARCHAR) = 'BO-1 Central Reservation'
                        THEN '11246131'
                    ELSE regexp_replace(CAST("Customer ID" AS VARCHAR), '\\.0$', '')
                END AS customer_id,
                EXTRACT(YEAR  FROM "Date") AS yr,
                EXTRACT(MONTH FROM "Date") AS mo,
                CAST("Transaction" AS VARCHAR) AS txn,
                CAST("Balance (base currency)" AS DOUBLE) AS balance,
                CAST("Total without taxe (base currency)" AS DOUBLE) AS fare,
                ({rate_sql}) AS commission_rate
            FROM dsr_src
            WHERE {_month_window_sql(prior_months)}
        ),
        scored AS (
            SELECT
                customer_id, yr, mo,
                CASE
                    WHEN txn IN ('Ticket payment', 'Reissuance Adjustment') THEN
                        COALESCE(fare, 0) * (1 - commission_rate)
                        + (COALESCE(balance, 0) - COALESCE(fare, 0))
                    WHEN txn IN ('Refund', 'Ticket void', 'Cancel refund') THEN
                        COALESCE(balance, 0)
                    WHEN txn = 'Penalty' THEN
                        COALESCE(balance, 0)
                    ELSE 0.0
                END AS amt
            FROM rows
        )
        SELECT
            s.yr, s.mo,
            {category_case} AS category,
            SUM(s.amt)      AS sales
        FROM scored s
        JOIN dim_customer c USING (customer_id)
        WHERE {category_case} IS NOT NULL
        GROUP BY 1, 2, 3
    """).to_df()
    history: dict[str, dict[str, float]] = {}
    for y, m, label in prior_months:
        part = _hist[(_hist.yr == y) & (_hist.mo == m)]
        history[label] = part.set_index("category")["sales"].to_dict()

    # ---- 3b. Year-over-year baseline by category (Counter/Corp/Mobi/Web)
    # Same as _fetch_category_yoy() but inlined here so the helper doesn't
    # need to be aware of the rollup categories.
    yoy_by_cat = _fetch_category_yoy(con, start)

    # ---- 4. Build the 4 rollup rows in the merged-intermediate shape ---
    rows = []
    for category, zenith_id, name in rollup_meta:
        row: dict = {
            "customer_id":    zenith_id,
            "agent_name":     name,
            "station":        "",
            "zone":           category,
            "agent_type":     category,
            "ota_status":     "",
            "sales_manager":  "",
            "thana":          "",
            "district_state": "",
            "country":        "Bangladesh",
            "current_sales":  cur.get(category, 0.0),
            "dom_seg":        int(seg_df.at[category, "dom_seg"])
                              if category in seg_df.index
                              and pd.notna(seg_df.at[category, "dom_seg"]) else 0,
            "int_seg":        int(seg_df.at[category, "int_seg"])
                              if category in seg_df.index
                              and pd.notna(seg_df.at[category, "int_seg"]) else 0,
            "total_seg":      int(seg_df.at[category, "total_seg"])
                              if category in seg_df.index
                              and pd.notna(seg_df.at[category, "total_seg"]) else 0,
            # YoY same-month-last-year per category (picked up by
            # build_agent_sheet's yoy_pct calc and the YoY column rename).
            "yoy_sales":      float(yoy_by_cat.get(category, 0.0)),
        }
        # Match the per-prior-month column naming used in build_agent_sheet
        for label, hist_map in history.items():
            row[f"{label} Sales"] = hist_map.get(category, 0.0)
        rows.append(row)
    return pd.DataFrame(rows)


# --------------------------------------------------------------------------- #
# MoM movers (agencies up >= +10% / down <= -10% vs the prior month)
# --------------------------------------------------------------------------- #
MOM_THRESHOLD = 0.10          # +/- 10% month-on-month
MOM_MIN_BDT = 100_000.0       # materiality floor: ignore agencies below 1 Lac in BOTH months
MOM_TOP_ROUTES = 5


_MOM_MAIL: dict = {}


def _salesperson_emails() -> dict[str, str]:
    """sales-person label -> address(es), from reference/salesperson_emails.xlsx.

    Analyst-side file: a colleague's exe has no reference/ folder, so an absent or unreadable
    file yields an empty column and the DSR still builds. Matched on the exact label the master
    carries (all 34 people match today), with a lower-cased fallback so a stray capitalisation
    in the roster does not blank the column.
    """
    f = _CFG.data_root / "reference" / "salesperson_emails.xlsx"
    if not f.is_file():
        return {}
    try:
        d = pd.read_excel(f)
    except Exception as exc:
        print(f"[dsr] WARN: could not read salesperson_emails.xlsx ({exc}); "
              f"the email column will be blank")
        return {}
    out: dict[str, str] = {}
    for r in d.to_dict("records"):
        lab = str(r.get("sales_person_label") or "").strip()
        em = str(r.get("emails") or "").strip()
        if lab and em and em.lower() != "nan":
            out[lab] = em
            out.setdefault(lab.lower(), em)
    return out

def build_mom_movers(con: duckdb.DuckDBPyConnection, agent: pd.DataFrame,
                     start: date, end: date) -> dict:
    """Agencies whose net moved >= +/-10% versus the previous calendar month.

    THE MONEY IS NOT RE-DERIVED. It is read straight off the `agent` frame that the Agent sheet
    is printed from, so every figure here is the same number the reader sees there. A first cut
    recomputed it from dsr_src with its own copy of the net expression and drifted on 18
    agencies (up to 797k BDT) while also pulling in 667 customers that the Agent sheet's own
    classification predicate excludes — two whole classes of discrepancy that simply cannot
    arise once the frame is shared. Only the ROUTE detail is queried, because the agent frame
    has no route grain.

    A pure percentage filter is noise on a 6,000-row book: an agency going 900 -> 1,200 BDT is
    +33% and means nothing. MOM_MIN_BDT keeps a row only when one of the two months clears
    1 Lac, and the sheet reports how many rows that removed. Agencies with no prior-month sales
    are NEW rather than "up infinity per cent", so they are listed separately.

    Returns {'up','down','new','routes','labels','skipped_small'}.
    """
    p_end = start - timedelta(days=1)                 # last day of the previous month
    p_start = p_end.replace(day=1)
    cur_lbl = f"{calendar.month_abbr[start.month]}-{str(start.year)[-2:]}"
    prv_lbl = f"{calendar.month_abbr[p_start.month]}-{str(p_start.year)[-2:]}"
    cur_col, prv_col = f"{cur_lbl} Sales", f"{prv_lbl} Sales"

    empty = pd.DataFrame(columns=["customer_id", "agent_name", "zone", "sales_manager",
                                  "prv_net", "cur_net", "cur_tkt", "delta", "pct"])
    if agent is None or agent.empty or cur_col not in agent.columns \
            or prv_col not in agent.columns:
        print(f"[dsr] MoM movers: agent frame lacks {cur_col!r}/{prv_col!r} — sheet skipped")
        return {"up": empty, "down": empty, "new": empty, "routes": pd.DataFrame(),
                "route_months": pd.DataFrame(), "agency_months": pd.DataFrame(),
                "months": [], "labels": (prv_lbl, cur_lbl), "skipped_small": 0}

    def _col(*names):
        for n in names:
            if n in agent.columns:
                return agent[n]
        return pd.Series([""] * len(agent), index=agent.index)

    d = pd.DataFrame({
        "customer_id": _col("Zenith ID").astype(str).str.replace(r"\.0$", "", regex=True).str.strip(),
        "agent_name": _col("Agent Name"),
        "zone": _col("Zone"),
        "sales_manager": _col("Sales Manager"),
        "prv_net": pd.to_numeric(agent[prv_col], errors="coerce").fillna(0.0),
        "cur_net": pd.to_numeric(agent[cur_col], errors="coerce").fillna(0.0),
        "cur_tkt": pd.to_numeric(_col(f"Total Seg {cur_lbl}"), errors="coerce").fillna(0),
    })
    d = d[~d.customer_id.str.startswith("Z-")]        # channel rollups are not agencies

    new = d[(d.prv_net <= 0) & (d.cur_net >= MOM_MIN_BDT)].copy()
    moved = d[d.prv_net > 0].copy()
    moved["delta"] = moved.cur_net - moved.prv_net
    moved["pct"] = moved.delta / moved.prv_net
    hit = moved[moved.pct.abs() >= MOM_THRESHOLD]
    material = hit[(hit.cur_net.abs() >= MOM_MIN_BDT) | (hit.prv_net.abs() >= MOM_MIN_BDT)]
    skipped = len(hit) - len(material)

    # ---- ROUTE + MONTH DETAIL for the agencies actually shown -------------------------
    # The sheet prints the headline (top routes, the two compared months) and hides the REST
    # behind Excel's outline "+" controls, so nothing is lost to a top-N cut-off:
    #   routes        every route in the report window   -> the visible top rows
    #   route_months  every route x every month of data  -> inside the "+" columns
    #   agency_months every month of data per agency     -> the agency's full sales trend
    #
    # ONE net expression is used for all three, and it is the same `dsr_amount` CASE that
    # dsr_sales uses (fare net of commission + tax on a sale; balance on refund / void /
    # cancel refund / penalty). That is not a style preference: if the monthly block used a
    # different formula from the Agent sheet, the "Jun-26" cell inside the "+" would disagree
    # with the "Jun-26 Net" column on the same row and the sheet would argue with itself.
    # Penalty alone runs ~10 cr a month, so dropping it from one side would be plainly visible.
    ids = set(material.customer_id) | set(new.customer_id)
    routes = pd.DataFrame(columns=["customer_id", "route", "sector", "tickets", "sales"])
    route_months = pd.DataFrame(columns=["customer_id", "route", "ym", "sales"])
    agency_months = pd.DataFrame(columns=["customer_id", "ym", "net"])
    months: list[str] = []
    if ids:
        rate_sql = build_rate_sql()
        dom_set = ", ".join(f"'{a}'" for a in BD_DOM_AIRPORTS)
        id_in = ", ".join("'" + c.replace("'", "''") + "'" for c in sorted(ids))
        # Materialise ONCE, already narrowed to these agencies. The three result sets below
        # would otherwise each rescan the full parquet history; filtering the ids up front is
        # what keeps the whole-history widening from costing more than the old one-month query.
        # `d <= end` clamps the newest month to the report end date, so a DSR run mid-month
        # shows the same partial figure in the month column as in the "<cur> Net" column
        # rather than a fuller month that would look like a contradiction.
        con.sql(f"""
            CREATE OR REPLACE TEMPORARY TABLE mom_src AS
            SELECT regexp_replace(CAST("Customer ID" AS VARCHAR), '\\.0$', '') AS customer_id,
                   CAST("Transaction" AS VARCHAR) AS txn,
                   CAST("Ticket number" AS VARCHAR) AS tkt,
                   CAST("Departure airport" AS VARCHAR) AS dep,
                   CAST("Arrival airport"   AS VARCHAR) AS arr,
                   "Date"::DATE                       AS d,
                   strftime("Date"::DATE, '%Y-%m')    AS ym,
                   CASE
                     WHEN CAST("Transaction" AS VARCHAR) IN ('Ticket payment','Reissuance Adjustment') THEN
                          COALESCE(CAST("Total without taxe (base currency)" AS DOUBLE),0)
                          * (1 - ({rate_sql}))
                          + (COALESCE(CAST("Balance (base currency)" AS DOUBLE),0)
                             - COALESCE(CAST("Total without taxe (base currency)" AS DOUBLE),0))
                     WHEN CAST("Transaction" AS VARCHAR) IN ('Refund','Ticket void',
                                                             'Cancel refund','Penalty') THEN
                          COALESCE(CAST("Balance (base currency)" AS DOUBLE),0)
                     ELSE 0.0
                   END AS amt
            FROM dsr_src
            WHERE "Date" IS NOT NULL
              AND "Date"::DATE <= DATE '{end.isoformat()}'
              AND regexp_replace(CAST("Customer ID" AS VARCHAR), '\\.0$', '') IN ({id_in})
        """)
        sector_sql = (f"CASE WHEN dep IN ({dom_set}) AND arr IN ({dom_set}) "
                      f"THEN 'Domestic' ELSE 'International' END")
        # EVERY route the agency has ever sold, not only the ones it sold this month. A route
        # that ran in March and stopped is exactly the kind of thing a KAM needs to see, and a
        # window-only list is precisely where it disappears — so the universe is all-time and
        # the report month is LEFT JOINed onto it. `in_window` is what keeps the visible top
        # rows identical to before: this month's routes sort first, dormant ones follow.
        routes = con.sql(f"""
            WITH allr AS (
                SELECT customer_id, dep || '-' || arr AS route, {sector_sql} AS sector,
                       SUM(amt) AS all_time
                FROM mom_src WHERE dep IS NOT NULL AND arr IS NOT NULL
                GROUP BY 1, 2, 3
            ), win AS (
                SELECT customer_id, dep || '-' || arr AS route,
                       COUNT(DISTINCT tkt) FILTER (WHERE txn = 'Ticket payment') AS tickets,
                       SUM(amt) AS sales
                FROM mom_src
                WHERE d BETWEEN DATE '{start.isoformat()}' AND DATE '{end.isoformat()}'
                  AND dep IS NOT NULL AND arr IS NOT NULL
                GROUP BY 1, 2
            )
            SELECT a.customer_id, a.route, a.sector, a.all_time,
                   w.tickets, w.sales,
                   (w.customer_id IS NOT NULL) AS in_window
            FROM allr a LEFT JOIN win w
                   ON w.customer_id = a.customer_id AND w.route = a.route
        """).to_df()
        route_months = con.sql("""
            SELECT customer_id, dep || '-' || arr AS route, ym, SUM(amt) AS sales
            FROM mom_src WHERE dep IS NOT NULL AND arr IS NOT NULL
            GROUP BY 1, 2, 3
        """).to_df()
        agency_months = con.sql("""
            SELECT customer_id, ym, SUM(amt) AS net FROM mom_src GROUP BY 1, 2
        """).to_df()
        months = sorted(str(m) for m in agency_months.ym.dropna().unique())
        _inw = int(routes.in_window.sum()) if len(routes) else 0
        print(f"[dsr] MoM detail: {len(routes):,} agency-routes "
              f"({_inw:,} sold in the window, {len(routes) - _inw:,} dormant) · "
              f"{len(route_months):,} route-months · {len(months)} month column(s) "
              f"({months[0] if months else '-'} .. {months[-1] if months else '-'})")

    return {"up": material[material.pct > 0].sort_values("delta", ascending=False),
            "down": material[material.pct < 0].sort_values("delta"),
            "new": new.sort_values("cur_net", ascending=False),
            "routes": routes, "route_months": route_months,
            "agency_months": agency_months, "months": months,
            "labels": (prv_lbl, cur_lbl),
            "skipped_small": max(skipped, 0)}


def build_agent_sheet(con, start: date, end: date,
                      zone: str | None = None) -> pd.DataFrame:
    """
    The "Agent" sheet — one row per BSP / Non-IATA / Non BSP agent, plus 4
    synthetic roll-up rows at the bottom (Counter, Corporate, Mobi App, Web)
    so the sheet reconciles to the Day Wise total.

    Columns:
      Idx, Zenith ID, Agent Name, Station (city), Zone, Agent Type, OTA Status,
      Sales Manager, Thana, District/State, Country,
      <previous 3 months Sales>, <current month Sales>,
      Dom Seg, Int Seg, Total Seg (for the current period)

    Matches the layout of the user's `DSR USBA Mar26 Updated.xlsx` / 'Agent' sheet.
    """
    glob = (PROJECT_ROOT / "curated" / "sales").as_posix() + "/**/*.parquet"
    rate_sql = build_rate_sql()

    # --- Current-period sales per customer (dsr_amount) ----------------
    # One row per BSP / Non-IATA agency. Counter / Corporate / Mobi App /
    # Web are intentionally NOT pulled per-customer here — they are folded
    # into 4 synthetic aggregate rows at the bottom of the sheet (see the
    # `_build_channel_rollup_rows()` call later). Without that aggregation
    # this query would explode to ~143K rows (every MOBILE/WEB single-trip
    # booking has its own customer record).
    current_df = con.sql("""
        SELECT
            customer_id,
            SUM(dsr_amount) AS current_sales
        FROM dsr_sales_enriched
        WHERE category IN ('BSP', 'Non-IATA')
        GROUP BY customer_id
    """).to_df()

    # --- Previous 3 months of sales ------------------------------------
    # IMPORTANT: this query MUST filter customers to the same category set
    # as current_df (BSP / Non-IATA only). Without the category filter, any
    # customer that's BSP-accredited but also CORP-named, OFFICE-channel,
    # CALL_CENTER, WEB, or MOBILE would be summed twice in the historical
    # column total — once here, once in the rollup row. The Jan-26 column
    # total was ~5.7 cr inflated before this filter was added (matches the
    # 104 BSP-but-CORP-named customers in dim_customer).
    prior_months = _last_n_months(start, AGENT_HISTORY_MONTHS)
    _all = con.sql(f"""
        WITH rows AS (
            SELECT
                regexp_replace(CAST("Customer ID" AS VARCHAR), '\\.0$', '') AS customer_id,
                EXTRACT(YEAR  FROM "Date") AS yr,
                EXTRACT(MONTH FROM "Date") AS mo,
                CAST("Transaction" AS VARCHAR) AS txn,
                CAST("Balance (base currency)" AS DOUBLE) AS balance,
                CAST("Total without taxe (base currency)" AS DOUBLE) AS fare,
                ({rate_sql}) AS commission_rate
            FROM dsr_src
            WHERE {_month_window_sql(prior_months)}
        ),
        scored AS (
            SELECT
                customer_id, yr, mo,
                SUM(
                    CASE
                        WHEN txn IN ('Ticket payment','Reissuance Adjustment') THEN
                            COALESCE(fare,0) * (1 - commission_rate)
                            + (COALESCE(balance,0) - COALESCE(fare,0))
                        WHEN txn IN ('Refund','Ticket void','Cancel refund') THEN
                            COALESCE(balance, 0)
                        WHEN txn = 'Penalty' THEN
                            COALESCE(balance, 0)
                        ELSE 0.0
                    END
                ) AS sales
            FROM rows
            GROUP BY 1, 2, 3
        )
        SELECT s.customer_id, s.yr, s.mo, s.sales
        FROM scored s
        JOIN dim_customer c ON s.customer_id = c.customer_id
        -- Mirror the category IN ('BSP', 'Non-IATA') filter used by
        -- current_df: exclude anyone whose category would be in the
        -- rollup set (Counter / Corporate / Mobi App / Web) or 'Others'.
        WHERE NOT (c.customer_name ILIKE 'CORP %')
          AND COALESCE(c.primary_channel, '') NOT IN
                ('OFFICE', 'CALL_CENTER', 'WEB', 'MOBILE')
          AND (
                c.agent_type IN ('BSP', 'Non-IATA', 'Non BSP')
                OR (c.primary_channel = 'AGENCY' AND c.agent_type IS NULL)
          )
    """).to_df()
    # split the one result back into a frame per month, preserving the old shape so nothing
    # downstream has to know the fetch changed
    history: dict[str, pd.DataFrame] = {}
    for y, m, label in prior_months:
        part = _all[(_all.yr == y) & (_all.mo == m)][["customer_id", "sales"]]
        history[label] = part.reset_index(drop=True)

    # --- Segments (Dom / Int / Total) for the current period -----------
    # Domestic = both Departure airport and Arrival airport in Bangladesh.
    # If the airport columns aren't reliable, both Dom and Int will be 0
    # (matching the template — the user fills these manually).
    segments = con.sql(f"""
        WITH rows AS (
            SELECT
                regexp_replace(CAST("Customer ID" AS VARCHAR), '\\.0$', '') AS customer_id,
                CAST("Transaction" AS VARCHAR) AS txn,
                CAST("seg" AS DOUBLE) AS seg,
                CAST("Departure airport" AS VARCHAR) AS dep,
                CAST("Arrival airport"   AS VARCHAR) AS arr
            FROM dsr_src
            WHERE "Date"::DATE BETWEEN DATE '{start.isoformat()}' AND DATE '{end.isoformat()}'
              AND CAST("Transaction" AS VARCHAR) = 'Ticket payment'
        )
        SELECT
            customer_id,
            -- BD domestic airports start with these codes
            SUM(COALESCE(seg,1)) FILTER (
                WHERE dep IN ('DAC','CGP','CXB','ZYL','JSR','RJH','BZL','SPD')
                  AND arr IN ('DAC','CGP','CXB','ZYL','JSR','RJH','BZL','SPD')
            ) AS dom_seg,
            SUM(COALESCE(seg,1)) FILTER (
                WHERE NOT (
                    dep IN ('DAC','CGP','CXB','ZYL','JSR','RJH','BZL','SPD')
                    AND arr IN ('DAC','CGP','CXB','ZYL','JSR','RJH','BZL','SPD')
                )
            ) AS int_seg,
            SUM(COALESCE(seg,1)) AS total_seg
        FROM rows
        GROUP BY 1
    """).to_df()

    # --- Customer attributes from dim_customer -------------------------
    # Pull every "real agency" customer plus the unclassified-AGENCY rows
    # that we now treat as Non-IATA (Apr 2026 brought 351 such customers
    # worth 20 cr that previously fell through to 'Others'). Direct
    # channels (OFFICE / CALL_CENTER / WEB / MOBILE) and Corporate are
    # NOT pulled here — they are added later as 4 synthetic aggregate
    # rows by `_build_channel_rollup_rows()` to keep the sheet at a
    # manageable size.
    # Single-zone DSR: restrict the agent universe to that zone (otherwise
    # the LEFT-join below keeps every network agent with current_sales=0).
    zone_clause = f"AND zone = '{zone}'" if zone else ""
    # Drop the non-surviving ids of merged multi-ID agencies. Their sales were folded onto the
    # primary id in dsr_sales (see `_sibling_primary`), so leaving them in the universe would
    # print an all-zero ghost row for an agency that is already listed once, correctly, above.
    sib_clause = ""
    try:
        _dead = con.sql("SELECT cid FROM dsr_sibling").df()["cid"].tolist()
        if _dead:
            sib_clause = "AND customer_id NOT IN (" + ", ".join(f"'{c}'" for c in _dead) + ")"
    except Exception:              # no merges applied this run -> nothing to exclude
        pass
    attrs = con.sql(f"""
        SELECT
            customer_id,
            customer_name      AS agent_name,
            zone_city_code     AS station,
            zone,
            COALESCE(agent_type, 'Non-IATA') AS agent_type,
            COALESCE(ota_status, '') AS ota_status,
            sales_person       AS sales_manager,
            district_state     AS thana,
            geo_district       AS district_state,
            geo_country        AS country
        FROM dim_customer
        WHERE
            (agent_type IN ('BSP', 'Non-IATA', 'Non BSP')
             OR (primary_channel = 'AGENCY' AND agent_type IS NULL))
            {zone_clause}
            {sib_clause}
    """).to_df()

    # OTA status comes from the SHARED authority (reporting/ota.py): the analyst's
    # reference/ota_list.xlsx UNION the master's ota_status, with the flag folded across a
    # merged agency's sibling ids.
    #
    # Why not just dim_customer.ota_status: this sheet's OTA cut used the master's flag while the
    # "Top OTA" sheet in this SAME workbook ranks from ota_list.xlsx. The two lists overlap on
    # only 61 ids, so 42 agencies were printed on "Top OTA" and inside "Agent - Non-OTA"
    # simultaneously — 26.51 cr of July sales that one sheet called OTA and the other did not.
    # Writing the resolved status back onto the row keeps the printed OTA Status column honest:
    # a row in the OTA cut always shows 'OTA'.
    try:
        _ota_ids = resolve_ota_ids(_CFG.data_root, con)
    except Exception as exc:
        _ota_ids = set()
        print(f"[dsr] WARN: OTA resolver unavailable ({exc}); falling back to the master flag")
    if _ota_ids and not attrs.empty:
        _is_ota = attrs.customer_id.astype(str).isin(_ota_ids)
        _was = attrs.ota_status.astype(str).str.strip().str.upper() == "OTA"
        _added = int((_is_ota & ~_was).sum())
        attrs.loc[_is_ota, "ota_status"] = "OTA"
        if _added:
            print(f"[dsr] OTA status resolved from the shared list: {int(_is_ota.sum())} agencies "
                  f"flagged ({_added} that the master alone would have missed)")

    # --- Year-over-year baseline (same month one year before `start`) -
    # For an Apr 2026 DSR, this pulls Apr 2025 per-agent sales — the file
    # 'Bi Analysis from sale jan25 to Feb 26.xlsx' supplies months prior
    # to May 2025 that the warehouse doesn't have.
    yoy_df = _fetch_yoy_baseline(con, start)

    # --- Merge everything ---------------------------------------------
    df = attrs.merge(current_df, on="customer_id", how="left")
    for label, h in history.items():
        df = df.merge(h.rename(columns={"sales": f"{label} Sales"}), on="customer_id", how="left")
    df = df.merge(segments, on="customer_id", how="left")
    df = df.merge(yoy_df, on="customer_id", how="left")

    # email beside the manager, so a KAM row carries a way to reach them
    _sp_mail = _salesperson_emails()
    df["sales_manager_email"] = [
        _sp_mail.get(str(v or "").strip(), _sp_mail.get(str(v or "").strip().lower(), ""))
        for v in df.get("sales_manager", pd.Series([""] * len(df)))]

    df["current_sales"] = df["current_sales"].fillna(0)
    for label in history:
        df[f"{label} Sales"] = df[f"{label} Sales"].fillna(0)
    df["dom_seg"] = df["dom_seg"].fillna(0).astype(int)
    df["int_seg"] = df["int_seg"].fillna(0).astype(int)
    df["total_seg"] = df["total_seg"].fillna(0).astype(int)
    df["yoy_sales"] = df["yoy_sales"].fillna(0)

    # Append the 4 channel-rollup rows (Counter / Corporate / Mobi App / Web)
    # so the agent sheet sums to the Day Wise total. Concat happens BEFORE
    # the rename so the lowercase column names still line up.
    rollup = _build_channel_rollup_rows(con, start, end, prior_months)
    if "sales_manager_email" not in rollup.columns:
        rollup["sales_manager_email"] = ""          # channel rollups have no KAM
    df = pd.concat([df, rollup], ignore_index=True)
    # rollup adds yoy_sales already; ensure any concat-NaN gets filled
    df["yoy_sales"] = df["yoy_sales"].fillna(0)

    # YoY % — current vs same month last year. Returns 0 when yoy_sales is
    # zero (no prior-year data on file), so the column reads as a clean 0%
    # rather than the spreadsheet rendering #DIV/0!.
    df["yoy_pct"] = df.apply(
        lambda r: ((r["current_sales"] - r["yoy_sales"]) / r["yoy_sales"])
                  if r["yoy_sales"] > 0 else 0.0,
        axis=1,
    )

    # Idx column placeholder. The real sequence is assigned AFTER the sort
    # below (so numbering runs 1..N top-to-bottom in display order, and the
    # Z-* roll-up footer rows stay blank). Was a single repeated literal 'A'.
    df.insert(0, "Idx", "")

    # Final column order matching the template
    cur_label = f"{calendar.month_abbr[start.month]}-{str(start.year)[-2:]} Sales"
    df = df.rename(columns={"current_sales": cur_label})

    # Reverse history order so it's oldest -> newest then current.
    # The first (AGENT_HISTORY_MONTHS - AGENT_VISIBLE_MONTHS) of these are the older block that
    # the writer collapses behind a plus sign; the last AGENT_VISIBLE_MONTHS stay on screen.
    history_labels = [f"{lbl} Sales" for _, _, lbl in prior_months][::-1]
    recent_labels = history_labels[-AGENT_VISIBLE_MONTHS:] if history_labels else []

    # YoY column label, e.g. "Apr-25 Sales (YoY)" for an Apr 2026 DSR.
    #
    # The "(YoY)" suffix is load-bearing now that the history runs twelve months: the twelfth
    # month back IS the same month last year, so this column and the oldest history column
    # would otherwise carry identical headers. They are NOT the same figure and must not be
    # merged: this one falls back to 'Bi Analysis from sale jan25 to Feb 26.xlsx' for months the
    # warehouse never received, while the history column can only report what the warehouse
    # holds. Where both have data they agree; where they do not, the difference is the point.
    yoy_label, _, _ = _yoy_month_label(start)
    yoy_sales_col = f"{yoy_label} Sales (YoY)"
    yoy_pct_col   = f"YoY {cur_label.replace(' Sales', '')} vs {yoy_label}"

    final_cols = [
        "Idx", "customer_id", "agent_name", "station", "zone", "agent_type",
        "ota_status", "sales_manager", "sales_manager_email", "thana", "district_state",
        "country",
        *history_labels,
        cur_label,
        "dom_seg", "int_seg", "total_seg",
        "yoy_sales", "yoy_pct",      # new YoY columns at the end
    ]
    df = df[final_cols].rename(columns={
        "customer_id": "Zenith ID",
        "agent_name": "Agent Name",
        "station": "Station",
        "zone": "Zone",
        "agent_type": "Agent Type",
        "ota_status": "OTA Status",
        "sales_manager": "Sales Manager",
        "sales_manager_email": "Sales Manager Email",
        "thana": "Thana",
        "district_state": "District/State",
        "country": "Country",
        "dom_seg": f"Dom Seg {cur_label.replace(' Sales', '')}",
        "int_seg": f"Int Seg {cur_label.replace(' Sales', '')}",
        "total_seg": f"Total Seg {cur_label.replace(' Sales', '')}",
        "yoy_sales": yoy_sales_col,
        "yoy_pct":   yoy_pct_col,
    })

    # Sort applied (per user's May-26 hand-polish pass):
    #   * Primary  : Agent Type bucket order
    #                Non-IATA → BSP → Non BSP → Corporate → Counter → Mobi App → Web
    #     (the "real" overseas agencies tend to lead in total sales, so this
    #     puts the heaviest agents at the top regardless of zone.)
    #   * Secondary: sum of the last 4 months sales DESC within the bucket
    #     (3 prior months + current — captures "which agent has the biggest
    #     four-month book of business")
    #   * The 4 synthetic Z-* rollup rows (Z-Counter, Z-Corporate, Z-Mobi App,
    #     Z-Web) stay pinned to the bottom as a footer block.
    type_order = {
        "Non-IATA":  0,
        "BSP":       1,
        "Non BSP":   2,
        "Corporate": 3,
        "Counter":   4,
        "Mobi App":  5,
        "Web":       6,
    }
    df["_is_rollup"]  = df["Zenith ID"].astype(str).str.startswith("Z-").astype(int)
    df["_type_rank"]  = df["Agent Type"].map(type_order).fillna(99).astype(int)
    # Deliberately the RECENT months plus current, not all twelve. Widening the history was a
    # presentation change; ranking on a year of book would silently reorder the whole sheet and
    # move agencies up or down for reasons nobody asked for.
    df["_four_mo"]    = df[recent_labels + [cur_label]].sum(axis=1)
    df = (
        df.sort_values(
            ["_is_rollup", "_type_rank", "_four_mo"],
            ascending=[True, True, False],
        )
        .drop(columns=["_is_rollup", "_type_rank", "_four_mo"])
        .reset_index(drop=True)
    )

    # Idx = 1..N over agent rows in final display order; blank on the Z-*
    # roll-up footer rows (Z-Counter / Z-Corporate / Z-Mobi App / Z-Web).
    _seq = 0
    _idx_out: list = []
    for _zid in df["Zenith ID"].astype(str):
        if _zid.startswith("Z-"):
            _idx_out.append("")
        else:
            _seq += 1
            _idx_out.append(_seq)
    df["Idx"] = _idx_out
    return df


BD_DOM_AIRPORTS = ('DAC', 'CGP', 'CXB', 'ZYL', 'JSR', 'RJH', 'BZL', 'SPD')


def _zone_segments(con, start: date, end: date,
                   zone: str | None = None) -> pd.DataFrame:
    """Compute Dom / Int / Total segments per zone from Ticket-payment rows.
    Domestic = both Dep and Arr airports in BD_DOM_AIRPORTS.
    If ``zone`` is given, restrict to that single zone (for zone-filtered DSRs)."""
    glob = (PROJECT_ROOT / "curated" / "sales").as_posix() + "/**/*.parquet"
    dom_set = ", ".join(f"'{a}'" for a in BD_DOM_AIRPORTS)
    zone_clause = f"AND c.zone = '{zone}'" if zone else ""
    return con.sql(f"""
        WITH rows AS (
            SELECT
                CASE WHEN CAST("Customer ID" AS VARCHAR) = 'BO-1 Central Reservation'
                     THEN '11246131'
                     ELSE regexp_replace(CAST("Customer ID" AS VARCHAR), '\\.0$', '')
                END AS customer_id,
                CAST("seg" AS DOUBLE) AS seg,
                CAST("Departure airport" AS VARCHAR) AS dep,
                CAST("Arrival airport"   AS VARCHAR) AS arr
            FROM dsr_src
            WHERE "Date"::DATE BETWEEN DATE '{start.isoformat()}' AND DATE '{end.isoformat()}'
              AND CAST("Transaction" AS VARCHAR) = 'Ticket payment'
        )
        SELECT
            c.zone,
            SUM(COALESCE(r.seg,1)) FILTER (WHERE r.dep IN ({dom_set})
                                              AND r.arr IN ({dom_set})) AS dom_seg,
            SUM(COALESCE(r.seg,1)) FILTER (WHERE NOT (r.dep IN ({dom_set})
                                                       AND r.arr IN ({dom_set}))) AS int_seg,
            SUM(COALESCE(r.seg,1)) AS total_seg,
            -- ticket counts per sector: needed to turn the target engine's target TICKETS
            -- into target SEGMENTS at this row's own segments-per-ticket ratio
            COUNT(*) FILTER (WHERE r.dep IN ({dom_set})
                               AND r.arr IN ({dom_set})) AS dom_tkt,
            COUNT(*) FILTER (WHERE NOT (r.dep IN ({dom_set})
                                        AND r.arr IN ({dom_set}))) AS int_tkt
        FROM rows r
        JOIN dim_customer c ON r.customer_id = c.customer_id
        WHERE c.zone IS NOT NULL
          {zone_clause}
        GROUP BY 1
    """).to_df()


def _counter_segments(con, start: date, end: date) -> pd.DataFrame:
    """Compute Dom / Int / Total segments per primary_pos (counter) — mirror of
    _zone_segments() but grouped by OFFICE customers' primary_pos instead of zone."""
    glob = (PROJECT_ROOT / "curated" / "sales").as_posix() + "/**/*.parquet"
    dom_set = ", ".join(f"'{a}'" for a in BD_DOM_AIRPORTS)
    return con.sql(f"""
        WITH rows AS (
            SELECT
                CASE WHEN CAST("Customer ID" AS VARCHAR) = 'BO-1 Central Reservation'
                     THEN '11246131'
                     ELSE regexp_replace(CAST("Customer ID" AS VARCHAR), '\\.0$', '')
                END AS customer_id,
                CAST("seg" AS DOUBLE) AS seg,
                CAST("Departure airport" AS VARCHAR) AS dep,
                CAST("Arrival airport"   AS VARCHAR) AS arr
            FROM dsr_src
            WHERE "Date"::DATE BETWEEN DATE '{start.isoformat()}' AND DATE '{end.isoformat()}'
              AND CAST("Transaction" AS VARCHAR) = 'Ticket payment'
        )
        SELECT
            c.primary_pos AS pos,
            SUM(COALESCE(r.seg,1)) FILTER (WHERE r.dep IN ({dom_set})
                                              AND r.arr IN ({dom_set})) AS dom_seg,
            SUM(COALESCE(r.seg,1)) FILTER (WHERE NOT (r.dep IN ({dom_set})
                                                       AND r.arr IN ({dom_set}))) AS int_seg,
            SUM(COALESCE(r.seg,1)) AS total_seg,
            -- ticket counts per sector: needed to turn the target engine's target TICKETS
            -- into target SEGMENTS at this row's own segments-per-ticket ratio
            COUNT(*) FILTER (WHERE r.dep IN ({dom_set})
                               AND r.arr IN ({dom_set})) AS dom_tkt,
            COUNT(*) FILTER (WHERE NOT (r.dep IN ({dom_set})
                                        AND r.arr IN ({dom_set}))) AS int_tkt
        FROM rows r
        JOIN dim_customer c ON r.customer_id = c.customer_id
        WHERE c.primary_channel = 'OFFICE'
          AND c.primary_pos IS NOT NULL
        GROUP BY 1
    """).to_df()


def _counter_sales(con, start: date, end: date) -> pd.DataFrame:
    """For OFFICE customers, aggregate sales per primary_pos (the counter label).
    Also fetch 3-month history."""
    cur = con.sql("""
        SELECT
            c.primary_pos AS pos,
            SUM(s.dsr_amount) AS current_sales
        FROM dsr_sales_enriched s
        JOIN dim_customer c ON s.customer_id = c.customer_id
        WHERE c.primary_channel = 'OFFICE'
          AND c.primary_pos IS NOT NULL
        GROUP BY 1
    """).to_df()

    # 3-month history per POS
    prior = _last_three_months(start)
    glob = (PROJECT_ROOT / "curated" / "sales").as_posix() + "/**/*.parquet"
    rate_sql = build_rate_sql()
    histories = {}
    for y, m, label in prior:
        df = con.sql(f"""
            WITH rows AS (
                SELECT
                    CASE WHEN CAST("Customer ID" AS VARCHAR) = 'BO-1 Central Reservation'
                         THEN '11246131'
                         ELSE regexp_replace(CAST("Customer ID" AS VARCHAR), '\\.0$', '')
                    END AS customer_id,
                    CAST("Transaction" AS VARCHAR) AS txn,
                    CAST("Balance (base currency)" AS DOUBLE) AS balance,
                    CAST("Total without taxe (base currency)" AS DOUBLE) AS fare,
                    ({rate_sql}) AS commission_rate
                FROM dsr_src
                WHERE EXTRACT(YEAR FROM "Date") = {y}
                  AND EXTRACT(MONTH FROM "Date") = {m}
            )
            SELECT
                c.primary_pos AS pos,
                SUM(CASE
                    WHEN r.txn IN ('Ticket payment','Reissuance Adjustment') THEN
                        COALESCE(r.fare,0)*(1-r.commission_rate)
                        + (COALESCE(r.balance,0) - COALESCE(r.fare,0))
                    WHEN r.txn IN ('Refund','Ticket void','Cancel refund') THEN r.balance
                    WHEN r.txn = 'Penalty' THEN r.balance
                    ELSE 0
                END) AS sales
            FROM rows r
            JOIN dim_customer c ON r.customer_id = c.customer_id
            WHERE c.primary_channel = 'OFFICE'
              AND c.primary_pos IS NOT NULL
            GROUP BY 1
        """).to_df()
        histories[label] = df

    out = cur.copy()
    for label, h in histories.items():
        out[label] = out["pos"].map(h.set_index("pos")["sales"]).fillna(0)
    out["current_sales"] = out["current_sales"].fillna(0)
    return out


def _trend(achieved) -> str:
    """The achievement band shown in the Trend column.

    NO TARGET MEANS NO TREND. Targets are None until the artefact is applied, and a row without
    one must not be labelled "Below 50%": that reads as a measured failure rather than an absent
    measurement, which is exactly how all 39 zones came to show a confident 0%.

    Module level, not nested, so it can be tested directly.
    """
    if achieved is None or (isinstance(achieved, float) and achieved != achieved):
        return ""
    if achieved >= 1.0:    return "Above 100%"
    if achieved >= 0.75:   return "Between 75% - 100%"
    if achieved >= 0.50:   return "Between 50% - 75%"
    return "Below 50%"


def load_zone_targets(start: date) -> "pd.DataFrame | None":
    """This month's per-zone targets, published by the target report. None if absent.

    The DSR does NOT compute targets. `june_target` owns that maths (capacity x proven load
    factor x yield) and writes `curated/targets/zone_targets_<YYYY-MM>.parquet` on every run;
    this reads it. One calculation, two reports, no way for them to disagree.

    RETURNING None IS A REAL ANSWER. Before this existed the DSR hardcoded 0 into every target
    cell, so all 39 zones printed "0%" achievement — a missing number wearing the clothes of a
    measured one. With no artefact the cells are left genuinely empty instead.
    """
    ym = f"{start.year:04d}-{start.month:02d}"
    p = PROJECT_ROOT / "curated" / "targets" / f"zone_targets_{ym}.parquet"
    if not p.is_file():
        print(f"[dsr] no target artefact for {ym} - target columns left blank "
              f"(run the target report to publish one)")
        return None
    try:
        t = pd.read_parquet(p)
    except Exception as exc:                                       # noqa: BLE001
        print(f"[dsr] target artefact unreadable ({type(exc).__name__}) - targets left blank")
        return None
    print(f"[dsr] targets: {len(t)} zone(s) from {p.name}")
    return t.set_index("zone")


def _apply_targets(rows: list[dict], targets, seg_per_tkt: dict) -> None:
    """Fill target_current / seg_target_* / target_achieved in place.

    COUNTERS ARE ALLOCATED, NOT TARGETED INDIVIDUALLY. The target engine works in sales zones
    and gives one `Z-Counter` figure for all 39 counters together, because a counter is not a
    zone. It is split here pro-rata on each counter's own trailing 3-month sales, which is the
    only defensible basis available: a counter that took 10% of counter revenue carries 10% of
    the counter target. The split is stated in the code rather than hidden so nobody reads a
    per-counter target as something ops set.

    Target SEGMENTS come from target TICKETS times that row's own segments-per-ticket, measured
    per sector. Segments per ticket differs a lot between sectors (a domestic return is 2 on 1,
    an international itinerary can be more), so applying a blended ratio would move the split
    between Dom and Int while leaving the total unchanged, which looks right and is not.
    """
    if targets is None:
        return
    counters = [r for r in rows if str(r.get("zone", "")).startswith("Counter-")]

    def _basis(r) -> float:
        """A counter's share weight: trailing 3-month sales, FLOORED AT ZERO.

        `_target_basis` is a net figure, so a quiet or wound-down counter whose refunds outran
        its sales in the window comes back NEGATIVE. Left unfloored that is doubly wrong: the
        counter is handed a negative target and negative segment targets (a target to sell minus
        eight thousand seats), and because it also shrinks the denominator, every OTHER counter's
        share is inflated to compensate. With one counter at +100 and one at -40 the base was 60,
        so a counter entitled to 100% of the pot was given 167% of it. The total still reconciled,
        which is exactly why it would have survived a tie-out check.

        A negative trailing net is not evidence of negative future capacity; it is no evidence.
        """
        return max(0.0, float(r.get("_target_basis", 0) or 0))

    counter_base = sum(_basis(r) for r in counters)
    ct = targets.loc["Z-Counter"] if "Z-Counter" in targets.index else None

    for r in rows:
        if r.get("kind") != "data":
            continue
        zone = str(r.get("zone", ""))
        if zone.startswith("Counter-"):
            share = (_basis(r) / counter_base) if counter_base > 0 else 0.0
            # No positive trailing history means no basis to allocate on, so the cells stay
            # ABSENT. Falling through with share 0 would write a 0.0 target and then a 0.0
            # achievement, which prints "Below 50%" -- the missing-number-in-measured-clothing
            # this whole feature exists to remove.
            if ct is None or share <= 0:
                continue
            tgt, tkd, tki = (float(ct["target_net"]) * share,
                             float(ct["target_tkt_dom"]) * share,
                             float(ct["target_tkt_int"]) * share)
        else:
            if zone not in targets.index:
                continue
            row = targets.loc[zone]
            tgt, tkd, tki = (float(row["target_net"]), float(row["target_tkt_dom"]),
                             float(row["target_tkt_int"]))
        spt = seg_per_tkt.get(zone if not zone.startswith("Counter-")
                              else r.get("area_description", ""), {})
        sd = tkd * spt.get("dom", 0.0)
        si = tki * spt.get("int", 0.0)
        r["target_current"] = tgt
        r["seg_target_dom"] = round(sd)
        r["seg_target_int"] = round(si)
        r["seg_target_total"] = round(sd + si)
        # `if tgt > 0`, never `if tgt`. A 0.0 target used to yield a 0.0 achievement, which
        # _trend() renders as a confident "Below 50%". The subtotal re-sum below already used
        # None for the same condition, so the two halves of one feature disagreed about how to
        # say "no target".
        r["target_achieved"] = (float(r.get("current_sales", 0) or 0) / tgt) if tgt > 0 else None


def _counter_history(c, prior_months) -> dict:
    """A counter row's prior-month sales and per-day averages, keyed the way the writer reads.

    The writer asks for `drow[label]` and `drow[f"per_day_{label}_lac"]` where the labels come
    from `_last_three_months(start)`, so they move every month. Building them here keeps the
    counter rows in step with the zone rows, which have always done it dynamically.

    Per-day uses each month's OWN length, not a flat 30: dividing a 31-day month by 30 quietly
    overstates its daily rate by 3%, and these columns sit next to each other for comparison.
    """
    out: dict = {}
    for y, m, label in prior_months:
        sales = float(c.get(label, 0) or 0)
        out[label] = sales
        out[f"per_day_{label}_lac"] = sales / LAC / calendar.monthrange(y, m)[1]
    return out


def build_zone_wise(con, start: date, end: date,
                    zone: str | None = None) -> pd.DataFrame:
    """
    Zone-wise performance — full company DSR layout with sections.

    Returns a single DataFrame with a 'kind' column that the writer uses to
    style each row. Sections (in order):

      1. BD Agent zones (Zone-1..Zone-19) grouped by city with subtotals:
            Dhaka Agents Total / Chittagong Total / Saidpur Total
            Bangladesh Total
      2. Overseas Agent zones (Zone-20..Zone-33) + Overseas Total
      3. Holidays placeholder
      4. Corporate placeholder
      5. Counter sales (OFFICE channel) grouped BD / Overseas
            Bangladesh Counters Grand Total / Overseas Counters Grand Total

    Segments (Dom/Int/Total) are computed from departure/arrival airports.
    """
    current = con.sql("""
        SELECT zone, SUM(dsr_amount) AS current_sales
        FROM dsr_sales_enriched
        WHERE zone IS NOT NULL
        GROUP BY 1
    """).to_df()

    prior = _last_three_months(start)
    glob = (PROJECT_ROOT / "curated" / "sales").as_posix() + "/**/*.parquet"
    rate_sql = build_rate_sql()

    # 3-month history per zone. Apply commission rate inside the inner CTE
    # before the column aliasing happens.
    history_dfs = {}
    for y, m, label in prior:
        h = con.sql(f"""
            WITH rows AS (
                SELECT
                    regexp_replace(CAST("Customer ID" AS VARCHAR), '\\.0$', '') AS customer_id,
                    CAST("Transaction" AS VARCHAR) AS txn,
                    CAST("Balance (base currency)" AS DOUBLE) AS balance,
                    CAST("Total without taxe (base currency)" AS DOUBLE) AS fare,
                    ({rate_sql}) AS commission_rate
                FROM dsr_src
                WHERE EXTRACT(YEAR  FROM "Date") = {y}
                  AND EXTRACT(MONTH FROM "Date") = {m}
            )
            SELECT
                c.zone,
                SUM(
                    CASE
                        WHEN r.txn IN ('Ticket payment','Reissuance Adjustment') THEN
                            COALESCE(r.fare,0) * (1 - r.commission_rate)
                            + (COALESCE(r.balance,0) - COALESCE(r.fare,0))
                        WHEN r.txn IN ('Refund','Ticket void','Cancel refund') THEN
                            COALESCE(r.balance, 0)
                        WHEN r.txn = 'Penalty' THEN
                            COALESCE(r.balance, 0)
                        ELSE 0.0
                    END
                ) AS sales
            FROM rows r
            JOIN dim_customer c ON r.customer_id = c.customer_id
            WHERE c.zone IS NOT NULL
              {f"AND c.zone = '{zone}'" if zone else ""}
            GROUP BY 1
        """).to_df()
        history_dfs[label] = h

    # Merge — start from dim_zone (gives us the full zone list + attributes)
    dim_zone = con.sql(f"""
        SELECT zone_code, area_description, city_code, district, country, region
        FROM read_parquet('{_DIM_ZONE}')
        WHERE category = 'Agent'
        ORDER BY zone_code
    """).to_df()

    out = dim_zone.rename(columns={"zone_code": "zone"}).copy()

    # dim_zone is the curated zone dimension, but it only knows the UNSUFFIXED codes
    # (Zone-1..Zone-33). The master actually assigns agencies to letter-suffixed SUB-ZONES —
    # Zone-22C/22M and Zone-28A/28D/28S — which are real zones with their own sales person.
    # Starting the frame from dim_zone alone dropped them from this sheet entirely: 585
    # agencies and 93.85 cr of July sales (14.8% of all zoned money, Zone-28D alone 79.53 cr)
    # appeared on the Agent sheet but had NO row here, so the two sheets in one workbook
    # disagreed by that much and "Overseas Total" was understated by ~30%.
    # Union in anything the data carries, inheriting the base zone's attributes.
    _known = set(out["zone"])
    _extra = [z for z in current["zone"].dropna().unique().tolist()
              if z not in _known and str(z).startswith("Zone-")]
    if _extra:
        import re as _re
        _rows = []
        for z in sorted(_extra):
            _base = _re.sub(r"([0-9]+)[A-Za-z]+$", r"\1", str(z))   # Zone-28D -> Zone-28
            _src = out[out["zone"] == _base]
            _r = (_src.iloc[0].to_dict() if len(_src)
                  else {c: None for c in out.columns})
            _r["zone"] = z
            _rows.append(_r)
        out = pd.concat([out, pd.DataFrame(_rows)], ignore_index=True)
        print(f"[dsr] zone sheet: added {len(_extra)} sub-zone row(s) missing from dim_zone "
              f"({', '.join(sorted(_extra))})")

    out["current_sales"] = out["zone"].map(current.set_index("zone")["current_sales"]).fillna(0)
    for label, h in history_dfs.items():
        out[label] = out["zone"].map(h.set_index("zone")["sales"]).fillna(0)

    # Segments per zone (Dom/Int/Total)
    seg = _zone_segments(con, start, end, zone=zone)
    seg_by_zone = seg.set_index("zone")
    out["seg_dom"]   = out["zone"].map(seg_by_zone["dom_seg"]).fillna(0).astype(int)
    out["seg_int"]   = out["zone"].map(seg_by_zone["int_seg"]).fillna(0).astype(int)
    out["seg_total"] = out["zone"].map(seg_by_zone["total_seg"]).fillna(0).astype(int)

    # Per-day averages in LACS (used by the company DSR layout)
    days_in_range = (end - start).days + 1
    out["per_day_cur_lac"] = out["current_sales"] / LAC / days_in_range
    for label in history_dfs:
        out[f"per_day_{label}_lac"] = out[label] / LAC / 30

    # Targets start EMPTY, not zero. They are filled from the published target artefact at the
    # end of this function (see _apply_targets); anything the artefact does not cover stays
    # blank, so a missing target reads as missing rather than as 0% achieved.
    for blank in ("seg_target_dom", "seg_target_int", "seg_target_total", "target_current"):
        out[blank] = None
    out["target_achieved"] = None

    out["trend"] = out["target_achieved"].apply(_trend)

    # ----- Build the ordered output (section by section) -----------------
    # Zone-1..9 are Dhaka, Zone-10..11B are Chittagong, Zone-16..17 are
    # Saidpur, Zone-20..33 are Overseas, everything else BD agent.
    def _with_subzones(codes: list[str]) -> list[str]:
        """Expand base zone codes to include their letter-suffixed sub-zones.

        The section lists are hardcoded literals, so a sub-zone that exists in the data but not
        in the literal list is emitted by nobody and silently vanishes from the sheet. Matching
        is anchored on the base code + letters only, so 'Zone-2' can never swallow 'Zone-22C'.
        """
        import re as _re
        present = [str(z) for z in out["zone"].dropna().tolist()]
        res: list[str] = []
        for c in codes:
            res.append(c)
            res.extend(sorted(z for z in present
                              if z != c and _re.fullmatch(_re.escape(c) + r"[A-Za-z]+", z)))
        return list(dict.fromkeys(res))

    dhaka      = _with_subzones([f"Zone-{n}" for n in range(1, 10)])
    chittagong = _with_subzones(["Zone-10", "Zone-11", "Zone-11A", "Zone-11B"])
    saidpur    = _with_subzones(["Zone-16", "Zone-17"])
    bd_other   = _with_subzones(["Zone-12", "Zone-13", "Zone-14", "Zone-15",
                                 "Zone-18", "Zone-19"])
    overseas   = _with_subzones([f"Zone-{n}" for n in range(20, 34)])

    # Nothing may be dropped: every zone carrying money must land in exactly one section.
    _sections = set(dhaka) | set(chittagong) | set(saidpur) | set(bd_other) | set(overseas)
    _orphans = [z for z in out.loc[out["current_sales"] != 0, "zone"].tolist()
                if z not in _sections]
    if _orphans:
        print(f"[dsr] WARNING: {len(_orphans)} zone(s) carry money but match no section and "
              f"will NOT appear on Zone Wise Sales: {', '.join(map(str, sorted(_orphans)))}")

    def _subtotal(rows, label):
        """Build a subtotal row from a list of data-row dicts. Sums every
        numeric column we care about (segments, sales, history, targets).

        THE HISTORY COLUMNS ARE NAMED DYNAMICALLY. They were hardcoded as "Dec-25", "Jan-26"
        ... — the same stale literals that blanked the counter rows — so every subtotal
        (Dhaka Agents Total, Bangladesh Total, the counter grand totals) summed month keys that
        no longer exist and printed nothing under the prior-month columns, while the zone rows
        above them showed real figures that visibly failed to add up.

        Per-day averages are summed too, not recomputed: a sum of per-day figures IS the group's
        per-day figure, whereas re-dividing would need the right day count per month.
        """
        hist = [lab for _, _, lab in prior]
        sumcols = (["seg_dom", "seg_int", "seg_total", "current_sales"]
                   + hist + [f"per_day_{h}_lac" for h in hist]
                   + ["seg_target_dom", "seg_target_int", "seg_target_total", "target_current"])
        sums = {c: sum(float(r.get(c, 0) or 0) for r in rows) for c in sumcols}
        tgt = sums.get("target_current", 0)
        ach = (sums.get("current_sales", 0) / tgt) if tgt else None
        return {"kind": "subtotal", "zone": "", "area_description": label,
                "city_code": "", **sums,
                "per_day_cur_lac": sums.get("current_sales", 0) / LAC / days_in_range,
                "target_achieved": ach, "trend": _trend(ach),
                # Subtotals are assembled BEFORE the targets are applied, so the target columns
                # would all sum to zero. The member dicts are the same objects _apply_targets
                # mutates, so keeping a reference lets the totals be re-summed once the targets
                # land. Dropped again before the frame is built.
                "_members": list(rows)}

    # Convert to list-of-dicts for easier section assembly
    rows = []
    zone_lookup = out.set_index("zone").to_dict("index")

    def _emit_zone(z):
        r = zone_lookup.get(z)
        if r:
            r2 = {"kind": "data", "zone": z, **r}
            rows.append(r2)
            return r2
        return None

    # BD Agent — Dhaka block
    dhaka_data = [_emit_zone(z) for z in dhaka]
    rows.append(_subtotal([r for r in dhaka_data if r], "Dhaka Agents Total"))
    # Chittagong
    cgp_data = [_emit_zone(z) for z in chittagong]
    rows.append(_subtotal([r for r in cgp_data if r], "Chittagong Total"))
    # Other BD agents (Cox's Bazar, Sylhet, Jessore, Khulna, Rajshahi, Barisal)
    other_bd_data = [_emit_zone(z) for z in bd_other[:4]]  # CXB, ZYL, JSR, KHL
    sai_data = [_emit_zone(z) for z in saidpur]
    rows.append(_subtotal([r for r in sai_data if r], "Saidpur Total"))
    _emit_zone(bd_other[4])  # Zone-18 Rajshahi
    _emit_zone(bd_other[5])  # Zone-19 Barisal

    # Bangladesh Total = all BD agents
    all_bd = [r for r in rows if r.get("kind") == "data"
                                  and r.get("zone") in (dhaka + chittagong + bd_other + saidpur)]
    rows.append(_subtotal(all_bd, "Bangladesh Total"))

    # Overseas
    overseas_data = [_emit_zone(z) for z in overseas]
    rows.append(_subtotal([r for r in overseas_data if r], "Overseas Total"))

    # Holiday / Corporate placeholders
    rows.append({"kind": "placeholder", "zone": "Holidays",
                  "area_description": "Holiday Package Total", "city_code": "N/A",
                  "current_sales": 0, "Dec-25": 0, "Jan-26": 0, "Feb-26": 0,
                  "seg_dom": 0, "seg_int": 0, "seg_total": 0,
                  "per_day_cur_lac": 0, "target_achieved": 0, "trend": ""})
    rows.append({"kind": "placeholder", "zone": "Corporate",
                  "area_description": "Corporate Agents Total", "city_code": "N/A",
                  "current_sales": 0, "Dec-25": 0, "Jan-26": 0, "Feb-26": 0,
                  "seg_dom": 0, "seg_int": 0, "seg_total": 0,
                  "per_day_cur_lac": 0, "target_achieved": 0, "trend": ""})

    # Counters — by primary_pos (the counter label). Split BD vs overseas
    # by whether the POS starts with an INT prefix. Pull segments per POS
    # so counter rows show real Dom/Int/Total counts like the agent zones do.
    counters     = _counter_sales(con, start, end)
    counter_segs = _counter_segments(con, start, end).set_index("pos")
    bd_counters       = counters[~counters["pos"].fillna("").str.startswith("INT ")]
    overseas_counters = counters[ counters["pos"].fillna("").str.startswith("INT ")]

    def _seg(pos: str, kind: str) -> int:
        if pos in counter_segs.index:
            v = counter_segs.loc[pos, kind]
            if pd.isna(v):
                return 0
            return int(v)
        return 0

    counter_idx_bd = 1
    bd_counter_rows: list[dict] = []
    for _, c in bd_counters.iterrows():
        pos = c["pos"]
        r2 = {
            "kind": "data", "zone": f"Counter-{counter_idx_bd}",
            "area_description": pos,
            "city_code": pos.split("-")[0] if "-" in pos else "",
            "current_sales": c["current_sales"],
            # PRIOR MONTHS AND THEIR PER-DAY AVERAGES, under the labels the WRITER reads.
            # These were hardcoded as "Dec-25", "Jan-26" ... — literals from the month this
            # section was first written. `_counter_sales` fetches the history for the real
            # trailing months (Jul-26, Jun-26 for an August run) and the writer looks it up by
            # those live labels, so every counter's prior-month and per-day columns came out
            # BLANK while the data sat in the frame under names nobody read. The zone rows have
            # always used the dynamic labels; only the counter rows carried literals.
            **_counter_history(c, prior),
            "seg_dom":   _seg(pos, "dom_seg"),
            "seg_int":   _seg(pos, "int_seg"),
            "seg_total": _seg(pos, "total_seg"),
            "per_day_cur_lac": c["current_sales"] / LAC / days_in_range,
            # left empty; both are filled from the target artefact by _apply_targets
            "target_achieved": None, "trend": "",
        }
        rows.append(r2)
        bd_counter_rows.append(r2)
        counter_idx_bd += 1
    if bd_counter_rows:
        rows.append(_subtotal(bd_counter_rows, "Bangladesh Counters Grand Total"))

    # Overseas counters
    counter_idx_os = counter_idx_bd
    overseas_rows: list[dict] = []
    for _, c in overseas_counters.iterrows():
        pos = c["pos"]
        r2 = {
            "kind": "data", "zone": f"Counter-{counter_idx_os}",
            "area_description": pos,
            "city_code": "OS",
            "current_sales": c["current_sales"],
            # PRIOR MONTHS AND THEIR PER-DAY AVERAGES, under the labels the WRITER reads.
            # These were hardcoded as "Dec-25", "Jan-26" ... — literals from the month this
            # section was first written. `_counter_sales` fetches the history for the real
            # trailing months (Jul-26, Jun-26 for an August run) and the writer looks it up by
            # those live labels, so every counter's prior-month and per-day columns came out
            # BLANK while the data sat in the frame under names nobody read. The zone rows have
            # always used the dynamic labels; only the counter rows carried literals.
            **_counter_history(c, prior),
            "seg_dom":   _seg(pos, "dom_seg"),
            "seg_int":   _seg(pos, "int_seg"),
            "seg_total": _seg(pos, "total_seg"),
            "per_day_cur_lac": c["current_sales"] / LAC / days_in_range,
            # left empty; both are filled from the target artefact by _apply_targets
            "target_achieved": None, "trend": "",
        }
        rows.append(r2)
        overseas_rows.append(r2)
        counter_idx_os += 1
    if overseas_rows:
        rows.append(_subtotal(overseas_rows, "Overseas Counters Grand Total"))

    # ----- Targets, from the artefact the target report publishes --------------------
    # Done LAST, once every row exists, because the counter allocation needs the full set of
    # counter rows to work out each one's share.
    targets = load_zone_targets(start)
    if targets is not None:
        # Basis for splitting the single Z-Counter target across the 39 counters: each
        # counter's own trailing 3-month sales, which the rows already carry.
        hist_keys = [lab for _, _, lab in prior]
        for r in rows:
            if str(r.get("zone", "")).startswith("Counter-"):
                r["_target_basis"] = sum(float(r.get(k, 0) or 0) for k in hist_keys)
        # Segments per ticket, per sector, for zones and for counters, measured on this
        # month's own rows so the conversion reflects how each actually sells.
        spt: dict = {}
        for frame, key in ((seg_by_zone.reset_index(), "zone"),
                           (counter_segs.reset_index(), "pos")):
            for x in frame.to_dict("records"):
                dt_, it_ = float(x.get("dom_tkt") or 0), float(x.get("int_tkt") or 0)
                spt[str(x[key])] = {
                    "dom": (float(x.get("dom_seg") or 0) / dt_) if dt_ else 0.0,
                    "int": (float(x.get("int_seg") or 0) / it_) if it_ else 0.0,
                }
        _apply_targets(rows, targets, spt)
        # The trend band is a reading of the achievement, so it has to be recomputed after the
        # targets land; leaving the placeholder value would label every row "Below 50%".
        for r in rows:
            ach = r.get("target_achieved")
            r["trend"] = _trend(float(ach)) if ach is not None else ""
        # Re-sum the subtotals now that their members carry targets.
        for r in rows:
            mem = r.get("_members")
            if not mem:
                continue
            for c in ("seg_target_dom", "seg_target_int", "seg_target_total", "target_current"):
                r[c] = sum(float(m.get(c, 0) or 0) for m in mem)
            tgt = r["target_current"]
            r["target_achieved"] = (float(r.get("current_sales", 0) or 0) / tgt) if tgt else None
            r["trend"] = _trend(r["target_achieved"])
        filled = sum(1 for r in rows if r.get("target_current"))
        print(f"[dsr] targets applied to {filled} row(s) "
              f"(zones direct, counters pro-rata on trailing 3-month sales)")

    # Scratch keys must not become columns in the emitted frame.
    for r in rows:
        r.pop("_members", None)
        r.pop("_target_basis", None)
    final_df = pd.DataFrame(rows)
    return final_df


# ---------------------------------------------------------------------------
# Dashboard sheet
# ---------------------------------------------------------------------------

def _clean_chart_labels(chart, series_name: str, sz: int = 700) -> None:
    """Make a chart's data labels show VALUE ONLY (no 'Series1' / category
    clutter), whole-number, small font, positioned above the point — and
    give the single series a meaningful name instead of 'Series1'.

    openpyxl's DataLabelList(showVal=True) leaves showSerName / showCatName
    unset, which Excel renders as 'Series1, 07May26, 80'. We force them False.
    """
    from openpyxl.chart.label import DataLabelList
    from openpyxl.chart.series import SeriesLabel
    from openpyxl.chart.text import RichText
    from openpyxl.drawing.text import (
        Paragraph, ParagraphProperties, CharacterProperties,
    )

    dl = DataLabelList()
    dl.showVal        = True
    dl.showSerName    = False
    dl.showCatName    = False
    dl.showLegendKey  = False
    dl.showPercent    = False
    dl.showBubbleSize = False
    dl.numFmt         = "0"
    dl.position       = "t"
    dl.txPr = RichText(p=[Paragraph(
        pPr=ParagraphProperties(defRPr=CharacterProperties(sz=sz)))])
    chart.dataLabels = dl
    # Name the series so it isn't "Series1".
    if chart.series:
        chart.series[0].tx = SeriesLabel(v=series_name)


def _emit_dashboard(wb, start: date, end: date,
                     day_wise_total_row: int = 48,
                     day_count: int = 30,
                     agent_n: int = 4612) -> None:
    """
    Build the executive Dashboard sheet.

    ``day_wise_total_row`` is the actual row number of the "Daily Total" row
    on the Day Wise Sales sheet (1-indexed). The caller computes this from
    ``7 + len(day_wise)`` and passes it in so the KPI formulas always point
    at the right row even when the number of category-rows changes (e.g. a
    new country, a new category, or after a customer-master refresh).

    ``day_count`` is the number of day columns on the Day Wise pivot (28 in
    Feb, 30 in Apr, 31 in Jan/Mar). Day columns start at col 2 (B) so the
    last day column is at index ``1 + day_count`` and the grand-total column
    is at ``2 + day_count``. The Dashboard formulas use these to build
    correct column letter ranges per month — without this, hardcoding
    AF (col 32) silently broke Jan/Feb/Mar which have different totals
    column positions.

    ``agent_n`` is the number of data rows on the Agent sheet (excluding the
    3-row header). Used to size the Total Agents COUNTA range correctly.
    """
    """
    Create the Dashboard sheet as the workbook's first tab. All values are
    *formulas* that reference the other sheets — so when the operations team
    edits a number on Top OTA, Day Wise, etc., the Dashboard updates live.

    Layout (designed to fit a single Excel window at 84% zoom):
       row 2:  Title banner (USBA SALES DASHBOARD - <Month>)
       row 3:  Subtitle (date range)
       row 5:  "QUICK NAVIGATION" section banner
       row 6:  5 hyperlink tiles (Day Wise / Zone Wise / City / Top OTA / Top Corp)
       row 8:  "KEY METRICS" section
       rows 9-11:  5 KPI cards (label / value / subtitle)
       rows 13-19: "TOP 5 POS" + "TOP 5 OTAs" side by side
       rows 21-27: "TOP 5 ZONES" + "TOP 5 CORPORATE" side by side
       row 29:  "30-DAY DAILY SALES TREND" + LineChart
       row 39:  "TOP 10 ZONES" + BarChart
       rows 51-58: Segment mix / Zone coverage / MoM
       rows 60-63: Weekday vs Weekend split
    """
    from openpyxl.chart import BarChart, LineChart, Reference
    from openpyxl.chart.label import DataLabelList
    from openpyxl.chart.layout import Layout, ManualLayout
    from openpyxl.chart.series import DataPoint
    from openpyxl.chart.shapes import GraphicalProperties
    from openpyxl.drawing.fill import ColorChoice
    from openpyxl.drawing.line import LineProperties
    from openpyxl.styles import Alignment, Font, PatternFill

    ws = wb.create_sheet("Dashboard", 0)
    cur_label = f"{calendar.month_abbr[start.month]}-{str(start.year)[-2:]}"
    cur_label_upper = cur_label.upper()              # APR-26
    month_name = start.strftime("%B %Y")

    _polish_sheet(ws, zoom=84, tab_color=DSR_NAVY)

    # Column widths — narrow rails A and G, wide content cols
    for col, w in (("A", 3.0), ("B", 30.6), ("C", 18.0), ("D", 22.0),
                    ("E", 18.0), ("F", 20.0), ("G", 3.0)):
        ws.column_dimensions[col].width = w

    # === Row 2: Title banner ===
    # Em-dashes (—) used throughout for the corporate look; APR-26 in caps.
    ws.row_dimensions[2].height = 40
    ws.merge_cells("B2:F2")
    ws["B2"] = f"USBA SALES DASHBOARD — {month_name}"
    _style_banner_title(ws["B2"])

    # Row 3: Subtitle
    ws.merge_cells("B3:F3")
    ws["B3"] = (f"Daily Sales Report — USBA — Period: "
                f"{start.strftime('%d %b %Y')} to {end.strftime('%d %b %Y')}")
    ws["B3"].font = Font(size=10, color=DSR_NAVY, italic=True)
    ws["B3"].alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[3].height = 18

    # === Row 5: QUICK NAVIGATION ===
    ws.merge_cells("B5:F5")
    ws["B5"] = "QUICK NAVIGATION"
    _style_dashboard_section(ws["B5"])
    ws.row_dimensions[5].height = 24

    # Emoji icons for quick visual scanning (matches the user's enhanced file)
    nav_targets = [
        ("B6", "'Day Wise Sales'!A1",         "📅 Day Wise Sales"),
        ("C6", "'Zone Wise Sales'!A1",        "📍 Zone Wise Sales"),
        ("D6", "'City Wise Top 20 Agent'!A1", "🏙️ City — Top 20"),
        ("E6", "'Top OTA'!A1",                "💻 Top OTA"),
        ("F6", "'Top Corp'!A1",               "🏢 Top Corporate"),
    ]
    for coord, target, label in nav_targets:
        ws[coord] = f'=HYPERLINK("#{target}","{label}")'
        _style_dashboard_nav(ws[coord])
    ws.row_dimensions[6].height = 28

    # === Row 8: KEY METRICS ===
    ws.merge_cells("B8:F8")
    ws["B8"] = "KEY METRICS"
    _style_dashboard_section(ws["B8"])
    ws.row_dimensions[8].height = 22

    # Row 9: labels   Row 10: values   Row 11: subtitles
    # All cell references that depend on data-driven counts use the params
    # passed in by the caller (write_excel) — this prevents the old hardcoded
    # 89 (row) and AF (column) from breaking Jan/Feb/Mar which have
    # different day counts than April.
    dt = day_wise_total_row
    last_day_col   = get_column_letter(1 + day_count)   # last day column
    total_col      = get_column_letter(2 + day_count)   # grand-total column
    days_range_dt  = f"B{dt}:{last_day_col}{dt}"        # all-day totals row
    days_range_hdr = f"B5:{last_day_col}5"              # date header row
    agent_last     = 3 + agent_n
    kpi_specs = [
        ("Total Sales (Lac)",   f"='Day Wise Sales'!{total_col}{dt}",
            '="Month total in Lac"'),
        ("Avg Daily Sales (Lac)", f"=AVERAGE('Day Wise Sales'!{days_range_dt})",
            f'="{day_count}-day average"'),
        ("Best Day (Lac)",      f"=MAX('Day Wise Sales'!{days_range_dt})",
            f'=INDEX(\'Day Wise Sales\'!{days_range_hdr},'
            f'MATCH(MAX(\'Day Wise Sales\'!{days_range_dt}),'
            f'\'Day Wise Sales\'!{days_range_dt},0))'),
        ("Weakest Day (Lac)",   f"=MIN('Day Wise Sales'!{days_range_dt})",
            f'=INDEX(\'Day Wise Sales\'!{days_range_hdr},'
            f'MATCH(MIN(\'Day Wise Sales\'!{days_range_dt}),'
            f'\'Day Wise Sales\'!{days_range_dt},0))'),
        ("Total Agents",        f"=COUNTA(Agent!C4:C{agent_last})",
            f'="Reporting in {cur_label}"'),
    ]
    for j, (label, value_formula, subtitle_formula) in enumerate(kpi_specs, start=2):
        col = chr(ord("A") + j - 1)
        ws[f"{col}9"]  = label
        _style_dashboard_kpi_label(ws[f"{col}9"])
        ws[f"{col}10"] = value_formula
        _style_dashboard_kpi_value(ws[f"{col}10"])
        ws[f"{col}10"].number_format = "#,##0.00"
        ws[f"{col}11"] = subtitle_formula
        _style_dashboard_kpi_subtitle(ws[f"{col}11"])
    ws.row_dimensions[9].height  = 22
    ws.row_dimensions[10].height = 38
    ws.row_dimensions[11].height = 18

    # === Row 13: TOP 5 POS (left) + TOP 5 OTAs (right) ===
    ws.merge_cells("B13:C13")
    ws["B13"] = "TOP 5 POS BY MONTH (Lac)"
    _style_dashboard_section(ws["B13"])
    ws.merge_cells("D13:F13")
    ws["D13"] = f"TOP 5 OTAs ({cur_label})"
    _style_dashboard_section(ws["D13"])
    ws.row_dimensions[13].height = 22

    # Row 14: column headers
    for coord, h in [("B14", "POS"), ("C14", "Total (Lac)"),
                      ("D14", "OTA Agent"), ("E14", "City"), ("F14", f"{cur_label} Sales")]:
        ws[coord] = h
        _style_dashboard_kpi_label(ws[coord])

    # Rows 15-19: data formulas pulling top 5 by rank
    # POS lookup range: data rows are 7 .. (dt-1). Row `dt` is the "Daily
    # Total" — including it lets the grand total win every LARGE() rank, so
    # we MUST stop at dt-1. The Total column is `total_col` (dynamic per
    # month: AD for Feb, AF for Apr, AG for Jan/Mar — see _emit_dashboard
    # docstring).
    pos_label_range = f"'Day Wise Sales'!$A$7:$A${dt - 1}"
    pos_total_range = f"'Day Wise Sales'!${total_col}$7:${total_col}${dt - 1}"
    for rank in range(1, 6):
        r = 14 + rank
        # IFERROR-wrapped so a POS/OTA list shorter than 5 (common in a
        # single-zone DSR) shows "" rather than #NUM! / #REF!.
        ws[f"B{r}"] = (f'=IFERROR(INDEX({pos_label_range},'
                       f'MATCH(LARGE({pos_total_range},{rank}),'
                       f'{pos_total_range},0)),"")')
        ws[f"C{r}"] = f'=IFERROR(LARGE({pos_total_range},{rank}),"")'
        # Top OTA pulls (col C=name, D=city, H=sales — those are the new ranked layout)
        ws[f"D{r}"] = f"=IFERROR('Top OTA'!C{rank + 6},\"\")"
        ws[f"E{r}"] = f"=IFERROR('Top OTA'!D{rank + 6},\"\")"
        ws[f"F{r}"] = f"=IFERROR('Top OTA'!H{rank + 6},\"\")"
        # Alternating row stripe
        fill = PatternFill("solid", fgColor=DSR_GREY_LIGHT) if rank % 2 == 0 else None
        for col in ("B", "C", "D", "E", "F"):
            c = ws[f"{col}{r}"]
            c.border = DSR_BORDER
            c.alignment = Alignment(vertical="center")
            if fill:
                c.fill = fill
            if col in ("C", "F"):
                c.font = Font(bold=True, color=DSR_NAVY)
                c.number_format = "#,##0.00" if col == "C" else "#,##0"

    # === Row 21: TOP 5 ZONES (left) + TOP 5 CORPORATE (right) ===
    ws.merge_cells("B21:C21")
    ws["B21"] = f"TOP 5 ZONES BY {cur_label_upper} SALES"
    _style_dashboard_section(ws["B21"])
    ws.merge_cells("D21:F21")
    ws["D21"] = f"TOP 5 CORPORATE ({cur_label})"
    _style_dashboard_section(ws["D21"])
    ws.row_dimensions[21].height = 22

    for coord, h in [("B22", "Zone"), ("C22", f"{cur_label} Sales"),
                      ("D22", "Corporate Agent"), ("E22", "City"),
                      ("F22", f"{cur_label} Sales")]:
        ws[coord] = h
        _style_dashboard_kpi_label(ws[coord])

    # Top 5 zones come from Zone Wise (rows 5-42). We must EXCLUDE the
    # subtotal rows (which have blank zone names like "Bangladesh Total"
    # but big values that would otherwise dominate the top 5).
    #
    # User found that AGGREGATE(14, 6, ...) renders inconsistently in their
    # Excel build — modern Excel sometimes prefixes it with @ which forces
    # a single-cell evaluation and breaks the array filter. Switched to
    # LARGE(IF(...)) which Excel 365 / 2021+ handles natively as a dynamic
    # array. (Older Excel would need this entered as a CSE array formula.)
    zones_col_a   = "'Zone Wise Sales'!$A$5:$A$42"
    zones_col_m   = "'Zone Wise Sales'!$M$5:$M$42"
    # Rank only REAL zones (name starts 'Zone-') that ALSO have sales > 0.
    # Multiplying the two boolean arrays gives a 1/0 mask; IF(mask, M) keeps
    # only qualifying values so LARGE() never sees a subtotal row or a zero.
    is_real_zone  = f'(LEFT({zones_col_a},5)="Zone-")*({zones_col_m}>0)'
    for rank in range(1, 6):
        r = 22 + rank
        large_zone = f'LARGE(IF({is_real_zone},{zones_col_m}),{rank})'
        # IFERROR wraps every rank: when fewer than 5 zones have sales (e.g. a
        # single-zone DSR has only 1), ranks 2-5 return "" instead of #NUM!.
        ws[f"B{r}"] = f'=IFERROR(INDEX({zones_col_a},MATCH({large_zone},{zones_col_m},0)),"")'
        ws[f"C{r}"] = f'=IFERROR({large_zone},"")'
        ws[f"D{r}"] = f"=IFERROR('Top Corp'!C{rank + 6},\"\")"
        ws[f"E{r}"] = f"=IFERROR('Top Corp'!D{rank + 6},\"\")"
        ws[f"F{r}"] = f"=IFERROR('Top Corp'!H{rank + 6},\"\")"
        fill = PatternFill("solid", fgColor=DSR_GREY_LIGHT) if rank % 2 == 0 else None
        for col in ("B", "C", "D", "E", "F"):
            c = ws[f"{col}{r}"]
            c.border = DSR_BORDER
            c.alignment = Alignment(vertical="center")
            if fill:
                c.fill = fill
            if col in ("C", "F"):
                c.font = Font(bold=True, color=DSR_NAVY)
                c.number_format = "#,##0"

    # === Row 29: Daily Sales Trend chart ===
    ws.merge_cells("B29:F29")
    ws["B29"] = f"{day_count}-DAY DAILY SALES TREND (Lac)"
    _style_dashboard_section(ws["B29"])
    ws.row_dimensions[29].height = 22

    # Hidden mirror of daily totals for the chart (cols A,B at rows 100+).
    # Column A = date string (from Day Wise row 5), Column B = day's total
    # (from the dynamic Daily Total row, NOT hardcoded — see _emit_dashboard
    # docstring).
    days_in_range = (end - start).days + 1
    for i in range(days_in_range):
        col_letter = get_column_letter(i + 2)  # source columns B..AE on Day Wise
        ws[f"A{100 + i}"] = f"='Day Wise Sales'!{col_letter}5"
        ws[f"B{100 + i}"] = f"='Day Wise Sales'!{col_letter}{dt}"

    trend = LineChart()
    # Add explicit axis titles since the section banner only labels the chart
    # at the top — without these the chart reads as "untitled lines on
    # untitled axes" which the user flagged.
    trend.title  = None  # banner above already labels this
    trend.y_axis.title = "Daily Sales (Lac)"
    trend.x_axis.title = "Date"
    trend.style = 2     # cleaner navy look
    trend.height = 7
    trend.width  = 22
    trend.legend = None
    # Force axis labels to render — openpyxl charts default to hiding tick
    # labels in some Excel viewers; setting delete=False + tickLblPos="low"
    # forces them visible.
    trend.x_axis.delete = False
    trend.y_axis.delete = False
    trend.x_axis.tickLblPos = "low"
    trend.y_axis.tickLblPos = "low"
    data_ref = Reference(ws, min_col=2, max_col=2,
                          min_row=100, max_row=100 + days_in_range - 1)
    cats_ref = Reference(ws, min_col=1, max_col=1,
                          min_row=100, max_row=100 + days_in_range - 1)
    trend.add_data(data_ref, titles_from_data=False)
    trend.set_categories(cats_ref)
    # Value-ONLY labels (no 'Series1'/date clutter), 7pt, named series.
    _clean_chart_labels(trend, "Daily Sales (Lac)")
    # Force the navy line colour
    if trend.series:
        s = trend.series[0]
        s.graphicalProperties = GraphicalProperties(solidFill=DSR_NAVY)
        s.graphicalProperties.line = LineProperties(solidFill=DSR_NAVY, w=20000)
    ws.add_chart(trend, "B30")

    # === Row 39: Top 10 zones bar chart ===
    ws.merge_cells("B39:F39")
    ws["B39"] = f"TOP 10 ZONES BY {cur_label_upper} SALES"
    _style_dashboard_section(ws["B39"])
    ws.row_dimensions[39].height = 22

    # Hidden mirror for top-10 zones (rows 130-139). Ordered ASCENDING so a
    # horizontal bar chart displays the biggest bar at the BOTTOM, smallest at
    # the top. Uses the same LARGE(IF()) filter as the Top 5 list so subtotal
    # rows ("Bangladesh Total" etc.) are excluded from the bar chart.
    for i in range(10):
        rank = 10 - i   # 10, 9, 8, ..., 1
        large_zone = f'LARGE(IF({is_real_zone},{zones_col_m}),{rank})'
        # IFERROR -> "" so the bar chart simply omits absent ranks (no #NUM!).
        ws[f"A{130 + i}"] = (
            f'=IFERROR(INDEX({zones_col_a},MATCH({large_zone},{zones_col_m},0)),"")'
        )
        ws[f"B{130 + i}"] = f'=IFERROR({large_zone},"")'

    bar = BarChart()
    bar.type = "bar"
    bar.style = 2
    bar.title = None  # banner above already labels this
    bar.legend = None
    bar.height = 9
    bar.width  = 22
    bar.x_axis.title = "Sales (BDT)"
    bar.y_axis.title = "Zone"
    # Force axis ticks visible — same defaults issue as the trend chart.
    bar.x_axis.delete = False
    bar.y_axis.delete = False
    bar.x_axis.tickLblPos = "low"
    bar.y_axis.tickLblPos = "low"
    # Sort ascending so the biggest bar is at the bottom — same as the user's
    # enhanced view.
    data_ref = Reference(ws, min_col=2, max_col=2, min_row=130, max_row=139)
    cats_ref = Reference(ws, min_col=1, max_col=1, min_row=130, max_row=139)
    bar.add_data(data_ref, titles_from_data=False)
    bar.set_categories(cats_ref)
    # Value-ONLY labels (no 'Series1'/zone clutter), named series.
    _clean_chart_labels(bar, "Zone Sales (BDT)")
    # Solid navy bars
    if bar.series:
        s = bar.series[0]
        s.graphicalProperties = GraphicalProperties(solidFill=DSR_NAVY)
    ws.add_chart(bar, "B40")

    # === Row 51: SEGMENT MIX ===
    ws.merge_cells("B51:F51")
    ws["B51"] = f"SEGMENT MIX — {cur_label_upper} (Bangladesh + Overseas Zones)"
    _style_dashboard_section(ws["B51"])
    ws.row_dimensions[51].height = 22

    for coord, h in [("B52", "Domestic Segments"), ("C52", "International Segments"),
                      ("D52", "Total Segments"), ("E52", "Domestic %"),
                      ("F52", "International %")]:
        ws[coord] = h
        _style_dashboard_kpi_label(ws[coord])

    ws["B53"] = '=SUMIF(\'Zone Wise Sales\'!$A$5:$A$87,"Zone-*",\'Zone Wise Sales\'!$G$5:$G$87)'
    ws["C53"] = '=SUMIF(\'Zone Wise Sales\'!$A$5:$A$87,"Zone-*",\'Zone Wise Sales\'!$H$5:$H$87)'
    ws["D53"] = "=B53+C53"
    ws["E53"] = "=IFERROR(B53/D53,0)"
    ws["F53"] = "=IFERROR(C53/D53,0)"
    for col in ("B", "C", "D", "E", "F"):
        _style_dashboard_kpi_value(ws[f"{col}53"])
        ws[f"{col}53"].font = Font(bold=True, size=16, color=DSR_NAVY)
        if col in ("E", "F"):
            ws[f"{col}53"].number_format = "0.0%"
        else:
            ws[f"{col}53"].number_format = "#,##0"
    ws.row_dimensions[53].height = 38

    # === Row 55: Zone Coverage + Month-over-Month ===
    ws.merge_cells("B55:C55")
    ws["B55"] = f"ZONE COVERAGE ({cur_label})"
    _style_dashboard_section(ws["B55"])
    ws.merge_cells("D55:F55")
    ws["D55"] = "MONTH-OVER-MONTH SALES (BDT)"
    _style_dashboard_section(ws["D55"])
    ws.row_dimensions[55].height = 22

    for coord, h in [("B56", "Zones with Sales"), ("C56", f"Total Actual ({cur_label})"),
                      ("D56", "Jan-26"), ("E56", "Feb-26"), ("F56", cur_label)]:
        ws[coord] = h
        _style_dashboard_kpi_label(ws[coord])

    ws["B57"] = '=COUNTIFS(\'Zone Wise Sales\'!$A$5:$A$42,"Zone-*",\'Zone Wise Sales\'!$M$5:$M$42,">0")'
    ws["C57"] = '=SUMIF(\'Zone Wise Sales\'!$A$5:$A$42,"Zone-*",\'Zone Wise Sales\'!$M$5:$M$42)'
    ws["D57"] = "=SUM(Agent!L4:L4615)"
    ws["E57"] = "=SUM(Agent!M4:M4615)"
    ws["F57"] = "=SUM(Agent!O4:O4615)"
    for col in ("B", "C", "D", "E", "F"):
        _style_dashboard_kpi_value(ws[f"{col}57"])
        ws[f"{col}57"].font = Font(bold=True, size=16, color=DSR_NAVY)
        ws[f"{col}57"].number_format = "#,##0"
    ws.row_dimensions[57].height = 38

    # Subtitles row
    ws["B58"] = '="of "&COUNTIF(\'Zone Wise Sales\'!$A$5:$A$42,"Zone-*")&" total zones"'
    ws["C58"] = '="Per zone avg: "&TEXT(IFERROR(C57/B57,0),"#,##0")'
    ws["D58"] = "baseline"
    ws["E58"] = '=TEXT(IFERROR(E57/D57-1,0),"+0.0%;-0.0%")&" vs Jan"'
    ws["F58"] = '=TEXT(IFERROR(F57/E57-1,0),"+0.0%;-0.0%")&" vs Feb (Mar n/a)"'
    for col in ("B", "C", "D", "E", "F"):
        _style_dashboard_kpi_subtitle(ws[f"{col}58"])

    # === Row 60: WEEKDAY vs WEEKEND ===
    ws.merge_cells("B60:F60")
    ws["B60"] = f"WEEKDAY vs WEEKEND — {cur_label_upper} (Lac)"
    _style_dashboard_section(ws["B60"])
    ws.row_dimensions[60].height = 22

    # En-dashes for the day ranges (Sun–Thu, Fri–Sat) — different from em-dash
    for coord, h in [("B61", "Weekday Avg (Sun–Thu)"), ("C61", "Weekend Avg (Fri–Sat)"),
                      ("D61", "Weekday Total"), ("E61", "Weekend Total"),
                      ("F61", "Weekend Drag")]:
        ws[coord] = h
        _style_dashboard_kpi_label(ws[coord])

    # Use Day Wise row 6 (DOW labels) to detect weekend days.
    # All formulas must be non-array (no OR() with ranges) — we expand to
    # AVERAGEIFS / SUMIFS / COUNTIFS so they evaluate without Ctrl-Shift-Enter.
    # Weekday vs Weekend split — uses the dynamic Daily Total row (dt) AND
    # the dynamic last-day-column letter so the formulas keep working when
    # the month has a different number of days (28 / 30 / 31).
    dtotal_range = f"'Day Wise Sales'!B{dt}:{last_day_col}{dt}"
    dow_range    = f"'Day Wise Sales'!B6:{last_day_col}6"
    ws["B62"] = (f'=IFERROR(AVERAGEIFS({dtotal_range},'
                  f'{dow_range},"<>Fri",{dow_range},"<>Sat"),0)')
    ws["C62"] = (
        f'=IFERROR((SUMIFS({dtotal_range},{dow_range},"Fri")'
        f'+SUMIFS({dtotal_range},{dow_range},"Sat"))'
        f'/(COUNTIFS({dow_range},"Fri")+COUNTIFS({dow_range},"Sat")),0)'
    )
    ws["D62"] = (f'=SUMIFS({dtotal_range},{dow_range},"<>Fri",{dow_range},"<>Sat")')
    ws["E62"] = (f'=SUMIFS({dtotal_range},{dow_range},"Fri")'
                  f'+SUMIFS({dtotal_range},{dow_range},"Sat")')
    ws["F62"] = "=IFERROR(C62/B62-1,0)"
    for col in ("B", "C", "D", "E", "F"):
        _style_dashboard_kpi_value(ws[f"{col}62"])
        ws[f"{col}62"].font = Font(bold=True, size=16, color=DSR_NAVY)
        if col == "F":
            ws[f"{col}62"].number_format = "+0.0%;-0.0%"
            ws[f"{col}62"].font = Font(bold=True, size=16, color=DSR_DARK_RED)
        else:
            ws[f"{col}62"].number_format = "#,##0.00"
    ws.row_dimensions[62].height = 38

    # Subtitle row 63 — count of weekdays / weekend days in the month
    ws["B63"] = ('=COUNTIFS(\'Day Wise Sales\'!B6:AE6,"<>Fri",'
                  '\'Day Wise Sales\'!B6:AE6,"<>Sat")&" weekdays in month"')
    ws["C63"] = ('=(COUNTIFS(\'Day Wise Sales\'!B6:AE6,"Fri")'
                  '+COUNTIFS(\'Day Wise Sales\'!B6:AE6,"Sat"))&" weekend days"')
    ws["F63"] = "Weekend vs Weekday avg"
    for col in ("B", "C", "D", "E", "F"):
        _style_dashboard_kpi_subtitle(ws[f"{col}63"])

    # Footer — middle-dot character (·) as separator, matches user's enhanced file
    ws.merge_cells("B32:F32")
    ws["B32"] = "All figures linked live to source sheets · Currency in BDT unless labeled (Lac)"
    ws["B32"].font = Font(size=9, color=DSR_GREY_TEXT, italic=True)
    ws["B32"].alignment = Alignment(horizontal="center", vertical="center")


# ---------------------------------------------------------------------------
# Excel writer
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Styling helpers — one per "kind of cell" the DSR uses.
# Each helper accepts a cell and applies fill + font + alignment + border
# in a single call so the writer functions stay readable.
# ---------------------------------------------------------------------------

def _style_banner_title(cell) -> None:
    """Navy banner used for every sheet's main title row.
    Matches the user's corporate Dashboard palette."""
    cell.font = Font(bold=True, size=18, color=DSR_WHITE, name="Calibri")
    cell.fill = PatternFill("solid", fgColor=DSR_NAVY)
    cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)


def _style_red_title(cell) -> None:
    """Navy banner — same as the main title, kept for compatibility with the
    'Top OTA / Top Corp / City Wise' callers."""
    cell.font = Font(bold=True, size=18, color=DSR_WHITE, name="Calibri")
    cell.fill = PatternFill("solid", fgColor=DSR_NAVY)
    cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)


def _style_date_header(cell) -> None:
    """Light-blue tinted date/day header row (Day Wise Sales rows 3-4)."""
    cell.font = Font(bold=True, color=DSR_NAVY, name="Calibri")
    cell.fill = PatternFill("solid", fgColor=DSR_BLUE_LIGHT)
    cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    cell.border = DSR_BORDER


def _style_table_header(cell) -> None:
    """Navy header with white bold text (replaces the old no-fill black header)."""
    cell.font = Font(bold=True, color=DSR_WHITE, name="Calibri")
    cell.fill = PatternFill("solid", fgColor=DSR_NAVY)
    cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    cell.border = DSR_BORDER


def _style_subheader(cell) -> None:
    """Light blue sub-header (group labels like 'Mar-26 Segment')."""
    cell.font = Font(bold=True, color=DSR_NAVY, name="Calibri")
    cell.fill = PatternFill("solid", fgColor=DSR_BLUE_LIGHT)
    cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    cell.border = DSR_BORDER


def _style_zone_header(cell) -> None:
    """Navy-filled header for Zone Wise Sales (was green, now matches palette)."""
    cell.font = Font(bold=True, color=DSR_WHITE, name="Calibri")
    cell.fill = PatternFill("solid", fgColor=DSR_NAVY)
    cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    cell.border = DSR_BORDER


def _style_sheet1_header(cell) -> None:
    """Sheet1 (zone manager directory) — keep the orange/blue look as a visual
    cue that this sheet is reference data, not generated sales data."""
    cell.font = Font(bold=True, color=DSR_BLUE, name="Calibri")
    cell.fill = PatternFill("solid", fgColor=DSR_ORANGE)
    cell.alignment = Alignment(horizontal="center", vertical="center")
    cell.border = DSR_BORDER


# --- Dashboard-specific helpers ----------------------------------------------

def _style_dashboard_section(cell) -> None:
    """Navy section banner (e.g. 'KEY METRICS', 'TOP 5 OTAs')."""
    cell.font = Font(bold=True, size=11, color=DSR_WHITE, name="Calibri")
    cell.fill = PatternFill("solid", fgColor=DSR_NAVY)
    cell.alignment = Alignment(horizontal="center", vertical="center")
    cell.border = DSR_BORDER


def _style_dashboard_kpi_label(cell) -> None:
    """Medium-blue KPI label (e.g. 'Total Sales (Lac)')."""
    cell.font = Font(bold=True, size=10, color=DSR_WHITE, name="Calibri")
    cell.fill = PatternFill("solid", fgColor=DSR_BLUE_MED)
    cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    cell.border = DSR_BORDER


def _style_dashboard_kpi_value(cell) -> None:
    """Large white-card KPI value (20pt navy bold)."""
    cell.font = Font(bold=True, size=20, color=DSR_NAVY, name="Calibri")
    cell.fill = PatternFill("solid", fgColor=DSR_WHITE)
    cell.alignment = Alignment(horizontal="center", vertical="center")
    cell.border = DSR_BORDER


def _style_dashboard_kpi_subtitle(cell) -> None:
    """Small grey subtitle text below a KPI value."""
    cell.font = Font(size=9, color=DSR_GREY_TEXT, name="Calibri", italic=True)
    cell.fill = PatternFill("solid", fgColor=DSR_WHITE)
    cell.alignment = Alignment(horizontal="center", vertical="center")
    cell.border = DSR_BORDER


def _style_dashboard_nav(cell) -> None:
    """Light-blue navigation tile (hyperlink to a sheet)."""
    cell.font = Font(bold=True, size=11, color=DSR_NAVY, underline="single", name="Calibri")
    cell.fill = PatternFill("solid", fgColor=DSR_BLUE_LIGHT)
    cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    cell.border = DSR_BORDER


def _polish_sheet(ws, *, zoom: int = 73, freeze: str | None = None,
                   tab_color: str | None = None) -> None:
    """Common per-sheet polish: hide gridlines, set zoom, freeze panes, tab color."""
    ws.sheet_view.zoomScale = zoom
    ws.sheet_view.showGridLines = False
    if freeze:
        ws.freeze_panes = freeze
    if tab_color:
        ws.sheet_properties.tabColor = tab_color
    # Print setup: landscape, fit-to-width
    ws.page_setup.orientation = ws.ORIENTATION_LANDSCAPE
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True


def _style_body(cell, *, fmt: str | None = None, bold: bool = False) -> None:
    """Default body cell styling (border + optional number format / bold)."""
    if bold:
        cell.font = Font(bold=True, color=DSR_BLACK)
    cell.border = DSR_BORDER
    if fmt:
        cell.number_format = fmt


def _emit_ranked_block(ws, df: pd.DataFrame, start_row: int, *,
                        cur_label: str, has_pct: bool,
                        group_title: str | None = None,
                        add_total_row: bool = False,
                        location_header: str = "City") -> int:
    """
    Emit one ranked-agent block (Top OTA, Top Corp, or one city of City Wise)
    in the company DSR layout. Returns the next row index after the block.

    Column map (1-indexed):
      col 1  Position
      col 2  Zenith Code
      col 3  Agent Name
      col 4  City
      col 5  Dom Seg
      col 6  Int Seg
      col 7  Total           (segment block — under "Mar-26 Segment")
      col 8  <cur> Sales
      col 9  % of OTA Sales  (Top OTA only, else blank)
      col 10 % of Airlines Sales (Top OTA only, else blank)
      col 11 (separator)
      col 12 <prev3>
      col 13 <prev2>
      col 14 <prev1>
      col 15 (separator)
      col 16 Variance vs <prev1>
      col 17 Variance vs <prev2>

    `group_title` (e.g. "Dhaka") puts a bold city header row above the
    sub-headers. `add_total_row` adds a Total row at the bottom.
    """
    r = start_row

    # Optional group title (e.g. "Dhaka") — for City Wise Top 20
    if group_title:
        cell = ws.cell(row=r, column=1, value=group_title)
        cell.font = Font(bold=True, size=12, color=DSR_BLACK)
        cell.alignment = Alignment(horizontal="center", vertical="center")
        ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=8)
        r += 1

    # Row r: section labels — "Last 3 month records" at col 12, "Variance" at col 16
    _style_table_header(ws.cell(row=r, column=12, value="Last 3 month records"))
    ws.merge_cells(start_row=r, start_column=12, end_row=r, end_column=14)
    _style_table_header(ws.cell(row=r, column=16, value="Variance"))
    ws.merge_cells(start_row=r, start_column=16, end_row=r, end_column=17)
    r += 1

    # Row r: sub-headers
    # Note: the 3 "Total Sales" labels at cols 12/13/14 used to repeat under
    # the "Last 3 month records" merged banner — that was redundant since
    # the banner already implies "total sales per month" and the row below
    # already labels each column with its month (Mar-26 / Feb-26 / Jan-26).
    # We now just emit the segment + current-month labels here; the history
    # columns get a single set of date sub-headers on row r+1.
    # Col-2 sub-header reads "Zenith Code" (not just "Zenith") — matches the
    # company DSR's convention; the user renamed this manually post-Apr-26.
    _style_table_header(ws.cell(row=r, column=2, value="Zenith Code"))
    _style_table_header(ws.cell(row=r, column=5, value=f"{cur_label} Segment"))
    ws.merge_cells(start_row=r, start_column=5, end_row=r, end_column=7)
    _style_table_header(ws.cell(row=r, column=8, value="Total Sales"))
    if has_pct:
        _style_table_header(ws.cell(row=r, column=9, value="% of Total"))
        _style_table_header(ws.cell(row=r, column=10, value="% of Total"))
    # Variance columns keep their sub-label so the user knows what's compared.
    _style_table_header(ws.cell(row=r, column=16, value="Variance"))
    _style_table_header(ws.cell(row=r, column=17, value="Variance"))
    r += 1

    # Row r: detail column headers. `location_header` is "City" for the
    # Top OTA / Top Corp ranked blocks (per-city customer rows) and "Area"
    # for the City Wise Top 20 sheet (per-area customer rows) — same data,
    # different label the company uses for the same dimension.
    headers = ["Position", "Code", "Agent Name", location_header,
               "Dom Seg", "Int Seg", "Total", cur_label]
    for j, h in enumerate(headers, start=1):
        _style_table_header(ws.cell(row=r, column=j, value=h))
    if has_pct:
        _style_table_header(ws.cell(row=r, column=9,  value="OTA Sales"))
        _style_table_header(ws.cell(row=r, column=10, value="Airlines Sales"))

    # Find the 3 history columns from df (oldest first → newest last)
    history_cols = [c for c in df.columns
                    if (c.endswith("-25") or c.endswith("-26"))
                    and not c.startswith("Variance")
                    and c != f"{cur_label} Sales"]
    variance_cols = [c for c in df.columns if c.startswith("Variance vs")]
    for j, h in enumerate(history_cols, start=12):
        _style_table_header(ws.cell(row=r, column=j, value=h))
    for j, h in enumerate(variance_cols, start=16):
        _style_table_header(ws.cell(row=r, column=j,
                                     value=f"{cur_label} vs {h.replace('Variance vs ', '')}"))
    r += 1

    # Data rows
    first_data_row = r
    for _, drow in df.iterrows():
        is_total = (drow.get("Agent Name") == "Total")
        for j, colname in enumerate(["Position", "Zenith Code", "Agent Name", "City",
                                      "Dom Seg", "Int Seg", "Total Seg",
                                      f"{cur_label} Sales"], start=1):
            v = drow.get(colname, "")
            cell = ws.cell(row=r, column=j, value=_safe(v))
            if isinstance(v, (int, float)) and pd.notna(v) and j >= 5:
                _style_body(cell, fmt=FMT_INT_ACC, bold=is_total)
            else:
                _style_body(cell, bold=is_total)
        # Pct columns (Top OTA only)
        if has_pct:
            for j, colname in enumerate(["% of OTA Sales", "% of Airlines Sales"], start=9):
                v = drow.get(colname, "")
                cell = ws.cell(row=r, column=j, value=_safe(v))
                if isinstance(v, (int, float)) and pd.notna(v):
                    _style_body(cell, fmt=FMT_PERCENT, bold=is_total)
                else:
                    _style_body(cell, bold=is_total)
        # History columns
        for j, colname in enumerate(history_cols, start=12):
            v = drow.get(colname, "")
            cell = ws.cell(row=r, column=j, value=_safe(v))
            if isinstance(v, (int, float)) and pd.notna(v):
                _style_body(cell, fmt=FMT_INT_ACC, bold=is_total)
            else:
                _style_body(cell, bold=is_total)
        # Variance columns (skip for Total row — variance doesn't apply)
        if not is_total:
            for j, colname in enumerate(variance_cols, start=16):
                v = drow.get(colname, "")
                cell = ws.cell(row=r, column=j, value=_safe(v))
                if isinstance(v, (int, float)) and pd.notna(v):
                    _style_body(cell, fmt=FMT_PERCENT)
                else:
                    _style_body(cell)
        r += 1

    return r


def _safe(v):
    """Convert pandas NA / NaN / NaT to None so openpyxl accepts the value.
    openpyxl raises ValueError on pd.NA — we need to pre-clean every cell."""
    if v is None:
        return None
    try:
        if pd.isna(v):
            return None
    except (TypeError, ValueError):
        pass
    if isinstance(v, (pd.Timestamp, datetime)):
        return v.to_pydatetime() if hasattr(v, "to_pydatetime") else v
    return v


def _size_agent_columns(ws) -> None:
    """Column widths for an agent sheet, matched on the HEADER TEXT in row 3.

    These used to be a list of letters: A, B, C, D, I, M, Q, V, W. That only holds while the
    column count does not change, and it already did not hold: V and W were sized for the
    leaderboard panel, which had drifted two columns away. Widening the history to twelve
    months would have moved every one of them again. Matching on the header cannot drift,
    because the header is what the reader sees.
    """
    exact = {"Idx": 7.4, "Zenith ID": 14.8, "Agent Name": 42.6, "Station": 14.8,
             "Zone": 11, "Agent Type": 12, "OTA Status": 11,
             "Sales Manager": 22, "Sales Manager Email": 30,
             "Thana": 16, "District/State": 16, "Country": 14}
    for j in range(1, ws.max_column + 1):
        head = str(ws.cell(row=3, column=j).value or "").strip()
        if not head:
            continue
        letter = get_column_letter(j)
        if head in exact:
            width = exact[head]
        elif head.startswith("Top Agent ("):
            width = 40.8
        elif head.startswith("Top 10 by"):
            width = 20.3
        elif head.startswith(("Dom Seg", "Int Seg", "Total Seg")):
            width = 14.4
        elif head.startswith("YoY "):
            width = 15
        elif head.endswith(" Sales") or head.endswith(" Sales (YoY)"):
            width = 17.6
        else:
            continue
        ws.column_dimensions[letter].width = width


def _group_older_months(ws, start: date) -> int:
    """Collapse the months older than the visible window behind a plus sign.

    The sheet carries a year of history but opens at its familiar width. Excel draws the
    expand control just right of the block (summaryRight is the default), next to the visible
    months it sits behind.

    MUST RUN AFTER _size_agent_columns. openpyxl's group() DELETES the individual column
    entries inside its range and stores one dimension spanning them, so any width set
    afterwards would create a second, overlapping entry. Running in this order also means the
    group inherits the month width, so the columns look right the moment they are expanded.

    Driven by the header text rather than by a column count, so it cannot drift.
    """
    older = {f"{lbl} Sales" for _, _, lbl in
             _last_n_months(start, AGENT_HISTORY_MONTHS)[AGENT_VISIBLE_MONTHS:]}
    idx = sorted(j for j in range(1, ws.max_column + 1)
                 if str(ws.cell(row=3, column=j).value or "").strip() in older)
    if not idx:
        return 0
    if idx != list(range(idx[0], idx[-1] + 1)):
        # Not contiguous means the column order changed underneath this helper. Grouping a
        # range that includes something else would hide a column nobody meant to hide.
        print(f"[dsr] WARN: the older-month columns are not contiguous ({idx}); "
              f"leaving them expanded rather than hiding the wrong column")
        return 0
    ws.column_dimensions.group(get_column_letter(idx[0]), get_column_letter(idx[-1]),
                               outline_level=1, hidden=True)
    return len(idx)


def _write_agent_sheet(wb, sheet_title: str, agent: pd.DataFrame, start: date, end: date,
                       cur_label: str, subtitle: str = "") -> None:
    """Write ONE agent listing — the full sheet, or an OTA / non-OTA cut of it.

    Extracted from build_workbook so the same layout can be emitted three times instead of
    being duplicated. Everything below is the sheet exactly as it was hand-polished in May-26
    (title banner, header row 3, SUM/blended-YoY summary row 4, data from row 5, and the
    Top-10 leaderboard side panel in columns U/V) — only the sheet name and the title suffix
    vary between cuts. The leaderboard formulas are written against this sheet's own data
    range, so each cut ranks its OWN top 10 rather than inheriting the parent's.
    """
    # Layout (post May-26 hand-polish, now baked into the writer):
    #   row 1    title banner
    #   row 3    column headers
    #   row 4    "Total" summary row — sums every numeric column across the
    #            entire agent list. Lets readers see the grand totals at the
    #            top without scrolling to the bottom.
    #   row 5+   data rows (sorted by Agent Type bucket, then 4-month sum DESC)
    ws = wb.create_sheet(sheet_title)
    ws["A1"] = (
        f"Agent Wise Sales{subtitle} From {start.strftime('%d/%m/%Y')} "
        f"To {end.strftime('%d/%m/%Y')}"
    )
    _style_red_title(ws["A1"])
    n_agent_rows = 0
    if not agent.empty:
        for j, col in enumerate(agent.columns, start=1):
            _style_table_header(ws.cell(row=3, column=j, value=str(col)))

        # --- Row 4: "Total" summary across the whole agent list ------------
        # column 3 ("Agent Name") shows the literal "Total" label, and every
        # numeric column gets a SUM formula spanning the data range.
        agent_first_data_row = 5
        agent_last_data_row  = 4 + len(agent)  # data lives rows 5..(4+N)
        ws.cell(row=4, column=3, value="Total").font = Font(bold=True, color=DSR_NAVY)
        ws.cell(row=4, column=3).fill = PatternFill("solid", fgColor=DSR_CREAM)
        # Column names of the current-month and same-month-last-year sales, so
        # the YoY total is a BLENDED ratio (CurrentTotal/PriorTotal-1) rather
        # than a meaningless SUM of per-row ratios.
        _cols_list = list(agent.columns)
        _cur_sales_name = f"{calendar.month_abbr[start.month]}-{str(start.year)[-2:]} Sales"
        # Found by its suffix, not rebuilt from the date: the history block now also contains a
        # column for the same month last year, and rebuilding the name would match that one.
        _yoy_sales_name = next((str(c) for c in _cols_list
                                if str(c).endswith(" Sales (YoY)")), None)
        _PCT_FMT = '0.0%;-0.0%;"-"'
        for j, col in enumerate(agent.columns, start=1):
            cell = ws.cell(row=4, column=j)
            cell.fill = PatternFill("solid", fgColor=DSR_CREAM)
            cell.border = DSR_BORDER
            cell.font = Font(bold=True, color=DSR_NAVY)
            col_letter = get_column_letter(j)
            sample = agent[col].dropna()
            if str(col).startswith("YoY "):
                # Blended YoY for the Total row: Total-current / Total-prior - 1.
                if _cur_sales_name in _cols_list and _yoy_sales_name in _cols_list:
                    cl = get_column_letter(_cols_list.index(_cur_sales_name) + 1)
                    yl = get_column_letter(_cols_list.index(_yoy_sales_name) + 1)
                    cell.value = f'=IF({yl}4=0,"-",{cl}4/{yl}4-1)'
                    cell.number_format = _PCT_FMT
            # Only sum numeric columns (history sales, current sales, segments).
            # Skip 'Idx' (a row-sequence — summing it is meaningless).
            elif col != "Idx" and not sample.empty and isinstance(sample.iloc[0], (int, float)):
                cell.value = (
                    f"=SUM({col_letter}{agent_first_data_row}:"
                    f"{col_letter}{agent_last_data_row})"
                )
                cell.number_format = FMT_INT_ACC

        # --- Row 5+: data rows -------------------------------------------
        for i, (_, drow) in enumerate(agent.iterrows(), start=agent_first_data_row):
            for j, val in enumerate(drow, start=1):
                colname = str(agent.columns[j - 1])
                cell = ws.cell(row=i, column=j, value=_safe(val))
                if isinstance(val, (int, float)) and pd.notna(val):
                    # YoY ratio columns render as a percentage (0.15 -> 15.0%),
                    # not an accounting integer (which showed 0).
                    if colname.startswith("YoY "):
                        _style_body(cell, fmt=_PCT_FMT)
                    else:
                        _style_body(cell, fmt=FMT_INT_ACC)
                else:
                    _style_body(cell)
            n_agent_rows = i

        # === Top-10 Agent leaderboard side panel ===========================
        # Rows 4-13 are ranks 1-10; the range starts at row 5 so the "Total" summary row is not
        # picked up as rank 1.
        #
        # BOTH the ranking column and the panel's own position are computed, never hardcoded.
        # They used to be column O and columns U/V, and adding a single column had already
        # broken both: O had drifted onto the PRIOR month, so a panel headed "Top Agent
        # (Jul-26)" was listing June's leaders, and the panel had landed on top of the YoY %
        # column, leaving column U holding formulas for ten rows and unlabelled ratios for the
        # six thousand below them.
        last_row = agent_last_data_row
        _cur_col = get_column_letter(_cols_list.index(_cur_sales_name) + 1) \
            if _cur_sales_name in _cols_list else "P"
        _panel = len(_cols_list) + 2          # one clear column between data and panel
        ws.cell(row=3, column=_panel, value=f"Top Agent ({cur_label})")
        ws.cell(row=3, column=_panel + 1, value=f"Top 10 by {cur_label} Sales")
        _style_table_header(ws.cell(row=3, column=_panel))
        _style_table_header(ws.cell(row=3, column=_panel + 1))
        for rank in range(1, 11):
            r = 3 + rank   # rank 1 -> row 4, rank 10 -> row 13
            ws.cell(row=r, column=_panel, value=(
                f'=INDEX($C${agent_first_data_row}:$C${last_row},'
                f'MATCH(LARGE(${_cur_col}${agent_first_data_row}:${_cur_col}${last_row},{rank}),'
                f'${_cur_col}${agent_first_data_row}:${_cur_col}${last_row},0))'
            ))
            ws.cell(row=r, column=_panel + 1,
                    value=f'=LARGE(${_cur_col}${agent_first_data_row}:'
                          f'${_cur_col}${last_row},{rank})')
            _style_body(ws.cell(row=r, column=_panel))
            _style_body(ws.cell(row=r, column=_panel + 1), fmt=FMT_INT_ACC)
            if rank % 2 == 0:
                ws.cell(row=r, column=_panel).fill = PatternFill("solid", fgColor=DSR_GREY_LIGHT)
                ws.cell(row=r, column=_panel + 1).fill = PatternFill("solid",
                                                                     fgColor=DSR_GREY_LIGHT)



def _kam_mail(label: str) -> str:
    """Address(es) for a KAM bucket — BOTH owners on a shared bucket, so either can be reached."""
    if not _MOM_MAIL:
        return ""
    if is_shared_bucket(label):
        parts = str(label).split("\u2014", 1)[-1].split(" + ")
        got = [_MOM_MAIL.get(x.strip(), "") for x in parts]
        return ", ".join([a for a in dict.fromkeys(got) if a])
    return _MOM_MAIL.get(label, "")


def _write_mom_sheet(wb, mom: dict, start: date, end: date) -> None:
    """MoM movers organised BY KAM (sales manager), because that is who acts on it.

    TWO LAYOUT RULES, both learned the hard way from the first version:

    1. EVERY row carries Zone and Sales Manager — including the indented route rows. The first
       version left them blank on route rows, so the moment a KAM filtered the sheet to their
       own name Excel dropped all their route detail and left bare agency rows. A parent/child
       sheet that cannot survive its own autofilter is not usable.
    2. Agencies are GROUPED under their KAM, not ranked globally. Ranking by change size
       scattered one manager's agencies from row 605 to row 3063; now each manager owns one
       contiguous block, ordered biggest gain -> biggest loss inside it.

    The sheet opens with a KAM SUMMARY — one line per manager — so the whole picture is visible
    before scrolling into 5,000 rows of detail.
    """
    prior_lbl, cur_lbl = mom["labels"]
    global _MOM_MAIL
    _MOM_MAIL = _salesperson_emails()
    ws = wb.create_sheet("MoM Movers")
    ws["A1"] = (f"Month-on-Month Movers by KAM — {cur_lbl} vs {prior_lbl}  "
                f"({start.strftime('%d/%m/%Y')} to {end.strftime('%d/%m/%Y')})")
    _style_red_title(ws["A1"])

    # Columns 1..13 are the headline the sheet opens on. Columns 14.. are one per month of
    # available history and are COLLAPSED behind an outline "+" so the sheet still reads as a
    # month-on-month page until the reader asks for the trend.
    months: list[str] = list(mom.get("months") or [])
    fixed = ["Zenith ID", "Agent / Route", "Zone", "Sales Manager", "Sales Manager Email",
             "Sector",
             f"{prior_lbl} Net", f"{cur_lbl} Net", "Change", "Change %",
             f"Tickets ({cur_lbl})", f"Sales ({cur_lbl})", "Routes"]
    NFIX = len(fixed)                       # 13 — last fixed column, first month is NFIX + 1
    MCOL0 = NFIX + 1

    def _mlabel(ym: str) -> str:
        """'2026-07' -> 'Jul-26' — same shape as the Agent sheet's month headings."""
        try:
            y, m = int(str(ym)[:4]), int(str(ym)[5:7])
            return f"{calendar.month_abbr[m]}-{str(y)[-2:]}"
        except Exception:
            return str(ym)

    heads = fixed + [_mlabel(m) for m in months]
    ncol = len(heads)
    note = (f"Every agency belongs to exactly ONE bucket, so no manager is listed twice and "
            f"no revenue is counted twice. Where the source names TWO people on one agency it "
            f"sits in an amber 'SHARED - A + B' bucket, reported once, rather than split 50/50 "
            f"(nobody has told us the split, and a fabricated half could feed a payout). "
            f"Each manager gets one block: agencies UP at least "
            f"+{MOM_THRESHOLD:.0%} first, then DOWN at least -{MOM_THRESHOLD:.0%}, then any NEW "
            f"(no {prior_lbl} sales — not a percentage change). Under each agency sit its top "
            f"{MOM_TOP_ROUTES} routes for {cur_lbl} by sales, domestic and international "
            f"together, each with its own tickets and sales. "
            f"NOTHING IS CUT OFF — click the '+' controls to open the rest. The '+' in the ROW "
            f"margin under an agency opens EVERY other route it has ever sold, including ones "
            f"it no longer flies (those show blank tickets/sales for {cur_lbl} but still carry "
            f"their monthly history — blank, not zero, so a dormant route is not mistaken for a "
            f"loss-making one); 'Routes' counts every route row underneath. The '+' above column "
            f"{get_column_letter(MCOL0)} opens a sales column for EVERY month held "
            f"({len(months)} month(s)), on the agency rows and on each route row. Month cells "
            f"are blank where there was no sale. Route months sum "
            f"to slightly less than the agency month because tickets with no airport pair carry "
            f"no route. Zone and Sales Manager are repeated "
            f"on the route rows ON PURPOSE so filtering by manager keeps the route detail. Money "
            f"is read straight off the Agent sheet, so both months tie to it exactly, and the "
            f"month columns use that same net formula. Agencies "
            f"under {MOM_MIN_BDT:,.0f} BDT in BOTH months are excluded as immaterial "
            f"({mom['skipped_small']:,} removed).")
    _style_body(ws.cell(row=2, column=1, value=note))
    # Merged over the FIXED columns only: merging across the collapsed month block would make
    # the note re-flow every time the reader opens or closes the "+".
    ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=NFIX)
    ws.row_dimensions[2].height = 60
    ws.cell(row=2, column=1).alignment = Alignment(wrap_text=True, vertical="top")

    up, down, new = mom["up"], mom["down"], mom["new"]
    routes = mom["routes"]
    # Index the routes ONCE. Filtering the whole frame per agency is O(agencies x routes) and
    # took 27 minutes on 1,777 agencies x 5,655 route rows.
    # ALL routes are kept now (was .head(MOM_TOP_ROUTES)); the writer prints the first
    # MOM_TOP_ROUTES open and puts the remainder in a collapsed outline group, so the sheet
    # looks the same on opening but nothing is thrown away.
    #
    # Sort order is what preserves the old headline: routes SOLD THIS MONTH first (biggest
    # first), then routes the agency once sold and no longer does, biggest lifetime first. So
    # the five open rows are the same five as before and everything new lands inside the "+".
    _by_cid: dict = {}
    if len(routes):
        _r = routes.copy()
        if "in_window" not in _r.columns:                     # tolerate an older frame shape
            _r["in_window"] = True
        if "all_time" not in _r.columns:
            _r["all_time"] = _r.get("sales", 0.0)
        _r["_w"] = _r["in_window"].fillna(False).astype(bool)
        _r = _r.sort_values(["_w", "sales", "all_time"], ascending=[False, False, False],
                            na_position="last")
        for _c, _b in _r.groupby("customer_id", sort=False):
            _by_cid[str(_c)] = _b.to_dict("records")

    # month lookups: agency -> {ym: net} and (agency, route) -> {ym: sales}.
    # Pivoted in one pass; a per-row scan of 375k route-months inside the writer loop would
    # repeat the O(agencies x rows) mistake the route index above exists to avoid.
    _amonths: dict = {}
    _rmonths: dict = {}
    if months:
        am = mom.get("agency_months")
        if am is not None and len(am):
            _amonths = (am.pivot_table(index="customer_id", columns="ym", values="net",
                                       aggfunc="sum").to_dict("index"))
            _amonths = {str(k): v for k, v in _amonths.items()}
        rm = mom.get("route_months")
        if rm is not None and len(rm):
            _rmonths = (rm.pivot_table(index=["customer_id", "route"], columns="ym",
                                       values="sales", aggfunc="sum").to_dict("index"))
            _rmonths = {(str(k[0]), str(k[1])): v for k, v in _rmonths.items()}

    def _write_months(row: int, vals: dict | None) -> None:
        """Fill the collapsed month block on one row. Blank where there was no sale."""
        if not vals:
            return
        for _i, _ym in enumerate(months):
            v = vals.get(_ym)
            if v is None or (isinstance(v, float) and pd.isna(v)) or float(v) == 0.0:
                continue
            _style_body(ws.cell(row=row, column=MCOL0 + _i, value=float(v)), fmt=FMT_INT_ACC)

    # ONE bucket per agency (reporting/kam.py). A two-name cell becomes a single SHARED
    # bucket instead of a phantom "KAM", so a person who owns some agencies alone and shares
    # others is no longer split across two rows — and the shared revenue is reported ONCE
    # rather than counted in both their lines (Shubajit Ganguly and Rathin Bepary both carried
    # the same +769,981 before this).
    def _kam(v) -> str:
        return kam_bucket(v)

    for df in (up, down, new):
        if len(df):
            df["_kam"] = df["sales_manager"].map(_kam)
    kams = sorted({k for df in (up, down, new) if len(df) for k in df["_kam"]})

    # ---- KAM SUMMARY -------------------------------------------------------------
    r = 4
    _style_table_header(ws.cell(row=r, column=1, value="KAM SUMMARY"))
    for j, h in enumerate(["KAM (or shared pair)", "Zones", "Agencies up", "Agencies down",
                            "New", "Gain", "Loss", "Net change"], start=2):
        _style_table_header(ws.cell(row=r, column=j, value=h))
    r += 1
    summary = []
    for k in kams:
        u, d, n = (df[df["_kam"] == k] if len(df) else df for df in (up, down, new))
        zones = sorted({str(z) for df in (u, d, n) if len(df) for z in df["zone"]
                        if str(z) not in ("", "nan", "None")})
        summary.append((k, ", ".join(zones)[:60], len(u), len(d), len(n),
                        float(u["delta"].sum()) if len(u) else 0.0,
                        float(d["delta"].sum()) if len(d) else 0.0))
    summary.sort(key=lambda t: -(t[5] + t[6]))
    for k, zl, nu, nd, nn, gain, loss in summary:
        _style_body(ws.cell(row=r, column=2, value=k), bold=True)
        if is_shared_bucket(k):           # a pair, not a person — flag it amber
            for _j in range(1, 10):
                ws.cell(row=r, column=_j).fill = PatternFill("solid", fgColor="FFF2CC")
        _style_body(ws.cell(row=r, column=3, value=zl))
        # Columns 2..9 line up 1:1 with the 8 KAM SUMMARY headings. (A blanket column-shift
        # applied to the DETAIL block once caught these too, pushing 'Agencies down' under the
        # 'New' heading — the summary read 0 down / 999 new.)
        _style_body(ws.cell(row=r, column=4, value=nu), fmt=FMT_INT_ACC)
        _style_body(ws.cell(row=r, column=5, value=nd), fmt=FMT_INT_ACC)
        _style_body(ws.cell(row=r, column=6, value=nn), fmt=FMT_INT_ACC)
        _style_body(ws.cell(row=r, column=7, value=gain), fmt=FMT_INT_ACC)
        _style_body(ws.cell(row=r, column=8, value=loss), fmt=FMT_INT_ACC)
        _style_body(ws.cell(row=r, column=9, value=gain + loss), fmt=FMT_INT_ACC)
        _style_body(ws.cell(row=r, column=1))
        r += 1

    # ---- DETAIL ------------------------------------------------------------------
    r += 1
    hdr_row = r
    for j, h in enumerate(heads, start=1):
        _style_table_header(ws.cell(row=r, column=j, value=h))
    r += 1

    def _agency_rows(df, band_fill):
        nonlocal r
        for x in df.to_dict("records"):
            cid = str(x.get("customer_id") or "")
            kam = _kam(x.get("sales_manager"))
            zone = str(x.get("zone") or "")
            _style_body(ws.cell(row=r, column=1, value=cid))
            nm = ws.cell(row=r, column=2, value=str(x.get("agent_name") or "")[:44])
            _style_body(nm)
            nm.font = Font(bold=True, color=DSR_NAVY)
            _style_body(ws.cell(row=r, column=3, value=zone))
            _style_body(ws.cell(row=r, column=4, value=kam))
            _style_body(ws.cell(row=r, column=5, value=_kam_mail(kam)))
            _style_body(ws.cell(row=r, column=6, value="ALL"))
            _style_body(ws.cell(row=r, column=7, value=_safe(x.get("prv_net"))), fmt=FMT_INT_ACC)
            _style_body(ws.cell(row=r, column=8, value=_safe(x.get("cur_net"))), fmt=FMT_INT_ACC)
            if "delta" in x and pd.notna(x.get("delta")):
                _style_body(ws.cell(row=r, column=9, value=_safe(x.get("delta"))), fmt=FMT_INT_ACC)
                _style_body(ws.cell(row=r, column=10, value=_safe(x.get("pct"))),
                            fmt='0.0%;-0.0%;"-"')
            else:
                _style_body(ws.cell(row=r, column=8))
                _style_body(ws.cell(row=r, column=9))
            _style_body(ws.cell(row=r, column=11, value=int(x.get("cur_tkt") or 0)), fmt=FMT_INT_ACC)
            _style_body(ws.cell(row=r, column=12, value=_safe(x.get("cur_net"))), fmt=FMT_INT_ACC)
            sub = _by_cid.get(cid, [])
            # "Routes" is what tells the reader there is something behind the "+": 5 rows on
            # screen against a count of 23 is a visible invitation to expand.
            _style_body(ws.cell(row=r, column=13, value=len(sub)), fmt=FMT_INT_ACC)
            for j in range(1, NFIX + 1):
                ws.cell(row=r, column=j).fill = PatternFill("solid", fgColor=band_fill)
            _write_months(r, _amonths.get(cid))
            r += 1
            for _n, t in enumerate(sub):
                rt = str(t.get("route") or "")
                _style_body(ws.cell(row=r, column=1))
                _style_body(ws.cell(row=r, column=2, value="      " + rt))
                # zone + KAM repeated so the autofilter keeps these rows with their parent
                _style_body(ws.cell(row=r, column=3, value=zone))
                _style_body(ws.cell(row=r, column=4, value=kam))
                _style_body(ws.cell(row=r, column=5, value=_kam_mail(kam)))
                _style_body(ws.cell(row=r, column=6, value=str(t.get("sector") or "")))
                for j in (7, 8, 9, 10):
                    _style_body(ws.cell(row=r, column=j))
                # A route with no sale THIS month gets blank tickets/sales, not zero — a zero
                # would read as "we flew it and made nothing". Its month cells still show when
                # it last ran, which is the whole reason dormant routes are listed.
                if bool(t.get("in_window", True)):
                    _style_body(ws.cell(row=r, column=11, value=int(t.get("tickets") or 0)),
                                fmt=FMT_INT_ACC)
                    _style_body(ws.cell(row=r, column=12, value=_safe(t.get("sales"))),
                                fmt=FMT_INT_ACC)
                else:
                    _style_body(ws.cell(row=r, column=11))
                    _style_body(ws.cell(row=r, column=12))
                _write_months(r, _rmonths.get((cid, rt)))
                # What stays OPEN is exactly what the top-5 sheet showed: this month's routes,
                # best first, at most MOM_TOP_ROUTES of them. A dormant route is always folded
                # away however few open rows an agency has — back-filling the visible block
                # with routes that did not sell this month would put 2,506 rows on the default
                # view that were never there, which is the opposite of "same sheet, more depth".
                # summaryBelow=False (set on the sheet) puts the +/- control on the row ABOVE
                # the group, i.e. the last open route, so expanding continues the list in place.
                if _n >= MOM_TOP_ROUTES or not bool(t.get("in_window", True)):
                    ws.row_dimensions[r].outlineLevel = 1
                    ws.row_dimensions[r].hidden = True
                r += 1

    for k, zl, nu, nd, nn, gain, loss in summary:
        band = ws.cell(row=r, column=1, value=f"KAM: {k}")
        band.font = Font(bold=True, color=DSR_WHITE)
        _style_body(ws.cell(row=r, column=2,
                            value=f"{nu} up / {nd} down / {nn} new   ·   net "
                                  f"{gain + loss:,.0f} BDT"))
        ws.cell(row=r, column=2).font = Font(bold=True, color=DSR_WHITE)
        _style_body(ws.cell(row=r, column=4, value=k))          # so the filter sees the band too
        ws.cell(row=r, column=4).font = Font(bold=True, color=DSR_WHITE)
        for j in range(1, NFIX + 1):
            ws.cell(row=r, column=j).fill = PatternFill("solid", fgColor=DSR_NAVY)
            ws.cell(row=r, column=j).border = DSR_BORDER
        r += 1
        for label, df, fill in (("UP", up, "E2EFDA"), ("DOWN", down, "FCE4E4"),
                                 ("NEW", new, "F2F2F2")):
            part = df[df["_kam"] == k] if len(df) else df
            if not len(part):
                continue
            _agency_rows(part, fill)

    ws.auto_filter.ref = f"A{hdr_row}:{get_column_letter(ncol)}{max(r - 1, hdr_row)}"

    # ---- OUTLINE ("+") CONTROLS --------------------------------------------------
    # summaryBelow / summaryRight = False put the +/- control BEFORE its group (above the
    # hidden rows, left of the hidden columns) rather than after it. With the defaults the
    # control for an agency's extra routes would land on the NEXT agency's row, which reads as
    # if it belonged to that agency.
    ws.sheet_properties.outlinePr.summaryBelow = False
    ws.sheet_properties.outlinePr.summaryRight = False
    ws.column_dimensions[get_column_letter(NFIX)].width = 8      # "Routes" — outside the group
    if months:
        # Width BEFORE group(): grouping collapses the range into the FIRST column's dimension
        # object and deletes the rest, so a width set afterwards would be dropped. The one
        # surviving dimension spans min..max, which is why every month column comes out 13 wide.
        ws.column_dimensions[get_column_letter(MCOL0)].width = 13
        ws.column_dimensions.group(get_column_letter(MCOL0), get_column_letter(ncol),
                                   outline_level=1, hidden=True)


def write_excel(out_path: Path,
                 day_wise: pd.DataFrame,
                 city_top20: dict,
                 top_ota: pd.DataFrame,
                 top_corp: pd.DataFrame,
                 zone_wise: pd.DataFrame,
                 agent: pd.DataFrame,
                 start: date, end: date,
                 mom: dict | None = None) -> None:
    out_path.parent.mkdir(parents=True, exist_ok=True)
    wb = Workbook()
    wb.remove(wb.active)

    # === Sheet 1: Dashboard (executive summary, all-formula) ============
    # Inserted FIRST so it lands at workbook position 0. Pulls every figure
    # from the other sheets via live formulas — when ops edits a cell elsewhere
    # the dashboard updates automatically.
    #
    # day_wise_total_row = 7 (first_data_row) + len(day_wise) — the "Daily
    # Total" row of the first pivot. day_count = number of day columns (excluding
    # the trailing 'Total' column in day_wise.columns). Both are passed in so
    # the Dashboard formulas stay correct across months with different lengths.
    day_wise_total_row = 7 + len(day_wise) if not day_wise.empty else 48
    # day_wise has one column per day PLUS a 'Total' column at the end
    day_count = (len(day_wise.columns) - 1) if not day_wise.empty else 30
    agent_n = len(agent)
    _emit_dashboard(wb, start, end,
                    day_wise_total_row=day_wise_total_row,
                    day_count=day_count,
                    agent_n=agent_n)

    # === Sheet 2+: Day Wise Sales =====================================
    # Layout mirrors the company DSR:
    #   row 1 = gold banner title
    #   row 3 = legend ("Indicates Highest Sales" with green pip)
    #   row 5 = date row (cream)
    #   row 6 = day-of-week (cream)
    #   row 7+ = data rows (accounting format)
    #   below data = "Daily Total" row + LineChart
    ws = wb.create_sheet("Day Wise Sales")
    ws["A1"] = f"POS Wise Daily Sales (In Lac) — {start.isoformat()} to {end.isoformat()}"
    _style_banner_title(ws["A1"])
    if not day_wise.empty:
        n_cols = len(day_wise.columns) + 1  # +1 for the Particulars column
        ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=n_cols)

        # Legend row (row 3): green pip at col 2, descriptive text at col 3
        ws.cell(row=3, column=2, value="").fill = PatternFill("solid", fgColor=DSR_GREEN)
        ws.cell(row=3, column=2).border = DSR_BORDER
        legend_cell = ws.cell(row=3, column=3, value="Indicates Highest Sales of the Day")
        legend_cell.font = Font(italic=True, color=DSR_BLACK)

        # Date header (row 5)
        ws.cell(row=5, column=1, value="Particulars")
        for j, col in enumerate(day_wise.columns, start=2):
            ws.cell(row=5, column=j,
                    value=col.strftime("%d%b%y") if isinstance(col, date) else str(col))
        for cell in ws[5]:
            _style_date_header(cell)

        # Day-of-week (row 6)
        ws.cell(row=6, column=1, value="Day")
        for j, col in enumerate(day_wise.columns, start=2):
            if isinstance(col, date):
                ws.cell(row=6, column=j, value=col.strftime("%a"))
        for cell in ws[6]:
            _style_date_header(cell)

        # Data rows (row 7+)
        first_data_row = 7
        for i, (idx, row) in enumerate(day_wise.iterrows(), start=first_data_row):
            ws.cell(row=i, column=1, value=idx)
            _style_body(ws.cell(row=i, column=1), bold=True)
            for j, val in enumerate(row, start=2):
                cell = ws.cell(row=i, column=j,
                               value=float(val) if pd.notna(val) else 0.0)
                _style_body(cell, fmt=FMT_LAC_ACC)
        last_data_row = first_data_row + len(day_wise) - 1

        # Conditional formatting: highlight max value per column (per day) in green.
        # We deliberately skip the last column ("Total") — highlighting a single
        # max in the Total column is meaningless.
        green_fill = PatternFill("solid", fgColor=DSR_GREEN)
        total_col_idx = len(day_wise.columns) + 1  # the Particulars+dates layout
        for j in range(2, total_col_idx):  # day columns only
            col_letter = get_column_letter(j)
            rng = f"{col_letter}{first_data_row}:{col_letter}{last_data_row}"
            formula = (
                f"AND({col_letter}{first_data_row}="
                f"MAX(${col_letter}${first_data_row}:${col_letter}${last_data_row}),"
                f"{col_letter}{first_data_row}<>0)"
            )
            ws.conditional_formatting.add(rng, FormulaRule(formula=[formula], fill=green_fill))

        # Daily Total row immediately below the data
        total_row = last_data_row + 1
        total_label = ws.cell(row=total_row, column=1, value="Daily Total")
        _style_body(total_label, bold=True)
        total_label.fill = PatternFill("solid", fgColor=DSR_CREAM)
        for j in range(2, total_col_idx):
            col_letter = get_column_letter(j)
            cell = ws.cell(row=total_row, column=j,
                           value=f"=SUM({col_letter}{first_data_row}:{col_letter}{last_data_row})")
            _style_body(cell, fmt=FMT_LAC_ACC, bold=True)
            cell.fill = PatternFill("solid", fgColor=DSR_CREAM)
        # Grand total at the end
        grand_letter = get_column_letter(total_col_idx)
        grand = ws.cell(row=total_row, column=total_col_idx,
                        value=f"=SUM({grand_letter}{first_data_row}:{grand_letter}{last_data_row})")
        _style_body(grand, fmt=FMT_LAC_ACC, bold=True)
        grand.fill = PatternFill("solid", fgColor=DSR_CREAM)

        # Line chart of the Daily Total row.
        #
        # User-driven enhancements applied during the May-26 hand-polish pass
        # (re-applied here so future runs match):
        #
        #   * Title           : "Daywise Sales Trend For <Month> (Lac)"
        #   * Style           : single solid navy line, no fill area
        #   * Markers         : circle, size 5, navy fill #1F3864
        #   * Y-axis title    : hidden (unit "(Lac)" lives in chart title)
        #   * Data labels     : position "t" (top), color #1F3864, size 8,
        #                       format "0" so values show as integers
        #   * Chart staging   : a hidden mirror at row 90-91 holding the
        #                       date strings and ROUND(value, 0) so the
        #                       chart's underlying data is also integers
        #                       (matches the user's manual rebuild).
        from openpyxl.chart.label import DataLabelList
        from openpyxl.chart.marker import Marker
        from openpyxl.chart.shapes import GraphicalProperties
        from openpyxl.chart.text import RichText
        from openpyxl.drawing.text import (
            Paragraph, ParagraphProperties, CharacterProperties,
            RichTextProperties, RegularTextRun,
        )
        from openpyxl.drawing.colors import ColorChoice
        from openpyxl.drawing.line import LineProperties

        # ---- Hidden staging mirror at rows 90/91 -----------------------
        # B90:AE90  = date strings (linked to row 5)
        # B91:AE91  = ROUND(value, 0) of the corresponding Daily Total cell
        # These let the chart reference clean integer values without
        # disturbing the actual Daily Total formulas in row `total_row`.
        for k in range(2, total_col_idx):
            col_letter = get_column_letter(k)
            ws.cell(row=90, column=k,
                    value=f"='Day Wise Sales'!{col_letter}5")
            ws.cell(row=91, column=k,
                    value=f"=ROUND('Day Wise Sales'!{col_letter}{total_row}, 0)")

        chart = LineChart()
        chart.title = f"Daywise Sales Trend For {start.strftime('%B')} (Lac)"
        chart.style = 12
        chart.y_axis.title = None   # unit lives in the chart title
        chart.x_axis.title = "Date"
        chart.height = 8
        chart.width = 24
        # Force axis tick label visibility (openpyxl defaults can hide them).
        chart.x_axis.delete = False
        chart.y_axis.delete = False
        chart.x_axis.tickLblPos = "low"
        chart.y_axis.tickLblPos = "low"

        # Data labels are configured AFTER add_data() below (so the series
        # exists and can be named) — see _clean_chart_labels().

        # Chart pulls from the staging mirror (rows 90/91), not the live
        # Daily Total formula row — keeps the chart values strictly integer.
        data_ref = Reference(ws, min_col=2, max_col=total_col_idx - 1,
                             min_row=91, max_row=91)
        cats_ref = Reference(ws, min_col=2, max_col=total_col_idx - 1,
                             min_row=90, max_row=90)
        chart.add_data(data_ref, titles_from_data=False, from_rows=True)
        chart.set_categories(cats_ref)
        # Value-ONLY labels (kills 'Series1, 07May26, 80' clutter), 8pt, named.
        _clean_chart_labels(chart, "Daily Sales (Lac)", sz=800)
        chart.legend = None

        # Series styling — solid navy line + circle markers size 5.
        if chart.series:
            s = chart.series[0]
            s.graphicalProperties = GraphicalProperties(
                solidFill=DSR_NAVY,
                ln=LineProperties(solidFill=DSR_NAVY, w=24000),
            )
            s.marker = Marker(symbol="circle", size=5)
            s.marker.graphicalProperties = GraphicalProperties(solidFill=DSR_NAVY)
        ws.add_chart(chart, f"A{total_row + 3}")

        # === Country Wise Daily Sales (In Lac) block ===
        # Matches the company DSR's second pivot at the bottom of Day Wise Sales.
        # Same column layout (date headers + Total) but rows are countries.
        cw_start = total_row + 22  # leave room for the chart
        cw_title = ws.cell(row=cw_start, column=total_col_idx // 2,
                            value="Country Wise Daily Sales (In Lac)")
        _style_zone_header(cw_title)
        # Merge the title across the full width
        ws.merge_cells(start_row=cw_start, start_column=1,
                       end_row=cw_start, end_column=total_col_idx)
        cw_title.alignment = Alignment(horizontal="center", vertical="center")

        # Date row + DOW row + headers (rows cw_start+2, +3, +4)
        ws.cell(row=cw_start + 2, column=1, value="")
        for j, col in enumerate(day_wise.columns, start=2):
            ws.cell(row=cw_start + 2, column=j,
                    value=col.strftime("%d%b%y") if isinstance(col, date) else str(col))
        for cell in ws[cw_start + 2]:
            _style_date_header(cell)
        for j, col in enumerate(day_wise.columns, start=2):
            if isinstance(col, date):
                ws.cell(row=cw_start + 3, column=j, value=col.strftime("%a"))
        ws.cell(row=cw_start + 3, column=1, value="")
        for cell in ws[cw_start + 3]:
            _style_date_header(cell)
        ws.cell(row=cw_start + 4, column=1, value="Particulars")
        for j, col in enumerate(day_wise.columns, start=2):
            ws.cell(row=cw_start + 4, column=j, value="Sales")
        for cell in ws[cw_start + 4]:
            _style_date_header(cell)

        # Aggregate Day Wise data by country (split each "Category|Country"
        # particulars label and sum over the four channels). Web/Mobi App/Counter/Corp
        # all contribute. Sort by country importance.
        country_pivot: dict[str, dict] = {}
        for idx in day_wise.index:
            country = idx.split("|", 1)[1] if "|" in idx else "Unknown"
            row_vals = day_wise.loc[idx]
            if country not in country_pivot:
                country_pivot[country] = {c: 0.0 for c in day_wise.columns}
            for col in day_wise.columns:
                country_pivot[country][col] += float(row_vals[col]) if pd.notna(row_vals[col]) else 0.0

        # Display order (matches company DSR)
        country_order = ["Bangladesh", "China", "India", "Malaysia", "Oman",
                          "Qatar", "Singapore", "Thailand", "UAE",
                          "United Arab Emirates", "Maldives",
                          "United Kingdom", "Saudi Arabia", "KSA"]
        ordered = [c for c in country_order if c in country_pivot]
        ordered += [c for c in country_pivot if c not in country_order]

        cw_data_start = cw_start + 5
        for i, country in enumerate(ordered):
            ws.cell(row=cw_data_start + i, column=1, value=f"{country} Sales")
            _style_body(ws.cell(row=cw_data_start + i, column=1), bold=True)
            for j, col in enumerate(day_wise.columns, start=2):
                v = country_pivot[country][col]
                cell = ws.cell(row=cw_data_start + i, column=j, value=v)
                _style_body(cell, fmt=FMT_LAC_ACC)

        # Country-wise Total row
        cw_total_row = cw_data_start + len(ordered)
        ws.cell(row=cw_total_row, column=1, value="Total")
        _style_body(ws.cell(row=cw_total_row, column=1), bold=True)
        ws.cell(row=cw_total_row, column=1).fill = PatternFill("solid", fgColor=DSR_CREAM)
        for j in range(2, total_col_idx + 1):
            col_letter = get_column_letter(j)
            cell = ws.cell(row=cw_total_row, column=j,
                            value=f"=SUM({col_letter}{cw_data_start}:{col_letter}{cw_total_row - 1})")
            _style_body(cell, fmt=FMT_LAC_ACC, bold=True)
            cell.fill = PatternFill("solid", fgColor=DSR_CREAM)

    cur_label = f"{calendar.month_abbr[start.month]}-{str(start.year)[-2:]}"

    # === Sheet 2: City Wise Top 20 Agent =================================
    # Title uses "Area wise" (post-May-26 rename) since the per-city blocks
    # are really per-area breakdowns; column header on row 7 (col D) is
    # also "Area" to match.
    ws = wb.create_sheet("City Wise Top 20 Agent")
    ws["A2"] = f"Area wise top 20 agent sales for {cur_label}"
    _style_red_title(ws["A2"])
    # Map raw city codes to display names (matching company DSR)
    CITY_DISPLAY = {
        "DAC": "Dhaka", "CGP": "Chattogram", "ZYL": "Sylhet", "JSR": "Jessore",
        "KHL": "Khulna", "SPD": "Saidpur", "RJH": "Rajshahi", "BZL": "Barisal",
        "CXB": "Cox's Bazar",
    }
    # Order: Bangladesh cities first, then overseas
    BD_ORDER = ["DAC", "CGP", "CXB", "ZYL", "JSR", "KHL", "SPD", "RJH", "BZL"]
    city_codes = list(city_top20.keys())
    city_codes.sort(key=lambda c: (BD_ORDER.index(c) if c in BD_ORDER else 99, c))
    row_cursor = 4
    for city_code in city_codes:
        dframe = city_top20[city_code]
        display = CITY_DISPLAY.get(city_code, city_code)
        row_cursor = _emit_ranked_block(ws, dframe, row_cursor,
                                          cur_label=cur_label, has_pct=False,
                                          group_title=display, add_total_row=True,
                                          location_header="Area")
        row_cursor += 2  # blank rows between cities

    # === Sheet 3: Top OTA ================================================
    ws = wb.create_sheet("Top OTA")
    ws["A2"] = f"TOP OTA sales for the month of {cur_label}"
    _style_red_title(ws["A2"])
    if not top_ota.empty and "Position" in top_ota.columns:
        _emit_ranked_block(ws, top_ota, 4,
                            cur_label=cur_label, has_pct=True)

    # === Sheet 4: Top Corp ===============================================
    ws = wb.create_sheet("Top Corp")
    ws["A2"] = f"Top corporate sales for {cur_label}"
    _style_red_title(ws["A2"])
    if not top_corp.empty and "Position" in top_corp.columns:
        _emit_ranked_block(ws, top_corp, 4,
                            cur_label=cur_label, has_pct=False)

    # (Mobi App and Web are now part of Day Wise Sales — no separate sheet,
    # matching the company's standard DSR template.)

    # === Sheet 5: Zone Wise Sales ========================================
    # Layout matches company DSR:
    #   row 1: title banner (gold)
    #   row 3: section sub-headers (Segment Target / Segment / Per Day Avg)
    #   row 4: column headers (Dom/Int/Total etc.)
    #   row 5+: data rows
    #   right-side legend: Above 100% / Between 75-100% / 50-75% / Below 50%
    ws = wb.create_sheet("Zone Wise Sales")
    ws["A1"] = f"Zone Wise Sales Performance Report — {start.isoformat()} to {end.isoformat()}"
    _style_banner_title(ws["A1"])

    if not zone_wise.empty:
        cur_label = f"{calendar.month_abbr[start.month]}-{str(start.year)[-2:]}"
        # Determine the 3 prior-month labels dynamically (oldest → newest)
        # and use only the OLDEST TWO in the sheet (current goes at col M).
        # The user collapsed the old 3-prior layout to 2-prior on Apr-26 so
        # the dashboard subtotals live at column M (= col 13). We honour
        # that layout going forward — the most-recent prior is implicit in
        # the per-day average of the current month, and the company DSR's
        # original 3-prior view can be reconstructed manually if needed.
        prior_months = _last_three_months(start)         # [(y,m,label) x 3]
        hist_labels  = [p[2] for p in prior_months][:2]  # oldest two
        # Sub-section header row (row 3). Layout post-2-col-collapse:
        #   1   Zone
        #   2   Area
        #   3   City
        #   4-6 Segment Target {cur}   (Dom/Int/Total)
        #   7-9 Segment {cur}          (Dom/Int/Total)
        #   10  {hist_labels[0]} Sales
        #   11  {hist_labels[1]} Sales
        #   12  Target {cur}
        #   13  {cur} Sales            <-- column M, what the dashboard reads
        #   14  Target Achieved
        #   15-18 Per Day Average      (hist[0], hist[1], Target, Cur — 4 cols)
        #   19  Current Trend
        groups = [
            (1,  "Zone",                   1),
            (2,  "Area",                   1),
            (3,  "City",                   1),
            (4,  f"Segment Target {cur_label}", 3),  # Dom/Int/Total
            (7,  f"Segment {cur_label}",   3),
            (10, f"{hist_labels[0]} Sales", 1),
            (11, f"{hist_labels[1]} Sales", 1),
            (12, f"Target {cur_label}",    1),
            (13, f"{cur_label} Sales",     1),
            (14, "Target Achieved",        1),
            (15, "Per Day Average Sales (In Lac)", 4),  # hist0/hist1/Target/Cur
            (19, "Current Trend",          1),
        ]
        # Cols 15-18 (Per Day group) and 19 (Current Trend) carry a real
        # sub-label in row 4, so they keep their two-row split. All OTHER
        # single-column headers (Zone/Area/City/Apr/Mar/Target/May/Target
        # Achieved) have a BLANK row 4 -> merge them VERTICALLY across rows
        # 3-4 so the label fills the full header height (no gap).
        _has_subheader = {15, 16, 17, 18, 19}
        for col, label, span in groups:
            cell = ws.cell(row=3, column=col, value=label)
            _style_zone_header(cell)
            if span > 1:
                ws.merge_cells(start_row=3, start_column=col,
                                end_row=3, end_column=col + span - 1)
            elif col not in _has_subheader:
                _style_zone_header(ws.cell(row=4, column=col))  # style the lower half
                ws.merge_cells(start_row=3, start_column=col,
                                end_row=4, end_column=col)

        # Detail header row (row 4)
        details = [
            "", "", "",
            "Dom", "Int", "Total",
            "Dom", "Int", "Total",
            "", "", "", "", "",                          # 10..14 have group headers already
            f"Sold {hist_labels[0]}", f"Sold {hist_labels[1]}",
            f"Target {cur_label}",    f"Sold {cur_label}",
            "Trend",
        ]
        for j, h in enumerate(details, start=1):
            if h:
                _style_zone_header(ws.cell(row=4, column=j, value=h))

        # Data rows (row 5+) — emit in the order build_zone_wise returns,
        # with subtotal rows styled distinctly.
        trend_fill = {
            "Above 100%":         PatternFill("solid", fgColor="00B050"),
            "Between 75% - 100%": PatternFill("solid", fgColor="92D050"),
            "Between 50% - 75%":  PatternFill("solid", fgColor=DSR_GOLD),
            "Below 50%":          PatternFill("solid", fgColor="FF0000"),
        }
        subtotal_fill = PatternFill("solid", fgColor=DSR_CREAM)
        for i, (_, drow) in enumerate(zone_wise.iterrows(), start=5):
            kind = drow.get("kind", "data")
            is_bold = kind in ("subtotal", "placeholder")

            # Column layout (after the May-26 collapse, see header section):
            #   1-3  Zone / Area / City
            #   4-6  Segment Target Dom/Int/Total
            #   7-9  Segment current Dom/Int/Total
            #   10   {hist_labels[0]} Sales
            #   11   {hist_labels[1]} Sales
            #   12   Target {cur}
            #   13   {cur} Sales            <-- column M (what dashboard reads)
            #   14   Target Achieved        <-- percentage
            #   15   Sold {hist_labels[0]}  per-day-avg in lacs
            #   16   Sold {hist_labels[1]}  per-day-avg in lacs
            #   17   Target {cur}           per-day-avg target (placeholder)
            #   18   Sold {cur}             per-day-avg in lacs
            #   19   Trend
            values = [
                drow.get("zone"),
                drow.get("area_description"),
                drow.get("city_code"),
                drow.get("seg_target_dom"),
                drow.get("seg_target_int"),
                drow.get("seg_target_total"),
                drow.get("seg_dom"),
                drow.get("seg_int"),
                drow.get("seg_total"),
                drow.get(hist_labels[0]),                # col 10  hist[0] sales
                drow.get(hist_labels[1]),                # col 11  hist[1] sales
                drow.get("target_current"),              # col 12  target
                drow.get("current_sales"),               # col 13  current sales (M)
                drow.get("target_achieved"),             # col 14  % achieved
                drow.get(f"per_day_{hist_labels[0]}_lac"), # col 15
                drow.get(f"per_day_{hist_labels[1]}_lac"), # col 16
                0,                                         # col 17 target/day placeholder
                drow.get("per_day_cur_lac"),               # col 18 sold-per-day current
                drow.get("trend"),                         # col 19
            ]
            for j, v in enumerate(values, start=1):
                cell = ws.cell(row=i, column=j, value=_safe(v))
                if isinstance(v, (int, float)) and pd.notna(v):
                    if 15 <= j <= 18:
                        _style_body(cell, fmt=FMT_LAC_ACC, bold=is_bold)
                    elif j == 14:
                        _style_body(cell, fmt=FMT_PERCENT, bold=is_bold)
                    else:
                        _style_body(cell, fmt=FMT_INT_ACC, bold=is_bold)
                else:
                    _style_body(cell, bold=is_bold)
                if is_bold:
                    cell.fill = subtotal_fill
            # Trend colour only on data rows — column shifted from 21 to 19
            if kind == "data":
                trend_val = drow.get("trend")
                if trend_val in trend_fill:
                    ws.cell(row=i, column=19).fill = trend_fill[trend_val]

        # Legend at the right side (col 23 onwards)
        legend_start = 5
        ws.cell(row=legend_start, column=23, value="Legend (Current Trend)").font = (
            Font(bold=True, color=DSR_BLACK)
        )
        for k, (label, fill) in enumerate(trend_fill.items(), start=1):
            ws.cell(row=legend_start + k, column=23, value=label).fill = fill
            _style_body(ws.cell(row=legend_start + k, column=23))

    # === Sheet 7: Agent (all) + the OTA / non-OTA cuts ===================
    # The analyst works OTAs and conventional agencies as separate books, so the same listing
    # is emitted three times. "Agent" is unchanged — the full list including the four synthetic
    # channel rollup rows (Z-Counter/Z-Corporate/Z-Web/Z-Mobi App) that make it reconcile to
    # Day Wise Sales. The two cuts carry AGENCY rows only: the rollups are channels, not
    # agencies, so putting them on both cuts would double-count them and putting them on one
    # would make that cut look arbitrarily larger. Cut totals therefore sum to the Agent sheet
    # MINUS the rollup rows, which is stated in each cut's title.
    _agent_all = agent
    if not agent.empty and "OTA Status" in agent.columns:
        _zid = agent.iloc[:, 1].astype(str)          # col B = Zenith ID; rollups are 'Z-...'
        _rollup = _zid.str.startswith("Z-")
        _is_ota = agent["OTA Status"].astype(str).str.strip().str.upper() == "OTA"
        _cuts = [
            ("Agent", _agent_all, ""),
            ("Agent - OTA", agent[_is_ota & ~_rollup], " (OTA only)"),
            ("Agent - Non-OTA", agent[~_is_ota & ~_rollup], " (excluding OTAs)"),
        ]
    else:
        _cuts = [("Agent", _agent_all, "")]
    for _title, _df, _sub in _cuts:
        _write_agent_sheet(wb, _title, _df, start, end, cur_label, _sub)

    # === MoM Movers ======================================================
    if mom:
        _write_mom_sheet(wb, mom, start, end)

    # === Sheet 7: Sheet1 (zone manager directory) ========================
    # Auto-populated from reference/zone_managers.xlsx. Operations edits that
    # file when a manager changes; the DSR picks it up automatically next run.
    # If the reference file is missing, fall back to the empty placeholder.
    ws = wb.create_sheet("Sheet1")
    headers = ["City", "Zone", "Area", "Zone Manager", "ID", "Contact No", "Date Of Joining"]
    for j, h in enumerate(headers, start=1):
        _style_sheet1_header(ws.cell(row=1, column=j, value=h))

    if ZONE_MGR_FILE.exists():
        mgrs = pd.read_excel(ZONE_MGR_FILE)
        # Match company layout: only show the City label on the first row of
        # each city group (rest of group leaves City blank — easier to read).
        prev_city = None
        for i, (_, mgr) in enumerate(mgrs.iterrows(), start=2):
            city = mgr["City"]
            display_city = city if city != prev_city else None
            prev_city = city

            # Normalise the date so it always displays as DD/MM/YYYY string
            doj = _safe(mgr["Date Of Joining"])
            if isinstance(doj, (datetime, date)):
                doj_str = doj.strftime("%d/%m/%Y")
            else:
                doj_str = str(doj) if doj is not None else ""

            # Contact number must keep its leading zero — store as string and
            # set the cell's number_format to text ('@') so Excel doesn't
            # silently coerce it back to an integer.
            contact = str(mgr["Contact No"]) if mgr["Contact No"] is not None else ""
            if contact and not contact.startswith("0") and len(contact) == 10:
                contact = "0" + contact  # repair lost leading zero from prior read

            row_vals = [display_city, mgr["Zone"], mgr["Area"], mgr["Zone Manager"],
                        mgr["ID"], contact, doj_str]
            for j, v in enumerate(row_vals, start=1):
                cell = ws.cell(row=i, column=j, value=v)
                _style_body(cell, bold=(j == 1 and display_city is not None))
                # City column gets the same orange/blue styling as the header
                # on rows that actually display the city code
                if j == 1 and display_city is not None:
                    _style_sheet1_header(cell)
                # Phone and date should display as raw text
                if j in (6, 7):
                    cell.number_format = "@"
    else:
        ws.cell(row=2, column=1,
                value=f"(Create {ZONE_MGR_FILE} with City/Zone/Area/Manager/ID/Contact/DOJ "
                      "columns and re-run.)")

    # === Per-sheet polish: zoom, freeze, gridlines, tab colour, widths ===
    # Specific column widths are chosen to match the user's curated April DSR.

    # Day Wise Sales
    if "Day Wise Sales" in wb.sheetnames:
        ws = wb["Day Wise Sales"]
        _polish_sheet(ws, zoom=73, freeze="B7", tab_color=DSR_BLUE_MED)
        ws.column_dimensions["A"].width  = 29.7
        ws.column_dimensions["B"].width  = 11.4
        ws.column_dimensions["AF"].width = 14.4
        ws.row_dimensions[1].height = 28
        ws.row_dimensions[5].height = 22

    # City Wise Top 20 Agent
    if "City Wise Top 20 Agent" in wb.sheetnames:
        ws = wb["City Wise Top 20 Agent"]
        _polish_sheet(ws, zoom=73, freeze="A7", tab_color=DSR_BLUE_MED)
        for col, w in (("A", 11.1), ("B", 14.8), ("C", 42.6), ("D", 10.2),
                        ("E", 12.0), ("H", 20.3), ("I", 2.6), ("L", 19.4),
                        ("M", 16.0), ("N", 16.0), ("O", 2.6),
                        ("P", 16.7), ("Q", 14.5)):
            ws.column_dimensions[col].width = w
        ws.row_dimensions[2].height = 28

    # Top OTA / Top Corp
    for name in ("Top OTA", "Top Corp"):
        if name in wb.sheetnames:
            ws = wb[name]
            _polish_sheet(ws, zoom=73, freeze="A7", tab_color=DSR_BLUE_MED)
            for col, w in (("A", 11.1), ("B", 14.8), ("C", 46.3), ("D", 10.2),
                            ("E", 12.0), ("H", 20.3), ("I", 14.8), ("K", 2.6),
                            ("L", 19.4), ("M", 16.0), ("N", 16.0), ("O", 2.6),
                            ("P", 16.7), ("Q", 14.5)):
                ws.column_dimensions[col].width = w
            ws.row_dimensions[2].height = 28

    # Zone Wise Sales
    if "Zone Wise Sales" in wb.sheetnames:
        ws = wb["Zone Wise Sales"]
        _polish_sheet(ws, zoom=73, freeze="A5", tab_color=DSR_BLUE_MED)
        for col, w in (("A", 13.9), ("B", 44.4), ("C", 11.1), ("J", 17.6),
                        ("O", 13.0), ("P", 13.9), ("U", 17.6), ("V", 16.7)):
            ws.column_dimensions[col].width = w
        ws.row_dimensions[1].height = 28

    # Agent + its OTA / non-OTA cuts — identical treatment, so they read as one family
    if "MoM Movers" in wb.sheetnames:
        _ws = wb["MoM Movers"]
        _polish_sheet(_ws, zoom=80, tab_color=DSR_BLUE_MED)
        for _c, _w in (("A", 12), ("B", 44), ("C", 11), ("D", 22), ("E", 30),
                        ("F", 14), ("G", 15), ("H", 15), ("I", 15), ("J", 11), ("K", 13),
                        ("L", 16)):
            _ws.column_dimensions[_c].width = _w
        _ws.row_dimensions[1].height = 28

    for _agent_sheet in ("Agent", "Agent - OTA", "Agent - Non-OTA"):
        if _agent_sheet not in wb.sheetnames:
            continue
        ws = wb[_agent_sheet]
        _polish_sheet(ws, zoom=69, freeze="A4", tab_color=DSR_BLUE_MED)
        _size_agent_columns(ws)
        _n_hidden = _group_older_months(ws, start)      # must follow the sizing, see the helper
        if _n_hidden and _agent_sheet == "Agent":
            print(f"[dsr] Agent sheet: {AGENT_HISTORY_MONTHS} months of history, the oldest "
                  f"{_n_hidden} collapsed behind the plus sign above the visible "
                  f"{AGENT_VISIBLE_MONTHS}")
        ws.row_dimensions[1].height = 28

    # Sheet1 (zone manager directory) — reference data, keep its own look
    if "Sheet1" in wb.sheetnames:
        ws = wb["Sheet1"]
        _polish_sheet(ws, zoom=100, tab_color=DSR_ORANGE)
        for col, w in (("A", 8), ("B", 12), ("C", 60), ("D", 25),
                        ("E", 12), ("F", 16), ("G", 16)):
            ws.column_dimensions[col].width = w

    # === #1: merge each sheet's title banner across its full table width ===
    # The title text is already centred + navy-styled (18pt white bold on
    # #1F3864) but was left UN-merged, so the banner looked broken (text in one
    # cell, fill spanning the rest). Merge the title row to the widest populated
    # header column. Skip any sheet whose title row is already merged
    # (Day Wise A1 + Dashboard B2:F2 merge themselves).
    _title_rows = {
        "Zone Wise Sales": 1, "Agent": 1, "Agent - OTA": 1, "Agent - Non-OTA": 1,
        "City Wise Top 20 Agent": 2, "Top OTA": 2, "Top Corp": 2,
    }
    for _sname, _trow in _title_rows.items():
        if _sname not in wb.sheetnames:
            continue
        _ws = wb[_sname]
        _already = any(m.min_row <= _trow <= m.max_row and m.min_col == 1
                       for m in _ws.merged_cells.ranges)
        if _already:
            continue
        _maxc = 1
        for _r in range(1, 7):                  # header band
            for _c in range(1, 40):
                if _ws.cell(_r, _c).value not in (None, ""):
                    _maxc = max(_maxc, _c)
        # Empty sheet (e.g. a zone with no Corporate/OTA agents): only the
        # title exists. Floor the merge at 12 cols so the banner still reads
        # as a proper banner instead of a lone wrapped word in column A, and
        # drop a 'no records' note underneath.
        if _maxc == 1:
            _maxc = 12
            note = _ws.cell(row=_trow + 2, column=1,
                            value="No records for this period / zone.")
            note.font = Font(italic=True, color=DSR_NAVY)
        _ws.merge_cells(start_row=_trow, start_column=1,
                        end_row=_trow, end_column=_maxc)

    # === Reorder sheets to match the user's preferred layout ============
    desired_order = ["Dashboard", "Agent", "City Wise Top 20 Agent",
                      "Day Wise Sales", "Top OTA", "Top Corp",
                      "Zone Wise Sales", "Sheet1"]
    wb._sheets = sorted(wb._sheets,
                         key=lambda s: desired_order.index(s.title)
                                        if s.title in desired_order else 99)

    wb.save(out_path)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def generate(params=None, cfg=None) -> Path:
    """Build the DSR workbook and return its path.

    params: ``month`` = 'YYYY-MM' (a full calendar month)  OR  both ``start`` + ``end``
    ('YYYY-MM-DD'); optional ``zone`` (e.g. 'Zone-4'); optional ``output`` (xlsx path,
    else defaults under the configured output dir).
    (Phase 0: data paths come from the module-level _CFG; cfg arg accepted for parity.)
    """
    params = params or {}
    month = params.get("month"); start_s = params.get("start"); end_s = params.get("end"); zone = params.get("zone")
    if month:
        y, m = int(month.split("-")[0]), int(month.split("-")[1])
        start = date(y, m, 1)
        end = date(y, m, calendar.monthrange(y, m)[1])
    elif start_s and end_s:
        start = date.fromisoformat(start_s)
        end = date.fromisoformat(end_s)
    else:
        raise ValueError("DSR needs 'month' (YYYY-MM) or both 'start' and 'end' (YYYY-MM-DD).")

    out = Path(params["output"]) if params.get("output") else \
        _CFG.output_dir / f"DSR_{month or (start_s + '_to_' + end_s)}.xlsx"

    con = duckdb.connect(str(WAREHOUSE))
    create_sales_view(con, start, end, zone=zone)
    attach_customer_attrs(con)
    day_wise = build_day_wise_sales(con, start, end)
    city_top20 = build_city_top20(con, start, end)
    top_ota = build_top_ota(con, start, end)
    top_corp = build_top_corp(con, start, end)
    zone_wise = build_zone_wise(con, start, end, zone=zone)
    agent = build_agent_sheet(con, start, end, zone=zone)
    mom = build_mom_movers(con, agent, start, end)
    print(f"[dsr] MoM movers: {len(mom['up']):,} up >= +{MOM_THRESHOLD:.0%} · "
          f"{len(mom['down']):,} down <= -{MOM_THRESHOLD:.0%} · {len(mom['new']):,} new")
    try:
        write_excel(out, day_wise, city_top20, top_ota, top_corp, zone_wise, agent, start, end,
                    mom=mom)
    except PermissionError:                     # file open in Excel -> sibling _v2 (same as other builders)
        out = out.with_name(out.stem + "_v2.xlsx")
        write_excel(out, day_wise, city_top20, top_ota, top_corp, zone_wise, agent, start, end,
                    mom=mom)
    return out
