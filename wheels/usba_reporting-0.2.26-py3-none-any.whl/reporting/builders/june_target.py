"""
_build_june2026_target_capacity.py
==================================

A CAPACITY-AWARE JULY 2026 target (rolled from June 2026-07-07): July capacity x 90% LF
x June per-seat route fares — the verified ~741 cr basis.

WHY THIS EXISTS
---------------
The previous target (554.7 cr) was built bottom-up (agent history x growth tiers)
and was never:
  * de-seasonalised for June's genuine demand slump, or
  * checked against the moving Eid/Hajj holidays, or
  * reconciled to total seat capacity.

This report fixes all three and tells the story so a non-technical reader gets it.

METHODOLOGY (researched - airline revenue management + moving-holiday seasonal adj)
----------------------------------------------------------------------------------
We blend three signals into ONE commit target, then test it against capacity.

  Signal A  Trailing x Seasonal (multiplicative decomposition, the RM standard):
              trailing 5-mo average (Dec-Apr)  x  June seasonal index
              June index = June-2025 / 12-month average  (June runs ~0.91 of avg)

  Signal B  Eid/Hajj-adjusted YoY anchor (anchor to the HOLIDAY, not the calendar):
              June-2025 actual  x  (1 + network growth)  x  Hajj-overlap factor
              -> June 2025 had Eid mid-month + Hajj May15-Jun15 (15 in-month days);
                 June 2026 has Eid at the very start + Hajj ends Jun 1 (~1 in-month
                 day), so international Hajj demand is LOWER -> small downward factor.

  Commit target = weighted blend of A and B.

Then the CAPACITY lens (the part that was missing):
  * convert the revenue target to seat-legs via realised per-sector YIELD,
  * express as a LOAD FACTOR (capacity fulfilment %),
  * set a STRETCH target at the proven peak load factor,
  * project a roadmap toward OPTIMAL load factor (~88% - NOT 100%; research shows
    100% is never the goal: best-in-class Ryanair ~96%, optimal LF balances yield).

OUTPUT
------
  logs/July2026_Target_Capacity.xlsx
    1. Target Summary        the number, how full it makes the planes, the story
    2. Methodology           every input + the blend, in plain words, with sources
    3. Zone-wise             per zone: target, Dom/Int split, share of capacity fill
    4. Route Utilisation     per route: capacity, target fill, gap (agent/route view)
    5. Roadmap & Projection  commit -> stretch -> optimal, and years-to-optimal

Run:
    .venv/Scripts/python.exe scripts/_build_june2026_target_capacity.py

Stack: duckdb + pandas + openpyxl (pinned).
"""

from __future__ import annotations

import calendar
import datetime as _dt
import os
import re
import sys
from pathlib import Path

import duckdb
import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from ..config import load_config
from ..ota import resolve_ota_ids
from ..common import build_rate_sql as _rate_sql

_CFG = load_config()                       # frozen-aware data root (ANALYSIS_HOME -> settings -> dev)
WAREHOUSE = _CFG.warehouse
SALES_GLOB = _CFG.sales_glob
ROOT = _CFG.data_root
LOGS = _CFG.logs
FLIGHT_LOADS = (_CFG.data_root / "curated" / "flight_loads" / "flight_loads.parquet").as_posix()
TARGET_WB = LOGS / "Agent_Targets_2026-06.xlsx"
OUTPUT = None  # set after the month constants are known (see below)


def build_rate_sql() -> str:               # keep existing no-arg call sites working
    return _rate_sql(_CFG)
CR = 1e7
DOM = "('DAC','CGP','CXB','ZYL','JSR','RJH','BZL','SPD')"
# Latest Zenith forward snapshot (current target-month load) — AUTO-PICKED: the newest
# zenith_flight_loads_*.xlsx in Documents/Downloads (timestamp in the filename),
# so a fresh pull is used automatically. None -> the live section is skipped.
def _newest_zenith_pull() -> "Path | None":
    candidates = []
    for folder in (Path.home() / "Documents", Path.home() / "Downloads"):
        try:
            candidates += list(folder.glob("zenith_flight_loads_*.xlsx"))
        except OSError:
            pass
    return max(candidates, key=lambda p: p.name) if candidates else None


CURRENT_LOADS = _newest_zenith_pull()
# flights on/before the pull's capture date are near-final; after = still building
SNAPSHOT_CUTOFF = (f"{CURRENT_LOADS.name[20:24]}-{CURRENT_LOADS.name[24:26]}-{CURRENT_LOADS.name[26:28]}"
                   if CURRENT_LOADS else "2026-06-07")
# ============================ THE TARGET MONTH ==============================================
# ROLLING THE REPORT TO A NEW MONTH IS ONE LINE: change TARGET_YM (or pass params["month"] /
# set TARGET_MONTH_ENV=YYYY-MM). Everything below — the labels, the calendar length, the
# trailing baseline, the same-month-last-year anchor, the 12-month average and the fare window
# — is DERIVED from it.
#
# It used to be six hardcoded literals scattered through the file ("2026-02":"2026-06",
# mser.get("2025-07"), YIELD_WIN = June, ...) that all had to be edited together. They drifted:
# by the July roll the variables were still called `june25` / `june_index` / `j25` while
# holding JULY values, and the CUT_LBL text had already gone stale once ("these used to be
# hardcoded 'Jun 7'"). A month roll must not be an exercise in finding every literal.
#
# The Zenith load pull is a ROLLING forward window (this month + the next), so parse_current()
# scopes to the TARGET month or capacity double-counts — the Jul-1 pull carried 2,380 July legs
# on top of June's 2,192, doubling seats and diluting the load factor.
#: The DEFAULT month rolls with the calendar. It used to be the literal "2026-08", which meant
#: every unattended publish shipped August's target for as long as nobody edited this line --
#: the same frozen-literal failure this file has already had three times (the six scattered
#: month literals above, the stale counter-history labels in the DSR, and a growth directive
#: that rode forward into a month it was never agreed for). An explicit TARGET_MONTH_ENV (which
#: is what --month sets) still wins, so pinning an old month is possible but must be asked for.
TARGET_YM = os.environ.get("TARGET_MONTH_ENV") or _dt.date.today().strftime("%Y-%m")
TARGET_YEAR, TARGET_MONTH = int(TARGET_YM[:4]), int(TARGET_YM[5:7])


def _shift_ym(year: int, month: int, delta: int) -> tuple[int, int]:
    """Month arithmetic that survives a year boundary: (2026, 1, -1) -> (2025, 12)."""
    i = year * 12 + (month - 1) + delta
    return i // 12, i % 12 + 1


def _ym(delta: int) -> str:
    """'YYYY-MM' `delta` months from the target month. _ym(0) is the target itself."""
    y, m = _shift_ym(TARGET_YEAR, TARGET_MONTH, delta)
    return f"{y:04d}-{m:02d}"


def _month_span(delta: int) -> tuple[str, str]:
    """(first day, last day) of the month `delta` months from the target."""
    y, m = _shift_ym(TARGET_YEAR, TARGET_MONTH, delta)
    return f"{y:04d}-{m:02d}-01", f"{y:04d}-{m:02d}-{calendar.monthrange(y, m)[1]:02d}"


def _sales_days_elapsed(con) -> int | None:
    """Day-of-month of the LAST sale we actually hold for the target month, or None.

    This is the honest "how far into the month are we" for a SALES comparison. It must come
    from the sales warehouse, because the only other date in this module, `_CUT_DAY`, is parsed
    out of the newest Zenith CAPACITY pull's filename and belongs to a different feed on a
    different schedule.
    """
    lo = f"{TARGET_YEAR:04d}-{TARGET_MONTH:02d}-01"
    hi = f"{TARGET_YEAR:04d}-{TARGET_MONTH:02d}-{calendar.monthrange(TARGET_YEAR, TARGET_MONTH)[1]:02d}"
    try:
        got = con.execute(f"""SELECT MAX("Date"::DATE)
            FROM read_parquet('{SALES_GLOB}', hive_partitioning=1, union_by_name=1)
            WHERE "Date"::DATE BETWEEN DATE '{lo}' AND DATE '{hi}'""").fetchone()
    except Exception:
        return None
    return got[0].day if got and got[0] else None


def _same_days_windows(con=None) -> tuple[tuple[str, str], tuple[str, str], int]:
    """(this month 1..N), (last month 1..N), N  where N is the SALES days elapsed this month.

    THE WHOLE DIAGNOSTIC RESTS ON THIS BEING LIKE FOR LIKE. Comparing a part-month against a
    whole one is the single easiest way to invent a collapse that never happened: on the 22nd of
    a 31-day month a flat business reads as 29% down. So last month is cut at the SAME day
    number, not taken in full.

    N COMES FROM THE SALES DATA, NOT FROM `_CUT_DAY`. `_CUT_DAY` is the day-of-month in the
    newest Zenith flight-loads filename, which is a CAPACITY snapshot on its own schedule, and
    using it here compared the wrong window in both directions:
      - Capacity pull STALE vs sales: real sold days are thrown away.
      - Capacity pull FRESH vs sales: the current window asks for days that have no sales rows
        yet, so a full-length prior month is set against a short current one and the bridge
        manufactures a decline, with every quiet agency flagged STOPPED.
    Measured on 2026-09-08 with the target month set to August: the newest pull was dated
    6 September, so `_CUT_DAY` was 6 and the bridge compared 1-6 August against 1-6 July for a
    month that had closed with a full 31 days of sales. Nineteen percent of the month, reported
    as the month's story.

    `con` is optional so the pure date arithmetic below stays unit-testable; without one it
    falls back to `_CUT_DAY`, which is only correct when the two feeds happen to agree.

    The day number is clamped to the length of the prior month, which matters exactly once a
    year and silently: without it, a 31 January snapshot asks for 31 February and DuckDB returns
    nothing at all, so the bridge would show the entire month as a gain out of nowhere.
    """
    cy, cm = TARGET_YEAR, TARGET_MONTH
    elapsed = _sales_days_elapsed(con) if con is not None else None
    n = min(elapsed if elapsed else _CUT_DAY, calendar.monthrange(cy, cm)[1])
    py, pm = _shift_ym(cy, cm, -1)
    pn = min(n, calendar.monthrange(py, pm)[1])
    return ((f"{cy:04d}-{cm:02d}-01", f"{cy:04d}-{cm:02d}-{n:02d}"),
            (f"{py:04d}-{pm:02d}-01", f"{py:04d}-{pm:02d}-{pn:02d}"), n)


MONTH_LBL = calendar.month_name[TARGET_MONTH]          # "August"
MON3 = calendar.month_abbr[TARGET_MONTH]               # "Aug"
CAL_DAYS = calendar.monthrange(TARGET_YEAR, TARGET_MONTH)[1]   # calendar days in the month
PRIOR_LBL = calendar.month_name[_shift_ym(TARGET_YEAR, TARGET_MONTH, -1)[1]]   # fare month
# named for the month it is actually for, so two months' workbooks never overwrite each other
OUTPUT = _CFG.output_dir / f"{MONTH_LBL}{TARGET_YEAR}_Target_Capacity.xlsx"
# human labels derived from the cutoff so sheet text always matches the data
# (these used to be hardcoded "Jun 7" and silently went stale on a fresh pull)
_CUT_DAY = int(SNAPSHOT_CUTOFF[8:10])
CUT_LBL = f"{MON3} {_CUT_DAY}"               # e.g. "Jul 2"  (snapshot day)
SELL_LBL = f"{MON3} {_CUT_DAY + 1}-{CAL_DAYS}"   # e.g. "Jul 3-31" (still-selling window)
DOM_SET = {"DAC", "CGP", "CXB", "ZYL", "JSR", "RJH", "BZL", "SPD"}

# ---- METHODOLOGY KNOBS (transparent + tunable) ------------------------------
# THE WHOLE TARGET IS ONE LINE:
#
#     target = SUM over every route ( route capacity x TARGET_LF x route fare x GROWTH_UPLIFT )
#
# capacity comes from curated/flight_loads for the TARGET month; route fare is that route's
# achieved net per booked seat over YIELD_WIN, the month BEFORE the target. Everything else on
# the sheet (the demand blend, the stretch ladder, the scenarios) is commentary on that line.
#
# Every knob below is settable WITHOUT EDITING THIS FILE, because editing a constant to answer
# "what if we asked for 5% instead of 10%" is how an experiment becomes the committed number by
# accident. Set them at the command line and they are recorded in the workbook and the artefact:
#
#     python scripts/report.py target -- --month 2026-09 --target-lf 0.88 --uplift 1.05
#
# They resolve at IMPORT, like the month, because the windows below are derived from them.
def _knob(env: str, default: float) -> float:
    """One knob, overridable by environment variable, validated here so a typo cannot become
    a silently wrong target. The CLI sets these before importing this module."""
    raw = os.environ.get(env)
    if raw is None or str(raw).strip() == "":
        return default
    try:
        v = float(raw)
    except (TypeError, ValueError):
        raise SystemExit(f"[target] {env}={raw!r} is not a number")
    if not 0 < v <= 3:
        raise SystemExit(f"[target] {env}={v} is out of range (expected 0 < v <= 3)")
    return v


# 5 complete months ending the month BEFORE the target (Mar-Jul for an August target)
TRAILING = (_month_span(-5)[0], _month_span(-1)[1])
YOY_GROWTH = 0.00      # network YoY growth — hold flat; the commit rests on capacity x LF x yield
# Hajj 2026 fell in May with return traffic running through June-July; neither Hajj nor Eid
# overlaps AUGUST 2026, so no haircut. RE-CHECK THIS ON EVERY ROLL — it is a moving holiday and
# it is the one input here that no amount of code derivation can work out for you.
HAJJ_FACTOR = _knob("TARGET_HAJJ_ENV", 1.00)
W_SEASONAL, W_YOY = 0.50, 0.50            # blend weights for signals A and B
PROVEN_STRETCH = None  # set from data (proven peak LF)
OPTIMAL_LF = 0.90      # research-backed optimal (NOT 100%; best-in-class ~96%); above proven peak

#: Seats we commit to selling. THE SINGLE BIGGEST LEVER on the number, and it used to be
#: hardcoded halfway down gather() where nobody reading the knobs block would find it.
TARGET_LF = _knob("TARGET_LF_ENV", 0.90)

# AUGUST 2026: +10% PUSH (analyst directive 2026-08-06). The unpushed basis — August capacity
# x 90% LF x July achieved route fares — came to 647 cr, and the ask is that landing on 647
# should read as ~90% achievement rather than 100%. 647 x 1.10 = 712 cr, so 647 lands at 90.9%.
#
# READ WHAT THIS KNOB ACTUALLY DOES BEFORE CHANGING IT. It multiplies the per-seat RATE, so the
# push is a YIELD ask: the same 90% of seats sold at a 10% higher average fare than July
# achieved. It does NOT raise the load factor — seats and LF stay fixed at 90%. Pushing the
# same 10% through load factor instead would imply 99% LF, which is above our proven peak
# (87.8%) and above best-in-class (~96%), i.e. not a target anyone could hit.
GROWTH_UPLIFT = _knob("TARGET_UPLIFT_ENV", 1.10)

#: The month GROWTH_UPLIFT's directive was actually issued for. A push is a DECISION about one
#: month, not a property of the method, and the default silently rode forward: the September
#: target was built carrying August's +10% ask because nothing asked whether it still applied.
#: Building any other month prints a warning naming this month; setting --uplift explicitly
#: adopts the value for the month being built and silences it.
UPLIFT_DIRECTIVE_MONTH = "2026-08"
UPLIFT_WAS_SET_EXPLICITLY = bool(os.environ.get("TARGET_UPLIFT_ENV"))

PROJ_SCENARIOS = [("Conservative", 0.015), ("Moderate", 0.025), ("Aggressive", 0.040)]


def target_basis() -> list[tuple[str, str, str]]:
    """(input, value, where it comes from) for every number that moves the target.

    Exists so the answer to "what is this target based on?" is printed with the target rather
    than reconstructed from the source afterwards.
    """
    stale = (not UPLIFT_WAS_SET_EXPLICITLY) and UPLIFT_DIRECTIVE_MONTH != TARGET_YM
    return [
        ("Target month", TARGET_YM, "--month, or TARGET_MONTH_ENV"),
        ("Formula", "sum over routes: capacity x LF x fare x uplift", "gather()"),
        ("Route capacity", f"the {TARGET_YM} schedule",
         "curated/flight_loads/flight_loads.parquet - refresh it with a post-month Zenith pull"),
        ("Load factor (LF)", f"{TARGET_LF:.0%}",
         "knob --target-lf" + ("" if os.environ.get("TARGET_LF_ENV") else " (default)")),
        ("Route fare", f"achieved net per booked seat, {_month_span(-1)[0][:7]}",
         "the month BEFORE the target, per route, from gold"),
        ("Growth uplift", f"x{GROWTH_UPLIFT:.2f}",
         ("knob --uplift (set for this run)" if UPLIFT_WAS_SET_EXPLICITLY else
          f"DEFAULT, last confirmed for {UPLIFT_DIRECTIVE_MONTH}"
          + (" - CONFIRM FOR THIS MONTH" if stale else ""))),
        ("Hajj/Eid factor", f"x{HAJJ_FACTOR:.2f}",
         "knob --hajj; moving holiday, re-check every roll (demand floor only)"),
        ("Trailing window", f"{TRAILING[0]} to {TRAILING[1]}", "demand FLOOR only, not the commit"),
    ]


def recent_calibration(months: int = 4) -> "pd.DataFrame":
    """Recent months: seats offered, net achieved, and the target if one was published.

    The uplift is a judgement about how hard to push, and it cannot be made from the formula
    alone -- it needs what the last few months actually delivered against what they were asked
    for. This is the evidence, computed live, so it can never go stale the way a number typed
    into a menu would.

    Targets come from the published artefacts, so a month built before those existed shows a
    blank target rather than a guess. Achieved comes from gold and is always available.
    """
    import duckdb

    rows = []
    con = duckdb.connect()
    rate = build_rate_sql()          # the ONE shared commission builder, same as every report
    for back in range(months, 0, -1):
        lo, hi = _month_span(-back)
        ym = lo[:7]
        net = con.execute(f"""
            WITH s AS (SELECT "Transaction" txn,
                              CAST("Balance (base currency)" AS DOUBLE) bal,
                              CAST("Total without taxe (base currency)" AS DOUBLE) fare,
                              ({rate}) r, "Date"::DATE d
                       FROM read_parquet('{SALES_GLOB}', hive_partitioning=1, union_by_name=1)
                       WHERE "Date" IS NOT NULL
                         AND "Date"::DATE BETWEEN DATE '{lo}' AND DATE '{hi}')
            SELECT SUM(CASE
                WHEN txn IN ('Ticket payment','Reissuance Adjustment')
                     THEN COALESCE(bal,0)-COALESCE(fare,0)*r
                WHEN txn IN ('Refund','Ticket void','Cancel refund','Penalty') THEN bal
                ELSE 0 END)/{CR}, MAX(d) FROM s""").fetchone()
        seats = con.execute(f"""
            SELECT SUM(capacity) FROM read_parquet('{FLIGHT_LOADS}')
            WHERE flight_date BETWEEN DATE '{lo}' AND DATE '{hi}'""").fetchone()[0]
        p = target_artefact_path(ym)
        tgt = None
        if p.exists():
            try:
                t = pd.read_parquet(p)
                tgt = float(t["target_net"].sum()) / CR
            except Exception:                                   # noqa: BLE001
                tgt = None
        rows.append(dict(month=ym, seats=seats, target_cr=tgt,
                         achieved_cr=(net[0] or 0.0), last_day=net[1]))
    return pd.DataFrame(rows)


def print_basis(show_calibration: bool = True) -> None:
    """The whole 'what is this based on' answer, on stdout. Printed before every build, and
    available on its own so the assumptions can be checked without paying for a build."""
    print("\n" + "=" * 78)
    print(f"  TARGET BASIS - {TARGET_YM}")
    print("=" * 78)
    for name, value, source in target_basis():
        print(f"  {name:<18} {str(value):<44} {source}")
    for w in warn_if_basis_is_stale():
        print("\n  [!] " + w.replace(". ", ".\n      "))
    if not show_calibration:
        print("=" * 78 + "\n")
        return
    try:
        cal = recent_calibration()
    except Exception as exc:                                    # noqa: BLE001
        print(f"\n  (calibration unavailable: {type(exc).__name__}: {exc})")
        print("=" * 78 + "\n")
        return
    print("\n  RECENT MONTHS - what was asked for, and what came in")
    print(f"  {'month':<9}{'seats':>10}{'target cr':>11}{'achieved':>10}{'ach %':>8}"
          f"{'ach/seat':>10}")
    for _, r in cal.iterrows():
        # pd.isna, NOT truthiness. A month with no published artefact comes back as NaN in a
        # float column, and NaN is TRUTHY, so `if t` printed "nan cr" and "nan%" as though the
        # target existed. Same trap as the commission match_op cell.
        seats = 0 if pd.isna(r["seats"]) else float(r["seats"])
        t = None if pd.isna(r["target_cr"]) else float(r["target_cr"])
        a = 0.0 if pd.isna(r["achieved_cr"]) else float(r["achieved_cr"])
        print(f"  {r['month']:<9}{seats:>10,.0f}"
              f"{(f'{t:,.0f}' if t else '-'):>11}"
              f"{a:>10,.1f}"
              f"{(f'{a / t * 100:.1f}%' if t else '-'):>8}"
              f"{(f'{a * CR / seats:,.0f}' if seats else '-'):>10}")
    print("  A partial month reads low: the last month here may still be filling.")
    print("=" * 78 + "\n")


def warn_if_basis_is_stale() -> list[str]:
    """Loud, printed warnings about inputs that were decided for a different month."""
    out = []
    if (not UPLIFT_WAS_SET_EXPLICITLY) and UPLIFT_DIRECTIVE_MONTH != TARGET_YM:
        slack = 1 / GROWTH_UPLIFT
        out.append(
            f"The x{GROWTH_UPLIFT:.2f} fare push was last confirmed for {UPLIFT_DIRECTIVE_MONTH} "
            f"and you are building {TARGET_YM}. This is a DECISION to re-take, not necessarily "
            f"an error: the multiplier is what makes hitting the plain capacity x LF x fare "
            f"number read as {slack:.0%} achieved rather than 100%, which is the intended "
            f"stretch. Confirm it with --uplift {GROWTH_UPLIFT:g}, or change it. Check it "
            f"against what the last two months actually achieved before deciding.")
    return out

# ---- palette ----------------------------------------------------------------
NAVY="1F3864"; BLUE_MED="2E5395"; BLUE_LIGHT="D9E1F2"; GREY_L="F2F2F2"; GREY_T="7F7F7F"
GREEN="00B050"; GREEN_F="C6EFCE"; GREEN_T="006100"; AMBER="FFC000"; AMBER_F="FFEB9C"
AMBER_T="9C6500"; RED="C00000"; RED_F="FFC7CE"; WHITE="FFFFFF"; BLACK="000000"; TEAL="2E8B9E"
THIN=Side(style="thin",color="BFBFBF"); BORDER=Border(left=THIN,right=THIN,top=THIN,bottom=THIN)
F_INT="#,##0"; F_CR='#,##0.0" cr"'; F_PCT="0.0%"; F_TK="#,##0"


# ======================================================================= #
def parse_current() -> dict | None:
    """Parse the latest Zenith forward snapshot into the current target-month load.

    The 'Seats Available' column reads like '5/410 99%' = available / capacity /
    load-factor. Booked = capacity - available. We split the month at the snapshot
    cutoff: flights on/before are near-final (realised), after are still building.
    """
    if not CURRENT_LOADS or not CURRENT_LOADS.exists():
        return None
    df = pd.read_excel(CURRENT_LOADS, sheet_name="Flight Loads")
    df.columns = [str(c).strip() for c in df.columns]
    sa = next(c for c in df.columns if "Seats Available" in c)
    o = next(c for c in df.columns if c == "Origin")
    dd = next(c for c in df.columns if c == "Destination")
    dcol = next(c for c in df.columns if "Flight Date" in c)

    def p(s):
        # AVAILABLE CAN BE NEGATIVE. An oversold leg reads "-3/142 102%", and a pattern of
        # `(\d+)` does not match a minus sign, so those rows returned (None, None) and were
        # then removed by the dropna below. That silently deleted the FULLEST flights of the
        # month, 13 legs and 2,688 seats out of August 2026, and biased the load factor down
        # because every dropped leg was at 100-103%. The workbook disagreed with itself as a
        # result: its Load Factor sheet read 339,048 seats where the store read 341,736.
        # scripts/_build_unsold_seats_analysis.py has always allowed the sign; this did not.
        m = re.match(r"\s*(-?\d+)\s*/\s*(\d+)\s+(\d+)%", str(s))
        return (int(m.group(1)), int(m.group(2))) if m else (None, None)

    df["avail"], df["cap"] = zip(*df[sa].map(p))
    df = df.dropna(subset=["cap"]).copy()
    df["booked"] = df["cap"] - df["avail"]
    df["sector"] = df.apply(
        lambda r: "Domestic" if str(r[o]).strip() in DOM_SET and str(r[dd]).strip() in DOM_SET
        else "International", axis=1)
    df["dt"] = pd.to_datetime(df[dcol], format="%d/%m/%Y", errors="coerce")
    # scope to the target month so a rolling snapshot (this month + next) doesn't double-count
    df = df[(df["dt"].dt.year == TARGET_YEAR) & (df["dt"].dt.month == TARGET_MONTH)].copy()
    df["flown"] = df["dt"] <= pd.Timestamp(SNAPSHOT_CUTOFF)

    def lf(g):
        c = g["cap"].sum(); return (c, g["booked"].sum(), g["booked"].sum() / c if c else 0)
    cap, bk, total_lf = lf(df)
    out = {"seats": cap, "booked": bk, "total_lf": total_lf,
           "lo": df["dt"].min(), "hi": df["dt"].max()}
    for sec in ["Domestic", "International"]:
        _, _, out[f"{sec.lower()}_lf"] = lf(df[df["sector"] == sec])
    _, _, out["flown_lf"] = lf(df[df["flown"]])
    _, _, out["building_lf"] = lf(df[~df["flown"]])
    out["flown_seats"] = df[df["flown"]]["cap"].sum()
    out["building_seats"] = df[~df["flown"]]["cap"].sum()
    # upcoming-only (not yet flown) seat LF — the true forward position
    up = df[~df["flown"]]
    out["upcoming_lf"] = up["booked"].sum() / up["cap"].sum() if up["cap"].sum() else 0
    out["upcoming_seats"] = up["cap"].sum()
    # per-route CURRENT bookings (whole month) — replaces the stale parquet routes
    rt = (df.groupby([df["Leg Route"] if "Leg Route" in df.columns else df.iloc[:, 7], "sector"])
            .agg(cap=("cap", "sum"), booked=("booked", "sum")).reset_index())
    rt.columns = ["leg_route", "sector", "cap", "booked"]
    rt["available"] = rt["cap"] - rt["booked"]
    rt["fill"] = rt["booked"] / rt["cap"]
    out["routes"] = rt
    # per-day load factor (the booking curve) + per-sector-period matrix
    daily = (df.groupby(df["dt"].dt.date)
               .agg(cap=("cap", "sum"), booked=("booked", "sum"),
                    dow=("Day", "first") if "Day" in df.columns else ("cap", "size"))
               .reset_index())
    daily.columns = ["date", "cap", "booked", "dow"]
    daily["lf"] = daily["booked"] / daily["cap"]
    daily["flown"] = pd.to_datetime(daily["date"]) <= pd.Timestamp(SNAPSHOT_CUTOFF)
    out["daily"] = daily
    sp = (df.groupby(["sector", "flown"]).agg(cap=("cap", "sum"), booked=("booked", "sum")))
    out["sector_period"] = sp  # index (sector, flown) -> cap, booked
    # raw per-flight-per-date frame for the by-flight x by-date load-factor matrix
    # (one row per leg per day; the sheet pivots dates into columns to the right)
    lr = "Leg Route" if "Leg Route" in df.columns else df.columns[7]
    out["flights"] = pd.DataFrame({
        "flight": df["Flight Number"].astype(str).str.strip() if "Flight Number" in df.columns else "",
        "route": df[lr].astype(str).str.strip(),
        "sector": df["sector"].values,
        "date": df["dt"].dt.date,
        "cap": df["cap"].astype(int),
        "booked": df["booked"].astype(int),
        "aircraft": df["Aircraft"].astype(str).str.strip() if "Aircraft" in df.columns else "",
        "std": df["Departure Time"].astype(str).str.strip() if "Departure Time" in df.columns else "",
    })
    return out


def gather() -> dict:
    con = duckdb.connect(str(WAREHOUSE), read_only=True); rate = build_rate_sql()

    def sale_expr(prefix=""):
        # PRIMARY SALE MEASURE = NET sale, ALL transactions (DSR net).
        # NET = (base fare - commission) + tax = balance - commission   [user's definition]
        # Ticket payment & Reissuance -> fare*(1-rate)+(bal-fare);  Refund/Void/Cancel/
        # Penalty -> balance (a NEGATIVE, so cancellations are netted out). Counting
        # refunds keeps revenue matched to actual flown seats (a refunded ticket's seat
        # is released, so it must not be credited). Same expression flows everywhere.
        b=f'{prefix}bal'; f=f'{prefix}fare'; r=f'{prefix}rate'; t=f'{prefix}txn'
        return (f"CASE WHEN {t} IN ('Ticket payment','Reissuance Adjustment') THEN {f}*(1-{r})+({b}-{f}) "
                f"WHEN {t} IN ('Refund','Ticket void','Cancel refund','Penalty') THEN {b} ELSE 0 END")

    def gross_expr(prefix=""):
        # GROSS sale = topline ticket revenue BEFORE commission = full balance, over the
        # SAME transaction set as net (gross - net = the commission added back on ticket-
        # payment / reissuance rows; refunds reverse the full balance just like net).
        b=f'{prefix}bal'; t=f'{prefix}txn'
        return (f"CASE WHEN {t} IN ('Ticket payment','Reissuance Adjustment',"
                f"'Refund','Ticket void','Cancel refund','Penalty') THEN {b} ELSE 0 END")

    base_cte = f"""
        SELECT "Date"::DATE d, CAST("Transaction" AS VARCHAR) txn,
               CAST("Balance (base currency)" AS DOUBLE) bal,
               CAST("Total without taxe (base currency)" AS DOUBLE) fare, ({rate}) rate,
               CAST("Departure airport" AS VARCHAR) dep, CAST("Arrival airport" AS VARCHAR) arr,
               CASE WHEN CAST("Departure airport" AS VARCHAR) IN {DOM}
                     AND CAST("Arrival airport" AS VARCHAR) IN {DOM} THEN 'Domestic'
                    ELSE 'International' END sector,
               CASE WHEN CAST("Customer ID" AS VARCHAR)='BO-1 Central Reservation' THEN '11246131'
                    ELSE regexp_replace(CAST("Customer ID" AS VARCHAR),'[.]0$','') END customer_id
        FROM read_parquet('{SALES_GLOB}', hive_partitioning=1, union_by_name=1) WHERE "Date" IS NOT NULL
    """

    # Monthly net sale (for trailing avg, June 2025, seasonal index)
    monthly = con.execute(f"""
        WITH s AS ({base_cte})
        SELECT date_trunc('month',d) m, SUM({sale_expr()}) net FROM s GROUP BY 1 ORDER BY 1
    """).df()
    monthly["cr"] = monthly["net"] / CR
    mser = monthly.set_index(monthly["m"].astype(str).str[:7])["cr"]

    # Baselines degrade HONESTLY when the data window is partial (Instant-mode
    # uploads may lack July-2025 / the full trailing months): the 90%-LF TARGET is
    # capacity-driven and unaffected; only the demand-floor explainer rows lose
    # their YoY ingredient. On the pipeline machine the full history is always
    # present, so these fallbacks never fire there.
    # All three windows are RELATIVE to the target month (see _ym): the 5 complete months
    # before it, the same month a year ago, and the 12 months ending just before it.
    trailing = mser.loc[_ym(-5):_ym(-1)].mean()
    if pd.isna(trailing):                                  # none of those months uploaded
        trailing = mser.mean() if len(mser) else 0.0
    # same month LAST YEAR (.get: no KeyError on partial data). Named for what it is — the
    # previous version called this `june25` while it held a July figure.
    ly_same_month = float(mser.get(_ym(-12), 0.0))
    avg12 = mser.loc[_ym(-12):_ym(-1)].mean()
    season_index = (ly_same_month / avg12) if (ly_same_month and avg12
                                               and not pd.isna(avg12)) else 1.0
    june25, june_index = ly_same_month, season_index       # legacy names, same values

    # Same-month-last-year Dom/Int split — the YoY demand-floor signal.
    # (fallback ~0.12 = last year's actual domestic share when that month is not uploaded)
    _ly_lo, _ly_hi = _month_span(-12)
    j25 = con.execute(f"""
        WITH s AS ({base_cte})
        SELECT sector, SUM({sale_expr()}) net FROM s
        WHERE d BETWEEN DATE '{_ly_lo}' AND DATE '{_ly_hi}' GROUP BY 1
    """).df().set_index("sector")["net"]
    dom_share = (j25.get("Domestic", 0) / j25.sum()) if len(j25) and float(j25.sum()) else 0.12

    # Per-sector realised yield — FARE WINDOW = THE MONTH BEFORE THE TARGET (analyst
    # instruction 2026-07-01: the target uses the previous month's average per-seat fare;
    # for an August target that is July). NET sale (all transactions) divided by the seats
    # actually booked in the SAME window, so refunds and their released seats cancel.
    #   NET   = balance - commission per booked seat (PRIMARY, drives the whole engine)
    #   GROSS = full balance per booked seat (kept ONLY for the commission bridge note)
    YIELD_WIN = _month_span(-1)
    # GROSS (Ticket Payment) = full balance of ticket-payment rows, before commission =
    # the topline ticket revenue. Shown beside NET on the summary & Road-to-90% sheets.
    tp_gross_expr = "CASE WHEN txn='Ticket payment' THEN bal ELSE 0 END"
    sec = con.execute(f"""
        WITH s AS ({base_cte})
        SELECT sector, SUM({sale_expr()}) net, SUM({tp_gross_expr}) gross FROM s
        WHERE d BETWEEN DATE '{YIELD_WIN[0]}' AND DATE '{YIELD_WIN[1]}' GROUP BY 1
    """).df().set_index("sector")
    sec_net = sec["net"]   # primary net sale by sector
    # seats booked in the SAME fare window (matched denominator for the yield)
    legs_y = con.execute(f"""
        SELECT sector, SUM(booked) bk FROM read_parquet('{FLIGHT_LOADS}')
        WHERE flight_date BETWEEN DATE '{YIELD_WIN[0]}' AND DATE '{YIELD_WIN[1]}' GROUP BY 1
    """).df().set_index("sector")
    # full historical fill (Mar5-May30) = the proven-PEAK load factor (best-ever)
    legs = con.execute(f"""
        SELECT sector, SUM(booked) bk, SUM(capacity) cap
        FROM read_parquet('{FLIGHT_LOADS}') WHERE UPPER(period)='HISTORICAL' GROUP BY 1
    """).df().set_index("sector")
    # net/gross TK per seat realised over YIELD_WIN (the month BEFORE the target, so July for
    # an August build), uplifted by GROWTH_UPLIFT so the target amount
    # carries the +5% growth while seats & load factor stay fixed. gr = gross/net is unaffected.
    yld = {s: sec.loc[s, "net"] / legs_y.loc[s, "bk"] * GROWTH_UPLIFT for s in ["Domestic", "International"]}       # net TK/seat (PRIMARY)
    yld_gross = {s: sec.loc[s, "gross"] / legs_y.loc[s, "bk"] * GROWTH_UPLIFT for s in ["Domestic", "International"]}  # gross TK/seat
    proven_lf = {s: legs.loc[s, "bk"] / legs.loc[s, "cap"] for s in ["Domestic", "International"]}
    # TRUE per-route yield over the fare window: route June net ÷ route June booked seats.
    # This is what the route-level commit uses (verified basis) — NOT the rescaled
    # route_yield dict further down, whose per-sector sums collapse back to the sector
    # blend by construction and would erase the route-mix effect (692 vs 717 cr).
    jy = con.execute(f"""
        WITH s AS ({base_cte}),
        sales AS (
            SELECT (s.dep||'-'||s.arr) route, SUM({sale_expr('s.')}) net
            FROM s WHERE s.d BETWEEN DATE '{YIELD_WIN[0]}' AND DATE '{YIELD_WIN[1]}' GROUP BY 1
        ),
        seats AS (
            SELECT leg_route route, SUM(booked) bk FROM read_parquet('{FLIGHT_LOADS}')
            WHERE flight_date BETWEEN DATE '{YIELD_WIN[0]}' AND DATE '{YIELD_WIN[1]}' GROUP BY 1
        )
        SELECT sales.route, sales.net / NULLIF(seats.bk, 0) ry
        FROM sales JOIN seats USING (route) WHERE seats.bk > 100
    """).df()
    tgt_route_yield = {r.route: r.ry * GROWTH_UPLIFT for r in jy.itertuples() if r.ry and r.ry > 0}

    # TARGET-MONTH CAPACITY = the FULL month, from the accumulated loads parquet — NOT the
    # live file. The Zenith "Flight Loads" export is a ROLLING forward window: pulled later
    # in the month it drops early days, so reading capacity from parse_current() silently
    # SHRANK the monthly target on every fresh pull (Jun-10 pull -> 533cr, Jun-14 -> 454cr,
    # purely from losing Jun 4-7). The parquet keeps one row per leg (latest numbers) across
    # all pulls, so the monthly target is COMPLETE and STABLE. (analyst-confirmed 2026-06-14.)
    # parse_current() is still used below for the LIVE "booked now" / load-factor-now snapshot.
    cur = parse_current()
    cap = con.execute(f"""
        SELECT sector, SUM(capacity) cap, SUM(booked) booked, SUM(capacity)-SUM(booked) available
        FROM read_parquet('{FLIGHT_LOADS}')
        WHERE year(flight_date) = {TARGET_YEAR} AND month(flight_date) = {TARGET_MONTH}
        GROUP BY 1
    """).df().set_index("sector")
    if cap.empty and cur is not None and cur.get("routes") is not None:   # fallback to live file
        cap = (cur["routes"].groupby("sector")
               .agg(cap=("cap", "sum"), booked=("booked", "sum"), available=("available", "sum")))
    # FULL-MONTH coverage adjustment: the pulls may not span every calendar day yet (the
    # Jul-2 snapshot covers Jul 1-30 — Jul 31 hasn't entered the rolling window). Scale
    # capacity to the full month so the target isn't quietly short by the missing days.
    # (verified basis 2026-07-01: 717 cr over 30 covered days x 31/30 ≈ 741 cr full July)
    days_cov = con.execute(f"""
        SELECT COUNT(DISTINCT flight_date::DATE) FROM read_parquet('{FLIGHT_LOADS}')
        WHERE year(flight_date) = {TARGET_YEAR} AND month(flight_date) = {TARGET_MONTH}
    """).fetchone()[0] or 0
    cov_adj = (CAL_DAYS / days_cov) if 0 < days_cov < CAL_DAYS else 1.0
    if cov_adj != 1.0:
        cap[["cap", "booked", "available"]] = cap[["cap", "booked", "available"]] * cov_adj
    # route table for the TARGET MONTH (used for the route-level commit + Route sheet)
    routes = con.execute(f"""
        SELECT leg_route, sector, SUM(capacity) cap, SUM(booked) booked, SUM(available) available,
               SUM(booked)*1.0/SUM(capacity) fill
        FROM read_parquet('{FLIGHT_LOADS}')
        WHERE year(flight_date) = {TARGET_YEAR} AND month(flight_date) = {TARGET_MONTH}
        GROUP BY leg_route, sector ORDER BY cap DESC
    """).df()
    routes[["cap", "booked", "available"]] = routes[["cap", "booked", "available"]] * cov_adj

    # Per-zone x sector baseline (Dec-Apr) for allocation + Dom/Int split.
    # Full channel bucketing so EVERY channel is counted (geographic Zone-N +
    # Z-Counter / Z-Web / Z-Mobi App / Z-Unmapped / Z-Corporate). Same precedence
    # as the DSR / daily_zone_sales; amounts are net ticket sales (sale_expr).
    # OTA membership comes from the SHARED resolver (reporting/ota.py) so this sheet, the DSR's
    # Agent OTA cuts and the DSR's Top OTA ranking all name the same agencies. Resolving it
    # locally is precisely what let two definitions drift apart: 42 agencies were on Top OTA and
    # inside the non-OTA cut at the same time, carrying 26.51 cr of July sales.
    ota_ids = resolve_ota_ids(ROOT, con)

    zone = con.execute(f"""
        WITH s AS ({base_cte})
        SELECT
          CASE
            WHEN c.customer_name ILIKE 'CORP %'    THEN 'Z-Corporate'
            WHEN c.primary_channel = 'OFFICE'      THEN 'Z-Counter'
            WHEN c.primary_channel = 'CALL_CENTER' THEN 'Z-Counter'
            WHEN c.primary_channel = 'WEB'         THEN 'Z-Web'
            WHEN c.primary_channel = 'MOBILE'      THEN 'Z-Mobi App'
            WHEN c.zone LIKE 'Zone-%'              THEN c.zone
            WHEN c.primary_channel = 'AGENCY'      THEN 'Z-Unmapped'
            ELSE 'Z-Unmapped'
          END AS zone,
          s.sector, SUM({sale_expr('s.')}) net,
          COUNT(*) FILTER (WHERE s.txn='Ticket payment') tickets
        FROM s LEFT JOIN dim_customer c ON s.customer_id=c.customer_id
        WHERE s.d BETWEEN DATE '{TRAILING[0]}' AND DATE '{TRAILING[1]}'
        GROUP BY 1,2
    """).df()

    bucket = """CASE
        WHEN c.customer_name ILIKE 'CORP %'    THEN 'Z-Corporate'
        WHEN c.primary_channel = 'OFFICE'      THEN 'Z-Counter'
        WHEN c.primary_channel = 'CALL_CENTER' THEN 'Z-Counter'
        WHEN c.primary_channel = 'WEB'         THEN 'Z-Web'
        WHEN c.primary_channel = 'MOBILE'      THEN 'Z-Mobi App'
        WHEN c.zone LIKE 'Zone-%'              THEN c.zone
        WHEN c.primary_channel = 'AGENCY'      THEN 'Z-Unmapped'
        ELSE 'Z-Unmapped' END"""
    # June month-to-date actual by zone (Jun 1 -> snapshot) — for the achievement sheet
    mtd = con.execute(f"""
        WITH s AS ({base_cte})
        SELECT {bucket} AS zone, s.sector, SUM({sale_expr('s.')}) net
        FROM s LEFT JOIN dim_customer c ON s.customer_id=c.customer_id
        WHERE s.d BETWEEN DATE '2026-06-01' AND DATE '{SNAPSHOT_CUTOFF}'
        GROUP BY 1,2
    """).df()
    # Monthly GROSS by zone over the last ~12 completed months + current — drives the
    # per-zone monthly trend block in the master sheet (analyst request 2026-06-14:
    # "need this in gross"). GROSS = topline ticket revenue before commission. cr units.
    zone_monthly = con.execute(f"""
        WITH s AS ({base_cte})
        SELECT {bucket} AS zone,
               strftime(date_trunc('month', s.d), '%Y-%m') ym,
               SUM({gross_expr('s.')})/{CR} gross_cr
        FROM s LEFT JOIN dim_customer c ON s.customer_id=c.customer_id
        WHERE s.d >= date_trunc('month', DATE '{SNAPSHOT_CUTOFF}') - INTERVAL 12 MONTH
          AND s.d <= DATE '{SNAPSHOT_CUTOFF}'
        GROUP BY 1,2
    """).df()
    # ---- WHY THE NUMBER MOVED: this month against last, SAME DAYS ELAPSED -----------------
    # The achievement table says whether we are short. It cannot say WHY, and "why" is the only
    # part anybody can act on. These three frames answer it at the three grains a sales meeting
    # actually works in: which zone, which route, which agency.
    #
    # Both windows are cut at the same day number (see _same_days_windows), so nothing here is
    # an artefact of the month being incomplete. Tickets are carried beside net because the two
    # together separate the only two ways revenue can fall: we sold FEWER seats, or we sold the
    # same seats CHEAPER. Those have opposite remedies and the net figure alone hides which.
    # `con` is passed so N comes from the SALES data, not from the capacity pull's filename.
    (_cur_lo, _cur_hi), (_prv_lo, _prv_hi), _elapsed = _same_days_windows(con)
    print(f"[target] why-moved window: {_cur_lo}..{_cur_hi} vs {_prv_lo}..{_prv_hi} "
          f"({_elapsed} days of sales)")

    def _mom(grain_sql: str, extra_join: str = "", group_extra: str = "") -> "pd.DataFrame":
        """Both windows at one grain, tagged 'cur' / 'prv', in a single scan."""
        return con.execute(f"""
            WITH s AS ({base_cte}),
            e AS (
                SELECT s.*, {bucket} AS zone, {grain_sql} AS grain{group_extra}
                FROM s LEFT JOIN dim_customer c ON s.customer_id=c.customer_id
                {extra_join}
                WHERE s.d BETWEEN DATE '{_prv_lo}' AND DATE '{_prv_hi}'
                   OR s.d BETWEEN DATE '{_cur_lo}' AND DATE '{_cur_hi}'
            )
            SELECT CASE WHEN d >= DATE '{_cur_lo}' THEN 'cur' ELSE 'prv' END win,
                   grain, sector,
                   SUM({sale_expr()}) net,
                   COUNT(*) FILTER (WHERE txn='Ticket payment') tickets
            FROM e GROUP BY 1,2,3
        """).df()

    mom_zone = _mom("""CASE
            WHEN c.customer_name ILIKE 'CORP %'    THEN 'Z-Corporate'
            WHEN c.primary_channel = 'OFFICE'      THEN 'Z-Counter'
            WHEN c.primary_channel = 'CALL_CENTER' THEN 'Z-Counter'
            WHEN c.primary_channel = 'WEB'         THEN 'Z-Web'
            WHEN c.primary_channel = 'MOBILE'      THEN 'Z-Mobi App'
            WHEN c.zone LIKE 'Zone-%'              THEN c.zone
            ELSE 'Z-Unmapped' END""")
    mom_route = _mom("s.dep || '-' || s.arr")
    # Agencies are folded the same way the agent sheets fold them: the three B2C buckets
    # collapse, real agencies keep their own identity under their trading name.
    mom_agency = _mom("""CASE
            WHEN c.primary_channel IN ('WEB','MOBILE')         THEN 'App/Web'
            WHEN c.primary_channel IN ('OFFICE','CALL_CENTER') THEN 'Counter'
            WHEN c.customer_name ILIKE 'CORP %'                THEN 'Corporate'
            ELSE COALESCE(c.customer_name, s.customer_id) END""")

    # Group key: B2C web/mobile -> 'App/Web', counters -> 'Counter', corporate ->
    # 'Corporate'; real agencies stay individual (their own customer_id).
    akey = """CASE
        WHEN c.primary_channel IN ('WEB','MOBILE')        THEN 'App/Web'
        WHEN c.primary_channel IN ('OFFICE','CALL_CENTER') THEN 'Counter'
        WHEN c.customer_name ILIKE 'CORP %'                THEN 'Corporate'
        ELSE s.customer_id END"""
    BUCKETS = "('App/Web','Counter','Corporate')"
    # Per-agent 5-mo Dom/Int baseline — for the per-agent target sheet
    agents = con.execute(f"""
        WITH s AS ({base_cte}),
        e AS (
            SELECT s.txn, s.bal, s.fare, s.rate, s.sector, s.d,
                   {akey} AS akey, c.customer_name cn, c.zone cz,
                   c.agent_type catype, c.sales_person csp, c.primary_channel cchan
            FROM s LEFT JOIN dim_customer c ON s.customer_id=c.customer_id
            WHERE s.d BETWEEN DATE '{TRAILING[0]}' AND DATE '{TRAILING[1]}'
        )
        SELECT akey AS customer_id,
               MAX(CASE WHEN akey IN {BUCKETS} THEN akey ELSE cn END) AS customer_name,
               MAX(CASE WHEN akey IN {BUCKETS} THEN akey ELSE cz END) AS "zone",
               MAX(CASE WHEN akey IN {BUCKETS} THEN 'B2C/Direct' ELSE catype END) AS agent_type,
               MAX(csp) AS sales_person, MAX(cchan) AS channel,
               SUM({sale_expr('e.')}) FILTER (WHERE e.sector='Domestic')     dom,
               SUM({sale_expr('e.')}) FILTER (WHERE e.sector='International') intl
        FROM e GROUP BY akey
    """).df()
    # REAL June actual sales — read straight from the parquet, Jun 1 -> whatever the
    # latest ingested day is (auto-extends as more June days land). No file dependency.
    JUNE_START = f"{TARGET_YEAR}-{TARGET_MONTH:02d}-01"   # target-month MTD anchor
    # Upper bound for the same window. Without it `s.d >= JUNE_START` is open-ended and the FIRST
    # day of next month's ingest silently folds into this month's ACHIEVED, Ach% and Ach% LF on
    # every sheet. The report reads correctly today only because the data happens to stop on the
    # month end — that is luck, not a guarantee.
    MONTH_END = (pd.Timestamp(JUNE_START) + pd.offsets.MonthEnd(0)).date().isoformat()
    mtd_actual = con.execute(f"""
        WITH s AS ({base_cte})
        SELECT {bucket} AS zone, s.sector, SUM({sale_expr('s.')}) net,
               COUNT(*) FILTER (WHERE s.txn='Ticket payment') tickets
        FROM s LEFT JOIN dim_customer c ON s.customer_id=c.customer_id
        WHERE s.d >= DATE '{JUNE_START}' AND s.d <= DATE '{MONTH_END}'
        GROUP BY 1,2
    """).df()
    # --- OTA-EXCLUDED twins of the three zone frames -------------------------------
    # The zone sheet mixes OTA volume in with conventional agencies, so a zone can look on
    # target purely because one OTA delivered. These re-run the SAME queries with the OTA
    # customer ids removed, which is why they must be queries and not a subtraction: tickets
    # and per-sector splits cannot be netted off a pre-aggregated zone row.
    # `ota_ids` is resolved further down for the agent sheet; it is needed here first, so the
    # resolution happens once at the top of gather() and is reused.
    _ota_sql = ("(" + ", ".join(f"'{c}'" for c in sorted(ota_ids)) + ")") if ota_ids else "('')"
    zone_ex_ota = con.execute(f"""
        WITH s AS ({base_cte})
        SELECT {bucket} AS zone, s.sector, SUM({sale_expr('s.')}) net,
               COUNT(*) FILTER (WHERE s.txn='Ticket payment') tickets
        FROM s LEFT JOIN dim_customer c ON s.customer_id=c.customer_id
        WHERE s.d BETWEEN DATE '{TRAILING[0]}' AND DATE '{TRAILING[1]}'
          AND CAST(s.customer_id AS VARCHAR) NOT IN {_ota_sql}
        GROUP BY 1,2
    """).df()
    mtd_actual_ex_ota = con.execute(f"""
        WITH s AS ({base_cte})
        SELECT {bucket} AS zone, s.sector, SUM({sale_expr('s.')}) net,
               COUNT(*) FILTER (WHERE s.txn='Ticket payment') tickets
        FROM s LEFT JOIN dim_customer c ON s.customer_id=c.customer_id
        WHERE s.d >= DATE '{JUNE_START}' AND s.d <= DATE '{MONTH_END}'
          AND CAST(s.customer_id AS VARCHAR) NOT IN {_ota_sql}
        GROUP BY 1,2
    """).df()
    zone_monthly_ex_ota = con.execute(f"""
        WITH s AS ({base_cte})
        SELECT {bucket} AS zone,
               strftime(date_trunc('month', s.d), '%Y-%m') ym,
               SUM({gross_expr('s.')})/{CR} gross_cr
        FROM s LEFT JOIN dim_customer c ON s.customer_id=c.customer_id
        WHERE s.d >= date_trunc('month', DATE '{SNAPSHOT_CUTOFF}') - INTERVAL 12 MONTH
          AND s.d <= DATE '{SNAPSHOT_CUTOFF}'
          AND CAST(s.customer_id AS VARCHAR) NOT IN {_ota_sql}
        GROUP BY 1,2
    """).df()

    jinfo = con.execute(f"""SELECT MAX("Date"::DATE), COUNT(DISTINCT "Date"::DATE)
        FROM read_parquet('{SALES_GLOB}', hive_partitioning=1, union_by_name=1)
        WHERE "Date"::DATE BETWEEN DATE '{JUNE_START}' AND DATE '{MONTH_END}'""").fetchone()
    june_hi, june_days = (str(jinfo[0]), int(jinfo[1])) if jinfo and jinfo[1] else (None, 0)
    # June ACTUAL sales by route (from parquet)
    june_route = con.execute(f"""
        WITH s AS ({base_cte})
        SELECT (s.dep||'-'||s.arr) AS route, SUM({sale_expr('s.')}) net,
               COUNT(*) FILTER (WHERE s.txn='Ticket payment') tickets
        FROM s WHERE s.d >= DATE '{JUNE_START}' AND s.d <= DATE '{MONTH_END}' GROUP BY 1
    """).df()
    # Per-route revenue-per-seat (net ticket-sale basis): scale route avg_fare to the sector net yield
    rf = con.execute(f"""
        SELECT leg_route, sector, SUM(capacity) cap,
               SUM(capacity*avg_fare)/NULLIF(SUM(capacity),0) avg_fare
        FROM read_parquet('{FLIGHT_LOADS}') WHERE UPPER(period)='FORWARD' GROUP BY 1,2
    """).df()
    # Per-agent-per-route 5-mo sales (net + tickets) — for the agent route breakdown
    agent_routes = con.execute(f"""
        WITH s AS ({base_cte}),
        e AS (
            SELECT s.txn, s.bal, s.fare, s.rate, s.sector, s.dep, s.arr,
                   {akey} AS akey, c.customer_name cn, c.zone cz
            FROM s LEFT JOIN dim_customer c ON s.customer_id=c.customer_id
            WHERE s.d BETWEEN DATE '{TRAILING[0]}' AND DATE '{TRAILING[1]}' AND s.txn='Ticket payment'
        )
        SELECT akey AS customer_id,
               MAX(CASE WHEN akey IN {BUCKETS} THEN akey ELSE cn END) AS "name",
               MAX(CASE WHEN akey IN {BUCKETS} THEN akey ELSE cz END) AS zn,
               (e.dep||'-'||e.arr) AS route, e.sector,
               SUM({sale_expr('e.')}) net,
               COUNT(*) FILTER (WHERE e.txn='Ticket payment') tickets
        FROM e GROUP BY akey, route, e.sector
    """).df()
    # Same agent x route breakdown for JUNE-TO-DATE (Jun 1 -> latest ingested day) —
    # powers the "Achieved so far" columns on the per-sales-person route-target sheets.
    agent_routes_mtd = con.execute(f"""
        WITH s AS ({base_cte}),
        e AS (
            SELECT s.txn, s.bal, s.fare, s.rate, s.dep, s.arr,
                   {akey} AS akey
            FROM s LEFT JOIN dim_customer c ON s.customer_id=c.customer_id
            WHERE s.d >= DATE '{JUNE_START}' AND s.d <= DATE '{MONTH_END}' AND s.txn='Ticket payment'
        )
        SELECT akey AS customer_id, (e.dep||'-'||e.arr) AS route,
               SUM({sale_expr('e.')}) net,
               COUNT(*) FILTER (WHERE e.txn='Ticket payment') tickets
        FROM e GROUP BY akey, route
    """).df()
    # (con stays open — the network-growth queries near the end still need it)
    # route yield dict (scale avg_fare so each sector still totals to its net yield)
    route_yield = {}
    if len(rf):
        sec_af = {s: (g['cap']*g['avg_fare']).sum()/g['cap'].sum() for s,g in rf.groupby('sector')}
        for _,x in rf.iterrows():
            base = sec_af.get(x['sector'],0)
            route_yield[x['leg_route']] = (x['avg_fare']*yld[x['sector']]/base) if base else yld[x['sector']]

    # Zone Area + Sales Person labels — from the CANONICAL zone parquets, NOT the old
    # reference/zone_managers.xlsx (which drifted from zone_master and still held the
    # superseded roster). dim_zone -> area_description, dim_sales_person -> sales_persons,
    # both keyed by zone_code and rebuilt by scripts/_parse_zone_master.py whenever the
    # zone master changes. Salesperson sub-zones (22M, 28D, ...) live in dim_sales_person;
    # area falls back to the base zone (22M -> 22) since dim_zone only has base/geo zones.
    import re as _re
    zlabels = {}
    try:
        _ref = ROOT / "reference"
        _dz = pd.read_parquet(_ref / "dim_zone.parquet")
        _sp = pd.read_parquet(_ref / "dim_sales_person.parquet")
        _area = dict(zip(_dz["zone_code"].astype(str), _dz["area_description"].astype(str)))
        _sper = dict(zip(_sp["zone_code"].astype(str), _sp["sales_persons"].astype(str)))
        _base = lambda z: _re.sub(r"([0-9]+)[A-Za-z]+$", r"\1", str(z))
        for z in set(_area) | set(_sper):
            a = _area.get(z) or _area.get(_base(z), "")
            s = _sper.get(z) or _sper.get(_base(z), "")
            s = "" if s in (None, "nan") else str(s).strip()
            # an agent zone with sales but no assigned salesperson reads "Unassigned"
            # (e.g. UK / Kuwait — no one currently owns them) instead of an empty cell
            if not s and _re.match(r"(?i)^zone-\d", str(z)):
                s = "Unassigned"
            zlabels[str(z)] = ("" if a in (None, "nan") else str(a), s)
    except Exception:
        pass

    # ---- the blend ----------------------------------------------------------
    sig_a = trailing * june_index                       # trailing x seasonal
    sig_b = june25 * (1 + YOY_GROWTH) * HAJJ_FACTOR     # Eid/Hajj-adjusted YoY
    commit = W_SEASONAL * sig_a + W_YOY * sig_b          # cr

    # split commit Dom/Int comes from the route-level sum below (July capacity mix)
    commit_dom = commit * dom_share
    commit_int = commit * (1 - dom_share)

    # capacity fulfilment of the commit target, by sector
    def lf(rev_cr, sector):
        legs_needed = (rev_cr * CR) / yld[sector]
        return legs_needed, legs_needed / cap.loc[sector, "cap"]
    dom_legs, dom_lf = lf(commit_dom, "Domestic")
    int_legs, int_lf = lf(commit_int, "International")
    total_cap = cap["cap"].sum()
    commit_lf = (dom_legs + int_legs) / total_cap

    # stretch target = proven peak LF per sector (revenue at current yield)
    stretch_dom = cap.loc["Domestic", "cap"] * proven_lf["Domestic"] * yld["Domestic"] / CR
    stretch_int = cap.loc["International", "cap"] * proven_lf["International"] * yld["International"] / CR
    stretch = stretch_dom + stretch_int
    peak_lf = (proven_lf["Domestic"] * cap.loc["Domestic", "cap"]
               + proven_lf["International"] * cap.loc["International", "cap"]) / cap["cap"].sum()
    # ---- COMMITTED TARGET: fill BOTH sectors to 90% load factor ------------
    # Per directive: the target is 90% LF on Domestic AND 90% on International.
    # The demand blend is kept as the FLOOR; proven-peak stretch is a milestone.
    demand_floor, demand_floor_lf = commit, commit_lf
    demand_a, demand_b = sig_a, sig_b
    # TARGET_LF is the module knob (see the knobs block). It used to be re-assigned to 0.90
    # right here, which meant the biggest lever on the number lived halfway down a 400-line
    # function and could not be changed without editing this file.
    # ROUTE-LEVEL commit (verified basis 2026-07-01): Σ_route July-cap_r × 90% × June-yield_r,
    # where yield_r = June net ÷ June booked seats ON THAT ROUTE (tgt_route_yield above).
    # July's capacity mix skews toward high-yield Gulf routes, so the sector-blended
    # cap×yld formula understates the SAME methodology by ~3% (692 vs 717 cr on the 30-day
    # base; ×31/30 coverage ≈ 741 cr) — the per-route sum keeps the mix effect.
    _rt = routes.copy()
    _rt["ry"] = _rt.apply(lambda x: tgt_route_yield.get(x["leg_route"]) or yld[x["sector"]], axis=1)
    _rt["tgt"] = _rt["cap"] * TARGET_LF * _rt["ry"]
    commit_dom = _rt.loc[_rt["sector"] == "Domestic", "tgt"].sum() / CR
    commit_int = _rt.loc[_rt["sector"] == "International", "tgt"].sum() / CR
    commit = commit_dom + commit_int
    commit_lf = TARGET_LF
    dom_lf, int_lf = TARGET_LF, TARGET_LF
    dom_legs = cap.loc["Domestic", "cap"] * TARGET_LF
    int_legs = cap.loc["International", "cap"] * TARGET_LF
    # sector-consistent revenue at each ladder rung (avoids the 'optimal < peak' artefact)
    optimal_rev = (cap.loc["Domestic", "cap"] * OPTIMAL_LF * yld["Domestic"]
                   + cap.loc["International", "cap"] * OPTIMAL_LF * yld["International"]) / CR
    full_rev = (cap.loc["Domestic", "cap"] * yld["Domestic"]
                + cap.loc["International", "cap"] * yld["International"]) / CR

    # ---- GROSS (Ticket Payment) counterparts, shown beside NET on the sheets ----
    # gr[sector] = gross-up factor (gross ticket fare / net fare). Gross of any sale =
    # Dom-part x gr_dom + Int-part x gr_int. Capacity rungs scale gross yld directly.
    gr = {s: yld_gross[s] / yld[s] for s in ["Domestic", "International"]}
    commit_gross = commit_dom * gr["Domestic"] + commit_int * gr["International"]
    stretch_gross = stretch_dom * gr["Domestic"] + stretch_int * gr["International"]   # proven-peak milestone
    demand_floor_gross = demand_floor * (commit_gross / commit) if commit else demand_floor
    full_rev_g = (cap.loc["Domestic", "cap"] * yld_gross["Domestic"]
                  + cap.loc["International", "cap"] * yld_gross["International"]) / CR
    optimal_rev_g = OPTIMAL_LF * full_rev_g

    # ---- "both sectors at 90% LF" sale, split by sales channel ---------------
    # Whole engine is NET ticket-payment, so the headline yld IS net. Seats x 90% x
    # net Rev/seat, then peel off the 3 DIRECT channels (Counter / Web / Mobile) via
    # the baseline mix to leave the AGENT sale. lf90_gross uses the gross yield purely
    # for the 'gross incl. commission' reference in the bridge note.
    DIRECT_Z = ["Z-Counter", "Z-Web", "Z-Mobi App"]
    lf90, lf90_excl, lf90_gross, direct_share = {}, {}, {}, {}
    for s in ["Domestic", "International"]:
        g = cap.loc[s, "cap"] * OPTIMAL_LF * yld[s] / CR         # all-channel NET sale @ 90% LF (cr)
        zs = zone[zone["sector"] == s]; tot = zs["net"].sum()
        dsh = zs[zs["zone"].isin(DIRECT_Z)]["net"].sum() / tot if tot else 0.0
        direct_share[s] = dsh; lf90[s] = g; lf90_excl[s] = g * (1 - dsh)
        lf90_gross[s] = cap.loc[s, "cap"] * OPTIMAL_LF * yld_gross[s] / CR

    # ---- Network-growth evidence (Mar5-May30 realised, completed flights) ----
    # International routes that flew >=90% full = proven, demand-constrained (spill).
    growth_add = con.execute(f"""
        SELECT leg_route, COUNT(*) legs, SUM(capacity) cap, SUM(booked) booked,
               SUM(booked)*1.0/SUM(capacity) lf, MEDIAN(capacity) acseats
        FROM read_parquet('{FLIGHT_LOADS}') WHERE UPPER(period)='HISTORICAL' AND capacity>0 AND sector='International'
        GROUP BY 1 HAVING SUM(capacity)>2000 AND SUM(booked)*1.0/SUM(capacity)>=0.90
        ORDER BY lf DESC, cap DESC
    """).df()
    growth_add["yld"] = growth_add["leg_route"].map(lambda r: route_yield.get(r) or yld["International"])
    # Chronically empty domestic routes (do NOT add — candidates to trim / redeploy).
    growth_trim = con.execute(f"""
        SELECT leg_route, SUM(capacity) cap, SUM(booked) booked, SUM(booked)*1.0/SUM(capacity) lf
        FROM read_parquet('{FLIGHT_LOADS}') WHERE UPPER(period)='HISTORICAL' AND capacity>0 AND sector='Domestic'
        GROUP BY 1 HAVING SUM(capacity)>2000 AND SUM(booked)*1.0/SUM(capacity)<0.60 ORDER BY cap DESC
    """).df()
    # Where the empty seats sit (drives the 'why 90% is the ceiling' block).
    cl = con.execute(f"""
        WITH legs AS (SELECT booked, capacity, booked*1.0/capacity lf FROM read_parquet('{FLIGHT_LOADS}')
                      WHERE UPPER(period)='HISTORICAL' AND capacity>0)
        SELECT SUM(capacity-booked) empty,
               SUM(CASE WHEN lf<0.70 THEN capacity-booked ELSE 0 END) empty_low,
               SUM(CASE WHEN lf>=0.90 THEN capacity-booked ELSE 0 END) empty_full FROM legs
    """).df().iloc[0]
    ceiling = {"empty": float(cl["empty"]), "empty_low": float(cl["empty_low"]), "empty_full": float(cl["empty_full"])}
    con.close()

    return dict(
        monthly=mser, trailing=trailing, june25=june25, avg12=avg12, june_index=june_index,
        sig_a=sig_a, sig_b=sig_b, commit=commit, commit_dom=commit_dom, commit_int=commit_int,
        dom_share=dom_share, yld=yld, proven_lf=proven_lf, cap=cap, routes=routes, zone=zone,
        zone_monthly=zone_monthly,
        mom_zone=mom_zone, mom_route=mom_route, mom_agency=mom_agency,
        mom_window=((_cur_lo, _cur_hi), (_prv_lo, _prv_hi), _elapsed),
        dom_lf=dom_lf, int_lf=int_lf, commit_lf=commit_lf, total_cap=total_cap,
        dom_legs=dom_legs, int_legs=int_legs,
        stretch=stretch, stretch_dom=stretch_dom, stretch_int=stretch_int,
        peak_lf=peak_lf, optimal_rev=optimal_rev, full_rev=full_rev,
        j25=j25, sec_net=sec_net, cur=cur,
        demand_floor=demand_floor, demand_floor_lf=demand_floor_lf,
        demand_a=demand_a, demand_b=demand_b,
        mtd=mtd, agents=agents, zlabels=zlabels, legs=legs, mtd_actual=mtd_actual,
        zone_ex_ota=zone_ex_ota, mtd_actual_ex_ota=mtd_actual_ex_ota,
        zone_monthly_ex_ota=zone_monthly_ex_ota,
        june_route=june_route, route_yield=route_yield, agent_routes=agent_routes,
        ota_ids=ota_ids,
        agent_routes_mtd=agent_routes_mtd,
        june_days=june_days, june_hi=june_hi,
        lf90=lf90, lf90_excl=lf90_excl, lf90_gross=lf90_gross, direct_share=direct_share,
        yld_gross=yld_gross, legs_y=legs_y,
        commit_gross=commit_gross, demand_floor_gross=demand_floor_gross,
        full_rev_g=full_rev_g, optimal_rev_g=optimal_rev_g, stretch_gross=stretch_gross,
        growth_add=growth_add, growth_trim=growth_trim, ceiling=ceiling,
    )


def zone_sort_key(z):
    """Natural order: Zone-1, Zone-2 ... Zone-11A, then the Z- channel buckets."""
    m = re.match(r"Zone-(\d+)([A-Za-z]*)$", str(z))
    if m:
        return (0, int(m.group(1)), m.group(2))
    return (1, 0, str(z))


# ======================================================================= #
def cell(ws,r,c,v,*,fmt=None,bold=False,size=11,color=BLACK,fill=None,align="left",
         wrap=False,border=False,italic=False):
    x=ws.cell(row=r,column=c,value=v)
    x.font=Font(bold=bold,size=size,color=color,name="Calibri",italic=italic)
    x.alignment=Alignment(horizontal=align,vertical="center",wrap_text=wrap)
    if fmt: x.number_format=fmt
    if fill: x.fill=PatternFill("solid",fgColor=fill)
    if border: x.border=BORDER
    return x

def bar(ws,row,c0,n,pct,color):
    f=max(0,min(n,round(pct*n)))
    for i in range(n):
        cc=ws.cell(row=row,column=c0+i)
        cc.fill=PatternFill("solid",fgColor=(color if i<f else "E7E6E6"))


# ======================================================================= #
def _sold_row(sold: float, jd: int, commit: float) -> tuple[str, str, str]:
    """The "Sold so far" glance row — and an HONEST verdict, or none at all.

    Two things the old one-liner got wrong:
      * it said "on pace" unconditionally, whatever the number was;
      * with no target-month sales in the data it still printed a percentage of target,
        so a month that simply has not started yet looked like a total collapse.
    `jd` is real days of data, never a default. Pace = elapsed share of the month.
    """
    if jd <= 0:
        return (f"Sold so far ({MONTH_LBL})", "no data yet",
                f"sales history has not reached {MONTH_LBL} — the target is capacity-driven "
                f"and unaffected")
    share = (sold / commit) if commit else 0.0
    pace = jd / CAL_DAYS
    verdict = ("ahead of pace" if share > pace * 1.05 else
               "behind pace" if share < pace * 0.95 else "on pace")
    return (f"Sold so far ({MON3} 1-{jd})", f"{sold:,.0f} cr",
            f"{share*100:.0f}% of target · {jd}/{CAL_DAYS} days elapsed ({pace*100:.0f}%) "
            f"— {verdict}")


def s_summary(wb,d):
    ws=wb.active; ws.title="Target Summary"; ws.sheet_view.showGridLines=False
    for c in range(1,16): ws.column_dimensions[get_column_letter(c)].width=8.4
    ws.merge_cells("A1:O1")
    cell(ws,1,1,f"US-BANGLA AIRLINES  •  {MONTH_LBL.upper()} {TARGET_YEAR} SALES TARGET (capacity-aware)",
         bold=True,size=16,color=WHITE,fill=NAVY,align="center"); ws.row_dimensions[1].height=30
    ws.merge_cells("A2:O2")
    # Month names DERIVED, never typed: this line said "fares from June ... July capacity"
    # for an August build, which is the sort of caption a reader trusts over the numbers.
    cell(ws,2,1,"All amounts = NET sale (base fare − commission + tax = balance − commission), all transactions incl. refunds.  "
                f"Per-seat fares from {PRIOR_LBL}, route by route. Set on {MONTH_LBL} seat capacity at 90% LF; "
                f"trailing avg + last-{MON3} give the demand floor.",
         size=9.5,color=GREY_T,fill=BLUE_LIGHT,align="center",italic=True)
    cards=[("TARGET (90% LF)",f"{d['commit']:,.0f} cr",f"net · gross {d['commit_gross']:,.0f} · Dom {d['commit_dom']:,.0f} + Intl {d['commit_int']:,.0f}",BLUE_MED),
           ("FILLS THE PLANE",f"{d['commit_lf']*100:.0f}%",f"of {int(d['total_cap']):,} seats (90% both sectors)",GREEN),
           ("DEMAND FLOOR",f"{d['demand_floor']:,.0f} cr",f"with no push ({d['demand_floor_lf']*100:.0f}% LF)",GREY_T)]
    for i,(lab,val,sub,acc) in enumerate(cards):
        c0=1+i*5; c1=c0+4
        for rr,(txt,sz,col,fl) in zip((4,5,6),[(lab,9.5,WHITE,acc),(val,18,acc,GREY_L),(sub,8.5,GREY_T,GREY_L)]):
            ws.merge_cells(start_row=rr,start_column=c0,end_row=rr,end_column=c1)
            cell(ws,rr,c0,txt,bold=(rr<6),size=sz,color=col,fill=fl,align="center",wrap=(rr==6))
    ws.row_dimensions[5].height=28; ws.row_dimensions[6].height=22
    # jd = days of TARGET-MONTH sales actually in the data. NO `or 6` fallback: when the sales
    # history has not reached the target month at all (building August on 31-Jul data) the old
    # default invented six days and printed "Sold so far (Aug 1-6)  0 cr  0% of target — on
    # pace", which reads as a catastrophic shortfall instead of "we have no August sales yet".
    cur=d.get('cur') or {}; jd=int(d.get('june_days',0) or 0)
    sold=(d['mtd_actual']['net'].sum()/CR) if d.get('mtd_actual') is not None else 0
    # LF sub-label: dynamic (was hardcoded "flown 88% + upcoming 41%"). Once the target month is
    # fully flown (no upcoming legs) say so instead of showing a stale forward split.
    _lf_sub = (f"incl. flown {cur.get('flown_lf',0)*100:.0f}% + upcoming {cur.get('upcoming_lf',0)*100:.0f}%"
               if (cur.get('upcoming_seats') or 0) > 0 else f"all flights flown ({cur.get('flown_lf',0)*100:.0f}%)")
    # Numbers at a glance (your simplified table)
    cell(ws,8,1,"THE NUMBERS AT A GLANCE",bold=True,size=12,color=NAVY)
    glance=[(f"Seat capacity ({MONTH_LBL})",f"{int(d['total_cap']):,}",""),
            (f"Load factor now ({CUT_LBL} snapshot)",f"{cur.get('total_lf',0)*100:.0f}%",_lf_sub),
            _sold_row(sold, jd, d['commit']),
            ("Usual trend (demand floor)",f"{d['demand_floor']:,.0f} cr",f"what {MONTH_LBL} does on its own"),
            (f"★ Target ({d['commit_lf']*100:.0f}% LF both sectors)",f"{d['commit']:,.0f} cr",f"≈ {d['commit_gross']:,.0f} cr gross (ticket pmt)  ·  Dom {d['commit_dom']:,.0f} + Intl {d['commit_int']:,.0f}"),
            ("Stretch to close (variance)",f"{d['commit']-d['demand_floor']:,.0f} cr","mostly domestic fare action")]
    r=9
    for lab,val,note in glance:
        star=lab.startswith("★"); fl=AMBER_F if star else GREY_L
        ws.merge_cells(start_row=r,start_column=1,end_row=r,end_column=6)
        cell(ws,r,1,lab,bold=True,size=10.5,color=AMBER_T if star else NAVY,fill=fl,border=True)
        ws.merge_cells(start_row=r,start_column=7,end_row=r,end_column=9)
        cell(ws,r,7,val,bold=True,size=11.5,color=AMBER_T if star else BLACK,fill=fl,align="center",border=True)
        ws.merge_cells(start_row=r,start_column=10,end_row=r,end_column=15)
        cell(ws,r,10,note,size=9,color=GREY_T,fill=fl,border=True)
        ws.row_dimensions[r].height=18; r+=1
    r+=1
    # The roadmap ladder (merged below the summary)
    cell(ws,r,1,"THE ROADMAP — empty plane → full   (Net & Gross-Ticket Payment)",bold=True,size=12,color=NAVY); r+=1
    clf=cur.get('total_lf',0)
    rungs=[(f"Booked now ({CUT_LBL})",clf,clf*d['full_rev'],clf*d['full_rev_g']),
           ("Demand floor (no push)",d['demand_floor_lf'],d['demand_floor'],d['demand_floor_gross']),
           ("Proven peak (last year's best)",d['peak_lf'],d['stretch'],d['stretch_gross']),
           ("★ TARGET — 90% both sectors",d['commit_lf'],d['commit'],d['commit_gross']),
           ("Full capacity (reference only)",1.0,d['full_rev'],d['full_rev_g'])]
    for h,(c0,c1) in zip(["Level","Load\nfactor","Seats filled","Net (cr)","Gross-Ticket\nPmt (cr)"],[(1,4),(5,6),(7,9),(10,12),(13,15)]):
        ws.merge_cells(start_row=r,start_column=c0,end_row=r,end_column=c1)
        cell(ws,r,c0,h,bold=True,size=9,color=NAVY,fill=BLUE_LIGHT,align="center",wrap=True,border=True)
    ws.row_dimensions[r].height=24; r+=1
    for lab,lf,rev,gross in rungs:
        star=lab.startswith("★"); fl=AMBER_F if star else (RED_F if "Full" in lab else None)
        ws.merge_cells(start_row=r,start_column=1,end_row=r,end_column=4)
        cell(ws,r,1,lab,bold=star,size=10,color=AMBER_T if star else (RED if "Full" in lab else NAVY),fill=fl,border=True)
        ws.merge_cells(start_row=r,start_column=5,end_row=r,end_column=6)
        cell(ws,r,5,lf,fmt=F_PCT,align="center",bold=True,fill=fl,border=True)
        ws.merge_cells(start_row=r,start_column=7,end_row=r,end_column=9)
        cell(ws,r,7,int(d['total_cap']*lf),fmt=F_INT,align="center",fill=fl,border=True)
        ws.merge_cells(start_row=r,start_column=10,end_row=r,end_column=12)
        cell(ws,r,10,rev,fmt=F_CR,align="center",bold=star,fill=fl,border=True)
        ws.merge_cells(start_row=r,start_column=13,end_row=r,end_column=15)
        cell(ws,r,13,gross,fmt=F_CR,align="center",bold=star,color=(AMBER_T if star else BLUE_MED),fill=fl,border=True)
        r+=1
    ws.merge_cells(start_row=r,start_column=1,end_row=r+1,end_column=15)
    cell(ws,r,1,f"TARGET = 90% load factor on BOTH sectors ({d['commit']:,.0f} cr net / {d['commit_gross']:,.0f} cr gross) — above our proven peak ({d['peak_lf']*100:.0f}%). "
                f"The job is to fill the empty DOMESTIC seats (today ~{d['proven_lf']['Domestic']*100:.0f}% → 90%); going PAST 90% needs more flights, not lower fares.",size=9.5,color=NAVY,wrap=True)
    r+=2
    # --- IF BOTH SECTORS HIT 90% LF — NET sale + GROSS, split by channel ---
    cell(ws,r,1,"THE TARGET BY CHANNEL — 90% LF both sectors  (net, with gross beside)",bold=True,size=12,color=NAVY); r+=1
    lf90=d.get('lf90',{}); lf90e=d.get('lf90_excl',{}); lf90g=d.get('lf90_gross',{}); dsh=d.get('direct_share',{})
    dom90=lf90.get('Domestic',0); int90=lf90.get('International',0); tot90=dom90+int90
    dome=lf90e.get('Domestic',0); inte=lf90e.get('International',0); tote=dome+inte
    # GROSS (ticket payment) versions, incl. the excl-direct split
    dom90g=lf90g.get('Domestic',0); int90g=lf90g.get('International',0); tot90g=dom90g+int90g
    domeg=dom90g*(1-dsh.get('Domestic',0)); integ=int90g*(1-dsh.get('International',0)); toteg=domeg+integ
    for h,(c0,c1) in zip(["Net sale at 90% LF","Domestic","International","Total","Gross-Ticket\nPmt (cr)"],
                         [(1,5),(6,8),(9,11),(12,15),(16,22)]):
        ws.merge_cells(start_row=r,start_column=c0,end_row=r,end_column=c1)
        cell(ws,r,c0,h,bold=True,size=9.5,color=NAVY,fill=BLUE_LIGHT,align="center",wrap=True,border=True)
    r+=1
    rows90=[("All channels (Seats × 90% × Rev/seat)",dom90,int90,tot90,tot90g,None),
            ("Less direct: Counter / Web / Mobile",-(dom90-dome),-(int90-inte),-(tot90-tote),-(tot90g-toteg),GREY_L),
            ("★ Agent / agency sale (excl. direct)",dome,inte,tote,toteg,AMBER_F)]
    for lab,dv,iv,tv,gv,fl in rows90:
        star=lab.startswith("★")
        ws.merge_cells(start_row=r,start_column=1,end_row=r,end_column=5)
        cell(ws,r,1,lab,bold=star,size=10,color=AMBER_T if star else NAVY,fill=fl,border=True)
        for v,(c0,c1) in zip((dv,iv,tv),[(6,8),(9,11),(12,15)]):
            ws.merge_cells(start_row=r,start_column=c0,end_row=r,end_column=c1)
            cell(ws,r,c0,v,fmt=F_CR,align="center",bold=star,color=AMBER_T if star else BLACK,fill=fl,border=True)
        ws.merge_cells(start_row=r,start_column=16,end_row=r,end_column=22)
        cell(ws,r,16,gv,fmt=F_CR,align="center",bold=star,color=(AMBER_T if star else BLUE_MED),fill=fl,border=True)
        r+=1
    ws.merge_cells(start_row=r,start_column=1,end_row=r,end_column=15)
    cell(ws,r,1,f"This IS the target: 90% LF on both sectors = {tot90:,.0f} cr net (≈ {tot90g:,.0f} cr gross, before commission). "
                f"Stripping out OUR OWN direct channels — Counter/Web/App (≈{dsh.get('Domestic',0)*100:.0f}% of domestic, "
                f"{dsh.get('International',0)*100:.0f}% of international baseline) — leaves {tote:,.0f} cr net that AGENTS / AGENCIES must drive.",
         size=9,color=GREY_T,wrap=True)
    ws.row_dimensions[r].height=26; r+=2
    # Short story
    cell(ws,r,1,"WHAT TO DO (plain words)",bold=True,size=12,color=NAVY); r+=1
    cd=cur.get('domestic_lf',0); yratio=d['yld']['International']/d['yld']['Domestic']
    story=[
        # Months DERIVED, never typed. This line hardcoded "July capacity x June per-seat fare"
        # and survived the rollover to August, so it contradicted the (already derived) header
        # two rows above it AND the Calculations sheet. Three captions, three different answers,
        # for one number a reader is trying to trust. YIELD_WIN is _month_span(-1), so the fare
        # month is PRIOR_LBL and the capacity month is MONTH_LBL, always.
        f"•  {MONTH_LBL}'s organic demand floor is {d['demand_floor']:,.0f} cr. The TARGET is "
        f"{d['commit']:,.0f} cr: {MONTH_LBL} seat capacity x 90% LF x {PRIOR_LBL} per-seat "
        f"fare, route by route.",
        f"•  The extra {d['commit']-d['demand_floor']:,.0f} cr is almost all DOMESTIC — those flights are only ~{cd*100:.0f}% booked and must roughly double. That needs FARE PROMOTIONS, not just agent effort.",
        f"•  A domestic seat earns ~{yratio:.0f}x less than international, so domestic fills the plane while international brings the money: push domestic for load factor, protect international for revenue.",
    ]
    for line in story:
        ws.merge_cells(start_row=r,start_column=1,end_row=r,end_column=15)
        cell(ws,r,1,line,size=10,wrap=True,fill=GREEN_F if line==story[0] else None)
        ws.row_dimensions[r].height=28; r+=1


def s_method(wb,d):
    ws=wb.create_sheet("Methodology"); ws.sheet_view.showGridLines=False
    ws.column_dimensions["A"].width=34; ws.column_dimensions["B"].width=20; ws.column_dimensions["C"].width=58
    cell(ws,1,1,"How the target was built (and why)",bold=True,size=14,color=NAVY)
    rows=[
        ("INPUT","VALUE","WHAT IT IS / WHY",True),
        ("Trailing 5-mo average (Dec-Apr)",f"{d['trailing']:,.0f} cr","Recent demand level, before seasonality.",False),
        (f"{MONTH_LBL} seasonal index",f"{d['june_index']:.2f}",f"{MONTH_LBL}-2025 ÷ 12-month average.",False),
        ("Signal A = Trailing × Seasonal",f"{d['sig_a']:,.0f} cr","Multiplicative decomposition — the revenue-management standard.",False),
        (f"Last {MONTH_LBL} (2025) actual",f"{d['june25']:,.0f} cr","Same-month-last-year anchor.",False),
        ("Network YoY growth",f"{YOY_GROWTH*100:+.0f}%","May'26 vs May'25 ran -3%; held flat (conservative).",False),
        ("Hajj-overlap factor",f"{HAJJ_FACTOR:.2f}","Hajj/Eid does not overlap July — no adjustment.",False),
        ("Signal B = Eid/Hajj-adjusted YoY",f"{d['sig_b']:,.0f} cr","Anchored to the HOLIDAY, not the calendar (Eid moved to May).",False),
        ("Blend weights (A : B)",f"{W_SEASONAL:.0%} : {W_YOY:.0%}","Equal trust in the seasonal model and the adjusted YoY.",False),
        ("Demand FLOOR (blend of A & B)",f"{d['demand_floor']:,.0f} cr",f"Organic {MONTH_LBL} demand. The FLOOR — not the target.",True),
        ("Proven-peak load factor",f"{d['commit_lf']*100:.0f}%","Best-ever sector LF (Dom 81% / Int 89%) — what the planes can fill.",False),
        ("★ AGGRESSIVE TARGET",f"{d['commit']:,.0f} cr",f"Fill both sectors to 90%. The committed {MONTH_LBL} number.",True),
        ("Domestic yield / seat",f"{d['yld']['Domestic']:,.0f} TK","Net sale per flown domestic seat (cheap).",False),
        ("International yield / seat",f"{d['yld']['International']:,.0f} TK","Net sale per flown international seat (~6× domestic).",False),
        ("Capacity fulfilment",f"{d['commit_lf']*100:.0f}%","Aggressive target ÷ yield → seats ÷ capacity = proven-peak LF.",True),
    ]
    r=3
    for a,b,c,hl in rows:
        fl=NAVY if (hl and a.startswith("★")) else (BLUE_LIGHT if hl else None)
        col=WHITE if (hl and a.startswith("★")) else NAVY if hl else BLACK
        cell(ws,r,1,a,bold=hl,size=10.5,color=col,fill=fl,border=True,wrap=True)
        cell(ws,r,2,b,bold=hl,size=10.5,color=col,fill=fl,border=True,align="center")
        cell(ws,r,3,c,size=10,color=col if hl else GREY_T,fill=fl,border=True,wrap=True)
        ws.row_dimensions[r].height=26; r+=1
    r+=1
    cell(ws,r,1,"Research basis (airline revenue management):",bold=True,color=NAVY); r+=1
    for note in [
        "• Moving holidays (Eid/Ramadan) must be anchored to the holiday, not the month — naive YoY 'can be off by weeks'. (US Census moving-holiday adjustment; ARIMAX Ramadan calendar-variation models.)",
        "• Multiplicative trend×seasonal index (ratio-to-moving-average) is the standard for seasonal sales. (Forecasting: Principles & Practice.)",
        "• 100% load factor is never the goal: best-in-class Ryanair ~96%; optimal LF balances yield vs fill. We target ~88%. (Seeking Alpha; PROS; easietech.)",
        "• Forward bookings look low now and build on a curve — judge fill vs the booking curve, not vs the final target. (Embark Aviation; Reuters Events.)",
    ]:
        ws.merge_cells(start_row=r,start_column=1,end_row=r,end_column=3)
        cell(ws,r,1,note,size=9.5,color=GREY_T,wrap=True); ws.row_dimensions[r].height=30; r+=1


CHANNEL_LABEL = {"Z-Counter": ("Airport & city counters", "Counter team"),
                 "Z-Web": ("Website (B2C)", "Digital team"),
                 "Z-Mobi App": ("Mobile app (B2C)", "Digital team"),
                 "Z-Corporate": ("Corporate accounts", "Corporate desk"),
                 "Z-Unmapped": ("Unassigned agencies", "")}


def s_routes(wb,d):
    ws=wb.create_sheet("Route Utilisation"); ws.sheet_view.showGridLines=False
    jd=int(d.get('june_days',6) or 6); pace=jd/CAL_DAYS
    cell(ws,1,1,f"Route-wise target · live bookings · {MON3} 1-{jd} actual",bold=True,size=14,color=NAVY)
    cell(ws,2,1,"Each route's target = its Seats × Target fill % × its OWN Rev/seat. Rev/seat differs by route "
                f"(e.g. DAC-DXB earns more per seat than DAC-MCT). 'Booked now' & 'Current fill' are the live {CUT_LBL} snapshot; "
                f"'Sold {MON3} 1-{jd}' is real sales. Amounts in NET (balance − commission) and GROSS (ticket payment).",size=9.5,color=NAVY,wrap=True)
    ws.merge_cells("A2:K2"); ws.row_dimensions[2].height=30
    gr={s:d['yld_gross'][s]/d['yld'][s] for s in ['Domestic','International']}
    heads=["Route","Sector","Seats","Booked\nnow","Current\nfill","Rev/seat\n(TK)","Target\nfill","Target net\n(cr)",f"Sold MTD\n({MON3} 1-{jd}, cr)","% sold\nvs target","Target gross\n(cr)"]
    widths=[11,12,9,8,8,10,8,11,12,10,11]
    for j,(h,w) in enumerate(zip(heads,widths),1):
        cell(ws,4,j,h,bold=True,size=9.5,color=NAVY,fill=BLUE_LIGHT,align="center",wrap=True,border=True)
        ws.column_dimensions[get_column_letter(j)].width=w
    ws.row_dimensions[4].height=28
    cur=d.get('cur') or {}
    rdf=cur['routes'].copy() if cur.get('routes') is not None else d['routes'].copy()
    ry=d.get('route_yield',{}); jr=d.get('june_route')
    sold={} if jr is None else dict(zip(jr['route'], jr['net']/CR))
    tgt_lf={'Domestic':d['dom_lf'],'International':d['int_lf']}
    rt=rdf.copy()
    if rt.empty:                     # an off-month live snapshot once fed an empty frame here and
        rt=d['routes'].copy()        # apply() on it returns a DataFrame -> crash; use parquet routes
    rt['ryield']=rt.apply(lambda x: ry.get(x['leg_route']) if ry.get(x['leg_route']) else d['yld'][x['sector']], axis=1)
    rt['raw']=rt['cap']*rt['sector'].map(tgt_lf)*rt['ryield']
    rt['tgt_sales']=0.0
    for sec,goal in [('Domestic',d['commit_dom']),('International',d['commit_int'])]:
        m=rt['sector']==sec; s=rt.loc[m,'raw'].sum()
        if s: rt.loc[m,'tgt_sales']=rt.loc[m,'raw']/s*goal
    rt['sold']=rt['leg_route'].map(lambda r: sold.get(r,0.0))
    rt['pct']=rt.apply(lambda x: x['sold']/x['tgt_sales'] if x['tgt_sales']>0 else 0,axis=1)
    rt['gross']=rt['tgt_sales']*rt['sector'].map(gr)
    rt=rt[rt['cap']>500]
    r=5; gc=gb=gsale=gsold=ggross=0.0
    def secrow(rr,lab,scap,sbk,ryld,tlf,ssale,ssold,fill,sgross=None):
        cell(ws,rr,1,lab,bold=True,size=11,color=WHITE,fill=fill,border=True)
        cell(ws,rr,2,"",fill=fill,border=True)
        cell(ws,rr,3,int(scap),fmt=F_INT,bold=True,color=WHITE,fill=fill,align="center",border=True)
        cell(ws,rr,4,int(sbk),fmt=F_INT,bold=True,color=WHITE,fill=fill,align="center",border=True)
        cell(ws,rr,5,sbk/scap if scap else 0,fmt=F_PCT,bold=True,color=WHITE,fill=fill,align="center",border=True)
        cell(ws,rr,6,(int(ryld) if ryld else ""),fmt=F_INT,bold=True,color=WHITE,fill=fill,align="center",border=True)
        cell(ws,rr,7,(tlf if tlf else ""),fmt=F_PCT,bold=True,color=WHITE,fill=fill,align="center",border=True)
        cell(ws,rr,8,ssale,fmt=F_CR,bold=True,color=WHITE,fill=fill,align="center",border=True)
        cell(ws,rr,9,ssold,fmt=F_CR,bold=True,color=WHITE,fill=fill,align="center",border=True)
        cell(ws,rr,10,ssold/ssale if ssale else 0,fmt=F_PCT,bold=True,color=WHITE,fill=fill,align="center",border=True)
        cell(ws,rr,11,(sgross if sgross is not None else ""),fmt=F_CR,bold=True,color=WHITE,fill=fill,align="center",border=True)
    for sec in ['Domestic','International']:
        srt=rt[rt['sector']==sec].sort_values('tgt_sales',ascending=False)
        if not len(srt): continue
        scap=srt['cap'].sum(); sbk=srt['booked'].sum(); ssale=srt['tgt_sales'].sum(); ssold=srt['sold'].sum()
        secrow(r,sec,scap,sbk,d['yld'][sec],tgt_lf[sec],ssale,ssold,BLUE_MED,srt['gross'].sum()); r+=1
        for _,x in srt.iterrows():
            stripe=GREY_L if r%2==0 else None
            cell(ws,r,1,x['leg_route'],bold=True,size=10,color=NAVY,fill=stripe,border=True)
            cell(ws,r,2,x['sector'],size=9,fill=stripe,border=True)
            cell(ws,r,3,int(x['cap']),fmt=F_INT,align="center",fill=stripe,border=True)
            cell(ws,r,4,int(x['booked']),fmt=F_INT,align="center",fill=stripe,border=True)
            fc=RED_F if x['fill']<0.4 else AMBER_F if x['fill']<0.7 else GREEN_F
            cell(ws,r,5,x['fill'],fmt=F_PCT,align="center",fill=fc,border=True)
            cell(ws,r,6,int(x['ryield']),fmt=F_INT,align="center",size=9,fill=stripe,border=True)
            cell(ws,r,7,tgt_lf[x['sector']],fmt=F_PCT,align="center",fill=stripe,border=True)
            cell(ws,r,8,x['tgt_sales'],fmt=F_CR,align="center",bold=True,color=NAVY,fill=stripe,border=True)
            cell(ws,r,9,x['sold'],fmt=F_CR,align="center",fill=stripe,border=True)
            pc=x['pct']; pf=GREEN_F if pc>=pace else AMBER_F if pc>=pace*0.5 else RED_F
            cell(ws,r,10,pc,fmt=F_PCT,align="center",fill=pf,border=True)
            cell(ws,r,11,x['gross'],fmt=F_CR,align="center",color=BLUE_MED,fill=stripe,border=True); r+=1
        gc+=scap; gb+=sbk; gsale+=ssale; gsold+=ssold; ggross+=srt['gross'].sum()
    secrow(r,"GRAND TOTAL",gc,gb,None,None,gsale,gsold,NAVY,ggross); r+=2
    ws.merge_cells(start_row=r,start_column=1,end_row=r+1,end_column=11)
    cell(ws,r,1,f"Routes grouped by sector with subtotals. Current fill is the live {CUT_LBL} booking (total {gb/gc*100:.0f}%). 'Rev/seat' is each route's own "
                "revenue per seat (international routes vary a lot), so two routes with the same seats can have very different targets. "
                f"'% sold' = real {MON3} 1-{jd} sales ÷ the route's whole-month target ({pace*100:.0f}% = on pace).",size=10,color=GREY_T,wrap=True)


def s_roadmap(wb,d):
    ws=wb.create_sheet("Roadmap & Projection"); ws.sheet_view.showGridLines=False
    cell(ws,1,1,"Roadmap — from this target toward full capacity",bold=True,size=14,color=NAVY)
    cell(ws,2,1,f"{MONTH_LBL} seat capacity = {int(d['total_cap']):,} (Domestic {int(d['cap'].loc['Domestic','cap']):,} / International {int(d['cap'].loc['International','cap']):,}). "
                "Each rung shows how many of those seats get filled.",size=10,color=GREY_T,wrap=True)
    ws.merge_cells("A2:G2"); ws.row_dimensions[2].height=24
    dc=d['cap'].loc['Domestic','cap']; ic=d['cap'].loc['International','cap']
    dy=d['yld']['Domestic']; iy=d['yld']['International']; ds=d['dom_share']
    c=d.get("cur") or {}
    rungs=[]
    if d.get("cur"):
        rungs.append((f"Booked now ({CUT_LBL})",c['total_lf'],
                      dc*c.get('domestic_lf',0)*dy/CR, ic*c.get('international_lf',0)*iy/CR,
                      f"All-{MON3} {c['total_lf']*100:.0f}% incl. days already flown ({c.get('flown_lf',0)*100:.0f}%); seats still to sell are {c.get('upcoming_lf',0)*100:.0f}% booked"))
    rungs+=[("Demand floor (no push)",d['demand_floor_lf'],d['demand_floor']*ds,d['demand_floor']*(1-ds),
             f"Where {MONTH_LBL} drifts on its own"),
            ("★ AGGRESSIVE TARGET",d['commit_lf'],d['commit_dom'],d['commit_int'],
             "Fill to best-ever load factor — the commitment"),
            ("Optimal LF (ceiling)",OPTIMAL_LF,dc*OPTIMAL_LF*dy/CR,ic*OPTIMAL_LF*iy/CR,
             "Research best practice (~90%)"),
            ("Full capacity (100%)",1.0,dc*dy/CR,ic*iy/CR,
             "Reference only — never the goal")]
    heads=["Level","Load\nfactor","Seats\nfilled","Domestic\n(cr)","Intl\n(cr)","Total\n(cr)","What it means"]
    widths=[20,8,11,10,10,11,26]
    for j,(h,w) in enumerate(zip(heads,widths),1):
        cell(ws,4,j,h,bold=True,size=9.5,color=NAVY,fill=BLUE_LIGHT,align="center",wrap=True,border=True)
        ws.column_dimensions[get_column_letter(j)].width=w
    ws.row_dimensions[4].height=26
    r=5
    for lab,lfv,drev,irev,mean in rungs:
        star=lab.startswith("★"); fl=AMBER_F if star else (RED_F if "Full" in lab else None)
        cell(ws,r,1,lab,bold=True,size=10.5,color=AMBER_T if star else (RED if "Full" in lab else NAVY),fill=fl,border=True)
        cell(ws,r,2,lfv,fmt=F_PCT,align="center",bold=True,fill=fl,border=True)
        cell(ws,r,3,int(d['total_cap']*lfv),fmt=F_INT,align="center",fill=fl,border=True)
        cell(ws,r,4,drev,fmt=F_CR,align="center",fill=fl,border=True)
        cell(ws,r,5,irev,fmt=F_CR,align="center",fill=fl,border=True)
        cell(ws,r,6,drev+irev,fmt=F_CR,align="center",bold=True,fill=fl,border=True)
        cell(ws,r,7,mean,size=9.5,fill=fl,border=True,wrap=True)
        ws.row_dimensions[r].height=22; r+=1
    r+=2
    cell(ws,r,1,"WHEN DO WE REACH OPTIMAL CAPACITY (88% LF)?",bold=True,size=12,color=NAVY); r+=1
    cell(ws,r,1,f"Starting point: {MONTH_LBL}'s ORGANIC level ~{d['demand_floor_lf']*100:.0f}% LF (the aggressive target is a one-month stretch to "
                f"{d['commit_lf']*100:.0f}%). To make ~{OPTIMAL_LF*100:.0f}% the SUSTAINED norm, gap = {(OPTIMAL_LF-d['demand_floor_lf'])*100:.0f} points, "
                "closed via demand growth + filling empty domestic seats year on year.",
         size=10,color=GREY_T,wrap=True)
    ws.merge_cells(start_row=r,start_column=1,end_row=r,end_column=4); ws.row_dimensions[r].height=38; r+=2
    for j,h in enumerate(["Growth pace","LF gain / yr","Years to 90%","Reaches optimal in"],1):
        cell(ws,r,j,h,bold=True,size=10,color=NAVY,fill=BLUE_LIGHT,align="center",border=True)
    r+=1
    gap=OPTIMAL_LF-d['demand_floor_lf']
    base_year=2026
    for name,pace in PROJ_SCENARIOS:
        yrs=gap/pace
        cell(ws,r,1,name,bold=True,size=10,color=NAVY,border=True)
        cell(ws,r,2,pace,fmt=F_PCT,align="center",border=True)
        cell(ws,r,3,round(yrs,1),align="center",border=True)
        cell(ws,r,4,f"~ {MON3} {base_year+int(round(yrs))}",align="center",border=True,
             fill=GREEN_F if yrs<=4 else AMBER_F if yrs<=7 else RED_F)
        r+=1
    r+=1
    cell(ws,r,1,"NOTE: the goal is OPTIMAL load factor (~88%), not 100%. Beyond ~90% the marginal seat sells at a loss and "
                "denied-boardings rise. 'Full capacity' here is a reference line, not a destination.",
         size=9.5,color=RED,italic=True,wrap=True)
    ws.merge_cells(start_row=r,start_column=1,end_row=r+1,end_column=4)


def s_calc(wb,d):
    ws=wb.create_sheet("Calculations"); ws.sheet_view.showGridLines=False
    ws.column_dimensions["A"].width=30; ws.column_dimensions["B"].width=46; ws.column_dimensions["C"].width=16
    cell(ws,1,1,"Methodology & Calculations — how every number is built",bold=True,size=14,color=NAVY)
    cell(ws,2,1,"The whole method in one place: blend a demand FLOOR, show the proven-peak fill as a milestone, then set the TARGET at 90% LF on BOTH sectors. "
                "Headline amounts are NET sale (balance - commission); the GROSS (ticket payment, before commission) is shown beside. "
                f"Per-seat fares from {PRIOR_LBL} (YIELD_WIN = the month before the target), route by route.",
         size=10,color=GREY_T,wrap=True); ws.merge_cells("A2:C2"); ws.row_dimensions[2].height=34
    dn=d['sec_net']['Domestic']/CR; intn=d['sec_net']['International']/CR
    dby=d['legs_y'].loc['Domestic','bk']; iby=d['legs_y'].loc['International','bk']   # PRIOR_LBL booked (yield denom)
    db=d['legs'].loc['Domestic','bk']; dcp=d['legs'].loc['Domestic','cap']           # full hist (fill rate)
    ib=d['legs'].loc['International','bk']; icp=d['legs'].loc['International','cap']
    dy=d['yld']['Domestic']; iy=d['yld']['International']
    djc=d['cap'].loc['Domestic','cap']; ijc=d['cap'].loc['International','cap']
    rows=[
        ("STEP","THE MATH","ANSWER",True),
        ("1) Revenue per seat — Domestic",f"{dn:,.1f} cr net / {int(dby):,} seats ({PRIOR_LBL}) x {GROWTH_UPLIFT:g} growth",f"{dy:,.0f} net / {d['yld_gross']['Domestic']:,.0f} gross TK",False),
        ("1) Revenue per seat — International",f"{intn:,.1f} cr / {int(iby):,} seats booked ({PRIOR_LBL}) x {GROWTH_UPLIFT:g} growth",f"{iy:,.0f} net / {d['yld_gross']['International']:,.0f} gross TK",False),
        ("2) Best-ever fill — Domestic",f"{int(db):,} seats sold ÷ {int(dcp):,} seats flown",f"{d['proven_lf']['Domestic']*100:.0f}%",False),
        ("2) Best-ever fill — International",f"{int(ib):,} ÷ {int(icp):,}",f"{d['proven_lf']['International']*100:.0f}%",False),
        ("2) Best-ever fill — Blended (milestone)",f"weighted by each sector's seats",f"{d['peak_lf']*100:.0f}%",True),
        ("3) Hajj-overlap factor","Hajj/Eid fell in May-June 2026 — no overlap with July;",f"none",False),
        (" ",f"factor {HAJJ_FACTOR:.2f} (no haircut on the July anchor).",f"x{HAJJ_FACTOR:.2f}",False),
        (" ","Fewer Hajj days = less international lift → small -3% cut",f"× 0.97",True),
        (f"4) Signal B (last {MONTH_LBL}, adjusted)",f"Last {MONTH_LBL} {d['june25']:,.0f} cr × growth {1+YOY_GROWTH:.2f} × Hajj {HAJJ_FACTOR:.2f}",f"{d['demand_b']:,.0f} cr",True),
        ("5) Signal A (average × season)",f"5-mo avg {d['trailing']:,.0f} cr × {MONTH_LBL} season {d['june_index']:.2f}",f"{d['demand_a']:,.0f} cr",True),
        ("6) Demand FLOOR (easy number)",f"(Signal A {d['demand_a']:,.0f} + Signal B {d['demand_b']:,.0f}) ÷ 2",f"{d['demand_floor']:,.0f} cr",True),
        ("7) TARGET — Domestic",f"{int(djc):,} {MONTH_LBL} seats × {d['dom_lf']*100:.0f}% LF × {dy:,.0f} TK (route-level)",f"{d['commit_dom']:,.1f} cr",False),
        ("7) TARGET — International",f"{int(ijc):,} seats × {d['int_lf']*100:.0f}% LF × {iy:,.0f} TK",f"{d['commit_int']:,.1f} cr",False),
        ("7) TARGET — TOTAL (net)",f"Domestic {d['commit_dom']:,.0f} + International {d['commit_int']:,.0f}  (90% LF both)",f"{d['commit']:,.0f} cr",True),
        ("7) TARGET — GROSS",f"Same seats × gross ticket fare (before commission)",f"{d['commit_gross']:,.0f} cr",True),
        ("8) Capacity fulfilment",f"target seats {int(d['commit_dom']*CR/dy+d['commit_int']*CR/iy):,} ÷ {int(d['total_cap']):,} {MONTH_LBL} seats",f"{d['commit_lf']*100:.0f}%",True),
    ]
    r=4
    for a,b,c,hl in rows:
        head = a=="STEP"
        fl = NAVY if head else (BLUE_LIGHT if hl else None)
        col = WHITE if head else (NAVY if hl else BLACK)
        cell(ws,r,1,a,bold=(hl or head),size=10,color=col,fill=fl,border=True,wrap=True)
        cell(ws,r,2,b,size=9.5,color=col if (hl or head) else GREY_T,fill=fl,border=True,wrap=True)
        cell(ws,r,3,c,bold=(hl or head),size=10.5,color=col,fill=fl,border=True,align="center")
        ws.row_dimensions[r].height=26; r+=1
    r+=1
    cell(ws,r,1,"Why this method (airline revenue-management basis):",bold=True,size=10,color=NAVY); r+=1
    for note in [
        "• Moving holidays (Eid/Hajj) are anchored to the holiday, not the calendar — none fall in July 2026, so no holiday adjustment applies.",
        f"• We blend recent average × season (Signal A) with last-{MONTH_LBL} (Signal B) — the standard multiplicative-seasonal approach.",
        f"• The FLOOR is what {MONTH_LBL} does on its own; the TARGET is set on CAPACITY (both sectors to 90% LF at June route fares).",
        "• 100% load factor is never the goal: best-in-class ~96%, optimal balances fill vs yield. We aim at our proven peak (~86%).",
    ]:
        ws.merge_cells(start_row=r,start_column=1,end_row=r,end_column=3)
        cell(ws,r,1,note,size=9,color=GREY_T,wrap=True); ws.row_dimensions[r].height=26; r+=1
    # --- WHY ~90% IS THE CEILING (fares fill it once; flights move it) ---
    r+=1
    ce=d.get('ceiling',{}); emp=ce.get('empty',0) or 1; low=ce.get('empty_low',0); full=ce.get('empty_full',0)
    fare_push=d['optimal_rev']-d['commit']
    cell(ws,r,1,"WHY ~90% IS THE CEILING  (fares vs flights)",bold=True,size=11,color=NAVY); r+=1
    crows=[
        ("Empty seats at proven peak (Mar-May)",f"{int(emp):,} seats","",False),
        ("   on chronically-LOW flights (<70%)",f"{int(low):,} = {low/emp*100:.0f}% of empties","fares can't fill — no demand there",False),
        ("   on already-FULL flights (>=90%)",f"{int(full):,} = {full/emp*100:.0f}%","no room to add",False),
        ("   the FILLABLE pool (the rest)",f"{int(emp-low-full):,} = {(emp-low-full)/emp*100:.0f}%","this IS the 86%->90% move",True),
        ("FARE lever (86%->90%, one-time)",f"+{fare_push:.0f} cr net","caps out the fillable pool",True),
        ("FLIGHT lever (repeatable growth)","+16 to +47 cr/mo each","add intl frequency — see Network Growth sheet",True),
    ]
    for a,b,note,hl in crows:
        fl=BLUE_LIGHT if hl else None
        cell(ws,r,1,a,bold=hl,size=9.5,color=NAVY if hl else BLACK,fill=fl,border=True)
        cell(ws,r,2,b,bold=hl,size=9.5,color=NAVY if hl else BLACK,fill=fl,align="center",border=True)
        cell(ws,r,3,note,size=9,color=GREY_T,fill=fl,border=True,wrap=True)
        ws.row_dimensions[r].height=22; r+=1


def zone_achievement_frame(d, exclude_ota: bool = False) -> "pd.DataFrame":
    """Zone-level target vs achievement — the math behind the 'Target vs
    Achievement' sheet, exposed as a function so other builders (the per-sales-person
    Target Packs) reuse EXACTLY the same numbers instead of re-deriving them.

    Index = zone.  Columns: btd/bti = baseline tickets per month (Dom/Intl, 5-mo avg),
    bs = baseline sales (cr/mo), td/ti/tt = June TARGET net (cr) Dom/Intl/Total,
    ttk = target tickets, sn = sold net (cr) June-to-date, stk = tickets sold,
    ach = sn/tt achievement ratio, leg = target seat-legs, cap = share of June capacity.
    """
    # FULL baseline — always needed, because the network scale factors below must be the
    # SAME on both versions of the sheet (see the comment on dsc/isc).
    _full=d['zone']
    fz_net=_full.pivot_table(index='zone',columns='sector',values='net',aggfunc='sum').fillna(0)
    fz_tkt=_full.pivot_table(index='zone',columns='sector',values='tickets',aggfunc='sum').fillna(0)
    _src=(d.get('zone_ex_ota') if exclude_ota else None)
    if _src is None: _src=_full
    zn_net=_src.pivot_table(index='zone',columns='sector',values='net',aggfunc='sum').fillna(0)
    zn_tkt=_src.pivot_table(index='zone',columns='sector',values='tickets',aggfunc='sum').fillna(0)
    for s in ['Domestic','International']:
        if s not in zn_net: zn_net[s]=0.0
        if s not in zn_tkt: zn_tkt[s]=0.0
        if s not in fz_net: fz_net[s]=0.0
        if s not in fz_tkt: fz_tkt[s]=0.0
    ma=(d.get('mtd_actual_ex_ota') if exclude_ota else None)
    if ma is None: ma=d.get('mtd_actual')
    sold_net=(ma.groupby('zone')['net'].sum()) if ma is not None else {}
    sold_tkt=(ma.groupby('zone')['tickets'].sum()) if ma is not None else {}
    # Scale factors come from the FULL baseline on BOTH versions. Re-deriving them from the
    # OTA-excluded baseline would silently redistribute the whole 749 cr network target across
    # the remaining agencies — every zone's target would GROW when OTAs are removed, which is
    # the opposite of what the sheet is for. Holding them fixed means each zone's non-OTA
    # target is its own non-OTA baseline at the network rate, and the two versions differ by
    # exactly the OTA contribution.
    dsc=(d['commit_dom']*CR)/fz_net['Domestic'].sum(); isc=(d['commit_int']*CR)/fz_net['International'].sum()
    tdt=d['cap'].loc['Domestic','cap']*d['proven_lf']['Domestic']     # target dom tickets ~ seat-legs
    tit=d['cap'].loc['International','cap']*d['proven_lf']['International']
    dts=tdt/fz_tkt['Domestic'].sum() if fz_tkt['Domestic'].sum() else 0
    its=tit/fz_tkt['International'].sum() if fz_tkt['International'].sum() else 0
    Z=pd.DataFrame(index=zn_net.index)
    Z['btd']=zn_tkt['Domestic']/5; Z['bti']=zn_tkt['International']/5
    Z['bs']=(zn_net['Domestic']+zn_net['International'])/5/CR
    Z['td']=zn_net['Domestic']*dsc/CR; Z['ti']=zn_net['International']*isc/CR; Z['tt']=Z['td']+Z['ti']
    # ttk is kept as the single total it has always been, but the two halves are exposed too:
    # the DSR needs a target SEGMENT split, and segments-per-ticket differs by sector, so it
    # cannot recover Dom/Int from the combined figure. Adding columns changes nothing for
    # existing readers.
    Z['ttk_dom']=zn_tkt['Domestic']*dts
    Z['ttk_int']=zn_tkt['International']*its
    Z['ttk']=Z['ttk_dom']+Z['ttk_int']
    Z['sn']=[ (sold_net.get(i,0.0)/CR if hasattr(sold_net,'get') else 0.0) for i in Z.index]
    Z['stk']=[ (sold_tkt.get(i,0.0) if hasattr(sold_tkt,'get') else 0.0) for i in Z.index]
    Z['ach']=[ (s/t if t>0 else 0) for s,t in zip(Z['sn'],Z['tt'])]
    Z['leg']=Z['td']*CR/d['yld']['Domestic']+Z['ti']*CR/d['yld']['International']
    Z['cap']=Z['leg']/d['total_cap']
    return Z[Z['tt']>=0.001].sort_index(key=lambda idx: idx.map(zone_sort_key))


def s_achievement(wb,d,title="Target vs Achievement",exclude_ota=False):
    ws=wb.create_sheet(title); ws.sheet_view.showGridLines=False
    jd=int(d.get('june_days',6) or 6); pace=jd/CAL_DAYS
    cell(ws,1,1,f"Zone-wise Target vs Achievement — {MONTH_LBL} {TARGET_YEAR}"
                + (" — EXCLUDING OTAs" if exclude_ota else ""),bold=True,size=14,color=NAVY)
    cell(ws,2,1,f"One master view per zone. Baseline = avg of last 5 months. Target = {MONTH_LBL} 90%-LF (net & gross). "
                f"Achieved = real {MON3} 1-{jd} ({pace*100:.0f}% of month, so ~{pace*100:.0f}% = on pace). "
                f"Ach% = sales vs target; Ach% LF = seats sold vs the 90%-LF ticket target. "
                f"Right block = each zone's monthly GROSS (cr) + 12-mo avg + trend (avg of last 3 of the 12 months vs avg of first 3). "
                f"Amounts NET (balance − commission) unless marked Gross."
                + (" THIS SHEET EXCLUDES ALL OTA AGENCIES — every column (baseline, target, "
                   "achieved, monthly gross) is recomputed from non-OTA sales only. Targets use "
                   "the SAME network rate as the full sheet, so a zone's target here is smaller "
                   "by exactly its OTA share rather than being re-spread over the agencies that "
                   "remain. A zone can show a SLIGHTLY HIGHER target here than on the full "
                   "sheet when its OTA rows were net negative over the baseline window "
                   "(refunds exceeding sales) — removing a negative raises the baseline."
                   if exclude_ota else ""),
         size=9.5,color=GREY_T,wrap=True); ws.merge_cells("A2:Q2"); ws.row_dimensions[2].height=42
    Z=zone_achievement_frame(d,exclude_ota=exclude_ota)
    zl=d.get('zlabels',{})
    gr={s:d['yld_gross'][s]/d['yld'][s] for s in ['Domestic','International']}   # net->gross per sector
    # per-zone monthly GROSS (cr) trend, merged in so this is the SINGLE master sheet
    zm=(d.get('zone_monthly_ex_ota') if exclude_ota else None)
    if zm is None: zm=d.get('zone_monthly')
    piv=(zm.pivot_table(index='zone',columns='ym',values='gross_cr',aggfunc='sum').fillna(0.0)
         if zm is not None and len(zm) else None)
    months=sorted(piv.columns) if piv is not None else []
    nmon=len(months)
    def mseries(zn):
        if piv is None or zn not in piv.index: return [0.0]*nmon
        return [float(piv.loc[zn,m]) for m in months]
    def mstats(series):
        """12-mo avg (EXCLUDING the partial current month) + 3mo-vs-3mo trend."""
        h=series[:-1] if len(series)>1 else series         # drop current (partial) month
        avg=sum(h)/len(h) if h else 0.0
        f3,l3=h[:3],h[-3:]
        fa=sum(f3)/len(f3) if f3 else 0.0; la=sum(l3)/len(l3) if l3 else 0.0
        return avg,((la/fa-1) if fa else None)
    AVG_C=18+nmon; TR_C=19+nmon
    # grouped header bands (row 4) — base blocks + the monthly trend block
    bands=[("",1,3,NAVY),("BASELINE (avg/mo)",4,6,BLUE_MED),((f"{MONTH_LBL.upper()} TARGET"),7,11,NAVY),
           ((f"ACHIEVED ({MON3} 1-%d)")%jd,12,16,BLUE_MED),("Cap",17,17,NAVY),
           ("MONTHLY GROSS (cr)  ·  12-mo avg  ·  trend (last 3mo vs first 3mo)",18,TR_C,BLUE_MED)]
    for lab,a,b,fl in bands:
        ws.merge_cells(start_row=4,start_column=a,end_row=4,end_column=b)
        cell(ws,4,a,lab,bold=True,size=9,color=WHITE,fill=fl,align="center",border=True)
    subs=(["Zone","Area","Sales Person","Tkt Dom","Tkt Intl","Sales\n(cr)",
           "Dom\n(cr)","Intl\n(cr)","Total\n(cr)","Total Gross\n(cr)","Tickets",
           "Tickets","Sales\n(cr)","Sales Gross\n(cr)","Ach\n%","Ach% LF\n(seats)","Fill\n%"]
          + months + ["12-mo\nAvg (cr)","Trend\n3v3"])
    widths=[10,20,14,7,7,7,7,7,8,9,7,7,8,9,7,8,6]+[7]*nmon+[8,8]
    for j,(h,w) in enumerate(zip(subs,widths),1):
        cell(ws,5,j,h,bold=True,size=8.5,color=NAVY,fill=BLUE_LIGHT,align="center",wrap=True,border=True)
        ws.column_dimensions[get_column_letter(j)].width=w
    ws.row_dimensions[5].height=28; ws.freeze_panes="D6"
    data_top=6; r=6
    for zn,x in Z.iterrows():
        stripe=GREY_L if r%2==0 else None
        area,sp=zl.get(zn, CHANNEL_LABEL.get(zn,("","")))
        ttg=x['td']*gr['Domestic']+x['ti']*gr['International']           # target gross (yield gross-up)
        ser=mseries(zn); avg,tr=mstats(ser)
        sng=ser[-1] if ser else 0.0                                      # achieved gross = ACTUAL current-month topline (ties to the trend's last column)
        achlf=(x['stk']/x['ttk']) if x['ttk'] else 0.0                   # % of the 90%-LF seat target filled
        base=[zn,area,sp,x['btd'],x['bti'],x['bs'],x['td'],x['ti'],x['tt'],ttg,x['ttk'],
              x['stk'],x['sn'],sng,x['ach'],achlf,x['cap']]
        bfmt=[None,None,None,F_INT,F_INT,'#,##0.0',F_CR,F_CR,F_CR,F_CR,F_INT,
              F_INT,F_CR,F_CR,"0.0%","0.0%","0.0%"]   # 1-decimal % to match the requested layout
        for j,(v,fm) in enumerate(zip(base,bfmt),1):
            cell(ws,r,j,v,fmt=fm,align="left" if j<=3 else "center",size=9,
                 bold=(j in (1,9)),color=NAVY if j==1 else BLACK,fill=stripe,border=True,wrap=(j==2))
        ws.cell(r,15).fill=PatternFill("solid",fgColor=(GREEN_F if x['ach']>=pace else AMBER_F if x['ach']>=pace*0.6 else RED_F))
        for k,val in enumerate(ser):
            cell(ws,r,18+k,val,fmt=F_CR,align="center",size=8.5,fill=stripe,border=True)
        cell(ws,r,AVG_C,avg,fmt=F_CR,align="center",size=9,fill=stripe,border=True)
        if tr is None:
            cell(ws,r,TR_C,"new",align="center",size=8,color=GREY_T,fill=stripe,border=True)
        else:
            cell(ws,r,TR_C,tr,fmt="0.0%",align="center",size=9,fill=stripe,border=True)
        r+=1
    # TOTAL
    tot=Z.sum()
    ttg=tot['td']*gr['Domestic']+tot['ti']*gr['International']
    totser=[sum(mseries(zn)[k] for zn in Z.index) for k in range(nmon)]
    tavg,ttr=mstats(totser)
    sng=totser[-1] if totser else 0.0                                    # achieved gross TOTAL = actual current-month topline
    achlf=(tot['stk']/tot['ttk']) if tot['ttk'] else 0.0
    cell(ws,r,1,"TOTAL",bold=True,color=WHITE,fill=NAVY,border=True)
    for cc in (2,3): cell(ws,r,cc,"",fill=NAVY,border=True)
    tvals=[(4,tot['btd'],F_INT),(5,tot['bti'],F_INT),(6,tot['bs'],'#,##0.0'),(7,tot['td'],F_CR),(8,tot['ti'],F_CR),
           (9,tot['tt'],F_CR),(10,ttg,F_CR),(11,tot['ttk'],F_INT),(12,tot['stk'],F_INT),(13,tot['sn'],F_CR),
           (14,sng,F_CR),(15,(tot['sn']/tot['tt'] if tot['tt'] else 0),"0.0%"),(16,achlf,"0.0%"),(17,tot['cap'],"0.0%")]
    for cc,v,fm in tvals:
        cell(ws,r,cc,v,fmt=fm,bold=True,color=WHITE,fill=NAVY,align="center",border=True)
    for k,val in enumerate(totser):
        cell(ws,r,18+k,val,fmt=F_CR,bold=True,color=WHITE,fill=NAVY,align="center",border=True)
    cell(ws,r,AVG_C,tavg,fmt=F_CR,bold=True,color=WHITE,fill=NAVY,align="center",border=True)
    cell(ws,r,TR_C,ttr,fmt="0.0%",bold=True,color=WHITE,fill=NAVY,align="center",border=True)
    # red→amber→green colour scale across the monthly grid (visual trend)
    try:
        from openpyxl.formatting.rule import ColorScaleRule
        ws.conditional_formatting.add(
            f"{get_column_letter(18)}{data_top}:{get_column_letter(17+nmon)}{r-1}",
            ColorScaleRule(start_type='min',start_color='FFC7CE',mid_type='percentile',mid_value=50,
                           mid_color='FFEB9C',end_type='max',end_color='C6EFCE'))
    except Exception:  # noqa: BLE001 — colour scale is cosmetic
        pass
    r+=2
    c=d.get("cur") or {}
    ws.merge_cells(start_row=r,start_column=1,end_row=r+1,end_column=14)
    cell(ws,r,1,f"Sold {tot['sn']:,.0f} cr in {jd} days = {tot['sn']/tot['tt']*100:.0f}% of the {tot['tt']:.0f} cr target — on pace. "
                f"Forward seat bookings: {c.get('total_lf',0)*100:.0f}% all-{MON3} (incl. flown {c.get('flown_lf',0)*100:.0f}%); "
                f"seats still to sell are {c.get('upcoming_lf',0)*100:.0f}% booked — that's the real gap.",size=9.5,color=GREY_T,wrap=True)
    # --- Seats / Booked now / Current fill — the seat inventory behind the target.
    # Zones are sales territories (their agents sell across many routes), so seats
    # and fill can only be shown by SECTOR, not per zone. Same source as Load Factor.
    r+=3
    capf=d.get('cap')
    if capf is not None and 'Domestic' in capf.index:
        cell(ws,r,1,f"SEATS BEHIND THE TARGET  (capacity is by route/sector, not by zone — {CUT_LBL} snapshot)",
             bold=True,size=11,color=NAVY); ws.merge_cells(start_row=r,start_column=1,end_row=r,end_column=6); r+=1
        for j,h in enumerate(["Sector","Seats","Booked now","Current fill","Seats to sell"],1):
            cell(ws,r,j,h,bold=True,size=10,color=NAVY,fill=BLUE_LIGHT,align="center",border=True)
        r+=1
        def crow(rr,lab,cc,bb,fill):
            totrow=(lab=="TOTAL"); fc=WHITE if totrow else BLACK
            cell(ws,rr,1,lab,bold=totrow,size=10,color=fc,fill=fill,border=True)
            cell(ws,rr,2,int(cc),fmt=F_INT,align="center",bold=totrow,color=fc,fill=fill,border=True)
            cell(ws,rr,3,int(bb),fmt=F_INT,align="center",bold=totrow,color=fc,fill=fill,border=True)
            v=bb/cc if cc else 0
            cell(ws,rr,4,v,fmt=F_PCT,align="center",bold=totrow,color=fc,
                 fill=(fill if totrow else (RED_F if v<0.5 else AMBER_F if v<0.8 else GREEN_F)),border=True)
            cell(ws,rr,5,int(cc-bb),fmt=F_INT,align="center",bold=totrow,color=fc,fill=fill,border=True)
        tc=tb=0.0
        for i,sec in enumerate(['Domestic','International']):
            cc=float(capf.loc[sec,'cap']); bb=float(capf.loc[sec,'booked']); tc+=cc; tb+=bb
            crow(r,sec,cc,bb,WHITE if i==0 else GREY_L); r+=1
        crow(r,"TOTAL",tc,tb,NAVY); r+=2
        cell(ws,r,1,"A zone's agents sell across many routes, so seats/fill can't be split by zone — shown by sector above.",
             size=9,italic=True,color=GREY_T); ws.merge_cells(start_row=r,start_column=1,end_row=r,end_column=6); r+=2
    # --- TARGET BY BASIS: net, gross & a separate total WITHOUT Web/Mobile/Counter ---
    gr={s:d['yld_gross'][s]/d['yld'][s] for s in ['Domestic','International']}
    def tg(block): return block['td'].sum()*gr['Domestic']+block['ti'].sum()*gr['International']
    dmask=Z.index.isin(['Z-Counter','Z-Web','Z-Mobi App'])
    cell(ws,r,1,"TARGET BY BASIS — net, gross & a separate total without Web/Mobile/Counter",bold=True,size=11,color=NAVY)
    ws.merge_cells(start_row=r,start_column=1,end_row=r,end_column=9); r+=1
    for (c0,c1),h in [((1,4),"Channel"),((5,6),"Net (cr)"),((7,9),"Gross-Ticket Pmt (cr)")]:
        ws.merge_cells(start_row=r,start_column=c0,end_row=r,end_column=c1)
        cell(ws,r,c0,h,bold=True,size=9.5,color=NAVY,fill=BLUE_LIGHT,align="center",border=True)
    r+=1
    brows=[("All channels",Z['tt'].sum(),tg(Z),None),
           ("less Web / Mobile / Counter",-Z.loc[dmask,'tt'].sum(),-tg(Z.loc[dmask]),GREY_L),
           ("★ Excl. direct — agents / agencies only",Z.loc[~dmask,'tt'].sum(),tg(Z.loc[~dmask]),AMBER_F)]
    for lab,nv,gv,fl in brows:
        star=lab.startswith("★")
        ws.merge_cells(start_row=r,start_column=1,end_row=r,end_column=4)
        cell(ws,r,1,lab,bold=star,size=10,color=AMBER_T if star else NAVY,fill=fl,border=True)
        ws.merge_cells(start_row=r,start_column=5,end_row=r,end_column=6)
        cell(ws,r,5,nv,fmt=F_CR,align="center",bold=star,color=AMBER_T if star else BLACK,fill=fl,border=True)
        ws.merge_cells(start_row=r,start_column=7,end_row=r,end_column=9)
        cell(ws,r,7,gv,fmt=F_CR,align="center",bold=star,color=AMBER_T if star else BLUE_MED,fill=fl,border=True)
        r+=1
    r+=2
    # WHY THE NUMBER MOVED. Built on the FULL book, so it is rendered on the full sheet only:
    # dropping it under the OTA-excluded table would put figures there that quietly disagree
    # with every row above them, which is worse than not having the section at all.
    if exclude_ota:
        cell(ws,r,1,"WHY THE NUMBER MOVED — this diagnostic is on the main "
                    "'Target vs Achievement' sheet. It is computed on the full book including "
                    "OTAs, so showing it here would contradict the OTA-excluded rows above.",
             size=9.5,color=GREY_T,italic=True,wrap=True)
        ws.merge_cells(start_row=r,start_column=1,end_row=r+1,end_column=12)
    else:
        s_why_moved(ws,d,r)


def mom_bridge(frame: "pd.DataFrame", top: int | None = None) -> "pd.DataFrame":
    """One row per grain value with last month, this month and WHY the two differ.

    THE DECOMPOSITION IS THE POINT. Revenue can only fall two ways, and they need opposite
    responses: fewer seats sold, or the same seats sold for less. Net alone hides which, so a
    zone down 12% reads the same whether its agents stopped selling or its fares were cut, and
    the meeting argues about it instead of acting.

        change  =  (tickets_now - tickets_then) x rate_then     <- VOLUME
                +  tickets_now x (rate_now - rate_then)         <- RATE

    The two terms sum to the change exactly, by construction, so the table always reconciles.

    IT IS COMPUTED PER SECTOR AND THEN ADDED, NEVER ON THE BLEND. An international ticket earns
    about 42,000 net and a domestic one about 6,200, so a month that simply sells a bit less
    international and the same domestic shows a large fall in BLENDED net per ticket while no
    price anywhere has moved. Done on the blend, the network TOTAL reported 30.6 cr of "rate"
    damage that was pure mix, and the two sector rows above it added to a different number than
    the total, which is the kind of thing a reader spots and then stops trusting the sheet over.
    Splitting each sector on its own rate and summing keeps the identity and leaves mix where it
    belongs, inside volume.

    RATE IS NET PER TICKET, NOT FARE. Net carries refunds, voids and penalties while the ticket
    count carries only ticket-payment rows, so this figure falls when CANCELLATIONS rise just as
    it does when prices drop. That is a feature (a wave of refunds is exactly the kind of thing
    this section exists to surface) but it must be read as "net earned per ticket sold", and the
    sheet says so.
    """
    cols=["grain","prv","cur","chg","pct","vol","rate","tprv","tcur","rprv","rcur","driver"]
    if frame is None or not len(frame):
        return pd.DataFrame(columns=cols)
    f=frame.copy()
    if "sector" not in f.columns:
        f["sector"]="all"
    # A NULL sector must NOT make the row disappear. pivot_table drops NaN group keys silently,
    # so a single unclassified row took its money out of the bridge with nothing to show for it
    # and the sector rows no longer added to the total.
    f["sector"]=f["sector"].fillna("unclassified").replace("", "unclassified")
    f["grain"]=f["grain"].fillna("(blank)")
    # FLATTEN THE PIVOT IMMEDIATELY. pivot_table over two value columns returns a MultiIndex,
    # and reset_index() turns the added columns into ('_vol','') tuples that a named groupby.agg
    # then cannot find. Plain column names keep the rest of this function readable.
    p=f.pivot_table(index=["grain","sector"],columns="win",values=["net","tickets"],
                    aggfunc="sum").fillna(0.0)
    p.columns=[f"{a}_{b}" for a,b in p.columns]
    for c in ("net_prv","net_cur","tickets_prv","tickets_cur"):
        if c not in p.columns:
            p[c]=0.0
    p=p.reset_index()
    p["_rp"]=[(n/t if t else 0.0) for n,t in zip(p.net_prv,p.tickets_prv)]
    p["_rc"]=[(n/t if t else 0.0) for n,t in zip(p.net_cur,p.tickets_cur)]
    p["_vol"]=(p.tickets_cur-p.tickets_prv)*p["_rp"]/CR
    p["_rate"]=p.tickets_cur*(p["_rc"]-p["_rp"])/CR
    g=p.groupby("grain").agg(_np=("net_prv","sum"), _nc=("net_cur","sum"),
                             _tp=("tickets_prv","sum"), _tc=("tickets_cur","sum"),
                             _v=("_vol","sum"), _r=("_rate","sum"))
    out=[]
    for gname,x in g.iterrows():
        prv=float(x["_np"])/CR; cur=float(x["_nc"])/CR
        tp=float(x["_tp"]); tc=float(x["_tc"])
        # Displayed net/ticket stays the blended figure, because that is the number a reader
        # can check against the two columns beside it. The SPLIT is what is done per sector.
        rp=(prv*CR/tp) if tp else 0.0
        rc=(cur*CR/tc) if tc else 0.0
        vol=float(x["_v"]); rate=float(x["_r"]); chg=cur-prv
        g_=gname
        # Which term actually explains the move. Ties and near-zero moves are called "flat"
        # rather than forced into one bucket, because naming a driver for noise is how a
        # diagnostic sheet starts being ignored.
        if abs(chg)<0.05:
            drv="flat"
        elif tp and not tc:
            drv="STOPPED"
        elif not tp and tc:
            drv="NEW"
        else:
            drv=("volume" if abs(vol)>=abs(rate) else "net/ticket")
        out.append(dict(grain=str(g_),prv=prv,cur=cur,chg=chg,
                        pct=(chg/prv if prv else None),vol=vol,rate=rate,
                        tprv=tp,tcur=tc,rprv=rp,rcur=rc,driver=drv))
    df=pd.DataFrame(out,columns=cols).sort_values("chg")
    if top:
        df=pd.concat([df.head(top), df.tail(top)]).drop_duplicates("grain")
    return df


def s_why_moved(ws, d, r: int) -> int:
    """The diagnostic block under the achievement table: what moved, and what drove it.

    Standing request (2026-08-31): this section is ALWAYS built, so the growth or decline behind
    a target is read off the sheet rather than reconstructed by hand every month.
    """
    (clo,chi),(plo,phi),n = d.get("mom_window",(("",""),("",""),0))
    zf=mom_bridge(d.get("mom_zone"))
    if not len(zf):
        cell(ws,r,1,"WHY THE NUMBER MOVED — not available: the warehouse holds no prior-month "
                    "window to compare against.",bold=True,size=11,color=GREY_T)
        return r+2
    cur_lbl=f"{clo[5:7]}/{clo[8:10]}-{chi[8:10]}"; prv_lbl=f"{plo[5:7]}/{plo[8:10]}-{phi[8:10]}"
    cell(ws,r,1,f"WHY THE NUMBER MOVED — this month against last, SAME DAYS ELAPSED "
                f"({cur_lbl} vs {prv_lbl}, {n} days each)",bold=True,size=12,color=NAVY)
    ws.merge_cells(start_row=r,start_column=1,end_row=r,end_column=13); r+=1
    cell(ws,r,1,"Both windows are cut at the same day number, so none of this is an artefact of "
                "the month being part-done. Every change is split into the only two things that "
                "can cause it: VOLUME (we sold more or fewer tickets) and NET/TICKET (each "
                "ticket earned more or less). The two always sum to the change. Net/ticket is "
                "net revenue per ticket sold, NOT the fare: net carries refunds, voids and "
                "penalties, so this column also falls when CANCELLATIONS rise. Read a big "
                "negative net/ticket with no volume drop as a refund wave, not a price cut. "
                "The split is worked out SEPARATELY FOR DOMESTIC AND INTERNATIONAL and then "
                "added, because an international ticket earns about seven times a domestic one, "
                "so selling a different MIX of the two would otherwise read as a fare change "
                "that never happened. Amounts are NET cr.",
         size=9,color=GREY_T,wrap=True)
    ws.merge_cells(start_row=r,start_column=1,end_row=r+1,end_column=13)
    ws.row_dimensions[r].height=30; r+=3

    HEADS=[("",22),("Last month\n(cr)",11),("This month\n(cr)",11),("Change\n(cr)",10),
           ("Change\n%",9),("of which\nVOLUME",10),("of which\nNET/TKT",10),
           ("Tickets\nlast",9),("Tickets\nnow",9),("Net/tkt\nlast",10),("Net/tkt\nnow",10),
           ("What drove\nit",12)]

    def _head(rr,title,note=""):
        cell(ws,rr,1,title,bold=True,size=10.5,color=NAVY)
        if note:
            cell(ws,rr,4,note,size=8.5,color=GREY_T,italic=True)
        rr+=1
        for j,(h,w) in enumerate(HEADS,1):
            cell(ws,rr,j,h,bold=True,size=8.5,color=NAVY,fill=BLUE_LIGHT,align="center",
                 wrap=True,border=True)
            if ws.column_dimensions[get_column_letter(j)].width in (None,0):
                ws.column_dimensions[get_column_letter(j)].width=w
        ws.row_dimensions[rr].height=26
        return rr+1

    def _row(rr,x,label=None,fill=None,bold=False):
        vals=[label or x["grain"],x["prv"],x["cur"],x["chg"],x["pct"],x["vol"],x["rate"],
              x["tprv"],x["tcur"],x["rprv"],x["rcur"],x["driver"]]
        fmts=[None,F_CR,F_CR,F_CR,"0.0%",F_CR,F_CR,F_INT,F_INT,F_TK,F_TK,None]
        for j,(v,fm) in enumerate(zip(vals,fmts),1):
            cell(ws,rr,j,v,fmt=fm,size=9,bold=bold or j==1,
                 align="left" if j in (1,12) else "center",fill=fill,border=True)
        # Colour the CHANGE cell, not the whole row: the eye should land on the size and sign
        # of the move first, and everything else is the explanation for it.
        ws.cell(rr,4).fill=PatternFill("solid",fgColor=(GREEN_F if x["chg"]>0.05 else
                                                        RED_F if x["chg"]<-0.05 else AMBER_F))
        return rr+1

    # ---- A. the bridge, by sector -------------------------------------------------------
    sec=d["mom_zone"].groupby(["win","sector"],as_index=False)[["net","tickets"]].sum()
    sec["grain"]=sec["sector"]
    sb=mom_bridge(sec)
    r=_head(r,"A.  THE BRIDGE — where the whole movement sits")
    for _,x in sb.sort_values("grain").iterrows():
        r=_row(r,x)
    # TOTAL keeps the SECTOR grain and only collapses the label, so its volume / net-per-ticket
    # split is the sum of the two rows above it. Collapsing the sectors first instead made the
    # total disagree with its own components by 23 cr.
    tot=d["mom_zone"].groupby(["win","sector"],as_index=False)[["net","tickets"]].sum()
    tot["grain"]="TOTAL"
    tb=mom_bridge(tot)
    for _,x in tb.iterrows():
        r=_row(r,x,fill=BLUE_LIGHT,bold=True)
    r+=2

    # ---- B. zones, all of them, worst first ---------------------------------------------
    zl=d.get("zlabels",{})
    r=_head(r,"B.  BY ZONE — every zone, biggest fall first",
            "the zone that lost the most is the first place to look")
    for _,x in zf.iterrows():
        area,sp=zl.get(x["grain"],CHANNEL_LABEL.get(x["grain"],("","")))
        lab=f"{x['grain']}  {sp}".strip() if sp else x["grain"]
        r=_row(r,x,label=lab)
    r+=2

    # ---- C. routes ----------------------------------------------------------------------
    rf=mom_bridge(d.get("mom_route"),top=8)
    if len(rf):
        r=_head(r,"C.  BY ROUTE — the 8 that fell most and the 8 that grew most",
                "route is departure-arrival as flown, both directions listed separately")
        for _,x in rf.iterrows():
            r=_row(r,x)
        r+=2

    # ---- D. agencies: the literal answer to "who worked last month and not this month" ---
    af=mom_bridge(d.get("mom_agency"))
    if len(af):
        # A materiality floor, because the tail is thousands of agencies whose month-to-month
        # noise would bury the twelve that matter. 1 lac of movement either way.
        mat=af[af.chg.abs()>=0.01]
        # SPLIT ON THE SIGN, NOT ON POSITION. `mat` is sorted worst-first, so head(12)/tail(8)
        # overlap whenever fewer than 20 agencies clear the floor -- and then the SAME agency is
        # printed twice, once in red under "not selling this month" and again under "the ones
        # going the other way". With 8 agencies above the floor every one appeared in both
        # blocks and four growers were listed as decliners. mom_bridge() already guards its own
        # head/tail with drop_duplicates for exactly this; this section did the slicing by hand
        # and did not. Sign-based cuts cannot overlap at any list length.
        fell=mat[mat.chg<0].head(12)
        grew=mat[mat.chg>0].sort_values("chg",ascending=False).head(8)
        r=_head(r,"D.  BY AGENCY — who sold last month and is not selling this month",
                "movement of at least 1 lac; STOPPED means they bought last month and nothing "
                "this month")
        for _,x in fell.iterrows():
            r=_row(r,x,fill=(RED_F if x["driver"]=="STOPPED" else None))
        if len(fell) and len(grew):
            cell(ws,r,1,"— and the ones going the other way —",size=9,italic=True,color=GREY_T)
            ws.merge_cells(start_row=r,start_column=1,end_row=r,end_column=12); r+=1
        for _,x in grew.iterrows():
            r=_row(r,x,fill=(GREEN_F if x["driver"]=="NEW" else None))
        r+=1
        stopped=int((af.driver=="STOPPED").sum()); new=int((af.driver=="NEW").sum())
        cell(ws,r,1,f"Across every agency: {stopped:,} bought last month and nothing so far this "
                    f"month, {new:,} are new this month. Only movements of 1 lac or more are "
                    f"listed above.",size=9,color=GREY_T,wrap=True)
        ws.merge_cells(start_row=r,start_column=1,end_row=r,end_column=12); r+=2
    return r


def s_agents(wb,d):
    ws=wb.create_sheet("Agent Targets"); ws.sheet_view.showGridLines=False
    cell(ws,1,1,f"Per-agent {MONTH_LBL} targets (aggressive {d['commit']:,.0f} cr cascaded down)",bold=True,size=14,color=NAVY)
    a=d['agents'].copy()
    a['dom']=a['dom'].fillna(0); a['intl']=a['intl'].fillna(0)
    a=a[(a['dom']>0)|(a['intl']>0)]
    sum_dom=a['dom'].sum()/CR; sum_int=a['intl'].sum()/CR
    dom_f=d['commit_dom']/sum_dom; int_f=d['commit_int']/sum_int   # share-of-total factors
    a['tgt_dom']=a['dom']/CR*dom_f; a['tgt_int']=a['intl']/CR*int_f
    a['tgt_total']=a['tgt_dom']+a['tgt_int']
    a=a.sort_values('tgt_total',ascending=False)
    # calculation note
    cell(ws,2,1,"HOW EACH AGENT'S TARGET IS SET:  take the agent's last-5-months sales, split Domestic vs International, "
                "and give them their SHARE of the sector goal — so a bigger (and more international) recent seller gets a bigger target.",
         size=9.5,color=NAVY,wrap=True); ws.merge_cells("A2:K2"); ws.row_dimensions[2].height=26
    cell(ws,3,1,f"Target Dom = (your 5-mo Domestic ÷ {sum_dom:,.0f} cr all-agents) × 57.7 cr   "
                f"[= 5-mo Dom × {dom_f:.3f}].    "
                f"Target Intl = (your 5-mo Intl ÷ {sum_int:,.0f} cr) × 535.3 cr   [= 5-mo Intl × {int_f:.3f}].",
         size=9,color=GREY_T,italic=True); ws.merge_cells("A3:K3"); ws.row_dimensions[3].height=16
    heads=["#","Zone","Customer ID","Agent Name","Type","Sales Person","5mo Dom\n(cr)","5mo Intl\n(cr)","Target Dom\n(cr)","Target Intl\n(cr)","Target Total\n(cr)"]
    widths=[5,9,11,30,10,18,10,10,11,11,12]
    for j,(h,w) in enumerate(zip(heads,widths),1):
        cell(ws,5,j,h,bold=True,size=9.5,color=NAVY,fill=BLUE_LIGHT,align="center",wrap=True,border=True)
        ws.column_dimensions[get_column_letter(j)].width=w
    ws.row_dimensions[5].height=28
    ws.freeze_panes="A6"
    r=6; idx=1
    for _,x in a.iterrows():
        if x['tgt_total']<0.001: continue
        stripe=GREY_L if idx%2==0 else None
        cell(ws,r,1,idx,align="center",size=9,fill=stripe,border=True)
        cell(ws,r,2,str(x['zone'] or ''),size=9,fill=stripe,border=True)
        cell(ws,r,3,str(x['customer_id'] or ''),size=9,fill=stripe,border=True)
        cell(ws,r,4,str(x['customer_name'] or '')[:44],size=9,fill=stripe,border=True)
        cell(ws,r,5,str(x['agent_type'] or x['channel'] or ''),size=9,fill=stripe,border=True)
        cell(ws,r,6,str(x['sales_person'] or ''),size=9,fill=stripe,border=True)
        cell(ws,r,7,x['dom']/CR,fmt='#,##0.00',align="center",size=9,fill=stripe,border=True)
        cell(ws,r,8,x['intl']/CR,fmt='#,##0.00',align="center",size=9,fill=stripe,border=True)
        cell(ws,r,9,x['tgt_dom'],fmt='#,##0.00',align="center",size=9,fill=stripe,border=True)
        cell(ws,r,10,x['tgt_int'],fmt='#,##0.00',align="center",size=9,fill=stripe,border=True)
        cell(ws,r,11,x['tgt_total'],fmt='#,##0.00',align="center",size=9,bold=True,fill=stripe,border=True)
        r+=1; idx+=1
    cell(ws,r,1,f"TOTAL — {idx-1:,} agents",bold=True,color=WHITE,fill=NAVY,border=True,align="left")
    ws.merge_cells(start_row=r,start_column=1,end_row=r,end_column=6)
    cell(ws,r,7,"",fill=NAVY,border=True); cell(ws,r,8,"",fill=NAVY,border=True)
    cell(ws,r,9,a['tgt_dom'].sum(),fmt=F_CR,bold=True,color=WHITE,fill=NAVY,align="center",border=True)
    cell(ws,r,10,a['tgt_int'].sum(),fmt=F_CR,bold=True,color=WHITE,fill=NAVY,align="center",border=True)
    cell(ws,r,11,a['tgt_total'].sum(),fmt=F_CR,bold=True,color=WHITE,fill=NAVY,align="center",border=True)


def agent_route_frame(d):
    """Per-agent, per-route targets — the math behind the 'Agent Route Target'
    sheet, exposed as a function so the per-sales-person Target Packs reuse EXACTLY
    the same cascade (5-month route sales × sector factor; +growth already inside yld).

    Returns ``(ar, agg, dom_f, int_f)``:
      ar  = display-ready route rows (sorted; cols: customer_id, name, zn, route,
            sector, tickets, net, tgt_tkt, tgt_amt (net cr), tgt_gross (cr), atot)
      agg = per-agent rollup (name, zn, tk5, s5, ttk, tamt, tgr, pct of commit)
      dom_f / int_f = the sector scale factors (for the explanatory subtitle).
    ``ar`` is None when no agent-route data is available.
    """
    ar=d.get('agent_routes')
    if ar is None or not len(ar):
        return None, None, 0.0, 0.0
    ar=ar.copy(); ar=ar[ar['net']>0]
    gr={s:d['yld_gross'][s]/d['yld'][s] for s in ['Domestic','International']}
    sum_dom=ar.loc[ar.sector=='Domestic','net'].sum()/CR; sum_int=ar.loc[ar.sector=='International','net'].sum()/CR
    dom_f=d['commit_dom']/sum_dom if sum_dom else 0; int_f=d['commit_int']/sum_int if sum_int else 0
    ar['scale']=ar['sector'].map({'Domestic':dom_f,'International':int_f}).fillna(0)
    ar['tgt_amt']=ar['net']/CR*ar['scale']; ar['tgt_tkt']=(ar['tickets']*ar['scale']).round().astype(int)
    ar['tgt_gross']=ar['tgt_amt']*ar['sector'].map(gr)
    agg=ar.groupby('customer_id').agg(name=('name','max'),zn=('zn','max'),
        tk5=('tickets','sum'),s5=('net','sum'),ttk=('tgt_tkt','sum'),tamt=('tgt_amt','sum'),tgr=('tgt_gross','sum'))
    agg['pct']=agg['tamt']/d['commit']
    ar=ar.merge(agg[['tamt']].rename(columns={'tamt':'atot'}),on='customer_id')
    ar['domf']=(ar['sector']!='Domestic').astype(int)   # Domestic (0) sorts before International (1)
    ar=ar[ar['tgt_amt']>=0.005].sort_values(['atot','customer_id','domf','tgt_amt'],ascending=[False,True,True,False])
    return ar, agg, dom_f, int_f


BUCKET_KEYS = ("App/Web", "Counter", "Corporate")     # channel rollups, not agencies


def s_agent_routes(wb, d, title="Agent Route Target", only=None):
    """Per-agent route targets — the full sheet, or its OTA / non-OTA cut.

    `only` is None (everything, including the App/Web, Counter and Corporate channel rollups),
    'OTA', or 'NONOTA'. The two cuts carry AGENCY rows ONLY: the channel rollups are not
    agencies, so putting them in both would double-count and putting them in one would inflate
    that cut. Each cut keeps '% of target' measured against the SAME network commit target, so
    the percentages stay comparable across sheets and add up rather than each re-basing to 100%.
    """
    ws=wb.create_sheet(title); ws.sheet_view.showGridLines=False
    cell(ws,1,1,"Agent targets with route breakdown (tickets & sales)"
                + ("" if only is None else f" — {'OTAs only' if only=='OTA' else 'excluding OTAs'}"),
         bold=True,size=14,color=NAVY)
    ar, agg, dom_f, int_f = agent_route_frame(d)
    if ar is None or not len(ar):
        cell(ws,3,1,"No data.",size=10,color=GREY_T); return
    if only is not None:
        ota = set(map(str, d.get('ota_ids') or set()))
        keep = [c for c in agg.index
                if str(c) not in BUCKET_KEYS
                and ((str(c) in ota) if only == 'OTA' else (str(c) not in ota))]
        agg = agg.loc[keep]
        ar = ar[ar['customer_id'].astype(str).isin({str(c) for c in keep})]
        if not len(ar):
            cell(ws,3,1,"No agents in this cut.",size=10,color=GREY_T); return
    _cut_note = ("" if only is None else
                 f" This cut holds {len(agg):,} of the network's agents and "
                 f"{agg['tamt'].sum():.1f} cr of the {d['commit']:.0f} cr target "
                 f"({agg['tamt'].sum()/d['commit']*100:.1f}%).")
    cell(ws,2,1,f"GRAND TOTAL on top. Then each agent (biggest first): a subtotal row with its % of the {d['commit']:.0f} cr target, followed by its routes — "
                f"DOMESTIC first, then International. Each route target = 5-month route sales × sector factor (Dom ×{dom_f:.3f}, Intl ×{int_f:.3f}). "
                f"{len(agg):,} agents.{_cut_note}",size=9.5,color=NAVY,wrap=True); ws.merge_cells("A2:J2"); ws.row_dimensions[2].height=30
    heads=["#","Agent / Route","Zone","Sector","5mo\nTickets","5mo Sales\n(cr)","Target\nTickets","Target Net\n(cr)","% of\ntarget","Target Gross\n(cr)"]
    widths=[5,34,9,12,10,11,10,12,8,12]
    for j,(h,w) in enumerate(zip(heads,widths),1):
        cell(ws,3,j,h,bold=True,size=9.5,color=NAVY,fill=BLUE_LIGHT,align="center",wrap=True,border=True)
        ws.column_dimensions[get_column_letter(j)].width=w
    ws.row_dimensions[3].height=28; ws.freeze_panes="A4"
    # GRAND TOTAL on top
    r=4
    cell(ws,r,1,"",fill=AMBER_F,border=True)
    cell(ws,r,2,"GRAND TOTAL — " + ("all agents" if only is None else
                ("OTA agents only" if only=='OTA' else "agents excluding OTAs")),
         bold=True,size=10.5,color=NAVY,fill=AMBER_F,border=True)
    for cc in (3,4): cell(ws,r,cc,"",fill=AMBER_F,border=True)
    cell(ws,r,5,int(agg['tk5'].sum()),fmt=F_INT,align="center",bold=True,fill=AMBER_F,border=True)
    cell(ws,r,6,agg['s5'].sum()/CR,fmt=F_CR,align="center",bold=True,fill=AMBER_F,border=True)
    cell(ws,r,7,int(agg['ttk'].sum()),fmt=F_INT,align="center",bold=True,fill=AMBER_F,border=True)
    cell(ws,r,8,agg['tamt'].sum(),fmt=F_CR,align="center",bold=True,color=NAVY,fill=AMBER_F,border=True)
    cell(ws,r,9,(1.0 if only is None else agg['tamt'].sum()/d['commit']),
         fmt=F_PCT,align="center",bold=True,fill=AMBER_F,border=True)
    cell(ws,r,10,agg['tgr'].sum(),fmt=F_CR,align="center",bold=True,color=NAVY,fill=AMBER_F,border=True)
    r+=1; idx=1; prev=None
    for _,x in ar.iterrows():
        cid=x['customer_id']
        if cid!=prev:
            prev=cid; a=agg.loc[cid]
            cell(ws,r,1,idx,align="center",size=9,bold=True,fill=BLUE_LIGHT,border=True)
            cell(ws,r,2,str(a['name'] or '')[:42],bold=True,size=9.5,color=NAVY,fill=BLUE_LIGHT,border=True)
            cell(ws,r,3,str(a['zn'] or ''),size=9,fill=BLUE_LIGHT,border=True)
            cell(ws,r,4,"",fill=BLUE_LIGHT,border=True)
            cell(ws,r,5,int(a['tk5']),fmt=F_INT,align="center",size=9,bold=True,fill=BLUE_LIGHT,border=True)
            cell(ws,r,6,a['s5']/CR,fmt='#,##0.00',align="center",size=9,bold=True,fill=BLUE_LIGHT,border=True)
            cell(ws,r,7,int(a['ttk']),fmt=F_INT,align="center",size=9,bold=True,fill=BLUE_LIGHT,border=True)
            cell(ws,r,8,a['tamt'],fmt='#,##0.00',align="center",size=9,bold=True,color=NAVY,fill=BLUE_LIGHT,border=True)
            cell(ws,r,9,a['pct'],fmt='0.00%',align="center",size=9,bold=True,fill=BLUE_LIGHT,border=True)
            cell(ws,r,10,a['tgr'],fmt='#,##0.00',align="center",size=9,bold=True,color=BLUE_MED,fill=BLUE_LIGHT,border=True)
            idx+=1; r+=1
        cell(ws,r,1,"",border=True)
        cell(ws,r,2,"      "+str(x['route'] or ''),size=9,color=NAVY,border=True)
        cell(ws,r,3,"",border=True)
        cell(ws,r,4,x['sector'],size=9,border=True)
        cell(ws,r,5,int(x['tickets']),fmt=F_INT,align="center",size=9,border=True)
        cell(ws,r,6,x['net']/CR,fmt='#,##0.00',align="center",size=9,border=True)
        cell(ws,r,7,int(x['tgt_tkt']),fmt=F_INT,align="center",size=9,border=True)
        cell(ws,r,8,x['tgt_amt'],fmt='#,##0.00',align="center",size=9,border=True)
        cell(ws,r,9,"",border=True)
        cell(ws,r,10,x['tgt_gross'],fmt='#,##0.00',align="center",size=9,color=BLUE_MED,border=True)
        r+=1
    # excl. direct channels (App/Web + Counter) totals row — net & gross.
    # Only meaningful on the full sheet: the cuts already exclude every channel rollup.
    if only is not None:
        return
    dmask=agg['name'].astype(str).isin(['App/Web','Counter']) | agg.index.isin(['App/Web','Counter'])
    en=agg.loc[~dmask,'tamt'].sum(); eg=agg.loc[~dmask,'tgr'].sum(); etk=int(agg.loc[~dmask,'ttk'].sum())
    cell(ws,r,1,"",fill=AMBER_F,border=True)
    cell(ws,r,2,"★ EXCL. App/Web + Counter (agents/agencies only)",bold=True,size=10,color=AMBER_T,fill=AMBER_F,border=True)
    for cc in (3,4,5): cell(ws,r,cc,"",fill=AMBER_F,border=True)
    cell(ws,r,6,"",fill=AMBER_F,border=True)
    cell(ws,r,7,etk,fmt=F_INT,align="center",bold=True,color=AMBER_T,fill=AMBER_F,border=True)
    cell(ws,r,8,en,fmt=F_CR,align="center",bold=True,color=AMBER_T,fill=AMBER_F,border=True)
    cell(ws,r,9,en/d['commit'],fmt=F_PCT,align="center",bold=True,color=AMBER_T,fill=AMBER_F,border=True)
    cell(ws,r,10,eg,fmt=F_CR,align="center",bold=True,color=AMBER_T,fill=AMBER_F,border=True)
    r+=1


def s_loadfactor(wb,d):
    ws=wb.create_sheet("Load Factor"); ws.sheet_view.showGridLines=False
    cur=d.get('cur')
    cell(ws,1,1,f"{MONTH_LBL} {TARGET_YEAR} Load Factor — by flight & date ({CUT_LBL} snapshot)",bold=True,size=14,color=NAVY)
    if not cur:
        cell(ws,3,1,"No flight-load snapshot available.",size=10,color=GREY_T); return
    cell(ws,2,1,"Load Factor = booked seats / capacity, shown per flight per day. Each new flight-date is a column to the RIGHT. "
                f"Cell colour: red <50%, amber 50-80%, green >=80%. {MON3} 1-{_CUT_DAY} already flew; later dates are still filling.",
         size=9.5,color=NAVY,wrap=True); ws.merge_cells("A2:H2"); ws.row_dimensions[2].height=30
    spr=cur.get('sector_period'); spd={}
    if spr is not None:
        for (sec,flown),row in spr.iterrows(): spd[(sec,bool(flown))]=(float(row['cap']),float(row['booked']))
    def lf(sec,p):
        if p=='whole': c=sum(spd.get((sec,f),(0,0))[0] for f in (True,False)); b=sum(spd.get((sec,f),(0,0))[1] for f in (True,False))
        elif p=='flown': c,b=spd.get((sec,True),(0,0))
        else: c,b=spd.get((sec,False),(0,0))
        return (b/c if c else 0),c,b
    cell(ws,4,1,"HOW FULL ARE THE PLANES?",bold=True,size=12,color=NAVY)
    # Utilization Achieved = booked load factor ÷ the 90% target LF (OPTIMAL_LF).
    # 100% utilization means the planes are filled to the 90% goal; below 100% =
    # seats still to sell against target. (analyst request 2026-06-14)
    util_heads=["Period","Domestic","International","All (Total)","Utilization\n(LF ÷ 90%)","Seats","Booked"]
    for j,(h,w) in enumerate(zip(util_heads,[27,12,14,12,13,12,12]),1):
        cell(ws,5,j,h,bold=True,size=9.5,color=NAVY,fill=BLUE_LIGHT,align="center",border=True); ws.column_dimensions[get_column_letter(j)].width=w
    r=6
    for lab,p,fl in [(f"Whole {MONTH_LBL} (all flights)","whole",AMBER_F),(f"Flown ({MON3} 1-{_CUT_DAY}, already gone)","flown",GREY_L),(f"★ STILL TO SELL ({SELL_LBL})","up",GREEN_F)]:
        dlf,dc,db=lf('Domestic',p); ilf,ic,ib=lf('International',p); tc=dc+ic; tb=db+ib
        tot_lf=tb/tc if tc else 0; util=tot_lf/OPTIMAL_LF if OPTIMAL_LF else 0
        cell(ws,r,1,lab,bold=True,size=10,color=AMBER_T if lab.startswith("★") else NAVY,fill=fl,border=True)
        cell(ws,r,2,dlf,fmt=F_PCT,align="center",fill=fl,border=True)
        cell(ws,r,3,ilf,fmt=F_PCT,align="center",fill=fl,border=True)
        cell(ws,r,4,tot_lf,fmt=F_PCT,align="center",bold=True,fill=fl,border=True)
        cell(ws,r,5,util,fmt=F_PCT,align="center",bold=True,
             color=(AMBER_T if lab.startswith("★") else NAVY),fill=fl,border=True)
        cell(ws,r,6,int(tc),fmt=F_INT,align="center",fill=fl,border=True)
        cell(ws,r,7,int(tb),fmt=F_INT,align="center",fill=fl,border=True); r+=1
    r+=1
    # --- the by-flight x by-date matrix (each later flight-date = a column to the RIGHT) ---
    fl=cur.get('flights')
    if fl is None or len(fl)==0:
        return
    import datetime as _dt
    fl=fl.copy(); fl['lf']=fl['booked']/fl['cap'].replace(0,1)
    dates=sorted(x for x in fl['date'].unique())
    ident=(fl.groupby(['sector','route','flight'])
             .agg(cap=('cap','max'),ac=('aircraft','first'),std=('std','first'),
                  bk=('booked','sum'),cp=('cap','sum')).reset_index())
    ident['mlf']=ident['bk']/ident['cp'].replace(0,1)
    lfmat=fl.pivot_table(index=['sector','route','flight'],columns='date',values='lf',aggfunc='mean')
    cell(ws,r,1,"LOAD FACTOR BY FLIGHT & DATE  (scroll right for later dates)",bold=True,size=12,color=NAVY); r+=1
    hr=r
    cell(ws,hr,1,"#",bold=True,size=9,color=NAVY,fill=BLUE_LIGHT,align="center",border=True); ws.column_dimensions['A'].width=4
    for j,(h,w) in enumerate(zip(["Flight","Leg / Sector","Aircraft","Cap","STD","Month\nLF"],[10,15,12,6,8,8]),2):
        cell(ws,hr,j,h,bold=True,size=9,color=NAVY,fill=BLUE_LIGHT,align="center",wrap=True,border=True)
        ws.column_dimensions[get_column_letter(j)].width=w
    d0=8
    for k,dt in enumerate(dates):
        dd=dt if isinstance(dt,_dt.date) else _dt.date.fromisoformat(str(dt))
        cell(ws,hr,d0+k,f"{dd.day}\n{dd.strftime('%a')}",bold=True,size=8,color=NAVY,fill=BLUE_LIGHT,align="center",wrap=True,border=True)
        ws.column_dimensions[get_column_letter(d0+k)].width=5.4
    ws.row_dimensions[hr].height=26; ws.freeze_panes=ws.cell(hr+1,d0).coordinate
    r=hr+1
    def lfcell(rr,col,v):
        if v is None or (isinstance(v,float) and v!=v):       # NaN/none -> blank (no flight that day)
            cell(ws,rr,col,"",size=8,border=True); return
        cell(ws,rr,col,v,fmt='0%',align="center",size=8,
             fill=(RED_F if v<0.5 else AMBER_F if v<0.8 else GREEN_F),border=True)
    def daily_row(rr,sub):                                    # per-date fill across one row
        g=sub.groupby('date').agg(b=('booked','sum'),c=('cap','sum'))
        for k,dt in enumerate(dates):
            v=(g.loc[dt,'b']/g.loc[dt,'c']) if (dt in g.index and g.loc[dt,'c']) else None
            lfcell(rr,d0+k,v)
    # grand-total daily fill row
    cell(ws,r,2,"ALL FLIGHTS — daily fill",bold=True,size=9.5,color=WHITE,fill=NAVY,border=True)
    for cc in (1,3,4,5,6): cell(ws,r,cc,"",fill=NAVY,border=True)
    cell(ws,r,7,fl['booked'].sum()/fl['cap'].sum(),fmt='0%',align="center",bold=True,size=9,color=WHITE,fill=NAVY,border=True)
    daily_row(r,fl); r+=1
    idx=1
    for sec in ['Domestic','International']:
        sf=fl[fl['sector']==sec]
        if len(sf)==0: continue
        cell(ws,r,2,sec.upper(),bold=True,size=10,color=WHITE,fill=BLUE_MED,border=True)
        for cc in (1,3,4,5,6): cell(ws,r,cc,"",fill=BLUE_MED,border=True)
        cell(ws,r,7,sf['booked'].sum()/sf['cap'].sum(),fmt='0%',align="center",bold=True,size=9,color=WHITE,fill=BLUE_MED,border=True)
        daily_row(r,sf); r+=1
        for _,a in ident[ident['sector']==sec].sort_values(['route','flight']).iterrows():
            cell(ws,r,1,idx,align="center",size=8,border=True)
            cell(ws,r,2,a['flight'],size=8.5,bold=True,color=NAVY,border=True)
            cell(ws,r,3,a['route'],size=8.5,border=True)
            cell(ws,r,4,a['ac'],size=8,border=True)
            cell(ws,r,5,int(a['cap']),fmt=F_INT,align="center",size=8,border=True)
            cell(ws,r,6,a['std'],size=8,align="center",border=True)
            mv=a['mlf']
            cell(ws,r,7,mv,fmt='0%',align="center",size=8,bold=True,
                 fill=(RED_F if mv<0.5 else AMBER_F if mv<0.8 else GREEN_F),border=True)
            key=(sec,a['route'],a['flight'])
            row=lfmat.loc[key] if key in lfmat.index else None
            for k,dt in enumerate(dates):
                lfcell(r,d0+k,(row[dt] if row is not None and dt in row.index else None))
            idx+=1; r+=1


def s_road90(wb,d):
    # The TARGET is 90% LF on both sectors. This sheet distributes the seats
    # needed to hit it across every zone (by its historical ticket share).
    ws=wb.create_sheet("Road to 90% LF"); ws.sheet_view.showGridLines=False
    cell(ws,1,1,"The 90% Target — the seat goal & how it spreads by zone",bold=True,size=14,color=NAVY)
    cell(ws,2,1,"The TARGET is 90% load factor on both sectors. Here is the ticket quota each zone must sell to hit it "
                "(split by its own Domestic/International mix), with the NET sale and the "
                "GROSS (Ticket Payment, before commission) it brings. One seat ≈ one ticket ≈ one flown leg.",size=9.5,color=GREY_T,wrap=True)
    ws.merge_cells("A2:H2"); ws.row_dimensions[2].height=32
    cap=d['cap']; yld=d['yld']; yg=d['yld_gross']
    s90={s: cap.loc[s,'cap']*OPTIMAL_LF for s in ['Domestic','International']}
    bkd={s: float(cap.loc[s,'booked']) for s in ['Domestic','International']}
    pk={'Domestic':cap.loc['Domestic','cap']*d['proven_lf']['Domestic'],
        'International':cap.loc['International','cap']*d['proven_lf']['International']}  # proven-peak milestone
    def rev(dd,ii): return (dd*yld['Domestic']+ii*yld['International'])/CR
    def grev(dd,ii): return (dd*yg['Domestic']+ii*yg['International'])/CR     # gross (ticket payment)
    tcap=cap['cap'].sum()
    # --- headline seat ladder (whole network) ---
    cell(ws,4,1,"THE SEAT GOAL (whole network)",bold=True,size=12,color=NAVY)
    for j,(h,w) in enumerate(zip(["Milestone","Load\nfactor","Seats (tickets)","Net sale (cr)","Gross-Ticket\nPmt (cr)"],[30,10,15,13,14]),1):
        cell(ws,5,j,h,bold=True,size=9,color=NAVY,fill=BLUE_LIGHT,align="center",wrap=True,border=True)
        ws.column_dimensions[get_column_letter(j)].width=w
    ws.row_dimensions[5].height=24
    rungs=[(f"Booked now ({CUT_LBL} snapshot)",bkd['Domestic'],bkd['International'],None),
           ("Proven peak (last year's best)",pk['Domestic'],pk['International'],None),
           ("★ TARGET — 90% both sectors",s90['Domestic'],s90['International'],AMBER_F)]
    r=6
    for lab,dd,ii,fl in rungs:
        star=lab.startswith("★"); seats=dd+ii
        cell(ws,r,1,lab,bold=star,size=10,color=AMBER_T if star else NAVY,fill=fl,border=True)
        cell(ws,r,2,seats/tcap,fmt=F_PCT,align="center",bold=star,fill=fl,border=True)
        cell(ws,r,3,int(seats),fmt=F_INT,align="center",bold=star,fill=fl,border=True)
        cell(ws,r,4,rev(dd,ii),fmt=F_CR,align="center",bold=star,fill=fl,border=True)
        cell(ws,r,5,grev(dd,ii),fmt=F_CR,align="center",bold=star,color=(AMBER_T if star else BLUE_MED),fill=fl,border=True); r+=1
    gd=s90['Domestic']-bkd['Domestic']; gi=s90['International']-bkd['International']
    ws.merge_cells(start_row=r,start_column=1,end_row=r,end_column=5)
    cell(ws,r,1,f"STILL TO SELL to reach 90%: {int(gd+gi):,} seats  (Domestic {int(gd):,} + International {int(gi):,}). "
                f"Domestic is the gap — it's only ~{bkd['Domestic']/cap.loc['Domestic','cap']*100:.0f}% booked.",
         bold=True,size=10,color=NAVY,fill=GREEN_F,border=True); r+=2
    # --- distribution by zone (by historical ticket share) ---
    cell(ws,r,1,"HOW THE 90% SEAT GOAL DISTRIBUTES — by zone (each zone's historical ticket share)",bold=True,size=12,color=NAVY); r+=1
    z=d['zone']; zt=z.pivot_table(index='zone',columns='sector',values='tickets',aggfunc='sum').fillna(0)
    for s in ['Domestic','International']:
        if s not in zt: zt[s]=0.0
    TD=zt['Domestic'].sum() or 1; TI=zt['International'].sum() or 1
    zt['sd']=s90['Domestic']*zt['Domestic']/TD; zt['si']=s90['International']*zt['International']/TI
    zt['st']=zt['sd']+zt['si']
    zt['rev']=(zt['sd']*yld['Domestic']+zt['si']*yld['International'])/CR
    zt['grev']=(zt['sd']*yg['Domestic']+zt['si']*yg['International'])/CR
    zt=zt[zt['st']>=1].sort_values('rev',ascending=False)
    heads=["#","Zone","Dom seats","Int seats","Total seats","Net sale (cr)","Gross-Ticket Pmt (cr)","% of goal"]
    for j,(h,w) in enumerate(zip(heads,[5,22,11,11,12,12,14,8]),1):
        cell(ws,r,j,h,bold=True,size=9,color=NAVY,fill=BLUE_LIGHT,align="center",wrap=True,border=True)
        ws.column_dimensions[get_column_letter(j)].width=w
    ws.row_dimensions[r].height=24
    r+=1; ws.freeze_panes=ws.cell(r,1).coordinate
    gtot=zt['st'].sum() or 1; i=1
    for zn,x in zt.iterrows():
        stripe=GREY_L if r%2==0 else None
        cell(ws,r,1,i,align="center",size=9,fill=stripe,border=True)
        cell(ws,r,2,str(zn),size=9.5,color=NAVY,fill=stripe,border=True)
        cell(ws,r,3,int(round(x['sd'])),fmt=F_INT,align="center",size=9,fill=stripe,border=True)
        cell(ws,r,4,int(round(x['si'])),fmt=F_INT,align="center",size=9,fill=stripe,border=True)
        cell(ws,r,5,int(round(x['st'])),fmt=F_INT,align="center",size=9,bold=True,fill=stripe,border=True)
        cell(ws,r,6,x['rev'],fmt=F_CR,align="center",size=9,bold=True,color=NAVY,fill=stripe,border=True)
        cell(ws,r,7,x['grev'],fmt=F_CR,align="center",size=9,color=BLUE_MED,fill=stripe,border=True)
        cell(ws,r,8,x['st']/gtot,fmt=F_PCT,align="center",size=9,fill=stripe,border=True)
        i+=1; r+=1
    cell(ws,r,1,"",fill=NAVY,border=True)
    cell(ws,r,2,"TOTAL — 90% goal",bold=True,color=WHITE,fill=NAVY,border=True)
    cell(ws,r,3,int(round(zt['sd'].sum())),fmt=F_INT,align="center",bold=True,color=WHITE,fill=NAVY,border=True)
    cell(ws,r,4,int(round(zt['si'].sum())),fmt=F_INT,align="center",bold=True,color=WHITE,fill=NAVY,border=True)
    cell(ws,r,5,int(round(zt['st'].sum())),fmt=F_INT,align="center",bold=True,color=WHITE,fill=NAVY,border=True)
    cell(ws,r,6,zt['rev'].sum(),fmt=F_CR,align="center",bold=True,color=WHITE,fill=NAVY,border=True)
    cell(ws,r,7,zt['grev'].sum(),fmt=F_CR,align="center",bold=True,color=WHITE,fill=NAVY,border=True)
    cell(ws,r,8,1.0,fmt=F_PCT,align="center",bold=True,color=WHITE,fill=NAVY,border=True)
    r+=1
    # --- the SAME goal WITHOUT the direct channels (Counter / Web / Mobile) ---
    # Those 3 are the airline's OWN channels; this strips them to leave what the
    # AGENTS / AGENCIES must sell, in net AND gross (ticket payment).
    direct=['Z-Counter','Z-Web','Z-Mobi App']
    dz=zt[zt.index.isin(direct)]
    def srow(lab,sd,si,st,rv,gv,fill,fc):
        cell(ws,r,1,"",fill=fill,border=True)
        cell(ws,r,2,lab,bold=True,size=9.5,color=fc,fill=fill,border=True)
        cell(ws,r,3,int(round(sd)),fmt=F_INT,align="center",size=9,color=fc,fill=fill,border=True)
        cell(ws,r,4,int(round(si)),fmt=F_INT,align="center",size=9,color=fc,fill=fill,border=True)
        cell(ws,r,5,int(round(st)),fmt=F_INT,align="center",size=9,bold=True,color=fc,fill=fill,border=True)
        cell(ws,r,6,rv,fmt=F_CR,align="center",size=9,bold=True,color=fc,fill=fill,border=True)
        cell(ws,r,7,gv,fmt=F_CR,align="center",size=9,bold=True,color=fc,fill=fill,border=True)
        cell(ws,r,8,"",fill=fill,border=True)
    srow("less direct: Counter / Web / Mobile",-dz['sd'].sum(),-dz['si'].sum(),-dz['st'].sum(),
         -dz['rev'].sum(),-dz['grev'].sum(),GREY_L,BLACK); r+=1
    a_st=zt['st'].sum()-dz['st'].sum(); a_rev=zt['rev'].sum()-dz['rev'].sum(); a_grev=zt['grev'].sum()-dz['grev'].sum()
    srow("★ AGENT / AGENCY — excl. Counter / Web / Mobile",zt['sd'].sum()-dz['sd'].sum(),
         zt['si'].sum()-dz['si'].sum(),a_st,a_rev,a_grev,AMBER_F,AMBER_T); r+=1
    ws.merge_cells(start_row=r,start_column=1,end_row=r,end_column=8)
    cell(ws,r,1,f"Agents/agencies must sell {int(round(a_st)):,} of the 90% seats = {a_rev:,.0f} cr net / {a_grev:,.0f} cr gross "
                f"(ticket payment). Counter/Web/App fill the other {int(round(dz['st'].sum())):,} seats themselves.",
         size=9,italic=True,color=GREY_T)


def s_growth(wb,d):
    # The growth lever beyond the ~90% LF ceiling: add frequency where demand spills.
    ws=wb.create_sheet("Network Growth"); ws.sheet_view.showGridLines=False
    cell(ws,1,1,"Network Growth — where to add capacity (the lever past 90% LF)",bold=True,size=14,color=NAVY)
    cell(ws,2,1,"Fares fill the plane to ~90% once; real growth = add seats where demand already spills. Routes below flew "
                ">=90% FULL in Mar-May (completed flights) — proven, demand-constrained. '+1 daily' = that aircraft x 30 days x its proven LF x yield.",
         size=9.5,color=GREY_T,wrap=True); ws.merge_cells("A2:H2"); ws.row_dimensions[2].height=28
    ga=d.get('growth_add'); yld=d['yld']; ylg=d['yld_gross']; gr_int=ylg['International']/yld['International']
    cell(ws,4,1,"ADD FREQUENCY — international routes that flew >=90% full",bold=True,size=12,color=NAVY)
    heads=["Route","Proven\nLF","~daily\nnow","Aircraft\nseats","Yield/seat\n(net TK)","+1 daily\nnet (cr/mo)","+1 daily\ngross (cr/mo)","Priority"]
    for j,(h,w) in enumerate(zip(heads,[12,9,9,10,12,13,14,11]),1):
        cell(ws,5,j,h,bold=True,size=9,color=NAVY,fill=BLUE_LIGHT,align="center",wrap=True,border=True)
        ws.column_dimensions[get_column_letter(j)].width=w
    ws.row_dimensions[5].height=28
    r=6
    if ga is not None:
        for _,x in ga.iterrows():
            net=x['acseats']*30*x['lf']*x['yld']/CR; gross=net*gr_int
            pr=("★ Tier 1" if (x['lf']>=0.97 and x['acseats']>=300) else "Tier 2" if x['lf']>=0.95 else "Tier 3")
            fl=GREEN_F if pr.startswith("★") else (AMBER_F if pr=="Tier 2" else None)
            cell(ws,r,1,x['leg_route'],bold=True,size=10,color=NAVY,fill=fl,border=True)
            cell(ws,r,2,x['lf'],fmt=F_PCT,align="center",size=9,fill=fl,border=True)
            cell(ws,r,3,round(x['legs']/86.0,1),fmt='0.0',align="center",size=9,fill=fl,border=True)
            cell(ws,r,4,int(x['acseats']),fmt=F_INT,align="center",size=9,fill=fl,border=True)
            cell(ws,r,5,int(x['yld']),fmt=F_INT,align="center",size=9,fill=fl,border=True)
            cell(ws,r,6,net,fmt=F_CR,align="center",size=9,bold=True,color=NAVY,fill=fl,border=True)
            cell(ws,r,7,gross,fmt=F_CR,align="center",size=9,color=BLUE_MED,fill=fl,border=True)
            cell(ws,r,8,pr,size=9,align="center",fill=fl,border=True); r+=1
    fare_push=d['optimal_rev']-d['commit']
    ws.merge_cells(start_row=r,start_column=1,end_row=r+1,end_column=8)
    cell(ws,r,1,f"PUNCHLINE: one extra international frequency on a top route ≈ +16 to +47 cr/MONTH each. The ENTIRE fleet-wide fare push "
                f"86%->90% is only +{fare_push:.0f} cr, ONE-TIME. Fares hit the ceiling; frequencies move it.",
         size=10,color=NAVY,fill=GREEN_F,wrap=True,bold=True); r+=3
    gt=d.get('growth_trim')
    cell(ws,r,1,"DO NOT ADD / redeploy — chronically empty DOMESTIC routes (<60% full)",bold=True,size=12,color=RED); r+=1
    for j,h in enumerate(["Route","Proven LF","Seats (Mar-May)","Booked"],1):
        cell(ws,r,j,h,bold=True,size=9,color=NAVY,fill=BLUE_LIGHT,align="center",border=True)
        ws.column_dimensions[get_column_letter(j)].width=[12,11,15,12][j-1]
    r+=1
    if gt is not None:
        for _,x in gt.iterrows():
            cell(ws,r,1,x['leg_route'],bold=True,size=10,color=NAVY,fill=RED_F,border=True)
            cell(ws,r,2,x['lf'],fmt=F_PCT,align="center",size=9,fill=RED_F,border=True)
            cell(ws,r,3,int(x['cap']),fmt=F_INT,align="center",size=9,fill=RED_F,border=True)
            cell(ws,r,4,int(x['booked']),fmt=F_INT,align="center",size=9,fill=RED_F,border=True); r+=1


#: Where the per-zone targets are published for other reports to read.
TARGET_ARTEFACT_DIR = ROOT / "curated" / "targets"


def target_artefact_path(ym: str) -> "Path":
    return TARGET_ARTEFACT_DIR / f"zone_targets_{ym}.parquet"


def write_target_artefact(d) -> "Path | None":
    """Publish this month's per-zone targets so the DSR can show them.

    WHY AN ARTEFACT RATHER THAN A SHARED FUNCTION CALL
        zone_achievement_frame() needs gather(), which is a multi-minute job: the DSR calling it
        would roughly double the DSR's build time for numbers this report has already worked
        out. So the target engine stays the single owner of the maths and writes a small file;
        the DSR reads it in milliseconds. The two reports then cannot disagree, because there is
        only one calculation.

        The DSR leaves its target cells BLANK when this file is absent. That matters: before
        this existed the DSR hardcoded 0 into every target cell and printed "0%" achievement for
        all 39 zones, which reads as a real measurement rather than a missing one.

    Written on every target build, so refreshing the target refreshes the DSR's targets too.
    """
    try:
        Z = zone_achievement_frame(d)
        out = pd.DataFrame({
            "zone": Z.index,
            "target_net": Z["tt"].to_numpy() * CR,        # BDT, the unit the DSR prints
            "target_net_dom": Z["td"].to_numpy() * CR,
            "target_net_int": Z["ti"].to_numpy() * CR,
            "target_tkt_dom": Z["ttk_dom"].to_numpy(),
            "target_tkt_int": Z["ttk_int"].to_numpy(),
            "target_tkt": Z["ttk"].to_numpy(),
        })
        out["month"] = TARGET_YM
        import datetime as _dtmod
        out["built_at"] = _dtmod.datetime.now().strftime("%Y-%m-%d %H:%M")
        # The knobs travel WITH the numbers. Six weeks on, "why was September 611 cr" is not
        # answerable from the parquet unless the assumptions are in it, and the file outlives
        # whatever was on screen the day it was built.
        out["basis_lf"] = TARGET_LF
        out["basis_uplift"] = GROWTH_UPLIFT
        out["basis_hajj"] = HAJJ_FACTOR
        out["basis_fare_month"] = _month_span(-1)[0][:7]
        TARGET_ARTEFACT_DIR.mkdir(parents=True, exist_ok=True)
        p = target_artefact_path(TARGET_YM)
        tmp = p.with_suffix(".tmp")
        out.to_parquet(tmp, index=False)
        os.replace(tmp, p)                    # atomic: never a half-written target file
        print(f"[target] published {len(out)} zone target(s) -> {p.name}")
        return p
    except Exception as exc:                                       # noqa: BLE001
        # Never let publishing the artefact break the workbook this function exists to build.
        print(f"[target] could not publish the target artefact: {type(exc).__name__}: {exc}")
        return None


def generate(params=None, cfg=None):
    """Build the target-month capacity workbook (8 sheets) and return its path.

    (Phase 0: paths come from the module-level _CFG resolved at import; the cfg arg
    is accepted for interface parity. Set ANALYSIS_HOME before import to retarget.)

    The target MONTH is a module constant (TARGET_YM), resolved at import because every
    derived window is too. A caller wanting a different month sets TARGET_MONTH_ENV=YYYY-MM
    BEFORE importing. If params["month"] disagrees we raise rather than quietly build the
    wrong month — a target workbook labelled August holding July's windows is the kind of
    error that gets sent to sales people before anyone notices.
    """
    want = str((params or {}).get("month") or "").strip()
    if want and want != TARGET_YM:
        raise ValueError(
            f"this module was imported for {TARGET_YM}, but month={want!r} was requested. "
            f"Set TARGET_MONTH_ENV={want} before importing reporting.builders.june_target "
            f"(the month drives constants resolved at import time).")
    # WHAT THIS TARGET IS BASED ON, printed BEFORE the multi-minute gather() rather than after,
    # so a wrong knob is caught while it still costs nothing to fix.
    print_basis()
    d = gather()
    write_target_artefact(d)
    wb = Workbook()
    # s_achievement is now the consolidated master sheet (target + achieved + gross +
    # monthly trend + 12-mo avg + 3v3 trend); the standalone Zone-wise / Zone Monthly
    # Trend sheets were merged into it (analyst: "all information in one sheet").
    s_summary(wb, d); s_calc(wb, d)
    s_achievement(wb, d)                                        # existing, unchanged
    s_achievement(wb, d, "Target vs Achievement - Non-OTA", exclude_ota=True)
    s_routes(wb, d)
    s_loadfactor(wb, d); s_road90(wb, d); s_growth(wb, d)
    # the agent listing three times: full, then the OTA / non-OTA cuts the analyst works
    # as separate books (same split the DSR's Agent sheet now carries)
    s_agent_routes(wb, d)
    s_agent_routes(wb, d, "Agent Route Target - OTA", only="OTA")
    s_agent_routes(wb, d, "Agent Route Target - Non-OTA", only="NONOTA")
    out = OUTPUT
    out.parent.mkdir(parents=True, exist_ok=True)
    try:
        wb.save(out)
    except PermissionError:
        out = out.with_name(out.stem + "_v2.xlsx")
        wb.save(out)
    return out
