"""
reporting.builders.load_factor_yearly: load factor month by month, 2024 to 2026, with the
movement figures the network team actually reads.

SOURCE
    curated/flight_history/flight_loads_yearly.parquet, written by
    scripts/ingest_flight_loads_yearly.py from the hand-maintained consolidated workbook.
    This is the ONLY store with prior years; the other two are 2026-only.

THE THREE MOVEMENTS, AND WHY EACH IS HERE
    MoM   this month against last month. Reads seasonality as much as performance, so it is
          shown but never used alone to judge a month.
    YoY   this month against the SAME month last year. Strips seasonality, which is why it is
          the one that answers "are we doing better".
    YTD   the year to date against the same span last year, so a part-year is compared with a
          part-year rather than a whole one.

TWO THINGS THIS REPORT REFUSES TO DO, BOTH LEARNED THE HARD WAY
    1. It never computes load factor by summing capacity and flown as independent columns.
       2026 carries `flown` on only 40% of its rows, so that method produced 33% against a true
       82%. Every ratio here is built from rows carrying BOTH figures.
    2. It never prints a MoM across a GAP in the source. 2024 is missing February to July
       entirely, so "Jan to Aug" is not a month-on-month move, it is a seven-month hole. Those
       cells read "gap" rather than a number that would be quietly wrong.

THE DASHBOARD
    Sheet 1 is a picture-first Dashboard: six NATIVE Excel charts plus a row of KPI cards.
    Native, not images, so the charts stay live: click a point and Excel shows the figure, and
    the whole thing survives being pasted into a deck. Every chart reads its numbers from the
    "Chart Data" sheet, which is left visible on purpose so any figure on the dashboard can be
    traced to a cell rather than taken on trust.

    The gap discipline carries into the charts too. Missing months are written as EMPTY cells,
    never as zero, and each chart is set to display blanks as a gap, so the 2024 hole breaks the
    line instead of drawing a plunge to zero that never happened.
"""
from __future__ import annotations

from datetime import datetime
from pathlib import Path

import pandas as pd
from openpyxl import Workbook
from openpyxl.chart import BarChart, LineChart, Reference
from openpyxl.chart.marker import DataPoint, Marker
from openpyxl.chart.shapes import GraphicalProperties
from openpyxl.drawing.line import LineProperties
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side

from ..config import Config, load_config

NAVY, BLUE, WHITE = "1F3864", "2E5395", "FFFFFF"
GREEN, AMBER, RED, GREY = "E2EFDA", "FFF2CC", "FCE4E4", "F2F2F2"
BORDER = Border(*([Side(style="thin", color="BFBFBF")] * 4))
FI, FP, FPT = "#,##0", "0.0%", '+0.0" pts";-0.0" pts";"0.0 pts"'

BD = ("DAC", "CGP", "CXB", "ZYL", "JSR", "RJH", "BZL", "SPD")
MAX_LF = 1.5          # above this, flown or capacity is mis-keyed in the source
FULL_MONTH = 0.90     # a month with fewer than 90% of its days in hand is a PARTIAL month

# Chart palette. One colour per year so the seasonality chart reads at a glance, plus a
# green/red pair for movement bars. Kept here so every chart on the dashboard agrees.
YEAR_COLOR = {2024: "A6B7D6", 2025: "4472C4", 2026: "1F3864"}   # pale past -> dark present
POS, NEG, TEAL, ORANGE = "2E9B57", "C0504D", "2E9B9B", "ED7D31"
MONTH_NAME = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
              "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]


def _blank_nan(s: pd.Series) -> pd.Series:
    """NaN back to None, so `is None` means what it looks like it means.

    A list of floats-and-Nones handed to pandas becomes float64, and every None in it silently
    becomes NaN. `x is None` is then False for a value that IS missing, so the "no previous
    month" notes never print and a month with no comparison gets styled as if it were flat.
    Object dtype is the price of having a real absence survive the round trip.
    """
    return s.astype(object).where(s.notna(), None)


def _c(ws, r, col, v, *, bold=False, fill=None, fmt=None, color="000000", size=9, wrap=False,
       align=None):
    if v is not None and v != v:      # NaN, from any frame that slipped past _blank_nan
        v = None                      # an empty cell, never the text "nan" or a #NUM!
    cell = ws.cell(row=r, column=col, value=v)
    cell.font = Font(bold=bold, color=color, size=size)
    cell.border = BORDER
    if fill:
        cell.fill = PatternFill("solid", fgColor=fill)
    if fmt:
        cell.number_format = fmt
    if wrap or align:
        cell.alignment = Alignment(wrap_text=wrap, vertical="top", horizontal=align or "general")
    return cell


def _head(ws, r, heads, widths):
    for j, (h, w) in enumerate(zip(heads, widths), start=1):
        _c(ws, r, j, h, bold=True, fill=BLUE, color=WHITE, wrap=True)
        ws.column_dimensions[ws.cell(row=r, column=j).column_letter].width = w
    ws.row_dimensions[r].height = 34


REQUIRED = {"flown_equiv", "lf_basis", "operated", "settled"}


def load_all(cfg: Config) -> pd.DataFrame:
    """Every row that can carry a ratio at all, with the ingest's flags left on.

    Used for the disclosures: what the excluded rows would have done to each month is printed
    beside the figure, so the exclusions are visible and reversible rather than buried.
    """
    p = cfg.data_root / "curated" / "flight_history" / "flight_loads_yearly.parquet"
    if not p.is_file():
        raise FileNotFoundError(
            f"no multi-year load store at {p}\n"
            f"  run: .venv/Scripts/python.exe scripts/ingest_flight_loads_yearly.py")
    d = pd.read_parquet(p)
    if REQUIRED - set(d.columns):
        raise FileNotFoundError(
            f"the load store at {p} predates the column-rename fix and is missing "
            f"{', '.join(sorted(REQUIRED - set(d.columns)))}.\n"
            f"  re-run: .venv/Scripts/python.exe scripts/ingest_flight_loads_yearly.py")
    # A ratio needs seats offered and a seats-carried figure. `flown_equiv` is the flown count
    # where the sheet recorded one and capacity x the sheet's own stated load factor where it
    # did not; `lf_basis` says which, so nothing is silently imputed.
    d = d[d.capacity.notna() & (d.capacity > 0) & d.flown_equiv.notna()]
    return d[d.flown_equiv / d.capacity <= MAX_LF].copy()


def load(cfg: Config) -> pd.DataFrame:
    """The rows a report may actually use.

    Two exclusions, both made by the ingest and both disclosed on the Coverage sheet:
      settled=False  the block was captured before departure and never refreshed, so it holds
                     bookings-so-far, not a load. 2026-07-20 onward reads 82%, 78%, 69% ...
                     36% while the independent booking store shows those same departures at
                     91-95%.
      operated=False the flight carried nobody at all, with no sold figure and no corroboration,
                     on a route that flew a normal load either side. A flight that did not
                     operate offered no seats, so counting it as 0% full invents seats that
                     were never for sale.
    """
    d = load_all(cfg)
    return d[d.settled & (d.operated == True)].copy()          # noqa: E712


MONTHLY_COLS = ["year_month", "flights", "seats", "flown", "days", "lf", "measured_share",
                "year", "mm", "days_in_month", "cover", "full", "mom", "yoy"]


def monthly(d: pd.DataFrame) -> pd.DataFrame:
    # An empty frame is a real case, not a bug: split_sector hands this an all-domestic or
    # all-international slice whenever the airline flew only one of the two, and a filtered
    # store can come out empty. groupby on nothing leaves float64 columns, and `.str[:4]` on a
    # float column raises, so the shape is returned explicitly instead.
    if d.empty:
        return pd.DataFrame(columns=MONTHLY_COLS)
    g = (d.groupby("year_month")
           .agg(flights=("flight_number", "size"), seats=("capacity", "sum"),
                flown=("flown_equiv", "sum"), days=("flight_date", "nunique"))
           .reset_index())
    g["lf"] = g.flown / g.seats
    # What share of the month's seats got their ratio from a RECORDED flown figure, as against
    # the sheet's own stated load factor. Printed so the basis is never invisible: a month at
    # 100% is measured throughout, anything less is partly the sheet taking its own word.
    meas = d[d.lf_basis == "measured"].groupby("year_month").capacity.sum()
    g["measured_share"] = (g.year_month.map(meas).fillna(0) / g.seats)
    g["year"] = g.year_month.str[:4].astype(int)
    g["mm"] = g.year_month.str[-2:]

    # HOW MUCH OF THE MONTH IS ACTUALLY IN HAND. A load factor is a ratio, so a month covering
    # three days looks exactly as authoritative as one covering thirty-one. Two months here are
    # slivers: January 2024 holds 3 days and the newest month is still filling up. Ranking or
    # comparing those against full months is how a partial month becomes a record.
    g["days_in_month"] = [pd.Period(ym, freq="M").days_in_month for ym in g.year_month]
    g["cover"] = g.days / g.days_in_month
    g["full"] = g.cover >= FULL_MONTH

    # MoM only where the PREVIOUS CALENDAR month is actually present. A gap must read as a gap.
    prev = {}
    for _, r in g.iterrows():
        y, m = int(r.year), int(r.mm)
        py, pm = (y - 1, 12) if m == 1 else (y, m - 1)
        prev[r.year_month] = f"{py}-{pm:02d}"
    lf = dict(zip(g.year_month, g.lf))
    g["mom"] = [lf[p] and (l - lf[p]) if prev[ym] in lf else None
                for ym, l, p in zip(g.year_month, g.lf, g.year_month.map(prev))]
    g["yoy"] = [(l - lf[f"{int(ym[:4])-1}-{ym[-2:]}"])
                if f"{int(ym[:4])-1}-{ym[-2:]}" in lf else None
                for ym, l in zip(g.year_month, g.lf)]
    g["mom"], g["yoy"] = _blank_nan(g["mom"]), _blank_nan(g["yoy"])
    return g.sort_values("year_month")


def _sheet_monthly(wb, g: pd.DataFrame) -> None:
    ws = wb.create_sheet("Monthly Trend")
    _c(ws, 1, 1, "LOAD FACTOR MONTH BY MONTH, 2024 to 2026, with movement",
       bold=True, size=13, color=WHITE, fill=NAVY)
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=10)
    _c(ws, 2, 1, "MoM compares with the previous calendar month and therefore carries "
                 "seasonality; YoY compares with the SAME month a year earlier and is the one to "
                 "judge performance on. A blank movement means the comparison month is absent "
                 "from the source, not that nothing changed: 2024 is missing February to July. "
                 "Check the Days column before quoting any month: a ratio built on 3 days looks "
                 "exactly as confident as one built on 31.",
       wrap=True)
    ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=10)
    ws.row_dimensions[2].height = 52
    _head(ws, 3, ["Month", "Days\ncovered", "Flights", "Seats", "Flown", "Load factor",
                  "MoM movement", "YoY movement", "Measured\nbasis", "Note"],
          [10, 10, 10, 12, 12, 11, 13, 13, 10, 34])
    r = 4
    part = {x["year_month"] for x in g.to_dict("records") if not x["full"]}
    for x in g.to_dict("records"):
        notes = []
        if not x["full"]:
            notes.append(f"PARTIAL MONTH, {int(x['days'])} of {int(x['days_in_month'])} days")
        if x["measured_share"] < 0.999:
            notes.append(f"{1 - x['measured_share']:.0%} of seats use the sheet's own stated "
                         f"load factor, no flown figure recorded")
        if x["mom"] is None:
            notes.append("no previous month in the source")
        if x["yoy"] is None:
            notes.append("no same month last year")
        # a movement is only like-for-like if BOTH ends are whole months
        y, m = int(x["year"]), int(x["mm"])
        pm = f"{y-1}-12" if m == 1 else f"{y}-{m-1:02d}"
        if x["mom"] is not None and pm in part:
            notes.append(f"MoM measured against a partial {pm}")
        if x["yoy"] is not None and f"{y-1}-{x['mm']}" in part:
            notes.append(f"YoY measured against a partial {y-1}-{x['mm']}")
        fill = None
        if x["yoy"] is not None:
            fill = GREEN if x["yoy"] > 0 else RED if x["yoy"] < -0.02 else AMBER
        for j, (v, fmt) in enumerate([
                (x["year_month"], None),
                (f"{int(x['days'])} of {int(x['days_in_month'])}", None),
                (x["flights"], FI), (x["seats"], FI),
                (x["flown"], FI), (x["lf"], FP),
                (x["mom"], FPT), (x["yoy"], FPT), (x["measured_share"], FP),
                ("; ".join(notes), None)], start=1):
            f = fill if j == 8 else (AMBER if (j == 2 and not x["full"]) else
                                     AMBER if (j == 9 and x["measured_share"] < 0.999) else None)
            _c(ws, r, j, v, fmt=fmt, fill=f, wrap=(j == 10))
        r += 1
    ws.freeze_panes = "B4"


def split_sector(d: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Domestic (both endpoints in Bangladesh) and everything else, each already monthly.

    Shared by the By Sector sheet and the dashboard so the two can never disagree about what
    counts as domestic.

    Split on a BOOLEAN MASK, not on `d.drop(dom.index)`. The frame reaches here from a concat
    and a parquet read, so its index labels are not guaranteed unique, and dropping by label
    would take every row sharing a label with a domestic one, silently deleting international
    flights. A mask cannot make that mistake.
    """
    is_dom = d.origin.isin(BD) & d.destination.isin(BD)
    return (monthly(d[is_dom]).set_index("year_month"),
            monthly(d[~is_dom]).set_index("year_month"))


def _partial_note(g: pd.DataFrame) -> str:
    """One sentence naming the months that are not whole, for sheets with no room for a column."""
    p = g[~g.full]
    if not len(p):
        return ""
    return ("Not whole months: " +
            "; ".join(f"{x['year_month']} holds {int(x['days'])} of {int(x['days_in_month'])} "
                      f"days" for x in p.to_dict("records")) +
            ". Their ratios are real but cover part of the month, so a movement into or out of "
            "one is not a like-for-like comparison.")


def _sheet_sector(wb, d: pd.DataFrame) -> None:
    ws = wb.create_sheet("By Sector")
    _c(ws, 1, 1, "DOMESTIC versus INTERNATIONAL, month by month",
       bold=True, size=12, color=WHITE, fill=NAVY)
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=7)
    md, mi = split_sector(d)
    note = _partial_note(monthly(d))
    if note:
        _c(ws, 2, 1, note, wrap=True, fill=AMBER)
        ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=7)
        ws.row_dimensions[2].height = 30
    _head(ws, 3, ["Month", "Dom seats", "Dom LF", "Dom MoM", "Intl seats", "Intl LF", "Intl MoM"],
          [10, 12, 10, 11, 12, 10, 11])
    r = 4
    for ym in sorted(set(md.index) | set(mi.index)):
        vals = [(ym, None)]
        for t in (md, mi):
            if ym in t.index:
                vals += [(t.at[ym, "seats"], FI), (t.at[ym, "lf"], FP), (t.at[ym, "mom"], FPT)]
            else:
                vals += [(None, None), (None, None), (None, None)]
        for j, (v, fmt) in enumerate(vals, start=1):
            _c(ws, r, j, v, fmt=fmt)
        r += 1
    ws.freeze_panes = "B4"


def _sheet_route(wb, d: pd.DataFrame) -> None:
    ws = wb.create_sheet("By Route")
    _c(ws, 1, 1, "ROUTES, newest month against the one before and against a year earlier",
       bold=True, size=12, color=WHITE, fill=NAVY)
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=7)
    g = monthly(d)
    latest_row = g[g.year_month == d.year_month.max()].iloc[0]
    if not latest_row["full"]:
        _c(ws, 2, 1,
           f"{latest_row['year_month']} holds only {int(latest_row['days'])} of "
           f"{int(latest_row['days_in_month'])} days, so every MoM and YoY on this sheet "
           f"compares part of a month against a whole one. Read the direction, not the size.",
           wrap=True, fill=AMBER)
        ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=7)
        ws.row_dimensions[2].height = 30
    _head(ws, 3, ["Route", "Latest month", "Seats", "Load factor", "MoM movement",
                  "YoY movement", "Note"], [12, 12, 11, 11, 13, 13, 26])
    latest = d.year_month.max()
    prev_y, prev_m = int(latest[:4]), int(latest[-2:])
    pm = f"{prev_y}-{prev_m-1:02d}" if prev_m > 1 else f"{prev_y-1}-12"
    ly = f"{prev_y-1}-{latest[-2:]}"

    def lf_by_route(ym):
        s = d[d.year_month == ym]
        if s.empty:
            return {}
        t = s.groupby("leg_route").agg(seats=("capacity", "sum"), flown=("flown", "sum"))
        return {k: (v.flown / v.seats, v.seats) for k, v in t.iterrows()}

    cur, pmv, lyv = lf_by_route(latest), lf_by_route(pm), lf_by_route(ly)
    r = 4
    for route, (lf, seats) in sorted(cur.items(), key=lambda kv: -kv[1][1]):
        mom = lf - pmv[route][0] if route in pmv else None
        yoy = lf - lyv[route][0] if route in lyv else None
        note = "" if route in pmv else f"not flown in {pm}"
        if route not in lyv:
            note = (note + "; " if note else "") + f"not flown in {ly}"
        fill = GREEN if (yoy or 0) > 0 else RED if (yoy or 0) < -0.02 else None
        for j, (v, fmt) in enumerate([(route, None), (latest, None), (seats, FI), (lf, FP),
                                      (mom, FPT), (yoy, FPT), (note, None)], start=1):
            _c(ws, r, j, v, fmt=fmt, fill=fill if j == 6 else None, wrap=(j == 7))
        r += 1
    ws.freeze_panes = "B4"


def _top_routes(d: pd.DataFrame, ym: str, n: int = 12) -> pd.DataFrame:
    """The n biggest routes by seats in one month, with that month's load factor."""
    s = d[d.year_month == ym]
    if s.empty:
        return pd.DataFrame(columns=["leg_route", "lf", "seats"])
    t = (s.groupby("leg_route").agg(seats=("capacity", "sum"), flown=("flown", "sum"))
          .assign(lf=lambda x: x.flown / x.seats)
          .sort_values("seats", ascending=False).head(n).reset_index())
    return t[["leg_route", "lf", "seats"]]


def _sheet_chart_data(wb, g: pd.DataFrame, md: pd.DataFrame, mi: pd.DataFrame,
                      routes: pd.DataFrame) -> tuple:
    """The numbers every dashboard chart plots, in cells.

    LEFT VISIBLE ON PURPOSE. A chart whose source is hidden is a chart nobody can check, and
    this report exists precisely because a load factor that looked plausible was wrong. Three
    blocks side by side, each returned as (first_row, last_row) so the caller can build its
    Reference objects without re-counting rows.

    Blanks stay BLANK. A month absent from the source must never be written as a zero: a zero
    draws a plunge to the floor and reads as a catastrophic month rather than as no data.
    """
    ws = wb.create_sheet("Chart Data")
    _c(ws, 1, 1, "SOURCE NUMBERS FOR THE DASHBOARD CHARTS. Empty cell = that month is absent "
                 "from the source, which is why the chart line breaks there rather than "
                 "dropping to zero. Movement is in PERCENTAGE POINTS.",
       bold=True, size=10, color=WHITE, fill=NAVY, wrap=True)
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=16)
    ws.row_dimensions[1].height = 30

    # BLOCK A, cols A-G: the monthly series
    for j, h in enumerate(["Month", "Load factor", "MoM pts", "YoY pts", "Seats",
                           "Domestic LF", "International LF", "Days covered"], start=1):
        _c(ws, 2, j, h, bold=True, fill=BLUE, color=WHITE, wrap=True)
        ws.column_dimensions[ws.cell(row=2, column=j).column_letter].width = 12
    r0 = 3
    for i, x in enumerate(g.to_dict("records")):
        r = r0 + i
        ym = x["year_month"]
        _c(ws, r, 1, ym)
        _c(ws, r, 2, x["lf"], fmt=FP)
        _c(ws, r, 3, None if x["mom"] is None else x["mom"] * 100, fmt="+0.0;-0.0")
        _c(ws, r, 4, None if x["yoy"] is None else x["yoy"] * 100, fmt="+0.0;-0.0")
        _c(ws, r, 5, x["seats"], fmt=FI)
        _c(ws, r, 6, float(md.at[ym, "lf"]) if ym in md.index else None, fmt=FP)
        _c(ws, r, 7, float(mi.at[ym, "lf"]) if ym in mi.index else None, fmt=FP)
        _c(ws, r, 8, f"{int(x['days'])} of {int(x['days_in_month'])}",
           fill=None if x["full"] else AMBER)
    r1 = r0 + len(g) - 1

    # BLOCK B, cols I-L: the same figures pivoted to calendar month x year, which is the only
    # shape that lets a reader see seasonality and performance apart from each other.
    years = sorted(g.year.unique())
    lf_by = {(int(x["year"]), x["year_month"][-2:]): x["lf"] for x in g.to_dict("records")}
    _c(ws, 2, 9, "Month", bold=True, fill=BLUE, color=WHITE)
    ws.column_dimensions["I"].width = 10
    for k, y in enumerate(years):
        _c(ws, 2, 10 + k, str(y), bold=True, fill=BLUE, color=WHITE)
        ws.column_dimensions[ws.cell(row=2, column=10 + k).column_letter].width = 10
    s0 = 3
    for i, name in enumerate(MONTH_NAME):
        r = s0 + i
        _c(ws, r, 9, name)
        for k, y in enumerate(years):
            _c(ws, r, 10 + k, lf_by.get((y, f"{i+1:02d}")), fmt=FP)
    s1 = s0 + 11

    # BLOCK C, cols N-P: the newest month's biggest routes
    c_route = 14
    for j, h in enumerate(["Route", "Load factor", "Seats"], start=c_route):
        _c(ws, 2, j, h, bold=True, fill=BLUE, color=WHITE)
        ws.column_dimensions[ws.cell(row=2, column=j).column_letter].width = 12
    t0 = 3
    for i, x in enumerate(routes.to_dict("records")):
        _c(ws, t0 + i, c_route, x["leg_route"])
        _c(ws, t0 + i, c_route + 1, x["lf"], fmt=FP)
        _c(ws, t0 + i, c_route + 2, x["seats"], fmt=FI)
    if not len(routes):
        # With no routes there is no block. Returning t0 anyway would hand the chart a range
        # covering the header plus one empty row, which plots a single nameless zero bar.
        _c(ws, t0, c_route, "no routes in the newest month")
    t1 = t0 + max(len(routes) - 1, 0)
    return (r0, r1), (s0, s1), (t0, t1), years


def _line(chart, idx: int, color: str, width: int = 28000, marker: str | None = "circle"):
    """One styled line series. Thick enough to read when the sheet is projected."""
    s = chart.series[idx]
    s.graphicalProperties = GraphicalProperties()
    s.graphicalProperties.line = LineProperties(solidFill=color, w=width)
    s.smooth = False
    if marker:
        s.marker = Marker(symbol=marker, size=6)
    return s


def _axes(chart, *, pct: bool = True, y_min=None, y_max=None, y_title=None, x_title=None):
    """Common axis treatment. `delete = False` matters: without it Excel hides the axis."""
    chart.x_axis.delete = False
    chart.y_axis.delete = False
    if pct:
        chart.y_axis.numFmt = "0%"
    if y_min is not None:
        chart.y_axis.scaling.min = y_min
    if y_max is not None:
        chart.y_axis.scaling.max = y_max
    chart.y_axis.title = y_title
    chart.x_axis.title = x_title
    chart.dispBlanksAs = "gap"        # a missing month breaks the line, it does not plot as 0
    chart.height, chart.width = 8.6, 15.2
    return chart


def _sheet_dashboard(wb, g: pd.DataFrame, routes: pd.DataFrame, latest: str, blocks) -> None:
    """Six live charts and a KPI strip. Built first so it is the sheet that opens.

    `blocks` is what _sheet_chart_data returned: the first and last row of each data block plus
    the list of years, so the Reference objects are built from what was actually written rather
    than from a row count computed twice and drifting.
    """
    ws = wb.create_sheet("Dashboard", 0)
    ws.sheet_view.showGridLines = False
    for col in range(1, 19):
        ws.column_dimensions[ws.cell(row=1, column=col).column_letter].width = 9.2

    _c(ws, 1, 1, "LOAD FACTOR DASHBOARD", bold=True, size=16, color=WHITE, fill=NAVY)
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=18)
    ws.row_dimensions[1].height = 26
    cover = f"{g.year_month.min()} to {g.year_month.max()}"
    _c(ws, 2, 1, f"Seat-weighted load factor across {cover}. Every chart reads from the Chart "
                 f"Data sheet, so any figure here can be traced to a cell. Load-factor axes "
                 f"start at 50%, not zero, so movement is legible; the KPI figures below are "
                 f"absolute.", wrap=True)
    ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=18)
    ws.row_dimensions[2].height = 28

    # KPI STRIP. Six cards, three columns each, spanning A to R.
    # Best and weakest are taken from WHOLE months only. The newest month sits at the top of
    # the table on 20 of 30 days, and a partial month crowned "best ever" is the single most
    # likely way this dashboard misleads someone who reads only the cards.
    last = g.iloc[-1]
    whole = g[g.full]
    best, worst = whole.loc[whole.lf.idxmax()], whole.loc[whole.lf.idxmin()]
    yoy_rows, partials = g[g.yoy.notna()], g[~g.full]
    cov_last = f"{int(last.days)} of {int(last.days_in_month)} days" + \
               ("" if last.full else ", PARTIAL")
    cards = [
        (f"LATEST MONTH ({latest})", f"{last.lf:.1%}", cov_last, NAVY),
        ("YEAR ON YEAR", "no prior year" if last.yoy is None else f"{last.yoy*100:+.1f} pts",
         "same month, a year earlier", POS if (last.yoy or 0) > 0 else NEG),
        ("MONTH ON MONTH", "gap in source" if last.mom is None else f"{last.mom*100:+.1f} pts",
         "carries seasonality, read with care",
         POS if (last.mom or 0) > 0 else NEG),
        ("BEST FULL MONTH", f"{best.lf:.1%}", f"{best.year_month}, whole months only", POS),
        ("WEAKEST FULL MONTH", f"{worst.lf:.1%}", f"{worst.year_month}, whole months only", NEG),
        ("MONTHS ON RECORD", f"{len(g)}",
         f"{len(yoy_rows)} carry a year-on-year read, {len(partials)} are partial", BLUE),
    ]
    for i, (label, big, sub, color) in enumerate(cards):
        c0 = 1 + i * 3
        for rr, val, kw in ((4, label, dict(bold=True, size=8, color=WHITE, fill=color)),
                            (5, big, dict(bold=True, size=18, color=color, fill=GREY)),
                            (6, sub, dict(size=8, fill=GREY, wrap=True))):
            _c(ws, rr, c0, val, align="center", **kw)
            for j in range(c0 + 1, c0 + 3):        # merged cells still need their borders
                _c(ws, rr, j, None, fill=kw.get("fill"))
            ws.merge_cells(start_row=rr, start_column=c0, end_row=rr, end_column=c0 + 2)
    ws.row_dimensions[5].height = 28
    ws.row_dimensions[6].height = 26

    cd = wb["Chart Data"]
    (r0, r1), (s0, s1), (t0, t1), years = blocks

    # 1. the whole series, one line. The headline shape.
    c1 = LineChart()
    c1.title = "Load factor by month, the full series"
    c1.add_data(Reference(cd, min_col=2, min_row=2, max_row=r1), titles_from_data=True)
    c1.set_categories(Reference(cd, min_col=1, min_row=r0, max_row=r1))
    _line(c1, 0, YEAR_COLOR[max(years)])
    _axes(c1, y_min=0.5, y_max=0.95, x_title="Month")
    c1.legend = None
    ws.add_chart(c1, "A9")

    # 2. the same numbers pivoted year over year. Seasonality and performance pulled apart:
    #    a line that sits ABOVE last year's at the same calendar month is a real gain.
    c2 = LineChart()
    c2.title = "Same calendar month, year against year"
    c2.add_data(Reference(cd, min_col=10, max_col=9 + len(years), min_row=2, max_row=s1),
                titles_from_data=True)
    c2.set_categories(Reference(cd, min_col=9, min_row=s0, max_row=s1))
    for k, y in enumerate(years):
        _line(c2, k, YEAR_COLOR.get(y, BLUE), width=30000 if y == max(years) else 20000)
    _axes(c2, y_min=0.5, y_max=0.95, x_title="Calendar month")
    ws.add_chart(c2, "J9")

    # 3. movement in points, coloured by sign so a bad month is visible without reading a number
    c3 = BarChart()
    c3.type, c3.title = "col", "Year-on-year movement, percentage points"
    c3.add_data(Reference(cd, min_col=4, min_row=2, max_row=r1), titles_from_data=True)
    c3.set_categories(Reference(cd, min_col=1, min_row=r0, max_row=r1))
    # per-point colour: DataPoint takes the raw `spPr`, the graphicalProperties alias only
    # works on an already-built instance
    c3.series[0].data_points = [
        DataPoint(idx=i, spPr=GraphicalProperties(solidFill=POS if (v or 0) >= 0 else NEG))
        for i, v in enumerate(g.yoy.tolist())]
    _axes(c3, pct=False, y_title="points", x_title="Month")
    c3.legend = None
    ws.add_chart(c3, "A27")

    # 4. capacity against fill. Bars are seats, the line is load factor on its own axis, so a
    #    month that added seats and still filled them is distinguishable from one that did not.
    c4 = BarChart()
    c4.type, c4.title = "col", "Seats offered (bars) against load factor (line)"
    c4.add_data(Reference(cd, min_col=5, min_row=2, max_row=r1), titles_from_data=True)
    c4.set_categories(Reference(cd, min_col=1, min_row=r0, max_row=r1))
    c4.series[0].graphicalProperties = GraphicalProperties(solidFill="D6DCE4")
    c4.y_axis.numFmt = "#,##0"
    c4.y_axis.majorGridlines = None
    c5 = LineChart()
    c5.add_data(Reference(cd, min_col=2, min_row=2, max_row=r1), titles_from_data=True)
    _line(c5, 0, ORANGE)
    c5.y_axis.axId, c5.y_axis.numFmt, c5.y_axis.title = 200, "0%", "load factor"
    c5.y_axis.scaling.min, c5.y_axis.scaling.max = 0.5, 0.95
    c4.y_axis.crosses = "max"          # the documented openpyxl recipe for a secondary axis
    c4 += c5
    # _axes writes the axis titles, so it has to name the seats axis here: calling it with the
    # default would blank the title set above.
    _axes(c4, pct=False, y_title="seats offered", x_title="Month")
    ws.add_chart(c4, "J27")

    # 5. the two businesses side by side; they do not move together
    c6 = LineChart()
    c6.title = "Domestic against international"
    c6.add_data(Reference(cd, min_col=6, max_col=7, min_row=2, max_row=r1), titles_from_data=True)
    c6.set_categories(Reference(cd, min_col=1, min_row=r0, max_row=r1))
    _line(c6, 0, TEAL)
    _line(c6, 1, ORANGE)
    _axes(c6, y_min=0.4, y_max=1.0, x_title="Month")
    ws.add_chart(c6, "A45")

    # 6. where the seats actually are this month
    c7 = BarChart()
    c7.type, c7.title = "bar", f"Biggest routes by seats, {latest}"
    c7.add_data(Reference(cd, min_col=15, min_row=2, max_row=t1), titles_from_data=True)
    c7.set_categories(Reference(cd, min_col=14, min_row=t0, max_row=t1))
    c7.series[0].graphicalProperties = GraphicalProperties(solidFill=BLUE)
    _axes(c7, y_min=0, y_max=1.0)
    c7.legend = None
    ws.add_chart(c7, "J45")

    r = 63
    for line in [
        "HOW TO READ THIS. The year-against-year chart is the one to judge performance on: a "
        "month can rise on the full-series line purely because it is a stronger season.",
        "A BROKEN LINE IS MISSING DATA, NOT A COLLAPSE. February to July 2024 are absent from "
        "the source workbook, and recent 2026 months carry capacity without a flown figure.",
        "PARTIAL MONTHS ARE PLOTTED BUT NOT RANKED. " + (
            "; ".join(f"{x['year_month']} holds {int(x['days'])} of "
                      f"{int(x['days_in_month'])} days"
                      for x in partials.to_dict("records")) or "none in this build") +
        ". Their points appear on the charts, but the best and weakest cards read whole "
        "months only, so a half-finished month cannot be crowned a record.",
        "Every load factor here is seat-weighted (total flown divided by total seats offered), "
        "computed only on flights that record BOTH figures, never as an average of ratios.",
    ]:
        _c(ws, r, 1, line, wrap=True, size=8)
        ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=18)
        ws.row_dimensions[r].height = 22
        r += 1


def _sheet_method(wb, d: pd.DataFrame, raw_n: int, allrows: pd.DataFrame) -> None:
    ws = wb.create_sheet("Coverage & Method")
    ws.column_dimensions["A"].width = 24
    ws.column_dimensions["B"].width = 104
    _c(ws, 1, 1, "WHAT THIS IS BUILT ON, AND WHERE THE SOURCE IS INCOMPLETE",
       bold=True, size=12, color=WHITE, fill=NAVY)
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=2)
    cov = d.groupby("year").agg(rows=("flown_equiv", "size"), months=("year_month", "nunique"))
    unsettled = allrows[~allrows.settled]
    nonop = allrows[allrows.settled & (allrows.operated == False)]      # noqa: E712
    stated = d[d.lf_basis == "stated"]

    # what INCLUDING the non-operating rows would do, month by month, so the exclusion is
    # visible as a number rather than as a claim
    eff = []
    for ym, g in allrows[allrows.settled].groupby("year_month"):
        op = g[g.operated == True]                                     # noqa: E712
        if len(op) and len(g) > len(op):
            eff.append(f"{ym} {(op.flown_equiv.sum()/op.capacity.sum() - g.flown_equiv.sum()/g.capacity.sum())*100:+.1f}")

    notes = [
        ("Source", "curated/flight_history/flight_loads_yearly.parquet, from the consolidated "
                   "flight-load workbook via scripts/ingest_flight_loads_yearly.py."),
        ("Rows used", f"{len(d):,} of {raw_n:,} parsed flight-days."),
        ("Columns get renamed", "On 2026-04-25 the workbook renamed 'Flown' to 'Flown Seats' "
                                "and 'Sold' to 'Sold Seats'. A map keyed on the old label alone "
                                "read May to August 2026 as capacity with no load, so the "
                                "report stopped at April and reported the figures missing. They "
                                "were never missing, only relabelled. Verified as the same "
                                "measure before merging: across 5,750 rows Flown Seats divided "
                                "by Capacity reproduces the sheet's OWN stated load factor to "
                                "within half a percentage point, and flown equals sold minus "
                                "no-shows and offloads on 99.4% of rows."),
        ("Not settled yet", f"{len(unsettled):,} row(s)"
                            + (f" ({unsettled.flight_date.min():%d %b %Y} to "
                               f"{unsettled.flight_date.max():%d %b %Y})" if len(unsettled) else "")
                            + " are EXCLUDED. Those blocks were captured before the flights "
                              "departed and never refreshed: they decay 82%, 78%, 69% down to "
                              "36%, which is a booking curve, while the independent Zenith "
                              "export shows the same departures at 91-95% booked. The cut is "
                              "found by cross-checking the two stores, not by a hardcoded date, "
                              "so it moves by itself when the workbook is refreshed."),
        ("Did not operate", f"{len(nonop):,} row(s) carry a capacity and a flown of exactly "
                            f"zero, with no sold figure, on routes that flew a normal load "
                            f"either side. A flight that did not operate offered no seats, so "
                            f"counting it as 0% full invents seats that were never for sale. "
                            f"They are excluded. Including them would move a month by: "
                            + ("; ".join(eff) if eff else "nothing") + " points."),
        ("Basis of the ratio", f"{len(d) - len(stated):,} row(s) use a RECORDED flown figure. "
                               f"{len(stated):,} use the sheet's own stated load factor because "
                               f"no flown figure was recorded; those are marked in the Measured "
                               f"basis column on the Monthly Trend sheet. Nothing is imputed "
                               f"beyond that."),
        ("Coverage", "  ".join(f"{y}: {int(r['months'])} month(s), {int(r['rows']):,} rows"
                               for y, r in cov.iterrows())),
        ("2024 is a part year", "February to July 2024 are ABSENT from the workbook. Any 2024 "
                                "annual average is Jan plus Aug-Dec, and a Jan-to-Aug 'MoM' "
                                "would span a seven-month hole. Those cells read blank."),
        ("Partial months", "A month holding under 90% of its calendar days is flagged PARTIAL "
                           "on the Monthly Trend sheet and excluded from the best and weakest "
                           "cards on the dashboard. January 2024 holds three days, so the "
                           "January 2025 year-on-year figure compares a whole month with a "
                           "three-day sample and is labelled as such."),
        ("Load factor", "flown / capacity, seat-weighted across the group, never a mean of "
                        "per-flight ratios. Rows above 150% are excluded as mis-keyed."),
        ("The sheet's own totals", "The workbook carries 'No. of flights' rows holding daily "
                                   "totals. They are dropped on the flight-number pattern, not "
                                   "on how believable their arithmetic looks: most are obvious "
                                   "(a capacity of 19 against 5,628 flown, because that column "
                                   "holds a flight count) but one reads a perfectly plausible "
                                   "92.3% and would have added 366 seats that never existed."),
        ("MoM vs YoY", "MoM carries seasonality and is shown for movement, not for judgement. "
                       "YoY compares the same month a year earlier and is the performance read."),
    ]
    r = 3
    for a, b in notes:
        _c(ws, r, 1, a, bold=True, color=NAVY, align="left")
        _c(ws, r, 2, b, wrap=True)
        ws.row_dimensions[r].height = 44
        r += 1


def generate(params: dict | None = None, cfg: Config | None = None) -> Path:
    params = params or {}
    cfg = cfg or load_config(validate=False)
    print("[lf-yearly] reading the multi-year load store ...")
    raw = pd.read_parquet(cfg.data_root / "curated" / "flight_history" /
                          "flight_loads_yearly.parquet")
    allrows = load_all(cfg)
    d = load(cfg)
    g = monthly(d)

    wb = Workbook()
    wb.remove(wb.active)
    _sheet_monthly(wb, g)
    _sheet_sector(wb, d)
    _sheet_route(wb, d)
    _sheet_method(wb, d, len(raw), allrows)

    # The dashboard needs its numbers in cells first, so Chart Data is written before it, then
    # the dashboard is inserted at position 0 so it is the sheet the workbook opens on.
    latest = str(g.year_month.max())
    md, mi = split_sector(d)
    routes = _top_routes(d, latest)
    blocks = _sheet_chart_data(wb, g, md, mi, routes)
    _sheet_dashboard(wb, g, routes, latest, blocks)
    wb.active = 0

    print(f"    {len(d):,} usable flight-days of {len(raw):,} parsed · "
          f"{g.year_month.min()} -> {g.year_month.max()}")
    n_uns = int((~allrows.settled).sum())
    if n_uns:
        u = allrows[~allrows.settled]
        print(f"    [EXCLUDED] {n_uns:,} row(s), {u.flight_date.min():%d %b} to "
              f"{u.flight_date.max():%d %b %Y}: captured before departure, so they hold "
              f"bookings-so-far and not a load")
    n_stated = int((d.lf_basis == "stated").sum())
    if n_stated:
        print(f"    [BASIS] {n_stated:,} row(s) have no flown figure and use the sheet's own "
              f"stated load factor; the Monthly Trend sheet shows the measured share per month")
    yoy = g[g.yoy.notna()]
    if len(yoy):
        print(f"    YoY available on {len(yoy)} month(s); "
              f"latest {yoy.iloc[-1].year_month} {yoy.iloc[-1].lf:.1%} "
              f"({yoy.iloc[-1].yoy*100:+.1f} pts)")
    for x in g[~g.full].to_dict("records"):
        print(f"    [PARTIAL] {x['year_month']} holds {int(x['days'])} of "
              f"{int(x['days_in_month'])} days at {x['lf']:.1%} - plotted, but kept out of the "
              f"best/weakest ranking")
    gaps = int(g.mom.isna().sum())
    if gaps:
        print(f"    {gaps} month(s) have no MoM because the previous month is absent from the "
              f"source (2024 is missing Feb-Jul)")

    out_dir = Path(params.get("out_dir") or cfg.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    out = out_dir / f"Load_Factor_Trend_{datetime.now():%Y%m%d}.xlsx"
    try:
        wb.save(out)
    except PermissionError:
        out = out.with_name(out.stem + "__new.xlsx")
        wb.save(out)
        print("    [note] the previous workbook is open in Excel, wrote a __new sibling")
    print(f"[OK] -> {out}")
    return out
