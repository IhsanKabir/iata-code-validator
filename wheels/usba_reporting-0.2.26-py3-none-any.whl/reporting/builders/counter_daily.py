"""
reporting.builders.counter_daily — "Counter Daily Activities", one sheet per day.

Reproduces the counter's own daily activity workbook (D01..D31) from the sales
warehouse: per day, the PNRs a counter issued, reissued and refunded, who served
them, for how much, and the running month totals.

RECONCILED AGAINST THE HAND-KEPT WORKBOOK (DAC-07 Baridhara, 6 Aug 2026):
    Issue 428,415 · Reissue 34,856 · Refund -8,870
    Total 463,271 · Net after refund 454,401      — every figure to the rupee.

Three rules had to be derived from that reconciliation; none is obvious:

1. GRAIN. The warehouse is per TICKET, the report is per PNR. One PNR was 27
   ticket rows of 4,349 against a single line of 117,423.

2. BLOCKS ARE PER TRANSACTION LINE, NOT PER PNR. A PNR issued and refunded on the
   same day belongs in BOTH blocks. Classifying the whole PNR one way put 19,370
   in the wrong block.

3. `Penalty` FOLLOWS ITS PNR'S ACTION — to Reissue for a reissued PNR, to Refund
   for a refunded one. That one rule moved 10,500.

So: Issue = Ticket payment + discounts · Reissue = Reissuance Adjustment + Penalty
· Refund = Refund + Adjustment + Penalty.

WHAT THE WAREHOUSE CANNOT GIVE
Customer mobile numbers are not in it. `mobile_lookup` is an optional callable
(PNR -> mobile) so the caller can fill them from Zenith; without one the column is
left blank rather than faked. Employee IDs (USBA-xxxxx) live in a reference file —
see `load_employee_ids`; unknown staff get a blank ID, never a guessed one.

Public entry point: ``generate(params, cfg) -> Path``.
params: month ("YYYY-MM"), counter (Point of sales), out_dir, mobile_lookup.
"""
from __future__ import annotations

import calendar
import datetime as dt
import json
import re
from collections import defaultdict
from pathlib import Path

import duckdb
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from ..config import Config, load_config

ISSUE, REISSUE, REFUND = "Ticket Issue", "Ticket Reissue", "Ticket Refund"
BLOCKS = (ISSUE, REISSUE, REFUND)

#: which block each transaction line belongs to. `Penalty` is decided per PNR.
_REFUND_LINES = {"Refund", "Adjustment"}
_REISSUE_LINES = {"Reissuance Adjustment"}

LEGEND = (
    ("INT", "International"), ("DOM", "Domestic Ticket"),
    ("TA", "Travel Agency Ticket"), ("OW", "One Way Ticket"),
    ("RT", "Return Ticket"), ("FSU", "First Segment Used Ticket"),
    ("UT", "Unused Ticket"), ("GF", "Group Fare"),
)

_TITLES = {"mr", "mrs", "ms", "miss", "dr", "prof", "engr"}
_NAVY = PatternFill("solid", fgColor="1F3864")
_GREY = PatternFill("solid", fgColor="EDF0F5")
_THIN = Side(style="thin", color="BFBFBF")
_BORDER = Border(left=_THIN, right=_THIN, top=_THIN, bottom=_THIN)


def name_key(name: str) -> str:
    """Match a name regardless of word order or title.

    The warehouse writes "Akter  Ms. Afia" where the counter writes "Afia Akter",
    so the sortable set of real name words is the only reliable key. "Md." is kept
    — it is part of the name here, not a title.
    """
    words = re.findall(r"[A-Za-z]+", str(name or "").lower())
    return " ".join(sorted(w for w in words if w not in _TITLES))


def load_employee_ids(cfg: Config) -> dict[str, str]:
    """name_key -> USBA employee id, from reference/counter_employees.json.

    Seeded from the counter's own workbook (every row carries name + id). Missing
    staff simply have no id — the report shows a blank, never a guess.
    """
    p = Path(cfg.data_root) / "reference" / "counter_employees.json"
    if not p.is_file():
        return {}
    try:
        raw = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return {name_key(k): str(v) for k, v in raw.items() if k and v}


def save_employee_ids(cfg: Config, mapping: dict[str, str]) -> Path:
    """Persist a display-name -> id map (merging with what is already there)."""
    p = Path(cfg.data_root) / "reference" / "counter_employees.json"
    p.parent.mkdir(parents=True, exist_ok=True)
    existing = {}
    if p.is_file():
        try:
            existing = json.loads(p.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            existing = {}
    existing.update({k: v for k, v in mapping.items() if k and v})
    p.write_text(json.dumps(existing, indent=2, ensure_ascii=False), encoding="utf-8")
    return p


def _gold(cfg: Config) -> str:
    return (Path(cfg.data_root) / "gold" / "sales_bi.parquet").as_posix()


def fetch(cfg: Config, counter: str, month: str):
    """Every counter line for the month, plus each PNR's ORIGINAL booking source."""
    y, m = (int(x) for x in month.split("-")[:2])
    last = calendar.monthrange(y, m)[1]
    lo, hi = f"{y:04d}-{m:02d}-01", f"{y:04d}-{m:02d}-{last:02d}"
    con = duckdb.connect()
    src = _gold(cfg)
    counter_sql = counter.replace("'", "''")
    lines = con.sql(f"""
        SELECT CAST("Pure Date" AS DATE) AS d,
               "Record Locator" AS loc, "Transaction" AS txn,
               "Sale agent" AS agent, "Payment Type" AS pay,
               "Journey type" AS jt, sector,
               SUM("Balance (base currency)") AS amt
        FROM read_parquet('{src}')
        WHERE Channel = 'OFFICE' AND "Point of sales" = '{counter_sql}'
          AND CAST("Pure Date" AS DATE) BETWEEN DATE '{lo}' AND DATE '{hi}'
          AND "Record Locator" IS NOT NULL
        GROUP BY 1, 2, 3, 4, 5, 6, 7
        ORDER BY 1, 2
    """).df()
    if lines.empty:
        return lines, {}, (lo, hi)

    locs = ",".join("'" + str(x).replace("'", "''") + "'"
                    for x in sorted(set(lines["loc"])))
    origin = con.sql(f"""
        SELECT "Record Locator" AS loc, "Point of sales" AS pos, Channel AS ch,
               MIN(CAST("Pure Date" AS DATE)) AS first_d
        FROM read_parquet('{src}')
        WHERE "Record Locator" IN ({locs}) AND "Transaction" = 'Ticket payment'
        GROUP BY 1, 2, 3
        QUALIFY ROW_NUMBER() OVER (PARTITION BY "Record Locator"
                                   ORDER BY MIN(CAST("Pure Date" AS DATE))) = 1
    """).df()
    booked_from = {r.loc: booking_source(r.pos, r.ch) for r in origin.itertuples()}
    return lines, booked_from, (lo, hi)


def booking_source(point_of_sale: str, channel: str) -> str:
    """How the counter names where a reissued PNR was originally sold.

    Verified against the hand-kept sheet: an own office becomes "<Office> Sales"
    (DAC-07 Baridhara -> "Baridhara Sales") and an agency booking becomes
    "INT TA" (Galileo 1G 1G / AGENCY).
    """
    pos = str(point_of_sale or "").strip()
    if str(channel or "").upper() == "OFFICE" and pos:
        # "DAC-07 Baridhara" -> "Baridhara Sales"
        tail = re.sub(r"^[A-Z]{3}-\d+\s*", "", pos).strip()
        return f"{tail} Sales" if tail else pos
    if str(channel or "").upper() == "AGENCY":
        return "INT TA"
    return pos or str(channel or "")


def _as_date(v) -> dt.date:
    """DuckDB hands dates back as pandas Timestamps; the sheets are keyed by date."""
    return v.date() if hasattr(v, "date") else v


def classify(lines):
    """(day, block, loc, agent) -> {amount, cash, pay, jt, sector}.

    Line-level classification: a PNR issued AND refunded on the same day lands in
    both blocks, which is what the counter's own sheet does.
    """
    has_refund: dict[tuple, bool] = defaultdict(bool)
    has_reissue: dict[tuple, bool] = defaultdict(bool)
    for r in lines.itertuples():
        key = (_as_date(r.d), r.loc)
        if r.txn in _REFUND_LINES:
            has_refund[key] = True
        if r.txn in _REISSUE_LINES:
            has_reissue[key] = True

    out: dict[tuple, dict] = {}
    for r in lines.itertuples():
        key = (_as_date(r.d), r.loc)
        if r.txn in _REFUND_LINES:
            block = REFUND
        elif r.txn in _REISSUE_LINES:
            block = REISSUE
        elif r.txn == "Penalty":
            block = REFUND if has_refund[key] else (
                REISSUE if has_reissue[key] else ISSUE)
        else:
            block = ISSUE                     # Ticket payment + discount lines
        k = (_as_date(r.d), block, r.loc, r.agent)
        cell = out.setdefault(k, {"amt": 0.0, "pay": r.pay, "jt": r.jt,
                                  "sector": r.sector})
        cell["amt"] += float(r.amt or 0.0)
    return {k: v for k, v in out.items() if round(v["amt"], 2) != 0.0}


def _c(ws, row, col, value, *, bold=False, fill=None, fmt=None, align=None,
       size=10, border=False, color=None):
    cell = ws.cell(row, col, value)
    cell.font = Font(bold=bold, size=size, color=color or "000000")
    if fill:
        cell.fill = fill
    if fmt:
        cell.number_format = fmt
    if align:
        cell.alignment = Alignment(horizontal=align, vertical="center")
    if border:
        cell.border = _BORDER
    return cell


_HDR_ISSUE = ["Counter Name", "Action", "Count PNR", "Employee Name", "Employee ID",
              "PNR", "Customer Mobile No", "", "Sales Amount (BDT)", "Cash", "Invoice"]
_HDR_REISSUE = ["Counter Name", "Action", "Count PNR", "Employee Name", "Employee ID",
                "PNR", "PNR Booked from", "Customer Mobile No",
                "Sales Amount (BDT)", "Cash", "Invoice"]


def _write_day(ws, day, rows_for_day, counter, booked_from, emp_ids, mobiles,
               previous_sales):
    """One D-sheet. Returns (total_sales, refund, net)."""
    # %-d is glibc-only and raises on Windows — build the day number ourselves
    title = (f"Counter Daily Activities of {day.day} {day:%b %Y}"
             if hasattr(day, "strftime") else "Counter Daily Activities")
    _c(ws, 1, 1, title, bold=True, size=12)
    r = 2
    totals = {}
    for block in BLOCKS:
        items = [(k, v) for k, v in rows_for_day.items() if k[1] == block]
        totals[block] = sum(v["amt"] for _k, v in items)
        if not items:
            continue
        header = _HDR_REISSUE if block == REISSUE else _HDR_ISSUE
        for j, h in enumerate(header, 1):
            if h:
                _c(ws, r, j, h, bold=True, fill=_NAVY, color="FFFFFF",
                   align="center", size=9, border=True)
        r += 1
        first = r
        for (_d, _b, loc, agent), v in sorted(items, key=lambda kv: -abs(kv[1]["amt"])):
            _c(ws, r, 4, agent, size=9, border=True)
            _c(ws, r, 5, emp_ids.get(name_key(agent), ""), size=9, border=True)
            _c(ws, r, 6, loc, size=9, border=True)
            if block == REISSUE:
                _c(ws, r, 7, booked_from.get(loc, ""), size=9, border=True)
                _c(ws, r, 8, mobiles.get(loc, ""), size=9, border=True)
            else:
                _c(ws, r, 7, mobiles.get(loc, ""), size=9, border=True)
            _c(ws, r, 9, round(v["amt"]), fmt="#,##0", align="right", size=9,
               border=True)
            if str(v.get("pay", "")).lower().startswith("cash"):
                _c(ws, r, 10, round(v["amt"]), fmt="#,##0", align="right", size=9,
                   border=True)
            else:
                _c(ws, r, 11, round(v["amt"]), fmt="#,##0", align="right", size=9,
                   border=True)
            r += 1
        _c(ws, first, 2, block, bold=True, size=9, border=True)
        _c(ws, first, 3, len({k[2] for k, _v in items}), bold=True, align="center",
           size=9, border=True)      # Count PNR = distinct PNRs, not lines
        r += 1

    total_sales = totals.get(ISSUE, 0.0) + totals.get(REISSUE, 0.0)
    refund = abs(totals.get(REFUND, 0.0))
    net = total_sales - refund
    r += 1
    for label, value in (("Privious Sales:", previous_sales),
                         ("Total Sales    :", total_sales),
                         ("Refund           :", refund),
                         ("Actual Sales  :", previous_sales + net)):
        _c(ws, r, 6, label, bold=True, size=10)
        _c(ws, r, 8, round(value), bold=True, fmt="#,##0", align="right", size=10)
        if label.startswith("Total"):
            _c(ws, r, 11, "Net Sell After Refund:", bold=True, size=10)
            _c(ws, r, 12, round(net), bold=True, fmt="#,##0", align="right", size=10)
        r += 2

    r += 1
    _c(ws, r, 2, "Note:", bold=True, size=9)
    for short, long in LEGEND:
        r += 1
        _c(ws, r, 2, f"{short}  =", size=9)
        _c(ws, r, 3, long, size=9)

    for col, w in ((1, 14), (2, 16), (3, 10), (4, 22), (5, 13), (6, 11), (7, 18),
                   (8, 18), (9, 17), (10, 12), (11, 12), (12, 12)):
        ws.column_dimensions[get_column_letter(col)].width = w
    return total_sales, refund, net


def generate(params: dict | None = None, cfg: Config | None = None) -> Path:
    params = params or {}
    cfg = cfg or load_config(validate=True)
    counter = params.get("counter") or "DAC-07 Baridhara"
    month = params.get("month") or dt.date.today().strftime("%Y-%m")
    mobile_lookup = params.get("mobile_lookup")          # PNR -> mobile, optional

    lines, booked_from, (lo, _hi) = fetch(cfg, counter, month)
    if lines.empty:
        raise ValueError(f"No counter activity for {counter} in {month}.")
    cells = classify(lines)
    emp_ids = load_employee_ids(cfg)

    mobiles: dict[str, str] = dict(params.get("mobiles") or {})
    if mobile_lookup:
        for loc in sorted({k[2] for k in cells}):
            if loc in mobiles:
                continue
            try:
                mobiles[loc] = mobile_lookup(loc) or ""
            except Exception:                            # noqa: BLE001
                mobiles[loc] = ""                        # never sink the report

    by_day: dict[dt.date, dict] = defaultdict(dict)
    for k, v in cells.items():
        by_day[k[0]][k] = v

    wb = Workbook()
    wb.remove(wb.active)
    running = float(params.get("opening_balance") or 0.0)
    y, m = (int(x) for x in month.split("-")[:2])
    for dayno in range(1, calendar.monthrange(y, m)[1] + 1):
        day = dt.date(y, m, dayno)
        rows = by_day.get(day, {})
        if not rows and not params.get("all_days"):
            continue
        ws = wb.create_sheet(f"D{dayno:02d}")
        ws.sheet_view.showGridLines = False
        _total, _refund, net = _write_day(ws, day, rows, counter, booked_from,
                                          emp_ids, mobiles, running)
        running += net

    out_dir = Path(params.get("out_dir") or cfg.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    safe = re.sub(r"[^A-Za-z0-9]+", "_", counter).strip("_")
    path = out_dir / f"Counter_Daily_Activities_{safe}_{month}.xlsx"
    wb.save(path)
    return path
