﻿"""
reporting.builders.city_market â€” the city-wise market sheet, built from the cited store.

WHAT IT EMITS (two files, deliberately)
    City_wise_data_SUBMISSION.xlsx
        The template's ORIGINAL shape and nothing else: No, Destinations, and the six columns
        as they were asked for. This is the file that gets sent. It carries no working, because
        the recipient asked for a filled template, not our evidence.
    City_wise_data_EVIDENCE.xlsx
        The same rows plus, for every figure, its source, its year, how far it can be trusted
        and how it was derived, then the BS demand columns and a Sources sheet. This is what
        defends the submission when someone asks where a number came from.

    Splitting them is not tidiness. A submission carrying our confidence vocabulary invites the
    reader to argue with the method instead of reading the answer, and an evidence pack squeezed
    into seven columns cannot defend anything.

HOW A CELL IS CHOSEN
    Facts are stored long, so one (entity, metric) can hold several competing values: UN DESA
    and BMET both answer "Bangladeshi living in Country" and disagree by design. The winner is
    picked by CONFIDENCE first (measured > official_estimate > apportioned > press_estimate),
    then by the most recent as_of_year. Whatever wins, the Remarks column names the basis, so
    the sheet never quietly presents a modelled figure as a counted one.

WHAT STAYS BLANK, AND WHY THAT IS THE POINT
    * values held at use=0 (apportioned or press, not yet signed off) are NOT printed
    * where a source genuinely has no figure the cell is empty and Remarks says which source
      was silent
    A blank with a stated reason is worth more than a plausible number, because the reader can
    act on the first and cannot audit the second. Every blank is counted in the run summary.
"""
from __future__ import annotations

import re
from datetime import datetime
from pathlib import Path

import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from ..config import Config, load_config

NAVY, BLUE, WHITE, GREY = "1F3864", "2E5395", "FFFFFF", "F2F2F2"
AMBER, GREENL, REDL = "FFF2CC", "E2EFDA", "FCE4E4"
BORDER = Border(*([Side(style="thin", color="BFBFBF")] * 4))
FI = "#,##0"

# best first. A value only beats another if it is MORE trustworthy, never merely newer.
CONF_RANK = {"measured": 0, "official_estimate": 1, "apportioned": 2, "press_estimate": 3}

#: The marker that lets a human decision outrank the source ranking. Written only by
#: scripts/_apply_analyst_final.py, never by a parser, so it cannot appear by accident.
#: See THE ANALYST OVERRIDE in best_values().
ADOPTED_MARK = "ADOPTED BY ANALYST"
CONF_LABEL = {"measured": "counted", "official_estimate": "official estimate",
              "apportioned": "APPORTIONED, not a count", "press_estimate": "press estimate"}

BD_AIRPORTS = ("DAC", "CGP", "CXB", "ZYL", "JSR", "RJH", "BZL", "SPD")


def _text_of(v) -> str:
    """A stored value_text as a clean string, treating NaN/None as empty.

    Mirrors _cell_str in the ingest, and for the same reason: NaN is truthy, so the obvious
    `str(v or "")` turns an empty cell into the string "nan". Here that would print the word
    "nan" into a submitted sheet where a population number belongs.
    """
    if v is None:
        return ""
    try:
        if pd.isna(v):
            return ""
    except (TypeError, ValueError):
        pass
    return str(v).strip()


def _c(ws, r, col, v, *, bold=False, fill=None, fmt=None, color="000000", size=9, wrap=False):
    cell = ws.cell(row=r, column=col, value=v)
    cell.font = Font(bold=bold, color=color, size=size)
    cell.border = BORDER
    if fill:
        cell.fill = PatternFill("solid", fgColor=fill)
    if fmt:
        cell.number_format = fmt
    if wrap:
        cell.alignment = Alignment(wrap_text=True, vertical="top")
    return cell


def _widths(ws, m: dict[str, float]) -> None:
    for k, v in m.items():
        ws.column_dimensions[k].width = v


# ---------------------------------------------------------------------------------------
def load_store(cfg: Config) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """(facts, crosswalk, sources). Missing store is a hard error: an empty sheet that looks
    built is worse than one that refuses to build."""
    facts_p = cfg.data_root / "curated" / "market_facts" / "market_facts.parquet"
    cw_p = cfg.reference / "market_geo_crosswalk.xlsx"
    src_p = cfg.reference / "market_sources.xlsx"
    if not facts_p.is_file():
        raise FileNotFoundError(
            f"no market store at {facts_p}\n"
            f"  run: .venv/Scripts/python.exe scripts/10_ingest_market_intel.py")
    if not cw_p.is_file():
        raise FileNotFoundError(
            f"no crosswalk at {cw_p}\n"
            f"  run: .venv/Scripts/python.exe scripts/_build_market_geo_crosswalk.py")
    facts = pd.read_parquet(facts_p)
    cw = pd.read_excel(cw_p, sheet_name="crosswalk")
    sources = pd.read_excel(src_p, sheet_name="sources") if src_p.is_file() else pd.DataFrame()
    return facts, cw, sources


# Among equally-confident sources, WHOSE census is it. A destination country counting its own
# residents beats a global third-party model of the same thing, even an older one, because the
# model is itself built from national sources and smooths away what it cannot see. This is not
# theoretical: UN DESA puts Bangladeshis in Saudi Arabia at 185,831 while Saudi's own 2022
# census counts 2,116,192, and in the Maldives at 556 against a census 74,815. Ranking on
# recency alone let the model beat the census and shipped both understatements.
SOURCE_PRIORITY = {"dest_census_": 0, "dest_stat_": 0, "mission_": 0,   # counted where they live
                   "uk_ons_": 0, "au_abs_": 0,
                   "undesa_": 1,                                       # a global model
                   "bmet_": 2}                                         # a flow used as a proxy



# "City" is ambiguous and the ambiguity is load-bearing: Greater London is 8.8m but the UN WUP
# agglomeration is 10.4m, and Manchester's city local authority is a fraction of Greater
# Manchester. Every value therefore states the UNIT it was measured over, keyed on the source
# that supplied it, so a reader never has to infer it from prose.
GEO_UNIT = {
    "un_wup_2025": "urban agglomeration (UN WUP)",
    "wb_wdi_pop": "whole country",
    "uk_ons_2021": "London = REGION; Birmingham/Manchester = city local authority",
    "au_abs_2021": "Significant Urban Area (ABS)",
    "dest_census_can_2021": "Census Metropolitan Area (Toronto CMA)",
    "dest_census_usa_acs": "Metropolitan Statistical Area, not the municipality",
    "dest_census_ita_istat": "comune (municipality)",
    "dest_census_jpn_tokyo": "Tokyo Metropolis",
    "dest_census_nzl_2023": "territorial authority (Auckland)",
    "dest_census_sau_2022": "whole country",
    "dest_census_mdv_2022": "whole country",
    "dest_stat_omn_2025": "whole country",
    "dest_stat_qat_2025": "whole country",
    "dest_stat_kwt_2026": "whole country",
    "mission_bd_cg_dubai_2025": "whole country",
    "official_bd_hc_singapore": "whole country (Singapore is a city-state)",
    "press_dawn_herald_2017": "Karachi city, ~105 settlements",
    "undesa_ims_2024": "whole country",
    "bmet_overseas": "whole country",
    "dest_stat_bhr_2022": "whole country",
    "dest_stat_mys_2025": "whole country",
    # The adopted estimates are stated at the grain they were supplied at: a city figure is a
    # city figure and the country figure is the modelled national total built from them.
    "analyst_final_2026": "as supplied: city rows are cities, the country row is the modelled "
                          "national total",
    "dest_census_jor_2015": "Amman GOVERNORATE (counted, not apportioned)",
    "dest_census_ind_2011": "district / state (counted)",
    "dest_census_pak_2023": "district (counted)",
    "dest_stat_kor_2025": "city or province (counted)",
    "dest_stat_jpn_2025": "prefecture (counted)",
    "dest_stat_deu_2024": "whole country",
    "dest_stat_fra_2019": "whole country",
    "dest_stat_grc_2025": "whole country",
    "dest_census_zaf_2022": "whole country",
}


def _geo_unit(source_id: str) -> str:
    return GEO_UNIT.get(str(source_id or ""), "")


# What each source actually MEASURES. The audit's sharpest structural point: a column holding
# country-of-birth, citizenship, ethnicity and worker counts side by side is not rank-comparable,
# and a reader will sort it anyway. Stating the measure per value is the cheapest honest fix.
MEASURE_OF = {
    # An adopted figure must never read as a count. Every other entry in this map names a
    # counting basis (country of birth, citizenship, a work permit); this one names the fact
    # that there is no counting basis at all, because it is our own judgement.
    "analyst_final_2026": "our own estimate, NOT a count",
    "uk_ons_2021": "country of birth",
    "au_abs_2021": "country of birth",
    "dest_census_can_2021": "country of birth",
    "dest_census_usa_acs": "country of birth",
    "dest_census_ita_istat": "citizenship",
    "dest_census_jpn_tokyo": "nationality register",
    "dest_census_nzl_2023": "ethnicity (incl. locally born)",
    "official_bd_hc_singapore": "migrant workers only",
    "press_dawn_herald_2017": "ethnicity (incl. locally born)",
    "dest_census_sau_2022": "census residents",
    "dest_census_mdv_2022": "census residents",
    "dest_stat_omn_2025": "workers, dependants excluded",
    "dest_stat_qat_2025": "workers, dependants excluded",
    "dest_stat_kwt_2026": "civil register residents",
    "mission_bd_cg_dubai_2025": "official estimate, basis unstated",
    "undesa_ims_2024": "modelled resident stock",
    "bmet_overseas": "EMPLOYMENT FLOW, departures not residents",
    "dest_stat_bhr_2022": "workers + dependants, a floor",
    "dest_stat_mys_2025": "work passes, a floor",
    "dest_census_jor_2015": "citizenship, census-counted",
    "dest_census_ind_2011": "migrants by place of last residence",
    "dest_census_pak_2023": "nationality (census)",
    "dest_stat_kor_2025": "foreign residents by nationality",
    "dest_stat_jpn_2025": "foreign residents by nationality",
    "dest_stat_deu_2024": "citizenship, central register",
    "dest_stat_fra_2019": "country of birth",
    "dest_stat_grc_2025": "valid residence permits",
    "dest_census_zaf_2022": "country of birth",
}


def _measure_of(source_id: str, conf: str) -> str:
    m = MEASURE_OF.get(str(source_id or ""), "")
    if conf == "apportioned":
        return f"APPORTIONED from {m}" if m else "APPORTIONED ESTIMATE"
    return m


# Human-readable publisher per source, for the Remarks column that actually gets sent.
# A diaspora figure this old is called out at the START of the Remarks column rather than left
# to be discovered. Ten years is the threshold because a census cycle is ten years, so anything
# past it has missed at least one enumeration it should have been replaced by.
NOW_YEAR = datetime.now().year
STALE_YEARS = 10

PUBLISHER_OF = {
    # ARRIVALS sources. A flow, not a stock, and named in full because these lines reach the
    # submission sheet, where a raw source_id like "in_tourism_dashboard" is jargon.
    "in_tourism_dashboard": "India Ministry of Tourism, foreign tourist arrivals",
    "th_mots_arrivals": "Thailand Ministry of Tourism and Sports, arrivals by nationality",
    "sg_singstat_iva_air": "Singapore Tourism Board, visitor arrivals by air",
    "my_datagovmy_arrivals": "Malaysia Immigration, arrivals by nationality",
    "np_ntb_arrivals": "Nepal Tourism Board / Dept of Immigration, arrivals by nationality",
    "lk_sltda_arrivals": "Sri Lanka Tourism Development Authority, tourist arrivals",
    "press_ind_current_estimate": "current estimate in general circulation, NOT a count",
    # Reads on the submitted sheet, so it says WHOSE estimate it is rather than printing the
    # raw id. The wording is deliberately plain about it being our own number, not a count.
    "analyst_final_2026": "US-Bangla commercial team estimate, adopted over the sourced figure",
    "mdv_maldivesmonetaryau_arrivals": "Maldives Immigration via the Monetary Authority, "
                                       "tourist arrivals",
    "mys_thebangladeshmonit_arrivals": "Tourism Malaysia figure quoted in the press, "
                                       "TOURIST basis",
    "calibrated_undesa_gap": "calibrated from peer countries, a model not a count",
    "undesa_ims_2024": "UN DESA modelled resident stock",
    "bmet_overseas": "BMET overseas-employment DEPARTURES (a flow, not residents)",
    "dest_census_sau_2022": "Saudi Census (GASTAT)",
    "dest_census_mdv_2022": "Maldives Census",
    "dest_stat_omn_2025": "Oman NCSI expatriate workforce",
    "dest_stat_qat_2025": "Qatar/Bangladesh MoEWOE employed nationals",
    "dest_stat_kwt_2026": "Kuwait PACI civil register",
    "mission_bd_cg_dubai_2025": "Consulate General of Bangladesh, Dubai (official estimate)",
    "uk_ons_2021": "UK Census (ONS)",
    "au_abs_2021": "Australian Census (ABS)",
    "dest_census_can_2021": "Canadian Census (StatCan)",
    "dest_census_usa_acs": "US Census ACS",
    "dest_census_ita_istat": "ISTAT resident register",
    "dest_census_jpn_tokyo": "Tokyo Metropolitan Government register",
    "dest_census_nzl_2023": "Stats NZ Census",
    "official_bd_hc_singapore": "Bangladesh High Commission Singapore (official estimate)",
    "press_dawn_herald_2017": "Dawn/Herald, informal survey",
    "dest_stat_bhr_2022": "Bahrain LMRA expatriate register",
    "dest_stat_mys_2025": "Malaysia Immigration Department work passes",
    "dest_census_jor_2015": "Jordan DOS Census 2015 (a FLOOR: garments alone now employ ~31,500)",
    "dest_census_ind_2011": "India Census 2011 (INDIA'S LATEST: the 2021 census was postponed, next is 2027)",
    "dest_census_pak_2023": "Pakistan Census, by district",
    "dest_stat_kor_2025": "Korea Immigration Service",
    "dest_stat_jpn_2025": "Japan Immigration Services Agency",
    "dest_stat_deu_2024": "Destatis central register",
    "dest_stat_fra_2019": "INSEE 2019 (latest published)",
    "dest_stat_grc_2025": "Greek Ministry of Migration",
    "dest_census_zaf_2022": "Statistics South Africa Census",
}


def _publisher_of(source_id: str) -> str:
    return PUBLISHER_OF.get(str(source_id or ""), str(source_id or "unstated source"))

def _source_rank(source_id: str) -> int:
    s = str(source_id or "")
    for prefix, rank in SOURCE_PRIORITY.items():
        if s.startswith(prefix):
            return rank
    return 1


def best_values(facts: pd.DataFrame) -> dict[tuple[str, str], dict]:
    """(entity_type, entity_key, metric) -> the winning row. use=0 values are excluded.

    entity_type IS PART OF THE KEY, and leaving it out was a real defect that shipped. Two of
    our IATA codes collide with ISO3 country codes: FRA is Frankfurt AND France, CAN is
    Guangzhou AND Canada. Keyed on (entity_key, metric) alone, France's 68,720,337 overwrote
    Frankfurt's 900,483 and Canada's 41,651,653 overwrote Guangzhou's, so the sheet printed a
    country's population as a city's. It reads as a plausible big-city number and nothing else
    breaks, which is why an external reviewer caught it before any of our own checks did.
    """
    live = facts[facts["use"] == 1].copy()
    live["_rank"] = live.confidence.map(CONF_RANK).fillna(9)
    live["_src"] = live.source_id.map(_source_rank)
    live = live.sort_values(["_rank", "_src", "as_of_year"], ascending=[True, True, False])
    out: dict[tuple[str, str], dict] = {}
    for r in live.to_dict("records"):
        out.setdefault((str(r["entity_type"]), str(r["entity_key"]), str(r["metric"])), r)

    # THE STALENESS OVERRIDE.
    #
    # Ranking by source type alone means a counted census always beats an estimate, however
    # many years apart they are. That is right almost everywhere: UN DESA reads 11x low against
    # Saudi's census and 134x low against the Maldives', so "newer" is usually worse. But it
    # left India printing a 2011 figure with no way to move, because every alternative loses on
    # type no matter how old the incumbent gets.
    #
    # So the override is narrow, and the gate is a HUMAN, not a rule: a materially newer value
    # displaces a stale winner ONLY if an analyst signed it off. UN DESA can never hijack a
    # census this way because it is never held for sign-off and so never carries the marker.
    for key, chosen in list(out.items()):
        yr = int(chosen.get("as_of_year") or 0)
        if not yr or NOW_YEAR - yr < STALE_YEARS:
            continue
        same = live[(live.entity_type == key[0]) & (live.entity_key == key[1]) &
                    (live.metric == key[2])]
        signed = same[same.method_note.astype(str).str.contains("SIGNED OFF", na=False) &
                      (same.as_of_year.astype(int) > yr)]
        if len(signed):
            win = signed.sort_values("as_of_year", ascending=False).iloc[0].to_dict()
            print(f"[city-market] {key[1]} {key[2]}: the {NOW_YEAR - yr}-year-old "
                  f"{chosen['source_id']} is replaced by the signed-off "
                  f"{win['source_id']} ({int(win['as_of_year'])})")
            out[key] = win

    # THE ANALYST OVERRIDE.
    #
    # Everything above ranks a value by WHAT KIND OF SOURCE it came from, and a counted census
    # always wins. That is the right default and it is why the store is trustworthy. But it
    # leaves no way for the company to say "we have looked at all of this and we are going with
    # our own number", and on 30 August 2026 that is exactly what the commercial team did: UN
    # DESA reads 1.6x to 134x below a destination census across the 24 countries where both
    # exist, median 5.0x, so the sourced figures were understating these markets badly.
    #
    # So an explicitly ADOPTED value wins outright. Three things keep this from becoming a hole
    # in the guard: the marker is never generated by any parser, so it can only be there because
    # a person put it there; the row still has to carry a registered source_id and a
    # signed_off_by like everything else; and what it displaced is recorded, so the decision is
    # visible rather than silent.
    for key, chosen in list(out.items()):
        if ADOPTED_MARK in str(chosen.get("method_note") or ""):
            continue                                   # already the winner, nothing displaced
        same = live[(live.entity_type == key[0]) & (live.entity_key == key[1]) &
                    (live.metric == key[2])]
        adopted = same[same.method_note.astype(str).str.contains(ADOPTED_MARK, na=False)]
        if not len(adopted):
            continue
        win = adopted.sort_values("as_of_year", ascending=False).iloc[0].to_dict()
        win["_displaced"] = (f"{chosen['source_id']} {int(chosen.get('as_of_year') or 0)}: "
                             f"{float(chosen.get('value') or 0):,.0f}")
        out[key] = win
    return out


def bs_evidence(cfg: Config, cw: pd.DataFrame) -> dict[str, dict]:
    """Per destination: do we sell it, and how much. Degrades to empty without gold."""
    gold = cfg.data_root / "gold" / "sales_bi.parquet"
    if not gold.is_file():
        return {}
    try:
        import duckdb
        con = duckdb.connect()
        d = con.execute(f"""
            SELECT "Arrival airport" AS apt,
                   COUNT(DISTINCT "Ticket number") AS tickets,
                   SUM("Balance (base currency)") AS net
            FROM read_parquet('{gold.as_posix()}')
            WHERE "Transaction" = 'Ticket payment' AND "Arrival airport" IS NOT NULL
              AND "Pure Date" >= DATE '{datetime.now().year}-01-01'
            GROUP BY 1""").df().set_index("apt")
    except Exception:                       # a mid-rebuild gold must not block the sheet
        return {}
    out = {}
    for r in cw.to_dict("records"):
        apts = [a.strip() for a in str(r.get("airport_codes") or "").split(",") if a.strip()]
        hit = [a for a in apts if a in d.index]
        if hit:
            out[str(r["code_given"])] = {
                "serves": True,
                "tickets": int(d.loc[hit, "tickets"].sum()),
                "net_cr": float(d.loc[hit, "net"].sum()) / 1e7,
                "airports": ", ".join(hit)}
        else:
            out[str(r["code_given"])] = {"serves": False}
    return out


# Tickets sold per resident Bangladeshi. Above VISITOR_RATIO the resident community cannot
# plausibly be filling the aircraft, so the traffic is visitors, patients or traders and a
# diaspora count is simply the wrong denominator for that route. The gap between the two groups
# in our own data is not marginal, it is three orders of magnitude: Dubai and Doha sit near
# 0.1 while Bangkok is around 493, Guangzhou 164 and Chennai 155. Anything in between is called
# mixed rather than forced into one camp.
VISITOR_RATIO = 10.0
MIXED_RATIO = 1.0
MIN_TICKETS_TO_JUDGE = 500      # below this the ratio is noise, so it is not classified at all


def _route_character(city_dia, tickets) -> tuple[float | None, str]:
    """(tickets per resident, what kind of route this is).

    Deliberately derived from OUR OWN sales, which need no external source and cannot be stale.
    It measures our traffic, not the whole market: a route we barely serve reads as small here
    even if the market is large. That is a limitation to state, not to hide.
    """
    if not tickets or tickets < MIN_TICKETS_TO_JUDGE:
        return None, "too few tickets to judge"
    if not isinstance(city_dia, (int, float)) or not city_dia or city_dia <= 0:
        return None, "no city diaspora figure"
    ratio = float(tickets) / float(city_dia)
    if ratio >= VISITOR_RATIO:
        kind = "VISITOR / MEDICAL driven"
    elif ratio >= MIXED_RATIO:
        kind = "mixed"
    else:
        kind = "diaspora driven"
    return round(ratio, 2), kind


def _city_visitors(picks: dict, cw: pd.DataFrame, iso: str) -> tuple[float | None, str]:
    """Bangladeshis ARRIVING at this city in a year, and on what basis.

    A separate number from the residents column and deliberately not added to it: 184 people
    live in Chennai and 48,116 arrive there, and they are not the same people. Summing them
    would produce a figure that means nothing.

    Two bases, and the sheet always says which:
      port of entry   the country publishes arrivals BY the airport people entered through.
                      India does, so Chennai, Kolkata and Delhi are counted directly.
      whole country   the country publishes only a national total, but this is the ONLY city we
                      list for it AND the country has one dominant international gateway, so the
                      national figure effectively is that city's. True for Kathmandu and
                      Colombo.
    Where neither holds, the cell stays blank. Splitting a national total across several listed
    cities by population share is exactly the apportionment that put 16,837 Bangladeshis in
    Mumbai when the census counted 900.
    """
    city = picks.get("city_arr")
    if city and city.get("value") is not None:
        return float(city["value"]), "port of entry"
    ctry = picks.get("ctry_arr")
    if not ctry or ctry.get("value") is None:
        return None, ""
    listed = cw[cw.country_iso3.astype(str) == str(iso)]
    if len(listed) == 1:
        return float(ctry["value"]), "whole country, this is its only listed gateway"
    return None, ""


def _city_share(city_dia, country_dia) -> float | None:
    """What share of the country's Bangladeshis this one city accounts for.

    The city figures are a PARTIAL list, a handful of cities per country rather than all of
    them, so these shares are not meant to reach 100%. Printing the share is what stops that
    reading as an arithmetic error: India's eight cities cover 10% of the country total, which
    is expected, and looks like a mistake only while it goes unstated.
    """
    if not isinstance(city_dia, (int, float)) or not isinstance(country_dia, (int, float)):
        return None
    if not country_dia or country_dia <= 0:
        return None
    return round(float(city_dia) / float(country_dia), 4)


def assemble(facts, cw, cfg) -> pd.DataFrame:
    """One row per destination with the chosen value AND its provenance side by side."""
    best = best_values(facts)
    bs = bs_evidence(cfg, cw)
    rows = []
    for r in cw.to_dict("records"):
        code, iso = str(r["code_given"]), str(r["country_iso3"])
        rec = {"no": r.get("no"), "template_label": r["template_label"],
               "city": r["city_name"], "code": code, "country": r["country_name_template"],
               "iso3": iso, "tier": r.get("tier", "")}
        picks = {
            "country_pop": best.get(("country", iso, "population_total")),
            # UN DESA resident stock first. BMET departures are the FALLBACK only, and only
            # where they are big enough to mean something: see _bmet_usable. Germany's 85
            # departures over six years is a true number and a false answer to "how many
            # Bangladeshis live in Germany", because Europe's community arrives on student,
            # professional, family and asylum routes an employment register never sees.
            "country_dia": best.get(("country", iso, "bd_diaspora_stock"))
                           or _bmet_usable(best.get(("country", iso, "bd_overseas_employment_cum"))),
            # kept so Remarks can say "BMET has only N, too few to use" instead of the bare
            # and less useful "no figure published"
            "bmet_raw": best.get(("country", iso, "bd_overseas_employment_cum")),
            "city_pop": best.get(("city", code, "population_total")),
            "city_dia": best.get(("city", code, "bd_diaspora_city")),
            # WHO FLIES THERE, as opposed to who lives there. A flow, not a stock, and the two
            # answer different questions: Bangkok has 145 resident Bangladeshis and carries
            # tens of thousands of visitors. Only India publishes this at city grain, via its
            # port-of-entry table.
            "city_arr": best.get(("city", code, "bd_visitor_arrivals")),
            "ctry_arr": best.get(("country", iso, "bd_visitor_arrivals")),
            "ctry_med": best.get(("country", iso, "bd_medical_arrivals")),
            # CATEGORICAL: the answer is a city name, carried in value_text, not value.
            "top_od": best.get(("city", code, "top_od_city")),
        }
        for name, p in picks.items():
            # A pick is numeric OR categorical. Reading value_text first means a categorical
            # fact never gets float()-ed into a crash, and a numeric one never prints as text.
            if p and _text_of(p.get("value_text")):
                rec[name] = _text_of(p["value_text"])
            else:
                rec[name] = float(p["value"]) if p and p.get("value") is not None else None
            rec[f"{name}_src"] = p["source_id"] if p else ""
            rec[f"{name}_yr"] = int(p["as_of_year"]) if p else ""
            rec[f"{name}_conf"] = p["confidence"] if p else ""
            rec[f"{name}_note"] = p["method_note"] if p else ""
            rec[f"{name}_unit"] = _geo_unit(p["source_id"]) if p else ""
            # What an ADOPTED value pushed aside, so the override is visible on the sheet rather
            # than only in the store. Blank for every value that won on the normal ranking.
            rec[f"{name}_displaced"] = (p or {}).get("_displaced", "") if p else ""
        e = bs.get(code, {})
        rec["bs_serves"] = "Y" if e.get("serves") else "N"
        rec["bs_tickets"] = e.get("tickets")
        rec["bs_net_cr"] = e.get("net_cr")
        rec["city_visitors"], rec["city_visitors_basis"] = _city_visitors(picks, cw, iso)
        rec["per_resident"], rec["route_type"] = _route_character(rec.get("city_dia"),
                                                                  e.get("tickets"))
        rec["city_share"] = _city_share(rec.get("city_dia"), rec.get("country_dia"))
        rec["remarks"] = _remarks(rec, picks, e, r)
        rows.append(rec)
    return pd.DataFrame(rows)


# Mirrors BMET_MIN_FOR_PROXY in scripts/10_ingest_market_intel.py. Below this many departures
# the figure says nothing about the resident community, so the cell stays blank and the Remarks
# column says why, which is the honest answer rather than a small confident-looking number.
BMET_MIN_FOR_PROXY = 1_000


def _bmet_usable(pick):
    """The BMET fallback, gated. Returns None when the figure is too small to be a proxy."""
    if pick is None:
        return None
    return pick if float(pick.get("value") or 0) >= BMET_MIN_FOR_PROXY else None


def _remarks(rec: dict, picks: dict, e: dict, cwrow: dict) -> str:
    """The one free column the template gives us. Spend it on what the reader cannot see:
    which basis the diaspora figure uses, what is missing and why, and our own demand."""
    bits = []
    # AGE FIRST, because a reader should never have to ask how old a number is. The vintage
    # used to sit mid-sentence inside the source citation, so a 2011 figure read as current
    # until somebody happened to notice the year. India is the whole of this problem: nine of
    # the ten figures older than a decade are Indian, and the store's median age is 3 years.
    old = []
    for label, p in (("country", picks.get("country_dia")), ("city", picks.get("city_dia"))):
        if p and str(p.get("as_of_year") or "").strip().isdigit():
            age = NOW_YEAR - int(p["as_of_year"])
            if age >= STALE_YEARS:
                old.append(f"the {label} figure is {age} YEARS OLD ({p['as_of_year']})")
    if old:
        # Name WHICH figure is stale. Once a signed-off current estimate replaces a stale
        # country total, the row can carry a 2025 country figure beside a 2011 city one, and a
        # single undifferentiated warning would misdescribe both.
        bits.append("AGE WARNING: " + " and ".join(old) +
                    "; no newer official count exists for it")
    # THE OVERRIDE, STATED ON THE ROW. An adopted figure beats a counted census, so the reader
    # is owed both the fact that a person chose it and the number it replaced. Without this the
    # sheet simply shows a different figure from last month with nothing to explain the jump.
    adopted = [(lab, rec.get(f"{k}_displaced"))
               for lab, k in (("country", "country_dia"), ("city", "city_dia"))
               if str(rec.get(f"{k}_displaced") or "").strip()]
    if adopted:
        bits.append("ADOPTED FIGURE, not the sourced one: " + "; ".join(
            f"the {lab} number is the commercial team's own estimate and replaces {was}"
            for lab, was in adopted) + ". Adopted deliberately because UN DESA and the "
            "destination censuses were judged to understate these markets")
    p = picks["country_dia"]
    if p is not None:
        # BRANCH ON THE SOURCE, NOT THE METRIC. This branched on metric, and every national
        # figure regardless of publisher carries metric 'bd_diaspora_stock', so the six
        # destination-country sources added later were all captioned "UN DESA resident stock".
        # Thirteen rows mis-cited their own source in the file that gets sent, which is exactly
        # the failure this column exists to prevent.
        bits.append(f"Diaspora basis: {_publisher_of(p['source_id'])} {p['as_of_year']} "
                    f"[{_measure_of(p['source_id'], p['confidence'])}]")
    elif picks.get("bmet_raw") is not None:
        # There IS a BMET number, it is just too small to mean anything. Saying so beats
        # "no figure published", which would imply nobody had looked.
        bits.append(f"No resident-stock figure published; BMET records only "
                    f"{float(picks['bmet_raw']['value']):,.0f} labour departures, too few to "
                    f"represent this country's Bangladeshi community, so the cell is left blank")
    else:
        bits.append("No Bangladeshi-diaspora figure published for this country")
    if picks["city_dia"] is None:
        bits.append("no city-level Bangladeshi figure exists")
    elif picks["city_dia"]["confidence"] in ("apportioned", "press_estimate"):
        cd = picks["city_dia"]
        bits.append(f"City figure is an APPORTIONED ESTIMATE, NOT A DIRECT COUNT: "
                    f"{_measure_of(cd['source_id'], cd['confidence'])}, from "
                    f"{_publisher_of(cd['source_id'])} {cd['as_of_year']} split by the city's "
                    f"share of national population (mixed reference years, so an approximation)"
                    if cd["confidence"] == "apportioned" else
                    f"City figure is a {CONF_LABEL[cd['confidence']]}: "
                    f"{_publisher_of(cd['source_id'])} {cd['as_of_year']}")
    else:
        # A MEASURED city figure needs its OWN citation. Without this branch the row carried
        # only the country line ("UN DESA resident stock"), so a reader naturally read that as
        # the source of the city number too, when London is UK ONS and Sydney is ABS. On a
        # sheet whose whole promise is that every value is traceable, mis-citing is worse than
        # leaving the cell blank. The country-of-birth caveat rides along because it is the
        # single most important thing about these particular counts.
        cd = picks["city_dia"]
        src = str(cd.get("source_id") or "").strip() or "national census"
        # The measure was HARDCODED as "census country of birth", which is wrong for Rome and
        # Milan (citizenship) and for Auckland (ethnicity, which INCLUDES locally-born children,
        # the exact opposite of the caveat that was printed).
        meas = _measure_of(cd["source_id"], cd["confidence"])
        bits.append(f"City figure: {_publisher_of(cd['source_id'])} {cd['as_of_year']} "
                    f"[{meas}]"
                    + (", excludes locally-born children so it understates the community"
                       if meas == "country of birth" else ""))
    if picks["city_pop"] is None:
        note = _text_of(cwrow.get("notes"))   # NaN would print literally as "(nan)"
        bits.append(f"no city population in UN WUP"
                    + (f" ({note})" if note and "METRO" not in note else ""))
    if str(cwrow.get("code_kind")) == "metro":
        bits.append(f"{rec['code']} is a metro code covering {cwrow.get('airport_codes')}")
    if e.get("serves"):
        bits.append(f"BS flies this: {e['tickets']:,} tickets YTD, {e['net_cr']:,.1f} cr")
        # DIASPORA IS NOT ALWAYS THE DEMAND DRIVER, and the ratio says which. Twelve routes sit
        # at 0.1-0.6 tickets per resident; Guangzhou is 1,037 and Chennai 85, because that
        # traffic is trade and medical travel by people who do not live there. Without this the
        # reader concludes the diaspora figure is broken, when it is simply the wrong lens.
        cd = picks["city_dia"]
        if cd is not None and float(cd.get("value") or 0) > 0:
            tpr = e["tickets"] / float(cd["value"])
            if tpr > 5:
                bits.append(f"NOTE {tpr:,.0f} tickets per resident Bangladeshi, versus 0.1-0.6 "
                            f"on our diaspora routes: demand here is NOT diaspora-driven "
                            f"(trade and medical travel), so do not read the city figure as the "
                            f"market size")
    else:
        bits.append("BS does not serve it")

    # WHO ARRIVES, not just who lives there. Without this a reader sees Chennai's 184 residents
    # and concludes there is no market, when 48,116 Bangladeshis entered India at Chennai in one
    # year and 69% of all Bangladeshi arrivals to India came for medical treatment. The resident
    # count is correct and is answering a different question from the one a network plan asks.
    ca, cm, cia = picks.get("ctry_arr"), picks.get("ctry_med"), picks.get("city_arr")
    if ca is not None and float(ca.get("value") or 0) > 0:
        part = " (PART YEAR)" if "PARTIAL YEAR" in str(ca.get("method_note") or "") else ""
        line = (f"ARRIVALS, a different measure from residence: "
                f"{float(ca['value']):,.0f} Bangladeshis arrived in this country in "
                f"{ca['as_of_year']}{part} per {_publisher_of(ca['source_id'])}")
        if cm is not None and float(cm.get("value") or 0) > 0:
            line += (f", of whom {float(cm['value']):,.0f} "
                     f"({float(cm['value']) / float(ca['value']):.0%}) for MEDICAL treatment")
        if cia is not None and float(cia.get("value") or 0) > 0:
            line += f"; {float(cia['value']):,.0f} of them entered at this city"
        bits.append(line)
    # say WHICH grain the visitors column used, so a national total standing in for a city is
    # never mistaken for a counted city figure
    basis = str(rec.get("city_visitors_basis") or "")
    if basis and rec.get("city_visitors"):
        bits.append(f"The VISITORS column on this row is measured at: {basis}")
    return ". ".join(bits) + "."


# ---------------------------------------------------------------------------------------
#: The submission sheet, as one list of (header, row-field, width, numeric?, added?).
#:
#: NOTHING IN THE WRITER ADDRESSES A COLUMN BY POSITION. Every earlier version carried the
#: number format as `j in (3, 4, 5, 6, 7)`, the highlight as `j == 7` and the widths as a dict
#: keyed on "A".."I". Inserting one column moved every one of those off its target silently:
#: the highlight landed on the wrong column and one money column lost its thousands separator,
#: neither of which raises anything. The same mistake has now cost this repo three separate
#: bugs, so the layout is declared once and the writer reads it.
#:
#: "(Approximate)" is the analyst's own wording, adopted here so a rebuild stops reverting it.
#: It is also the more honest label: only 11 of these 63 city figures are measured, the rest are
#: apportioned from the country total or taken from a mission statement.
#:
#: The two VISITORS columns are ADDED to the template, not merged into the residents ones. They
#: answer a different question: 184 Bangladeshis live in Chennai and 48,116 arrive there in a
#: year, and adding the two would produce a number describing nobody. They are also kept at
#: their own grain, country beside country and city beside city, because a national total is
#: never split across the cities we happen to list.
SUB_COLS: list[tuple[str, str, int, bool, bool]] = [
    # header,                                              field,          width, num,  added
    ("",                                                   "no",              5, False, False),
    ("Destinations",                                       "template_label", 26, False, False),
    ("Total Population in Country",                        "country_pop",    18, True,  False),
    ("Bangladeshi living in Country",                      "country_dia",    20, True,  False),
    ("Bangladeshi VISITORS to Country (arrivals per year)", "ctry_arr",      22, True,  True),
    ("Total population in City ",                          "city_pop",       18, True,  False),
    ("Bangladeshi living in City(Approximate)",            "city_dia",       20, True,  False),
    ("Bangladeshi VISITORS to City (arrivals per year)",   "city_visitors",  22, True,  True),
    ("Most connected City By Air ",                        "top_od",         20, False, False),
    ("Remarks ",                                           "remarks",        74, False, False),
]


def write_submission(df: pd.DataFrame, out: Path) -> Path:
    """The template's original shape plus the columns the analyst asked for, and nothing else."""
    wb = Workbook()
    ws = wb.active
    ws.title = "Sheet1"
    for j, (head, _f, _w, _n, _a) in enumerate(SUB_COLS, start=1):
        _c(ws, 1, j, head, bold=True, fill=BLUE, color=WHITE, wrap=True)
    ws.row_dimensions[1].height = 32
    last = len(SUB_COLS)
    for r, x in enumerate(df.to_dict("records"), start=2):
        for j, (_h, field, _w, is_num, is_added) in enumerate(SUB_COLS, start=1):
            v = x.get(field)
            if field == "top_od":
                v = v or "NOT AVAILABLE"
            # Amber marks a column that was not in the original template, so a reader who knows
            # the old sheet can see at a glance what is new.
            _c(ws, r, j, v, fmt=FI if is_num else None,
               fill=AMBER if (is_added and v) else None, wrap=(j == last))
    _widths(ws, {get_column_letter(j): w
                 for j, (_h, _f, w, _n, _a) in enumerate(SUB_COLS, start=1)})
    ws.freeze_panes = "C2"
    wb.save(out)
    return out


def write_evidence(df: pd.DataFrame, sources: pd.DataFrame, out: Path, stats: dict) -> Path:
    wb = Workbook()
    ws = wb.active
    ws.title = "City Wise Data"
    heads = [("#", 5), ("Destination", 24), ("City", 15), ("IATA", 7), ("Country", 15),
             ("ISO3", 7),
             ("Country population", 15), ("src", 12), ("yr", 6), ("basis", 20),
             ("BD in country", 15), ("src", 12), ("yr", 6), ("basis", 22),
             ("City population", 15), ("src", 12), ("yr", 6), ("basis", 20),
             ("geographic unit", 30),
             ("BD in city", 15), ("src", 12), ("yr", 6), ("basis", 22),
             ("geographic unit", 34), ("measure", 22),
             ("BS serves", 9), ("BS tickets YTD", 12), ("BS net cr", 10),
             # The two columns that answer "is a resident count even the right denominator here"
             ("City share of country", 11), ("Tickets per resident", 12), ("What drives it", 22),
             # And the external answer to the same question, where a country publishes it
             ("BD arrivals in city", 13), ("src", 12), ("yr", 6),
             ("BD arrivals in country", 14), ("of which medical", 13),
             ("Remarks", 70)]
    _c(ws, 1, 1, "CITY WISE DATA - EVIDENCE PACK  Â·  every figure with its source, year and "
                 "how far it can be trusted", bold=True, size=12, color=WHITE, fill=NAVY)
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=len(heads))
    _c(ws, 2, 1, "'basis' is the confidence attached to that value. APPORTIONED means WE split "
                 "a country figure across cities: it is a model, not a count, and it is only "
                 "here at all if an analyst signed it off. A blank cell means the source was "
                 "silent, and the Remarks column says which one.   "
                 "CITY SHARE OF COUNTRY is not meant to reach 100%: we list a handful of cities "
                 "per country, not all of them, so India's eight cities covering 10% of the "
                 "country total is expected rather than an error.   "
                 "TICKETS PER RESIDENT and WHAT DRIVES IT come from OUR OWN sales, not from an "
                 "external source. Above 10 tickets per resident the community living there "
                 "cannot be filling the aircraft, so the traffic is visitors, patients or "
                 "traders and the diaspora column is the wrong denominator for that route.   "
                 "BD ARRIVALS is the external check on the same question: how many Bangladeshis "
                 "ARRIVED, a flow, against how many LIVE there, a stock. Only India publishes "
                 "it at city grain, through its port-of-entry table. DO NOT DIVIDE our tickets "
                 "by it: our figure is this year to date and the arrivals figure is a different "
                 "and usually earlier full year, so a ratio of the two would compare unlike "
                 "periods. Read them side by side instead.",
       wrap=True)
    ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=len(heads))
    ws.row_dimensions[2].height = 74
    for j, (h, w) in enumerate(heads, start=1):
        _c(ws, 3, j, h, bold=True, fill=BLUE, color=WHITE, wrap=True)
        ws.column_dimensions[ws.cell(row=3, column=j).column_letter].width = w
    ws.row_dimensions[3].height = 30
    r = 4
    for x in df.to_dict("records"):
        vals = [x["no"], x["template_label"], x["city"], x["code"], x["country"], x["iso3"]]
        for k in ("country_pop", "country_dia", "city_pop", "city_dia"):
            vals += [x[k], x[f"{k}_src"], x[f"{k}_yr"],
                     CONF_LABEL.get(x[f"{k}_conf"], "")]
            if k == "city_pop":
                vals += [x.get("city_pop_unit", "")]
            if k == "city_dia":
                note = str(x.get("city_dia_note") or "")
                m = re.search(r"MEASURE: ([^.]+)\.", note)
                # the note's own MEASURE: prefix wins; otherwise derive it from the source, so
                # rows written before that convention existed are not left blank
                meas = m.group(1) if m else _measure_of(x.get("city_dia_src", ""),
                                                        x.get("city_dia_conf", ""))
                vals += [x.get("city_dia_unit", ""), meas]
        vals += [x["bs_serves"], x["bs_tickets"], x["bs_net_cr"],
                 x.get("city_share"), x.get("per_resident"), x.get("route_type"),
                 x.get("city_arr"), x.get("city_arr_src"), x.get("city_arr_yr"),
                 x.get("ctry_arr"), x.get("ctry_med"),
                 x["remarks"]]
        for j, v in enumerate(vals, start=1):
            head = heads[j - 1][0]
            # BY NAME, never by number. Adding three columns here shifted every index past
            # "BS net cr", and a hardcoded list had already put a percent format on the Y/N
            # serves column and a decimal on a ticket count.
            fmt = None
            if head in ("Country population", "BD in country", "City population", "BD in city",
                        "BS tickets YTD", "BD arrivals in city", "BD arrivals in country",
                        "of which medical"):
                fmt = FI
            elif head == "BS net cr":
                fmt = "#,##0.0"
            elif head == "City share of country":
                fmt = "0.0%"
            elif head == "Tickets per resident":
                fmt = "#,##0.0"
            fill = None
            if head == "basis" and isinstance(v, str) and "APPORTION" in v:
                fill = AMBER
            if head in ("Country population", "BD in country", "City population",
                        "BD in city") and v is None:
                fill = REDL
            # a route the residents cannot explain is the whole point of the column, so it is
            # coloured rather than left to be spotted
            if head == "What drives it" and isinstance(v, str) and v.startswith("VISITOR"):
                fill = AMBER
            _c(ws, r, j, v, fmt=fmt, fill=fill, wrap=(head == "Remarks"))
        r += 1
    ws.auto_filter.ref = f"A3:{ws.cell(row=3, column=len(heads)).column_letter}{r-1}"
    ws.freeze_panes = "G4"

    s = wb.create_sheet("Sources")
    _c(s, 1, 1, "SOURCES", bold=True, size=12, color=WHITE, fill=NAVY)
    s.merge_cells(start_row=1, start_column=1, end_row=1, end_column=7)
    if len(sources):
        cols = [c for c in sources.columns]
        for j, h in enumerate(cols, start=1):
            _c(s, 2, j, str(h), bold=True, fill=BLUE, color=WHITE, wrap=True)
        for i, rec in enumerate(sources.to_dict("records"), start=3):
            for j, cname in enumerate(cols, start=1):
                _c(s, i, j, rec.get(cname), wrap=True)
        _widths(s, {"A": 18, "B": 34, "C": 22, "D": 40, "E": 30, "F": 12, "G": 10, "H": 14,
                    "I": 60})

    n = wb.create_sheet("Coverage")
    _c(n, 1, 1, "WHAT IS FILLED, AND WHAT IS NOT", bold=True, size=12, color=WHITE, fill=NAVY)
    n.merge_cells(start_row=1, start_column=1, end_row=1, end_column=3)
    for j, h in enumerate(["Column", "Filled", "Gap and why"], start=1):
        _c(n, 2, j, h, bold=True, fill=BLUE, color=WHITE)
    for i, (a, b, c) in enumerate(stats["coverage"], start=3):
        _c(n, i, 1, a, bold=True)
        _c(n, i, 2, b)
        _c(n, i, 3, c, wrap=True)
        n.row_dimensions[i].height = 30
    _widths(n, {"A": 30, "B": 12, "C": 96})
    wb.save(out)
    return out


# ---------------------------------------------------------------------------------------
def generate(params: dict | None = None, cfg: Config | None = None) -> Path:
    params = params or {}
    cfg = cfg or load_config(validate=False)
    facts, cw, sources = load_store(cfg)
    df = assemble(facts, cw, cfg)

    filled = {k: int(df[k].notna().sum()) for k in
              ("country_pop", "country_dia", "city_pop", "city_dia", "top_od")}
    # The coverage denominator is the number of destinations ACTUALLY BUILT, not a literal 63.
    # It was 63, and the moment the commercial team added Penang every line read "64/63", which
    # is the kind of nonsense that makes a reader stop trusting the rest of the summary.
    n_dest = len(df)
    held = int((facts["use"] == 0).sum())
    cov = [
        ("Total Population in Country", f"{filled['country_pop']}/{n_dest}", "World Bank WDI."),
        ("Bangladeshi living in Country", f"{filled['country_dia']}/{n_dest}",
         "UN DESA publishes a Bangladesh-origin row only where the destination country's own "
         "statistics identify country of birth. Where it is silent, BMET is used if present "
         "and the Remarks column says so."),
        ("Total population in City", f"{filled['city_pop']}/{n_dest}",
         "UN WUP 2025 urban centre. Sharjah is absent because DEGURBA merges it into the Dubai "
         "urban centre, so it is left blank rather than given Dubai's figure."),
        ("Bangladeshi living in City", f"{filled['city_dia']}/{n_dest}",
         "Published for the UK, US, Canada, Australia and New Zealand only. Everywhere else it "
         "can only be apportioned from the country figure, which is a model, not a count, and "
         "is withheld until signed off."),
        ("Most connected City By Air", f"{filled['top_od']}/{n_dest}",
         "Means: where does this city's population travel to most, i.e. the busiest "
         "INTERNATIONAL origin-destination city pair from that city. Domestic pairs are "
         "excluded on purpose: Delhi-Mumbai or Sydney-Melbourne would top most of these lists "
         "and say nothing about the market. THIS COLUMN IS AN ESTIMATE, not a measurement. "
         "Each entry states its own basis: 'published' means a route statistic was found, "
         "'reported' means a reputable aviation source states it, 'inferred' means it is a "
         "judgement from network structure with no source found. Treat it as indicative only."),
        ("Values held pending sign-off", str(held),
         "apportioned or press values sitting at use=0. They are in the store but not on any "
         "sheet."),
    ]
    out_dir = Path(params.get("out_dir") or cfg.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    # House convention: a workbook left open in Excel must not kill the run. Without this the
    # whole rebuild is lost to a window somebody forgot to close, and worse, the caller can be
    # left reading the STALE file on screen and believing it is the new one.
    diverted: list[str] = []
    try:
        sub = write_submission(df, out_dir / "City_wise_data_SUBMISSION.xlsx")
    except PermissionError:
        sub = write_submission(df, out_dir / "City_wise_data_SUBMISSION__new.xlsx")
        diverted.append("SUBMISSION")
    try:
        ev = write_evidence(df, sources, out_dir / "City_wise_data_EVIDENCE.xlsx",
                            {"coverage": cov})
    except PermissionError:
        ev = write_evidence(df, sources, out_dir / "City_wise_data_EVIDENCE__new.xlsx",
                            {"coverage": cov})
        diverted.append("EVIDENCE")

    print(f"[city-market] {len(df)} destinations")
    for a, b, _ in cov:
        print(f"    {a:<32} {b}")
    # The ACTUAL paths, not the intended ones. This line used to be printed by the wrapper from
    # a hardcoded filename, so a run that had been diverted to a __new sibling still announced
    # the main path, and the file sitting at that path was the PREVIOUS build. The whole point
    # of the lock-tolerant save is that nobody reads a stale sheet believing it is fresh, and
    # announcing the wrong name defeated it precisely when it mattered.
    print(f"[OK] -> {sub}")
    print(f"     -> {ev}")
    for name in diverted:
        print(f"    [WARNING] {name} was OPEN IN EXCEL, so the new copy went to a __new "
              f"sibling. The file at the plain name is the PREVIOUS build and is now stale. "
              f"Close it and re-run to replace it.")
    return sub




