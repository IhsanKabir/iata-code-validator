"""
reporting.builders.visit_consolidate - merge a folder (or any set) of DAILY visit files into the ONE
monthly workbook the visit report already knows how to read.

WHY (Sep-2026)
    Until August the reps' visits arrived as ONE workbook: one tab per rep, each tab a stack of
    day-blocks. September arrived as 164 separate files, one per rep per day, 146 of them with a
    single tab called "Sheet1". parse_visits skips any tab named Sheet1 (in the monthly workbook
    that tab is the blank template), so a daily file parsed to ZERO visits and the report stopped
    with "parsed 0 visits". The admin console's picker could only hand over one .xlsx anyway.

    Rather than teach the parser, and the verifier (which deliberately recounts with its OWN code
    path), a second input format, this rebuilds the format they both already trust: one sheet per
    rep, that rep's daily tables stacked top to bottom, each still carrying its own banner and
    date. Parser, verifier and normaliser then run unchanged on the result.

RULES
    - A tab is taken only if it holds a visit table ("Name of Agent" / "Name of Corporate").
      Empty "Sheet2" tabs are ignored.
    - Byte-identical files are read ONCE (3 in the September folder). Rows repeated ACROSS
      different files, e.g. a rep re-sending a cumulative workbook each day, are left in: the
      report already drops (rep, date, agency) duplicates and lists them on its Data Quality sheet.
    - The rep is the tab's "Name:" value, else "Report By:", else "Station:", else the file name
      with its dates removed. A value that is itself a label is skipped: one template repeats the
      label ('Name: | Name: | MD.TAKBIR-AL-ZOHA'), and reading it literally filed that rep's day on
      a tab called "Name".
    - Spellings of one person land on ONE tab: punctuation and spacing are ignored, and a name
      wholly contained in a longer one ('Md. Barru Ibna Azam' in 'Md. Barru Ibna Azam Barno',
      'Rubayet Hossain Rupom' in 'Md. Rubayet Hossain Rupom') is folded into it. Only names of
      MIN_CONTAINED+ letters fold, so a short name cannot swallow an unrelated longer one.
    - Days are separated by GAP blank rows. _block_date looks at most 5 rows above a table's
      header for its date, so a narrower gap would let a table with no date of its own pick up the
      previous file's last cells as its date.
    - NOTHING IS INVENTED. No date is taken from a file name; a table with no date stays undated
      and is reported by the builder, exactly as it would be inside a monthly workbook.
    - Every non-empty source cell must reach the merged workbook. The count is checked, and a
      merge that lost a cell refuses to be used.
    - Stacking puts each later day's banner inside the previous day's row range. In the real
      templates the banner values sit outside the agency column (measured: 0 such rows in
      September and 0 in July's monthly book), but a template that put the rep's name or a typed
      date in that column would be counted as a visit, so every merge is re-parsed and says so.
    - Folders are read one level deep. A sub-folder is usually a copy, and reading it too would
      count its visits twice.

The merged workbook is written as "Agency Visit Report <Mon> <YYYY> (consolidated).xlsx" in
Downloads, where the report's own auto-pick (month in the file name) finds it next time, so the
plain "newest in Downloads", VERIFY and normalise actions all work on it with no extra step.
"""
from __future__ import annotations

import hashlib
import re
import warnings
from collections import Counter
from pathlib import Path
from typing import NamedTuple

import pandas as pd
from openpyxl import Workbook
from openpyxl.cell.cell import ILLEGAL_CHARACTERS_RE

from .visit_tracking import DOWNLOADS, _blocks, _rep_name

#: What the pinned stack can open. Old .xls needs xlrd, which is not installed.
READABLE = (".xlsx", ".xlsm")
#: Blank rows between one daily table and the next; must exceed _block_date's 5-row look-up.
GAP = 6
#: Tab names parse_visits treats as the monthly workbook's blank template, and so skips.
TEMPLATE_TABS = ("sheet1", "sheet", "template")
#: Shortest grouping key allowed to fold into a longer name that contains it.
MIN_CONTAINED = 12
#: Our own outputs, never re-read as input when they sit in the chosen folder.
_OURS = re.compile(r"\(consolidated|Agency_Visit_Tracking|Agency_Visit_NORMALISED", re.I)
#: A cell that is only a label: 'Name:', 'Date & Day:', 'Report By:'.
_LABEL_ONLY = re.compile(r"^\s*[A-Za-z][A-Za-z &./]{0,24}:\s*$")
_DATE_LIKE = re.compile(r"^\s*\d{1,2}\s*[/.\-]\s*\d{1,2}\s*[/.\-]\s*\d{2,4}")
_MON = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
_DATEISH = re.compile(
    r"\(\d+\)|\bcopy\b|\d+(st|nd|rd|th)?"
    r"|\b(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\b"
    r"|\b(mon|tue|wed|thu|fri|sat|sun)[a-z]*\b|['’]", re.I)


class Consolidation(NamedTuple):
    path: Path
    month: str               # 'YYYY-MM', the month the merged file is named for
    reps: dict               # sheet title -> number of daily tables stacked on it
    files_read: int
    duplicates: list         # "<file> (same as <file>)" for byte-identical copies
    skipped: list            # (file name, reason)
    subfolders: int          # sub-folders present but deliberately not read
    cells_in: int            # non-empty cells across every table taken
    cells_out: int           # non-empty cells written; must equal cells_in
    spellings: list          # (folded spelling, kept spelling)


# ------------------------------------------------------------------------------ identity
def _banner_value(raw: pd.DataFrame, label: str) -> str:
    """The value after a banner label such as 'Name:' in a tab's top rows.

    Text after the colon in the same cell, else the next text cell in the row that is not itself
    a label. 'Name of Agent' carries no colon, so a table header is never mistaken for the label.
    """
    pat = re.compile(r"^\s*(?:" + label + r")\s*:\s*(.*)$", re.I)
    for _, row in raw.head(6).iterrows():
        cells = row.tolist()
        for k, v in enumerate(cells):
            m = pat.match(v) if isinstance(v, str) else None
            if not m:
                continue
            same = m.group(1).strip(" -:–")
            if same and not _LABEL_ONLY.match(m.group(1)):
                return same
            for nx in cells[k + 1:]:
                if isinstance(nx, str) and nx.strip() and not _LABEL_ONLY.match(nx):
                    return nx.strip()
            return ""
    return ""


def _stem_without_dates(p: Path) -> str:
    """'CCU Sales Visit Report 01-9-2026 (1)' -> 'CCU Sales Visit Report'."""
    s = _DATEISH.sub(" ", p.stem)
    return re.sub(r"[\s_\-,.()]+", " ", s).strip() or p.stem


def rep_of(raw: pd.DataFrame, file: Path) -> str:
    """Who a daily table belongs to, from the most specific evidence available."""
    name = _banner_value(raw, "name") or _banner_value(raw, r"report\s*by")
    if not name:
        station = _banner_value(raw, "station")
        name = f"Station {station}" if station else ""
    return name or _stem_without_dates(file)


def _key(name: str) -> str:
    """Grouping key: letters and digits only, so punctuation and spacing variants group."""
    return re.sub(r"[^a-z0-9]", "", name.lower()) or name


def _fold_spellings(groups: dict) -> list:
    """Fold each group whose key sits wholly inside a longer key into that longer group."""
    folded = []
    for k in sorted(list(groups), key=len):
        if k not in groups or len(k) < MIN_CONTAINED:
            continue
        host = next((o for o in sorted(groups, key=len, reverse=True) if o != k and k in o), None)
        if host:
            # both spellings captured BEFORE the names are pooled, or the message can name the
            # same spelling twice once the pooled majority decides the tab's title
            folded.append((_display(groups[k]), _display(groups[host])))
            groups[host]["frames"] += groups[k]["frames"]
            groups[host]["names"] += groups[k]["names"]
            del groups[k]
    return folded


def _display(group: dict) -> str:
    """The spelling used most often; the longest on a tie, so a surname is not dropped."""
    counts = Counter(group["names"])
    return max(counts, key=lambda n: (counts[n], len(n)))


def _sheet_title(name: str, used: set) -> str:
    """A legal, unique Excel tab name that parse_visits will not mistake for the template."""
    t = re.sub(r"[\[\]:*?/\\]", " ", name).strip()[:31] or "Rep"
    if t.lower() in TEMPLATE_TABS:
        t = f"Rep {t}"[:31]
    base, n = t, 2
    while t.lower() in used:
        suffix = f" ({n})"
        t, n = base[:31 - len(suffix)] + suffix, n + 1
    used.add(t.lower())
    return t


# ---------------------------------------------------------------------------------- read
def _tabs(file: Path) -> list[tuple[str, pd.DataFrame]]:
    """(tab name, raw cells) for every tab of `file` that holds a visit table."""
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        sheets = pd.read_excel(file, sheet_name=None, header=None)
    return [(str(n), r) for n, r in sheets.items() if len(r) and _blocks(r)]


def needs_consolidation(path: Path) -> bool:
    """True when parse_visits would read NOTHING from this workbook, because every tab holding a
    table carries a template name. That is the shape of every single-tab daily file."""
    tabs = _tabs(path)
    return bool(tabs) and all(n.strip().lower() in TEMPLATE_TABS for n, _ in tabs)


def _month_of(frames: list[pd.DataFrame]) -> str:
    """The month most real date cells fall in, the same rule parse_visits uses."""
    stamps = [v for r in frames for c in r.columns for v in r[c]
              if isinstance(v, pd.Timestamp) or type(v).__name__ == "datetime"]
    if not stamps:
        return pd.Timestamp.today().strftime("%Y-%m")
    per = pd.Series([pd.Timestamp(t).to_period("M") for t in stamps]).mode().iloc[0]
    return f"{per.year:04d}-{per.month:02d}"


def _cell_value(v):
    """A source cell as openpyxl wants it; None for an empty cell."""
    if v is None:
        return None
    try:
        if pd.isna(v):
            return None
    except (TypeError, ValueError):
        pass
    if isinstance(v, pd.Timestamp):
        return v.to_pydatetime()
    if isinstance(v, str):
        return ILLEGAL_CHARACTERS_RE.sub("", v)
    return v.item() if hasattr(v, "item") else v


# ----------------------------------------------------------------------------- consolidate
def consolidate(files, out_dir: Path | None = None) -> Consolidation:
    """Stack every daily visit table in `files` onto one sheet per rep and save the workbook."""
    out_dir = Path(out_dir) if out_dir else DOWNLOADS
    seen: dict[str, str] = {}
    dups, skipped = [], []
    groups: dict[str, dict] = {}
    cells_in = 0
    for f in sorted({Path(x) for x in files}, key=lambda p: p.name.lower()):
        if f.name.startswith("~$") or _OURS.search(f.name):
            continue
        if f.suffix.lower() not in READABLE:
            skipped.append((f.name, f"not a readable workbook ({f.suffix or 'no extension'}); "
                                    f"save it as .xlsx"))
            continue
        digest = hashlib.md5(f.read_bytes()).hexdigest()
        if digest in seen:
            dups.append(f"{f.name} (same as {seen[digest]})")
            continue
        seen[digest] = f.name
        try:
            tabs = _tabs(f)
        except Exception as e:                                   # noqa: BLE001 - report, carry on
            skipped.append((f.name, f"could not be opened: {type(e).__name__}: {e}"))
            continue
        if not tabs:
            skipped.append((f.name, "no 'Name of Agent' or 'Name of Corporate' table on any tab"))
            continue
        for _tab, raw in tabs:
            rep = rep_of(raw, f)
            g = groups.setdefault(_key(rep), {"names": [], "frames": []})
            g["names"].append(rep)
            g["frames"].append(raw)
            cells_in += int(raw.notna().sum().sum())
    if not groups:
        why = "; ".join(f"{n}: {r}" for n, r in skipped[:5]) or "no readable files"
        raise ValueError(f"no visit tables found in the chosen files ({why})")
    folded = _fold_spellings(groups)

    month = _month_of([fr for g in groups.values() for fr in g["frames"]])
    wb = Workbook()
    wb.remove(wb.active)
    used: set = set()
    reps: dict = {}
    cells_out = 0
    for g in sorted(groups.values(), key=lambda x: _display(x).lower()):
        name = _display(g)
        # The parser names the rep from the TOP of the tab, i.e. the first table stacked here, so
        # put first a table whose own banner the parser reads as this rep's kept spelling.
        frames = sorted(g["frames"], key=lambda r: 0 if _rep_name(r, "") == name else 1)
        ws = wb.create_sheet(_sheet_title(name, used))
        top = 1
        for raw in frames:
            for i, row in enumerate(raw.itertuples(index=False), start=top):
                for j, v in enumerate(row, start=1):
                    v = _cell_value(v)
                    if v is not None:
                        ws.cell(i, j, v)
                        cells_out += 1
            top += len(raw) + GAP
        reps[ws.title] = len(frames)

    y, m = month.split("-")
    target = out_dir / f"Agency Visit Report {_MON[int(m) - 1]} {y} (consolidated).xlsx"
    out_dir.mkdir(parents=True, exist_ok=True)
    try:
        wb.save(target)
    except PermissionError:                                      # open in Excel
        target = target.with_name(target.stem[:-1] + " 2).xlsx")
        wb.save(target)
    return Consolidation(target, month, reps, len(seen), dups, skipped, 0, cells_in, cells_out,
                         folded)


def banner_rows_counted_as_visits(workbook: Path) -> pd.DataFrame:
    """Visits whose 'agency' is really a rep's name, a typed date or a label.

    Stacking puts each later day's banner inside the previous day's row range, so this is the one
    way a merge could inflate the count. Zero in September and July; checked on every merge."""
    from .visit_tracking import parse_visits
    v, _roster, _notes = parse_visits(workbook)
    if v.empty:
        return v
    reps = {_key(str(n)) for n in pd.concat([v["rep_name"], v["salesperson"]]).dropna().unique()}
    agent = v["agent"].astype(str)
    bad = agent.map(_key).isin(reps) | agent.str.match(_DATE_LIKE) | agent.str.match(_LABEL_ONLY)
    return v[bad]


def resolve_source(source, out_dir: Path | None = None) -> Path:
    """Turn whatever was chosen (a workbook, several files, or a folder) into one readable workbook.

    A normal monthly workbook is returned untouched. Anything else is consolidated first, and the
    path of the merged workbook is returned.
    """
    items = source if isinstance(source, (list, tuple)) else [source]
    paths = [Path(str(s).strip().strip('"')) for s in items if str(s).strip()]
    if not paths:
        raise FileNotFoundError("no visit source was given")
    for p in paths:
        if not p.exists():
            raise FileNotFoundError(f"visit source not found: {p}")
    one = paths[0]
    if (len(paths) == 1 and one.is_file() and one.suffix.lower() in READABLE
            and not needs_consolidation(one)):
        return one

    files, subfolders = [], 0
    for p in paths:
        if p.is_dir():
            kids = sorted(p.iterdir())
            files += [k for k in kids if k.is_file()]
            subfolders += sum(1 for k in kids if k.is_dir())
        else:
            files.append(p)
    res = consolidate(files, out_dir)._replace(subfolders=subfolders)
    print(f"[consolidate] {res.files_read} file(s) -> {len(res.reps)} rep sheet(s) for {res.month}")
    for title, n in res.reps.items():
        print(f"     {title:<32} {n:>3} daily table(s)")
    for short, longer in res.spellings:
        print(f"   same person, one tab: '{short}' and '{longer}'")
    for d in res.duplicates:
        print(f"   skipped, identical copy: {d}")
    for name, why in res.skipped:
        print(f"   skipped {name}: {why}")
    if res.subfolders:
        print(f"   {res.subfolders} sub-folder(s) NOT read (usually copies; choose one directly "
              f"to use it)")
    if res.cells_in != res.cells_out:
        raise ValueError(f"the merge lost data: {res.cells_in:,} source cells but "
                         f"{res.cells_out:,} written; not building from it")
    print(f"   all {res.cells_out:,} source cells carried -> {res.path}")
    bad = banner_rows_counted_as_visits(res.path)
    if len(bad):
        print(f"[consolidate] WARNING: {len(bad)} row(s) read as visits are really a rep name, a "
              f"date or a label, e.g. {list(bad['agent'].astype(str).head(3))}. A template puts "
              f"its banner in the agency column; check those tabs before trusting the count.")
    return res.path
