"""
reporting.common — shared SQL/data helpers used by more than one builder.

Currently: the time-versioned commission-rate CASE expression (ported verbatim
from scripts/target.py, but parameterised on Config so it has no hidden paths),
and the validation that keeps a half-finished rule out of that expression.
"""
from __future__ import annotations

import sys

from .config import Config

#: A rate rule is only usable if it can actually become SQL. `usable_rate_rules` drops the rest
#: and says why, because the alternative is what happened on 2026-09-02: someone added a row to
#: reference/commission_rates.xlsx with match_field "Counters", no match_values and no
#: effective_from. `str(NaN)` is the text "nan", so it compiled to
#:     WHEN CAST("Counters" AS VARCHAR) IN ('nan') AND ...
#: and every consumer died with `Binder Error: Referenced column "Counters" not found`. The DSR
#: could not be published at all, and the error named a column nobody had heard of rather than
#: the spreadsheet row that caused it.
#:
#: Six separate copies of this loop exist in the repo, so ONE bad row broke all of them at once.


#: How a rule compares its field. `in` is the default so every existing rule keeps working.
#: `regex` exists because the thing people actually want to express -- "issued at a counter" --
#: is a PATTERN, not a list: counters are `DAC-04 Motijheel`, `RJH-2 Rajshahi City`,
#: `INT Dubai City (Dubai)` and so on, the set grows, and enumerating it means a new counter
#: silently takes the wrong rate.
MATCH_OPS = ("in", "not in", "like", "not like", "regex")


def _lit(v: str) -> str:
    """A SQL string literal. Doubles any single quote, which is not theoretical: one of our own
    counters is `CXB 2  Airport (Cox's Bazar)`, so listing counters by name in a rule -- the
    obvious thing to do -- emitted `'Cox's Bazar'` and killed the build with a parser error."""
    return "'" + str(v).replace("'", "''") + "'"


def _ident(name: str) -> str:
    """A quoted SQL identifier, with any embedded double quote doubled so a stray character in
    a hand-typed match_field cannot terminate the quoting and change the statement."""
    return '"' + str(name).replace('"', '""') + '"'


def _match_clause(field: str, op: str, values: list[str]) -> str:
    """The comparison half of one rule's WHEN.

    The field is TRIMMED on both sides of every comparison. The source spells the same value
    more than one way -- 'BO-1 Central Reservation' and 'BO-1 Central Reservation ' are both in
    the data -- and an untrimmed comparison silently misses one of them.
    """
    f = f"trim(CAST({_ident(field)} AS VARCHAR))"
    if op == "regex":
        return " OR ".join(f"regexp_matches({f}, {_lit(v)})" for v in values)
    if op == "like":
        return " OR ".join(f"{f} LIKE {_lit(v)}" for v in values)
    if op == "not like":
        # Same NULL trap as `not in` below, and for the same reason: `NULL NOT LIKE 'x'` is
        # NULL, not TRUE, and CASE treats NULL as false. A rule meaning "everyone except the
        # OTAs" would therefore skip every agency whose Agent Type is blank -- and blank is a
        # real, common state here (the unzoned-agencies report exists because of it). Unlike a
        # dropped rule this failed in complete silence: no warning, just a smaller match set.
        clauses = " AND ".join(f"{f} NOT LIKE {_lit(v)}" for v in values)
        return f"({_ident(field)} IS NOT NULL AND {clauses})"
    lst = ", ".join(_lit(v) for v in values)
    if op == "not in":
        # A NULL field makes NOT IN evaluate to NULL, not TRUE, so the rule would silently skip
        # those rows. Say what should happen to them explicitly instead.
        return f"({_ident(field)} IS NOT NULL AND {f} NOT IN ({lst}))"
    return f"{f} IN ({lst})"


def _cell_op(row) -> str:
    """`match_op` off one spreadsheet row, defaulting to `in` when the cell is blank.

    NOT `str(row.get("match_op") or "in")`. A blank cell reads back as float NaN, and NaN is
    TRUTHY in Python -- `nan or "in"` is nan, never the default -- so `str()` then produced the
    text "nan", which is not a legal op, and the rule was dropped with a confusing warning.

    That is the SAME `str(NaN) == "nan"` trap that took the DSR down on 2026-09-02, reintroduced
    inside the fix for it. It is worse on a `*` row: dropping the catch-all default collapses
    the whole chain to its ELSE, silently repricing every row in the report. `in` is documented
    as the default precisely so an analyst can leave this column alone, so the default has to
    actually fire.
    """
    import pandas as pd   # lazy, per this module's contract

    raw = row.get("match_op")
    return ("in" if pd.isna(raw) else str(raw)).strip().lower() or "in"


def usable_rate_rules(rates, known_columns=None):
    """Yield only the rate rules that can be compiled, warning about each one dropped.

    `known_columns`, when given, is the set of column names the SQL will run against; a rule
    naming anything else is dropped rather than allowed to fail at query time. Matching is
    case-insensitive because the reference file is hand-typed.
    """
    import pandas as pd   # lazy, to honour the lazy-import contract of this module

    known = {str(c).strip().lower() for c in known_columns} if known_columns else None
    for _, row in rates.iterrows():
        order = row.get("rule_order", "?")
        field = str(row.get("match_field") or "").strip()
        why = None
        rate = row.get("commission_rate")
        if not field or field.lower() == "nan":
            why = "no match_field"
        elif pd.isna(rate):
            why = "no commission_rate"
        else:
            # float() is called for real here rather than left to the emitter, where a value
            # like "5%" raised ValueError and took the whole build down instead of skipping
            # one rule. The same check rejects a blank-looking cell that is really text.
            try:
                rate = float(rate)
            except (TypeError, ValueError):
                why = f"commission_rate {row.get('commission_rate')!r} is not a number"
            else:
                if not 0.0 <= rate <= 1.0:
                    why = (f"commission_rate {rate} is outside 0..1 - rates are decimals, "
                           f"so 5% is 0.05")
        if not why and field != "*":
            vals = row.get("match_values")
            # Split it the way the emitter will. ",,," is not blank but yields nothing, and an
            # empty list compiles to `IN ()`, which is a syntax error rather than a no-op.
            parts = ([] if pd.isna(vals)
                     else [v.strip() for v in str(vals).split(",") if v.strip()])
            if not parts or str(vals).strip().lower() == "nan":
                why = f"match_field {field!r} but no usable match_values"
            elif known is not None and field.lower() not in known:
                why = f"match_field {field!r} is not a column in the data"
        op = _cell_op(row)
        if not why and field != "*" and op not in MATCH_OPS:
            why = f"match_op {op!r} is not one of {', '.join(MATCH_OPS)}"
        if why:
            print(f"[WARN] commission_rates rule {order}: {why} - rule ignored",
                  file=sys.stderr)
            continue
        yield row


def rate_case_sql(rates, indent: str = "", known_columns=None) -> str:
    """The whole ``CASE WHEN ... END`` for the commission rate, built once for every caller.

    FOUR NEAR-IDENTICAL COPIES OF THIS LOOP USED TO EXIST (dsr, common, target,
    05_build_fact_customer_monthly). They drifted: only one trimmed the field, and a rule added
    to the spreadsheet could take effect in one report and not another while both looked right.
    They now all call this.

    ORDER IS EVERYTHING and it is where the 2026-09-02 rule actually failed, twice over. This is
    a first-match-wins chain, so a wildcard `*` rule with an open date window matches every row
    and NOTHING numbered after it can ever fire. A rule placed below the default is dead, and
    nothing said so; it is warned about here.
    """
    import pandas as pd   # lazy, per this module's contract

    lines = [f"{indent}CASE"]
    catch_all_at = None
    for row in usable_rate_rules(rates, known_columns):
        order = row.get("rule_order", "?")
        field = str(row["match_field"]).strip()
        rate = float(row["commission_rate"])
        eff_from = (pd.Timestamp(row.get("effective_from"))
                    if pd.notna(row.get("effective_from")) else pd.Timestamp("1900-01-01"))
        eff_to = (pd.Timestamp(row.get("effective_to"))
                  if pd.notna(row.get("effective_to")) else None)

        guards = [f"""{indent}"Date"::DATE >= DATE '{eff_from.strftime('%Y-%m-%d')}'"""]
        if eff_to is not None:
            guards.append(f""""Date"::DATE <= DATE '{eff_to.strftime('%Y-%m-%d')}'""")
        date_guard = " AND ".join(g.strip() for g in guards)

        if catch_all_at is not None:
            print(f"[WARN] commission_rates rule {order}: it sits BELOW the catch-all rule "
                  f"{catch_all_at}, which matches every row, so it can never fire - move it "
                  f"above that rule", file=sys.stderr)

        if field == "*":
            lines.append(f"{indent}    WHEN {date_guard} THEN {rate}")
            if eff_to is None:
                catch_all_at = order
        else:
            op = _cell_op(row)
            vals = [v.strip() for v in str(row["match_values"]).split(",") if v.strip()]
            # THE MATCH CLAUSE IS PARENTHESISED, ALWAYS. A multi-value `regex` or `like` rule
            # emits `a OR b`, and SQL binds AND tighter than OR, so `a OR b AND date_guard`
            # means `a OR (b AND date_guard)` -- the first alternative escapes the date window
            # completely and the rule silently applies outside its own effective dates.
            lines.append(f"{indent}    WHEN ({_match_clause(field, op, vals)}) "
                         f"AND {date_guard} THEN {rate}")

    if len(lines) == 1:
        # `CASE ELSE x END` with no WHEN is a syntax error, so an empty or fully-rejected rules
        # table produced SQL that would not parse. Fall back to the flat default instead, which
        # is what the missing-file path already returns.
        print("[WARN] commission_rates: no usable rule at all - falling back to a flat 0.07",
              file=sys.stderr)
        return "0.07"
    lines.append(f"{indent}    ELSE 0.07")
    lines.append(f"{indent}END")
    return "\n".join(lines)


def build_rate_sql(cfg: Config) -> str:
    """Return a ``CASE WHEN ... END`` snippet yielding the per-row commission_rate,
    honoring the time-versioned schema in ``reference/commission_rates.xlsx``.

    First matching rule (by ascending ``rule_order``) wins; each rule is gated by
    both its (field, values) match AND the transaction Date falling inside
    (effective_from, effective_to]. Missing file -> flat 0.07 fallback.
    """
    import pandas as pd   # lazy: keeps `import reporting` free of the heavy stack (lazy-import contract)

    rates_file = cfg.reference / "commission_rates.xlsx"
    if not rates_file.exists():
        return "0.07"
    rates = pd.read_excel(rates_file, sheet_name="rates").sort_values("rule_order")
    return rate_case_sql(rates)
