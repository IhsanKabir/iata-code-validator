"""
reporting.itinerary - segments and route legs from a sales row's "Routing information".

TWO FINDINGS OF 2026-09-15 THAT THIS MODULE EXISTS TO FIX

1. SEGMENTS WERE UNDERCOUNTED. The Zenith export fills the per-row segment count ("seg") only in
   some exports: 61 of 500 curated files carry the column at all (March and part of April 2026).
   Everywhere else every consumer's COALESCE(seg, 1) counted a round trip as ONE segment.
   Where the export DID fill seg, it equals the number of legs in "Routing information" on all
   333,277 rows (DAC-CXB -> 1, DAC-CXB-DAC -> 2, DAC-DXB-KUL-DXB-DAC -> 4), so the legs are a
   verified stand-in. August 2026 domestic segments were 16% low and international 42% low, and
   the March/April months that did carry seg looked like a jump that was only the export changing.
   `segments_from_routing` (pandas, for ingest and Instant Reports) and `fill_seg_arrow` (pyarrow,
   for rewriting existing parquet files) apply the same rule: keep a stamped seg, otherwise use
   the legs, otherwise leave it empty so COALESCE(seg, 1) still supplies 1.
   seg IS A SEGMENT COUNT ONLY ON 'Ticket payment' ROWS. On every other transaction the March/April
   exports stamp a signed bookkeeping value instead: 0 on Commission, Penalty, Reissuance and
   discount rows, and MINUS the legs on Refund and Ticket void (428,158 such rows). The fill does
   not copy that sign, so a non-ticket row may read +legs in one month and 0 or -legs in another.
   Nothing reads it there: gold blanks seg off Ticket payment rows and every consumer (DSR, target,
   fact_customer_monthly, Power BI) filters to Ticket payment before summing. Always do the same.

2. ROUTE MONEY SAT ON THE OUTBOUND LEG. A return ticket is ONE sales row: the whole fare, with the
   Departure/Arrival airports of the OUTBOUND leg. Grouping money by Departure-Arrival therefore
   booked the return leg's money on the outbound route. August 2026, gross BDT per booked seat:
   DAC-JED 63,191 and JED-DAC 23,239; shared evenly across the itinerary's legs they are 42,618 and
   44,575. `route_legs_sql` returns every row once per leg with `leg_share` = 1 / legs, so
   SUM(amount * leg_share) by route puts half of a return fare on each direction. The network total
   is unchanged. A row whose itinerary does not START with its own Departure-Arrival (0.75% of
   ticket rows: reissues of a later leg, open jaws) keeps its whole amount on its own route, because
   there is no safe way to tell which legs that money covers.

Imports stay inside the functions: `reporting` core must not pull pandas/pyarrow in at import time
(the download-only desktop app imports this package without them).
"""
from __future__ import annotations

#: The sales column that carries the itinerary.
ROUTING_COL = "Routing information"

#: A usable routing is 3-letter airport codes joined by '-'. Every curated row matched this or was
#: empty when checked on 2026-09-15; anything else is treated as empty rather than guessed at.
ROUTING_REGEX = r"^[A-Z]{3}(-[A-Z]{3})+$"

#: The longest itinerary seen is 5 airports (4 legs). route_legs_sql allows more so a longer one
#: is never silently cut short.
MAX_LEGS = 8


def legs_in_routing(routing: object) -> int | None:
    """Legs in one routing string (DAC-CXB-DAC -> 2), or None when empty or malformed."""
    import re

    if routing is None:
        return None
    text = str(routing).strip()
    if not re.fullmatch(ROUTING_REGEX, text):
        return None
    return text.count("-")


def segments_from_routing(df):
    """A copy of `df` whose `seg` is filled from the routing legs where the export left it empty.

    A seg the export stamped is never changed. A row with no usable routing keeps an empty seg.
    If `seg` is missing entirely the column is added, because the DSR SQL needs it to bind.
    """
    import pandas as pd

    out = df.copy()
    if ROUTING_COL in out.columns:
        routing = out[ROUTING_COL].astype("string").str.strip()
        valid = routing.str.fullmatch(ROUTING_REGEX).fillna(False).astype(bool)
        legs = routing.str.count("-").astype("Float64").where(valid).astype("float64")
    else:
        legs = pd.Series(float("nan"), index=out.index, dtype="float64")
    if "seg" in out.columns:
        seg = pd.to_numeric(out["seg"], errors="coerce").astype("float64")
        out["seg"] = seg.where(seg.notna(), legs)
    else:
        out["seg"] = legs
    return out


def fill_seg_arrow(table):
    """pyarrow Table -> (Table with `seg` filled from the routing legs, rows newly filled).

    The same rule as `segments_from_routing`, in pyarrow so existing parquet files can be
    rewritten without a pandas round trip changing any other column's type.
    """
    import pyarrow as pa
    import pyarrow.compute as pc

    n = table.num_rows
    if ROUTING_COL in table.column_names:
        routing = pc.utf8_trim_whitespace(pc.cast(table[ROUTING_COL], pa.string()))
        valid = pc.fill_null(pc.match_substring_regex(routing, ROUTING_REGEX), False)
        legs = pc.if_else(valid, pc.cast(pc.count_substring(routing, "-"), pa.float64()),
                          pa.scalar(None, pa.float64()))
    else:
        legs = pa.nulls(n, pa.float64())

    def _count(mask) -> int:
        return int(pc.sum(pc.cast(mask, pa.int64())).as_py() or 0)

    if "seg" in table.column_names:
        seg = pc.cast(table["seg"], pa.float64())
        filled = _count(pc.and_(pc.is_null(seg), pc.is_valid(legs)))
        table = table.set_column(table.column_names.index("seg"), "seg", pc.coalesce(seg, legs))
    else:
        filled = _count(pc.is_valid(legs))
        table = table.append_column("seg", legs)
    return table, filled


def route_legs_sql(src: str, dep: str = "dep", arr: str = "arr", rtg: str = "rtg") -> str:
    """DuckDB SQL: every row of `src` once per itinerary leg, with `route` and `leg_share` added.

    `src` is a table, CTE name or parenthesised subquery with the columns named by `dep`, `arr`
    and `rtg`. Aggregate money as SUM(amount * leg_share) grouped by `route`. The result is
    parenthesised so it can be used directly after FROM.
    """
    return f"""(
        SELECT * EXCLUDE (_legs, _split, k),
               CASE WHEN _split THEN split_part({rtg}, '-', k) || '-' || split_part({rtg}, '-', k + 1)
                    ELSE {dep} || '-' || {arr} END                         AS route,
               CASE WHEN _split THEN 1.0 / _legs ELSE 1.0 END                 AS leg_share
        FROM (
            SELECT *,
                   len(string_split({rtg}, '-')) - 1                          AS _legs,
                   COALESCE(regexp_full_match({rtg}, '[A-Z]{{3}}(-[A-Z]{{3}})+')
                            AND len(string_split({rtg}, '-')) >= 3
                            AND split_part({rtg}, '-', 1) || '-' || split_part({rtg}, '-', 2)
                                = {dep} || '-' || {arr},
                            FALSE)                                             AS _split
            FROM {src}
        ) _x
        JOIN range(1, {MAX_LEGS + 1}) AS _k(k)
          ON (_split AND k <= _legs) OR (NOT _split AND k = 1)
    )"""
