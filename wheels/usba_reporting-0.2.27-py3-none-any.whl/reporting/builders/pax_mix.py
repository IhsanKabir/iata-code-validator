"""
reporting.builders.pax_mix: who actually travels, adult / child / infant, month by month,
plus gender, age and nationality where we genuinely hold them.

THE REPORT IS IN TWO HALVES AND THEY ARE NOT THE SAME KIND OF NUMBER
--------------------------------------------------------------------
1. ADULT / CHILD / INFANT: WHOLE DATABASE, INFERRED FROM THE FARE
   The sales data carries no passenger type. But a child and an infant are sold at fixed
   fractions of the adult fare, so comparing a ticket to the HIGHEST fare on its own PNR
   recovers the type. Measured against 26,913 passengers whose real date of birth we hold:

       true adult   ratio 1.00   (5th-95th percentile 1.00 - 1.00)
       true child   ratio 0.750  (5th-95th percentile 0.749 - 0.758)
       true infant  ratio 0.100  or 0.250   (two fare rules)

   With the bands below: 99.54% accurate overall; child precision 97.6% / recall 92.1%;
   infant precision 89.8% / recall 96.5%.

   WIDER BANDS LOOK FINE AND ARE NOT. A 0.60-0.85 child band scores 97.19% overall yet only
   59.6% precision: four in ten "children" are adults on a discounted fare, median age 28.
   Adults dominate the mix, so overall accuracy hides it. The bands are tight on purpose.

2. GENDER / AGE / NATIONALITY: A SAMPLE, MEASURED, NOT INFERRED
   These exist only in the Zenith Dossier passenger export, which covers the PNRs somebody
   looked up: about 2% of the book, and NOT a random 2%. Every sheet states its coverage,
   because a gender split quoted without it becomes "the airline's passenger profile".

WHAT THE FARE METHOD CANNOT DO
   * a PNR with ONE ticket has no second fare to compare against, so its passenger is taken
     to be an adult. That default was CHECKED, not assumed: on 18,871 solo tickets carrying a
     real date of birth, 99.90% were adults and 0.10% children. So the population rate (out of
     every ticket) is the true mix. An unaccompanied child is missed, but there are very few.
   * it infers. About 2.4% of predicted children are adults on a cheap fare. That is fine for
     a distribution and wrong for anything per-passenger.
   * it says nothing about gender, age or nationality. Fares carry no such signal.
"""
from __future__ import annotations

import calendar
import re
from datetime import datetime
from pathlib import Path

import duckdb
import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side

from ..config import Config, load_config

NAVY, BLUE, WHITE, GREY = "1F3864", "2E5395", "FFFFFF", "F2F2F2"
AMBER, GREENL, REDL = "FFF2CC", "E2EFDA", "FCE4E4"
BORDER = Border(*([Side(style="thin", color="BFBFBF")] * 4))
FI, FP = "#,##0", "0.0%"

# Bands fitted to the observed distribution, NOT to round numbers. See the module docstring
# for what widening them costs.
CHILD_LO, CHILD_HI = 0.745, 0.765
INF_BANDS = ((0.08, 0.12), (0.23, 0.27))

# Measured on 26,913 passengers with a real DOB. Printed on the Method sheet so the reader can
# weigh the numbers rather than take them on trust.
ACCURACY = [
    ("Overall", "99.54%", "", ""),
    ("Adult", "", "99.7%", "99.8%"),
    ("Child", "", "97.6%", "92.1%"),
    ("Infant", "", "89.8%", "96.5%"),
]

BD = ("DAC", "CGP", "CXB", "ZYL", "JSR", "RJH", "BZL", "SPD")


def _c(ws, r, col, v, *, bold=False, fill=None, fmt=None, color="000000", size=9, wrap=False,
       align=None):
    cell = ws.cell(row=r, column=col, value=v)
    cell.font = Font(bold=bold, color=color, size=size)
    cell.border = BORDER
    if fill:
        cell.fill = PatternFill("solid", fgColor=fill)
    if fmt:
        cell.number_format = fmt
    if wrap or align:
        cell.alignment = Alignment(wrap_text=wrap, vertical="top",
                                   horizontal=align or "general")
    return cell


def _head(ws, r, heads, widths):
    for j, (h, w) in enumerate(zip(heads, widths), start=1):
        _c(ws, r, j, h, bold=True, fill=BLUE, color=WHITE, wrap=True)
        ws.column_dimensions[ws.cell(row=r, column=j).column_letter].width = w
    ws.row_dimensions[r].height = 30


def _type_sql() -> str:
    """The CASE that turns a fare ratio into a passenger type."""
    inf = " OR ".join(f"(ratio BETWEEN {lo} AND {hi})" for lo, hi in INF_BANDS)
    return (f"CASE WHEN n_tkt < 2 THEN 'adult (no benchmark)' "
            f"WHEN {inf} THEN 'infant' "
            f"WHEN ratio BETWEEN {CHILD_LO} AND {CHILD_HI} THEN 'child' "
            f"ELSE 'adult' END")


def fetch_mix(cfg: Config, legs: bool = False) -> pd.DataFrame:
    """One row per TICKET across the whole book, with its inferred passenger type.

    Ticket payments carry exactly one row per ticket (verified), so no coupon de-duplication
    is needed; if that ever changes this must aggregate to ticket grain first or the benchmark
    silently shifts.

    legs=True returns one row per itinerary LEG instead (reporting.itinerary.route_legs_sql):
    a DAC-DXB-DAC ticket becomes a DAC-DXB row and a DXB-DAC row, EACH A WHOLE PASSENGER (a
    passenger is not shared across legs the way money is), with the sector judged per leg. The
    passenger type is still decided per TICKET, because the benchmark CTEs below run before the
    split, so splitting can never change who a passenger is. The route grid uses legs=True; this
    report's own sheets stay per ticket.
    """
    glob = (cfg.data_root / "curated" / "sales" / "**" / "*.parquet").as_posix()
    dom = ", ".join(f"'{a}'" for a in BD)
    con = duckdb.connect()
    if legs:
        from ..itinerary import route_legs_sql
        final = (f"SELECT ym, CASE WHEN split_part(route, '-', 1) IN ({dom}) "
                 f"AND split_part(route, '-', 2) IN ({dom}) THEN 'Domestic' ELSE 'International' END "
                 f"AS sector, route, n_tkt, ratio, fare, {_type_sql()} AS pax_type "
                 f"FROM {route_legs_sql('r')}")
    else:
        final = (f"SELECT ym, sector, dep || '-' || arr AS route, n_tkt, ratio, fare, "
                 f"{_type_sql()} AS pax_type FROM r")
    return con.execute(f"""
        WITH t AS (
            SELECT CAST("Record Locator" AS VARCHAR)                AS pnr,
                   CAST("Ticket number" AS VARCHAR)                 AS tkt,
                   CAST("Total without taxe (base currency)" AS DOUBLE) AS fare,
                   strftime("Date"::DATE, '%Y-%m')                  AS ym,
                   CASE WHEN "Departure airport" IN ({dom})
                         AND "Arrival airport"   IN ({dom})
                        THEN 'Domestic' ELSE 'International' END    AS sector,
                   CAST("Departure airport" AS VARCHAR)             AS dep,
                   CAST("Arrival airport" AS VARCHAR)               AS arr,
                   CAST("Routing information" AS VARCHAR)           AS rtg
            FROM read_parquet('{glob}', hive_partitioning=1, union_by_name=1)
            WHERE "Transaction" = 'Ticket payment'
              AND "Record Locator" IS NOT NULL
              AND "Total without taxe (base currency)" > 0
              AND "Date" IS NOT NULL
        ), b AS (
            -- the benchmark is the DEAREST ticket on the same booking: the adult fare
            SELECT pnr, MAX(fare) AS pnr_max, COUNT(DISTINCT tkt) AS n_tkt
            FROM t GROUP BY 1
        ), r AS (
            SELECT t.*, b.pnr_max, b.n_tkt, t.fare / b.pnr_max AS ratio
            FROM t JOIN b USING (pnr)
        )
        -- per ticket or per leg, chosen above; the passenger type is already fixed per ticket
        {final}
    """).df()


def partial_months(cfg: Config) -> set[str]:
    """Months the data only covers PART of, so their ticket counts are not comparable.

    The newest month is always short: the export is taken mid-month, so August reads 65k
    against a 230k norm and looks like travel collapsed rather than like eight days of it.
    Rates per month are unaffected (a ratio does not care how many days), but the raw
    counts beside them are, so the month is labelled instead of dropped: throwing away the
    newest month hides the most recent signal, which is usually the one being asked about.
    Checks BOTH ends because the first month of coverage could equally start mid-month.
    """
    glob = (cfg.data_root / "curated" / "sales" / "**" / "*.parquet").as_posix()
    con = duckdb.connect()
    d = con.execute(f"""
        SELECT strftime("Date"::DATE, '%Y-%m') AS ym,
               MIN("Date"::DATE) AS lo, MAX("Date"::DATE) AS hi
        FROM read_parquet('{glob}', hive_partitioning=1, union_by_name=1)
        WHERE "Transaction" = 'Ticket payment' AND "Date" IS NOT NULL
        GROUP BY 1""").df()
    out = set()
    for row in d.itertuples():
        lo, hi = pd.Timestamp(row.lo), pd.Timestamp(row.hi)
        if lo.day > 1 or hi.day < calendar.monthrange(hi.year, hi.month)[1]:
            out.add(row.ym)
    return out


def load_dossier(cfg: Config) -> pd.DataFrame:
    """Every Zenith passenger export we can find, unioned and de-duplicated.

    Reads a folder so coverage GROWS as more bulk lookups are run: drop another
    passenger_details_*.xlsx in and re-run. De-duplicated on (PNR, passenger) because the same
    booking gets looked up more than once.
    """
    seen, frames = set(), []
    for folder in (cfg.reference / "passenger_details", Path.home() / "Downloads",
                   Path.home() / "Documents"):
        if not folder.is_dir():
            continue
        for p in sorted(folder.glob("passenger_details*.xlsx")):
            try:
                xl = pd.ExcelFile(p)
                sh = next((s for s in xl.sheet_names if "passenger" in s.lower()),
                          xl.sheet_names[0])
                d = pd.read_excel(p, sheet_name=sh)
            except Exception:
                continue
            if "Passenger" not in d.columns or "PNR" not in d.columns:
                continue
            d["source_file"] = p.name
            frames.append(d)
            seen.add(p.name)
    if not frames:
        return pd.DataFrame()
    d = pd.concat(frames, ignore_index=True)
    d["PNR"] = d.PNR.astype(str).str.strip()
    d = d.drop_duplicates(["PNR", "Passenger"])
    d["dob"] = pd.to_datetime(d.get("Date of Birth"), errors="coerce")
    return d


# ---------------------------------------------------------------------------------------
def _sheet_monthly(wb, mix: pd.DataFrame, partial: set[str] | None = None) -> None:
    ws = wb.create_sheet("Monthly Mix")
    _c(ws, 1, 1, "PASSENGER MIX BY MONTH: adult / child / infant, whole database",
       bold=True, size=13, color=WHITE, fill=NAVY)
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=10)
    _c(ws, 2, 1, "Inferred from the fare: a child is sold at 75% of the adult fare and an "
                 "infant at 10% or 25%, so each ticket is compared with the dearest ticket on "
                 "its own booking. Measured 99.5% accurate against 26,913 passengers whose "
                 "date of birth we hold (see Method). A booking holding a SINGLE ticket has no "
                 "second fare to compare against, so its passenger is taken to be an adult. "
                 "That default is not a guess: on 18,871 solo tickets whose real date of birth "
                 "we hold, 99.90% were adults and 0.10% children, so almost nobody flies alone "
                 "as a child. The POPULATION rate (out of every ticket sold) is therefore the "
                 "true passenger mix and is the figure to quote. The GROUP-BOOKING rate beside "
                 "it is the same children measured only across bookings of 2+ tickets, which "
                 "is about double, because that is where families are. Both are real; they "
                 "answer 'who flies' and 'who flies together'.",
       wrap=True)
    ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=10)
    ws.row_dimensions[2].height = 92
    # WHICH DENOMINATOR IS THE TRUE RATE, SETTLED BY MEASUREMENT, NOT BY ARGUMENT.
    # 53% of tickets sit alone on their booking and have no fare to compare against. It was
    # tempting to treat those as unassessable and quote the child rate only across the other
    # 47%. Joining real dates of birth to those solo tickets killed that idea: 99.90% of them
    # are adults. So folding them into adult is correct, and the population rate leads here.
    # The group-booking rate is kept beside it because it is the right denominator for a
    # family-travel question, and it is roughly double, so the two must never be swapped.
    _head(ws, 3, ["Month", "Tickets", "Child", "Infant",
                  "Child % (population)", "Infant % (population)",
                  "Child+Inf % (population)", "Group bookings (2+ tkt)",
                  "Child % (group bookings)", "Solo-ticket %"],
          [10, 11, 10, 10, 12, 12, 13, 13, 13, 11])
    r = 4

    def _row(label, blk, bold=False):
        nonlocal r
        n = len(blk)
        ch = int((blk.pax_type == "child").sum())
        inf = int((blk.pax_type == "infant").sum())
        nb = int((blk.pax_type == "adult (no benchmark)").sum())
        meas = n - nb
        fill = NAVY if bold else None
        col = WHITE if bold else "000000"
        vals = [(label, None), (n, FI), (ch, FI), (inf, FI),
                (ch / n if n else None, FP), (inf / n if n else None, FP),
                ((ch + inf) / n if n else None, FP),
                (meas, FI), (ch / meas if meas else None, FP),
                (nb / n if n else None, FP)]
        for j, (v, fmt) in enumerate(vals, start=1):
            _c(ws, r, j, v, bold=bold, fmt=fmt, fill=fill, color=col)
        r += 1

    partial = partial or set()
    g = mix.groupby("ym")
    for ym in sorted(mix.ym.unique()):
        # label, never drop: the rates hold, only the raw counts are short
        _row(f"{ym} (partial)" if ym in partial else ym, g.get_group(ym))
    _row("TOTAL", mix, bold=True)
    ws.freeze_panes = "B4"


def _sheet_sector(wb, mix: pd.DataFrame) -> None:
    ws = wb.create_sheet("By Sector")
    _c(ws, 1, 1, "MONTH x SECTOR: where the families travel", bold=True, size=13,
       color=WHITE, fill=NAVY)
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=7)
    # Same denominator rule as Monthly Mix: the percentage is out of MEASURABLE tickets
    # (bookings holding 2+ tickets), never out of every ticket. See the note there.
    _head(ws, 2, ["Month", "Sector", "Tickets", "Measurable (2+ tkt)", "Child", "Infant",
                  "Child+Inf % of measurable"], [10, 15, 11, 13, 10, 10, 15])
    r = 3
    for (ym, sec), blk in mix.groupby(["ym", "sector"]):
        n = len(blk)
        ch = int((blk.pax_type == "child").sum())
        inf = int((blk.pax_type == "infant").sum())
        meas = n - int((blk.pax_type == "adult (no benchmark)").sum())
        for j, (v, fmt) in enumerate([(ym, None), (sec, None), (n, FI), (meas, FI),
                                      (ch, FI), (inf, FI),
                                      ((ch + inf) / meas if meas else None, FP)], start=1):
            _c(ws, r, j, v, fmt=fmt)
        r += 1
    ws.freeze_panes = "C3"


def _sheet_routes(wb, mix: pd.DataFrame) -> None:
    ws = wb.create_sheet("Top Routes")
    _c(ws, 1, 1, "ROUTES BY FAMILY TRAFFIC: highest child+infant share of the tickets we can assess",
       bold=True, size=13, color=WHITE, fill=NAVY)
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=6)
    _head(ws, 2, ["Route", "Sector", "Tickets", "Measurable (2+ tkt)", "Child", "Infant",
                  "Child+Inf % of measurable"], [12, 15, 11, 13, 10, 10, 15])
    # RANK ON THE MEASURABLE SHARE, not on the share of all tickets. Dividing by every
    # ticket would rank a route partly by how FEW solo travellers it carries: a route with
    # many single-ticket bookings is pushed down the list even when its family traffic is
    # heavy. The floor is on measurable tickets too, so a route only qualifies once enough
    # of it can actually be assessed.
    agg = (mix.assign(ch=(mix.pax_type == "child").astype(int),
                      inf=(mix.pax_type == "infant").astype(int),
                      meas=(mix.pax_type != "adult (no benchmark)").astype(int))
              .groupby(["route", "sector"])
              .agg(n=("ratio", "size"), ch=("ch", "sum"), inf=("inf", "sum"),
                   meas=("meas", "sum"))
              .reset_index())
    agg = agg[agg.meas >= 500].copy()
    agg["share"] = (agg.ch + agg.inf) / agg.meas
    r = 3
    for x in agg.nlargest(40, "share").to_dict("records"):
        for j, (v, fmt) in enumerate([(x["route"], None), (x["sector"], None), (x["n"], FI),
                                      (x["meas"], FI), (x["ch"], FI), (x["inf"], FI),
                                      (x["share"], FP)], start=1):
            _c(ws, r, j, v, fmt=fmt)
        r += 1


def _sheet_demographics(wb, dos: pd.DataFrame, mix_pnrs: int) -> None:
    ws = wb.create_sheet("Demographics (sample)")
    _c(ws, 1, 1, "GENDER · AGE · NATIONALITY: MEASURED, but on a SAMPLE",
       bold=True, size=13, color=WHITE, fill=NAVY)
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=6)
    if dos.empty:
        _c(ws, 3, 1, "No Zenith passenger export found. Run the PNR Bulk Lookup's "
                     "'Passenger details -> Excel' and drop the file in "
                     "reference/passenger_details/.", wrap=True)
        return
    cov = dos.PNR.nunique() / mix_pnrs if mix_pnrs else 0
    _c(ws, 2, 1, f"Source: the Zenith Dossier passenger export, {len(dos):,} passengers across "
                 f"{dos.PNR.nunique():,} bookings. That is {cov*100:.2f}% of the "
                 f"{mix_pnrs:,} bookings in the database, and it is NOT a random sample: it is "
                 f"whichever PNRs were looked up. Read these as indicative of that sample, not "
                 f"as the airline's passenger profile. Coverage grows as more bulk lookups are "
                 f"run.", wrap=True)
    ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=6)
    ws.row_dimensions[2].height = 56

    r = 4
    _c(ws, r, 1, "GENDER", bold=True, size=11, color=WHITE, fill=NAVY)
    ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=6)
    r += 1
    _head(ws, r, ["Gender", "Passengers", "Share of known", "", "", ""], [16, 12, 14, 2, 2, 2])
    r += 1
    gk = dos["Gender"].dropna() if "Gender" in dos else pd.Series(dtype=str)
    for val, n in gk.value_counts().items():
        _c(ws, r, 1, str(val), align="left")
        _c(ws, r, 2, int(n), fmt=FI)
        _c(ws, r, 3, n / len(gk), fmt=FP)
        r += 1
    _c(ws, r, 1, f"not recorded: {len(dos) - len(gk):,} of {len(dos):,}", align="left")
    r += 2

    _c(ws, r, 1, "AGE BANDS (age at the date of the export)", bold=True, size=11,
       color=WHITE, fill=NAVY)
    ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=6)
    r += 1
    _head(ws, r, ["Band", "Passengers", "Share of known", "", "", ""], [16, 12, 14, 2, 2, 2])
    r += 1
    dob = dos.dob.dropna()
    if len(dob):
        age = (pd.Timestamp.today() - dob).dt.days / 365.25
        bands = pd.cut(age, [0, 2, 12, 18, 25, 35, 50, 65, 200],
                       labels=["infant <2", "child 2-12", "12-18", "18-25", "25-35",
                               "35-50", "50-65", "65+"])
        for val, n in bands.value_counts().sort_index().items():
            _c(ws, r, 1, str(val), align="left")
            _c(ws, r, 2, int(n), fmt=FI)
            _c(ws, r, 3, n / len(dob), fmt=FP)
            r += 1
    _c(ws, r, 1, f"no date of birth: {len(dos) - len(dob):,} of {len(dos):,}", align="left")
    r += 2

    _c(ws, r, 1, "NATIONALITY", bold=True, size=11, color=WHITE, fill=NAVY)
    ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=6)
    r += 1
    _head(ws, r, ["Nationality", "Passengers", "Share of known", "", "", ""],
          [22, 12, 14, 2, 2, 2])
    r += 1
    nat = dos["Nationality"].dropna() if "Nationality" in dos else pd.Series(dtype=str)
    for val, n in nat.value_counts().head(25).items():
        _c(ws, r, 1, str(val), align="left")
        _c(ws, r, 2, int(n), fmt=FI)
        _c(ws, r, 3, n / len(nat), fmt=FP)
        r += 1
    _c(ws, r, 1, f"not recorded: {len(dos) - len(nat):,} of {len(dos):,}", align="left")


def _sheet_method(wb, mix: pd.DataFrame) -> None:
    ws = wb.create_sheet("Method & Accuracy")
    _c(ws, 1, 1, "HOW ADULT / CHILD / INFANT IS DECIDED, AND HOW WELL IT WORKS",
       bold=True, size=13, color=WHITE, fill=NAVY)
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=4)
    rows = [
        ("The rule", "Compare each ticket's base fare with the DEAREST ticket on the same "
                     "booking. A child is sold at 75% of the adult fare, an infant at 10% or "
                     "25%."),
        ("Bands used", f"infant: {INF_BANDS[0][0]}-{INF_BANDS[0][1]} or "
                       f"{INF_BANDS[1][0]}-{INF_BANDS[1][1]};  child: {CHILD_LO}-{CHILD_HI};  "
                       f"otherwise adult."),
        ("Why so tight", "Fitted to the observed spread, not to round numbers. True children "
                         "sit between 0.749 and 0.758 at the 5th-95th percentile. A wider "
                         "0.60-0.85 band scores 97.19% overall yet only 59.6% precision: four "
                         "in ten 'children' are adults on a discounted fare, median age 28. "
                         "Adults dominate the mix, so overall accuracy hides that entirely."),
        ("Validated against", "26,913 passengers whose real date of birth is held in the "
                              "Zenith Dossier, joined to their ticket by booking and name."),
        ("Solo-ticket bookings", "53% of tickets sit alone on their booking, so there is no "
                                 "second fare to compare against and the passenger is counted "
                                 "an adult. CHECKED, not assumed: on 18,871 solo tickets "
                                 "carrying a real date of birth, 99.90% were adults, 0.10% "
                                 "children and none were infants. So the default is right and "
                                 "the population rate is the true mix. An unaccompanied child "
                                 "is missed, but there are very few."),
        ("Which rate to quote", "The POPULATION rate, out of every ticket sold. The "
                                "group-booking rate (2+ tickets) is about double and answers a "
                                "different question, 'who flies together', because that is "
                                "where the families are. Do not swap them."),
        ("Not suitable for", "Anything per-passenger. About 2.4% of predicted children are "
                             "adults on a cheap fare. Use it for distributions."),
    ]
    r = 3
    for a, b in rows:
        _c(ws, r, 1, a, bold=True, color=NAVY, align="left")
        _c(ws, r, 2, b, wrap=True)
        ws.merge_cells(start_row=r, start_column=2, end_row=r, end_column=4)
        ws.row_dimensions[r].height = 42
        r += 1
    r += 1
    _c(ws, r, 1, "MEASURED ACCURACY", bold=True, size=11, color=WHITE, fill=NAVY)
    ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=4)
    r += 1
    _head(ws, r, ["", "Accuracy", "Precision", "Recall"], [16, 12, 12, 12])
    r += 1
    for a, acc, p, rec in ACCURACY:
        _c(ws, r, 1, a, bold=True, align="left")
        _c(ws, r, 2, acc)
        _c(ws, r, 3, p)
        _c(ws, r, 4, rec)
        r += 1
    for col, w in (("A", 22), ("B", 34), ("C", 34), ("D", 34)):
        ws.column_dimensions[col].width = w


# ---------------------------------------------------------------------------------------
def generate(params: dict | None = None, cfg: Config | None = None) -> Path:
    params = params or {}
    cfg = cfg or load_config(validate=False)
    print("[pax-mix] scanning every ticket in the book ...")
    mix = fetch_mix(cfg)
    if mix.empty:
        raise RuntimeError("no ticket rows found in curated/sales")
    dos = load_dossier(cfg)
    n_pnr = int(mix.groupby("ym").size().sum())      # placeholder, replaced below
    con = duckdb.connect()
    glob = (cfg.data_root / "curated" / "sales" / "**" / "*.parquet").as_posix()
    n_pnr = con.execute(f"""SELECT COUNT(DISTINCT CAST("Record Locator" AS VARCHAR))
        FROM read_parquet('{glob}', hive_partitioning=1, union_by_name=1)
        WHERE "Record Locator" IS NOT NULL""").fetchone()[0]

    wb = Workbook()
    wb.remove(wb.active)
    _sheet_monthly(wb, mix, partial_months(cfg))
    _sheet_sector(wb, mix)
    _sheet_routes(wb, mix)
    _sheet_demographics(wb, dos, n_pnr)
    _sheet_method(wb, mix)

    ch = int((mix.pax_type == "child").sum())
    inf = int((mix.pax_type == "infant").sum())
    nb = int((mix.pax_type == "adult (no benchmark)").sum())
    meas = len(mix) - nb
    print(f"    {len(mix):,} tickets · {mix.ym.nunique()} month(s)")
    print(f"    single-ticket bookings, nothing to compare against: {nb:,} "
          f"({nb/len(mix)*100:.1f}%)")
    print(f"    POPULATION mix over all {len(mix):,} tickets: child {ch:,} "
          f"({ch/len(mix)*100:.2f}%) · infant {inf:,} ({inf/len(mix)*100:.2f}%)   <- quote these")
    print(f"    among the {meas:,} GROUP bookings (2+ tkt): child {ch/meas*100:.2f}% · "
          f"infant {inf/meas*100:.2f}%  (where the families are)")
    print(f"    Dossier sample: {len(dos):,} passengers" if len(dos) else
          "    Dossier sample: none found")

    out_dir = Path(params.get("out_dir") or cfg.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    out = out_dir / f"Passenger_Mix_{datetime.now():%Y%m%d}.xlsx"
    try:
        wb.save(out)
    except PermissionError:
        out = out.with_name(out.stem + "__new.xlsx")
        wb.save(out)
    return out
