"""
reporting.daily_load_reader — reads the "Daily Domestic / International Flight Load"
workbooks (the ops team's forward-booking snapshots) into flat rows.

FORMAT
------
One SHEET PER SNAPSHOT DATE ('12-AUG-2026', '01-AUGUST-2026', "07'August 2023" …),
each holding the next ~15 departure dates across the columns:

    row 1  title
    row 2  |       |          |     | 2026-08-12 | 2026-08-13 | …   <- departure dates
    row 3  | ROUTE | FLIGHT NO| STD | WED        | THU        | …
    row 4+ | DAC-CCU | BS201  | …   | 66         |            | …   <- SEATS SOLD

Cells are seats sold, sometimes "35/2" meaning 35 passengers + 2 infants (an infant
flies without a seat, so `sold` takes the first number only).

WHICH SNAPSHOT COUNTS
---------------------
A departure date appears in up to 15 snapshots as its bookings build. The value from
the sheet whose OWN date equals the departure date is the final picture for that day,
so that is the one kept; earlier snapshots for the same departure are ignored. When
that sheet is missing, the latest snapshot at or before departure is used and the row
is marked `is_final=False` so callers can tell a settled number from a partial one.

NO CAPACITY
-----------
These workbooks carry no capacity/aircraft column anywhere — footer rows are just the
author and run times. Seats sold is all they give; anything needing capacity (fill %,
empty seats) has to join it from the ops history. This module never invents one.
"""
from __future__ import annotations

import datetime as dt
import re
from dataclasses import dataclass
from pathlib import Path

import pandas as pd
from openpyxl import load_workbook

# 'BS 307' / 'BS201' / 'BS 321D' -> BS307 / BS201 / BS321D
_FLIGHT_RE = re.compile(r"^[A-Z0-9]{2}\d{2,4}[A-Z]?$")
_ROUTE_RE = re.compile(r"^([A-Z]{3})\s*-\s*([A-Z]{3})$")
# "35/2" = 35 pax + 2 infants; plain "66" = 66 pax
_CELL_RE = re.compile(r"^\s*(\d+)\s*(?:/\s*(\d+)\s*)?$")

# this archive starts in 2023; anything earlier in a date cell is a broken value
_MIN_PLAUSIBLE_YEAR = 2015

_MONTHS = {
    "JAN": 1, "JANUARY": 1, "FEB": 2, "FEBRUARY": 2, "MAR": 3, "MARCH": 3,
    "APR": 4, "APRIL": 4, "MAY": 5, "JUN": 6, "JUNE": 6, "JUL": 7, "JULY": 7,
    "AUG": 8, "AUGUST": 8, "SEP": 9, "SEPT": 9, "SEPTEMBER": 9, "OCT": 10,
    "OCTOBER": 10, "NOV": 11, "NOVEMBER": 11, "DEC": 12, "DECEMBER": 12,
}


@dataclass(frozen=True)
class DailyLoadRow:
    flight_date: dt.date
    flight_number: str
    leg_route: str
    sold: int
    infant: int
    sector: str            # "DOM" | "INTL" — from the workbook, not guessed
    as_of: dt.date         # the snapshot the number came from
    is_final: bool         # as_of == flight_date


def parse_sheet_date(name: str) -> dt.date | None:
    """'12-AUG-2026', '01-AUGUST-2026', '31-JULY-2026 ', \"07'August 2023\" -> date."""
    s = str(name).strip().replace("'", " ").replace("_", " ")
    s = re.sub(r"[.\-/]+", " ", s)
    m = re.match(r"^\s*(\d{1,2})\s+([A-Za-z]+)\s+(\d{4})\s*$", s)
    if not m:
        return None
    mon = _MONTHS.get(m.group(2).upper())
    if not mon:
        return None
    try:
        return dt.date(int(m.group(3)), mon, int(m.group(1)))
    except ValueError:
        return None


def parse_load_cell(v) -> tuple[int, int] | None:
    """Cell -> (sold, infants). None when the cell holds no number."""
    if v is None:
        return None
    if isinstance(v, bool):
        return None
    if isinstance(v, (int, float)):
        if pd.isna(v):
            return None
        return int(v), 0
    m = _CELL_RE.match(str(v))
    if not m:
        return None
    return int(m.group(1)), int(m.group(2) or 0)


def _norm_flight(v) -> str:
    return re.sub(r"\s+", "", str(v or "")).upper()


def _norm_route(v) -> str | None:
    m = _ROUTE_RE.match(re.sub(r"\s+", "", str(v or "")).upper())
    return f"{m.group(1)}-{m.group(2)}" if m else None


def _sector_of_workbook(path: Path) -> str:
    return "DOM" if "domestic" in path.name.lower() else "INTL"


def read_workbook(path: str | Path) -> list[DailyLoadRow]:
    """Every (departure date, flight) load in one snapshot workbook, deduped to the
    best snapshot per departure (see module docstring)."""
    path = Path(path)
    sector = _sector_of_workbook(path)
    wb = load_workbook(path, read_only=True, data_only=True)
    # best[(date, flight, leg)] = (as_of, sold, infant)
    best: dict[tuple, tuple] = {}
    try:
        for name in wb.sheetnames:
            ws = wb[name]
            rows = [list(r) for r in ws.iter_rows(values_only=True)]
            if len(rows) < 4:
                continue
            # row 2 (index 1) carries the departure dates from column D on
            dates: dict[int, dt.date] = {}
            for j, v in enumerate(rows[1]):
                d = v.date() if isinstance(v, dt.datetime) else (
                    v if isinstance(v, dt.date) else None)
                # a few sheets carry a malformed row-2 cell that Excel resolves to a
                # 1905 serial date; those are not departures, drop them outright
                if d is not None and d.year >= _MIN_PLAUSIBLE_YEAR:
                    dates[j] = d
            if not dates:
                continue
            # The snapshot's own date is its FIRST departure column — taken from the
            # data, never the tab name: names are inconsistent ('31-JULY-2026 ' with a
            # trailing space) and at least one ("07'August 2023") disagrees with the
            # dates inside it by a year. parse_sheet_date() is kept only as a sanity
            # check for callers.
            as_of = dates[min(dates)]        # LEFTMOST date column, not the earliest
                                             # value — a stray out-of-order cell must
                                             # not become the snapshot date
            for row in rows[2:]:
                leg = _norm_route(row[0] if row else None)
                flight = _norm_flight(row[1] if len(row) > 1 else None)
                if not leg or not _FLIGHT_RE.match(flight):
                    continue          # skips the author / STARTING TIME footer rows
                for j, d in dates.items():
                    if j >= len(row):
                        continue
                    parsed = parse_load_cell(row[j])
                    if parsed is None:
                        continue
                    sold, infant = parsed
                    key = (d, flight, leg)
                    prev = best.get(key)
                    # closest snapshot at//before departure wins; a snapshot AFTER the
                    # departure date is stale forward data, never better than an on-day one
                    if as_of > d:
                        continue
                    if prev is None or as_of > prev[0]:
                        best[key] = (as_of, sold, infant)
    finally:
        wb.close()

    return [
        DailyLoadRow(flight_date=d, flight_number=f, leg_route=leg, sold=s,
                     infant=i, sector=sector, as_of=a, is_final=(a == d))
        for (d, f, leg), (a, s, i) in sorted(best.items())
    ]


def read_many(paths) -> pd.DataFrame:
    """Rows from several snapshot workbooks as a DataFrame (dom + intl together)."""
    rows: list[DailyLoadRow] = []
    for p in paths:
        rows.extend(read_workbook(p))
    if not rows:
        return pd.DataFrame(columns=["flight_date", "flight_number", "leg_route",
                                     "sold", "infant", "sector", "as_of", "is_final"])
    df = pd.DataFrame([r.__dict__ for r in rows])
    # the same departure can appear in BOTH workbooks only if a route were listed
    # twice; keep the most recent snapshot if so
    df = (df.sort_values("as_of")
            .drop_duplicates(["flight_date", "flight_number", "leg_route"], keep="last")
            .reset_index(drop=True))
    return df
