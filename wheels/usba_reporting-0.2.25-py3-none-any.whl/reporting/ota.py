"""
reporting/ota.py — THE single answer to "is this customer an OTA?".

WHY THIS MODULE EXISTS
----------------------
Two OTA definitions were live at the same time and nobody had reconciled them:

  * ``reference/ota_list.xlsx``      — 225 analyst-maintained ids. The DSR's "Top OTA" sheet
                                       ranks OTAs from this file.
  * ``dim_customer.ota_status``      — 62 ids flagged in the master. The DSR's Agent OTA cut and
                                       the target report's OTA cut used this.

They overlap on only 61 ids. The consequence was visible in the shipped workbook: 42 agencies
appeared on "Top OTA" *and* on "Agent - Non-OTA" at the same time, carrying 26.51 cr of July
sales — so a reader placing the two sheets side by side could not reconcile them, and 6% of what
one sheet called "excluding OTAs" was revenue the company's own OTA ranking calls OTA.

THE RULE: an agency is an OTA if EITHER source says so, and the flag then travels across a
merged agency's sibling ids. Union rather than "pick one" is deliberate — it is the only choice
that takes OTA status away from nobody, so switching to it cannot quietly drop an agency out of
a book someone is already working. It is also monotonic: adding a row to either source can only
add OTAs, never remove them.

Every surface that splits on OTA must call this. Re-deriving it locally is what caused the drift.
"""
from __future__ import annotations

from pathlib import Path

import pandas as pd

# The three sibling pairs the kit maintains by hand (IATA + Non-IATA codes for one agency).
# Kept here as well as in the merge map so the fold still works on a machine with no reference/.
HARDCODED_SIBLINGS: dict[str, str] = {
    "10000277": "BEFRESH", "11662412": "BEFRESH",
    "10000179": "TALON", "11731796": "TALON",
    "10502007": "GOZAYAAN", "12084060": "GOZAYAAN",
}


def _norm(v) -> str:
    """'10000174.0' / ' 10000174 ' / 10000174 -> '10000174'; blank-ish -> ''."""
    if v is None:
        return ""
    s = str(v).strip()
    if not s or s.lower() in {"nan", "none", "nat"}:
        return ""
    return s[:-2] if s.endswith(".0") else s


def _sibling_groups(data_root: Path) -> dict[str, str]:
    """customer_id -> group key, from the audited merge map plus the hardcoded pairs."""
    groups = dict(HARDCODED_SIBLINGS)
    f = data_root / "reference" / "agency_merge_map.csv"
    if f.is_file():
        try:
            m = pd.read_csv(f, dtype=str)
            for r in m.itertuples():
                if str(getattr(r, "use", "")).strip() == "1":
                    groups.setdefault(_norm(r.cid), f"NM:{r.merge_key}")
        except Exception:                       # unreadable -> hardcoded pairs only
            pass
    groups.pop("", None)
    return groups


def resolve_ota_ids(data_root: Path, con=None) -> set[str]:
    """Every customer id that counts as an OTA, siblings folded.

    ``con`` is an open DuckDB connection with ``dim_customer`` registered; pass None (or a
    connection without it) and the master half is simply skipped — the file half still works,
    so a colleague's exe with no warehouse still gets the analyst's OTA list.
    """
    ids: set[str] = set()

    # (a) the analyst-maintained list — the same file the DSR's Top OTA sheet ranks from
    f = data_root / "reference" / "ota_list.xlsx"
    if f.is_file():
        try:
            d = pd.read_excel(f)
            col = next((c for c in d.columns if str(c).strip().lower() == "customer_id"), None)
            if col is not None:
                ids |= {_norm(v) for v in d[col]}
        except Exception:
            pass

    # (b) the master's own flag
    if con is not None:
        try:
            d = con.execute("""
                SELECT CAST(customer_id AS VARCHAR) cid FROM dim_customer
                WHERE upper(trim(COALESCE(ota_status, ''))) = 'OTA'
            """).df()
            ids |= {_norm(v) for v in d["cid"]}
        except Exception:                       # no dim_customer in this connection
            pass

    ids.discard("")
    if not ids:
        return set()

    # (c) fold across merged siblings: one agency, one answer
    groups = _sibling_groups(data_root)
    ota_keys = {k for cid, k in groups.items() if cid in ids}
    return ids | {cid for cid, k in groups.items() if k in ota_keys}
