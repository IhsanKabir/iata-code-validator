"""
reporting.builders.load_factor_seats — LOAD FACTOR EXPRESSED IN SEATS.

PURPOSE: the load-factor picture counted in SEATS rather than a percentage —
how many seats were offered, how many flew, and how many went out EMPTY. Rebuilt
from the curated ops history, so ingesting more Zenith load files and re-running
refreshes every number; nothing is hand-maintained.

SOURCE: curated/flight_history/flight_loads_history.parquet (post-departure ops:
capacity + flown per departure, written by scripts/ingest_flight_history.py). A
departure counts when capacity > 0 AND a flown figure was recorded — a scheduled
row with no flown figure is not an operated flight and is skipped, never zero-filled.

THE THREE-WAY SPLIT (this is the point of the report)
-----------------------------------------------------
A BD-BD leg is NOT automatically domestic. Flights like BS343 DAC-CGP-DXB fly the
DAC-CGP sector on an aircraft sized for Dubai and pick up only a little local
traffic, so their sector runs ~35% full. Counting those as "domestic" understated
the real domestic fill by 5-7 points and charged a third of the domestic empty
seats to a shortfall that never existed. So legs are grouped:

  DOMESTIC                              flights that only ever fly BD-BD
  INTERNATIONAL                         any leg touching a foreign point
  DOMESTIC SECTOR OF INTERNATIONAL      BD-BD legs flown by a service that also
                                        touches a foreign point (grouped under
                                        the onward international point)

A flight is "mixed" when its own leg set contains both BD-BD and foreign legs.

SHEETS
------
* "Seats Summary" — years side by side (one column block each) on a shared row
  skeleton, so a flight sits on the same row in every year and you read across.
  Sector -> destination -> flight, with Fill % beside Avg Seats Filled.
* "<year> Daily Seats" — the flight x date grid with SEATS FLOWN in each cell,
  shaded red->green by how full that departure was. Blank = did not operate.

Public entry point: ``generate(params, cfg) -> Path``.
params: date_from / date_to (YYYY-MM-DD, optional), out_dir.
"""
from __future__ import annotations

import datetime as dt
import re
from collections import defaultdict
from pathlib import Path

import duckdb
import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from ..config import Config, load_config

# Bangladesh airports — both endpoints in here means the LEG is domestic (the
# flight may still be an international service; see MIXED below).
BD_AIRPORTS = frozenset({"DAC", "CGP", "CXB", "ZYL", "JSR", "RJH", "BZL", "SPD"})

DOM = "DOMESTIC"
INTL = "INTERNATIONAL"
TAG = "DOMESTIC SECTOR OF INTERNATIONAL FLIGHTS"
SECTORS = (DOM, INTL, TAG)
SECTOR_LABELS = {DOM: "Domestic (own flights)", INTL: "International",
                 TAG: "Dom. sector of intl flt"}

HDR = ["Flight No", "Leg/Sector", "Flights", "Avg Seats/Flight", "Avg Seats Filled",
       "Fill %", "Avg Empty Seats", "Total Seats Offered", "Total Seats Filled",
       "Total Empty Seats"]
NC = len(HDR)
STRIDE = NC + 1

NAVY = PatternFill("solid", fgColor="1F3864")
SECT = PatternFill("solid", fgColor="2E5C8A")
DESTF = PatternFill("solid", fgColor="D9E1F2")
GREY = PatternFill("solid", fgColor="EDF0F5")
BAND = PatternFill("solid", fgColor="B4C6E7")
WHITE = "FFFFFF"
_THIN = Side(style="thin", color="BFBFBF")
BORDER = Border(left=_THIN, right=_THIN, top=_THIN, bottom=_THIN)

# Trailing letter is a real extra/delayed section (BS307D); only footer junk rows
# like "No. of flights" must be filtered out.
FLIGHT_RE = re.compile(r"^[A-Z0-9]{2}\d{2,4}[A-Z]?$")

_fill_cache: dict[str, PatternFill] = {}


def is_domestic_leg(leg: str) -> bool:
    ends = [e.strip().upper() for e in str(leg).split("-")]
    return len(ends) == 2 and all(e in BD_AIRPORTS for e in ends)


def destination_of(leg: str) -> str:
    """The point the leg is 'about': the foreign end for an international leg,
    otherwise the non-DAC end (matching how the load board groups routes)."""
    ends = [e.strip().upper() for e in str(leg).split("-")]
    if len(ends) != 2:
        return str(leg).strip().upper()
    foreign = [e for e in ends if e not in BD_AIRPORTS]
    if foreign:
        return foreign[0]
    non_dac = [e for e in ends if e != "DAC"]
    return non_dac[0] if non_dac else ends[-1]


def lf_fill(lf: float) -> PatternFill:
    """Excel's classic 3-colour scale: red (empty) -> yellow -> green (full)."""
    lf = max(0.0, min(1.0, lf))
    red, yellow, green = (0xF8, 0x69, 0x6B), (0xFF, 0xEB, 0x84), (0x63, 0xBE, 0x7B)
    a, b, t = (red, yellow, lf / 0.5) if lf <= 0.5 else (yellow, green, (lf - 0.5) / 0.5)
    key = "%02X%02X%02X" % tuple(round(a[i] + (b[i] - a[i]) * t) for i in range(3))
    f = _fill_cache.get(key)
    if f is None:
        f = _fill_cache[key] = PatternFill("solid", fgColor=key)
    return f


def _history_path(cfg: Config) -> Path:
    return Path(cfg.data_root) / "curated" / "flight_history" / "flight_loads_history.parquet"


def fetch(cfg: Config, date_from: str | None, date_to: str | None):
    """One row per OPERATED departure: (d, year, flight, leg, capacity, flown)."""
    src = _history_path(cfg)
    if not src.is_file():
        raise FileNotFoundError(
            f"No ops history at {src}. Run scripts/ingest_flight_history.py on the "
            "Zenith load files first — this report is built from flown data.")
    where = ["capacity IS NOT NULL", "capacity > 0", "flown IS NOT NULL"]
    if date_from:
        where.append(f"flight_date >= DATE '{date_from}'")
    if date_to:
        where.append(f"flight_date <= DATE '{date_to}'")
    con = duckdb.connect()
    df = con.sql(f"""
        SELECT CAST(flight_date AS DATE) AS d,
               strftime(CAST(flight_date AS DATE), '%Y') AS y,
               TRIM(CAST(flight_number AS VARCHAR)) AS flight,
               UPPER(TRIM(CAST(leg_route AS VARCHAR))) AS leg,
               SUM(capacity) AS capacity, SUM(flown) AS flown
        FROM read_parquet('{src.as_posix()}')
        WHERE {' AND '.join(where)}
        GROUP BY 1, 2, 3, 4
        ORDER BY 1, 3, 4
    """).df()
    return df[df.flight.str.replace(" ", "", regex=False).str.match(FLIGHT_RE)]


def discover_daily_load_files(folder: Path | None = None) -> list[Path]:
    """Newest "Daily … Flight Load … .xlsx" per sector from ~/Downloads.

    The ops team drops a fresh Domestic and International snapshot workbook there;
    picking the newest of each keeps the report current without a file-picker. An
    explicit params["daily_files"] always wins over this.
    """
    folder = folder or (Path.home() / "Downloads")
    if not folder.is_dir():
        return []
    newest: dict[str, Path] = {}
    for f in folder.glob("*.xlsx"):
        n = f.name.lower()
        if f.name.startswith("~$") or "flight load" not in n or not n.startswith("daily"):
            continue
        key = "dom" if "domestic" in n else "intl"
        if key not in newest or f.stat().st_mtime > newest[key].stat().st_mtime:
            newest[key] = f
    return [newest[k] for k in sorted(newest)]


def fetch_daily_files(cfg: Config, files, date_from: str | None, date_to: str | None):
    """Same shape as fetch(), but sourced from the ops team's "Daily Domestic /
    International Flight Load" snapshot workbooks.

    Those files carry SEATS SOLD per flight per departure date and no capacity at
    all, so capacity is resolved from the ingested ops history, in this order:

      1. the exact (flight, leg, date) capacity, when that departure was ingested;
      2. otherwise that flight+leg's most common capacity — an ESTIMATE, since the
         aircraft is swapped day to day (the same leg appears at 420/425/434/436);
      3. otherwise the departure is left out of the report, never given a guessed
         capacity, and counted in `dropped_no_capacity` so the gap is visible.

    Returns (df, meta).
    """
    from ..daily_load_reader import read_many

    df = read_many([Path(f) for f in files])
    if df.empty:
        return df, {"rows": 0, "dropped_no_capacity": 0, "estimated_capacity": 0}
    df = df.rename(columns={"flight_number": "flight", "leg_route": "leg"})
    df["d"] = pd.to_datetime(df["flight_date"]).dt.date
    if date_from:
        df = df[df["d"] >= dt.date.fromisoformat(date_from)]
    if date_to:
        df = df[df["d"] <= dt.date.fromisoformat(date_to)]
    if df.empty:
        return df, {"rows": 0, "dropped_no_capacity": 0, "estimated_capacity": 0}

    hist_path = _history_path(cfg)
    exact = pd.DataFrame(columns=["d", "flight", "leg", "capacity"])
    typical = pd.DataFrame(columns=["flight", "leg", "cap_typical"])
    if hist_path.is_file():
        con = duckdb.connect()
        h = con.sql(f"""
            SELECT CAST(flight_date AS DATE) AS d,
                   TRIM(CAST(flight_number AS VARCHAR)) AS flight,
                   UPPER(TRIM(CAST(leg_route AS VARCHAR))) AS leg,
                   capacity
            FROM read_parquet('{hist_path.as_posix()}')
            WHERE capacity IS NOT NULL AND capacity > 0
        """).df()
        if not h.empty:
            h["d"] = pd.to_datetime(h["d"]).dt.date
            exact = h.groupby(["d", "flight", "leg"], as_index=False).capacity.max()
            typical = (h.groupby(["flight", "leg"]).capacity
                        .agg(lambda s: s.mode().iloc[0])
                        .reset_index().rename(columns={"capacity": "cap_typical"}))

    df = df.merge(exact, on=["d", "flight", "leg"], how="left")
    df = df.merge(typical, on=["flight", "leg"], how="left")
    n_exact = int(df["capacity"].notna().sum())
    df["capacity"] = df["capacity"].fillna(df["cap_typical"])
    dropped = int(df["capacity"].isna().sum())
    estimated = int(df["capacity"].notna().sum()) - n_exact
    df = df[df["capacity"].notna()].copy()
    df["flown"] = df["sold"].astype(float)      # seats sold = seats that flew
    df["y"] = pd.to_datetime(df["d"]).dt.strftime("%Y")
    meta = {"rows": int(len(df)), "dropped_no_capacity": dropped,
            "estimated_capacity": estimated, "exact_capacity": n_exact}
    return df[["d", "y", "flight", "leg", "capacity", "flown"]], meta


def shape(df):
    """Returns (stats, tree, dates_by_year, cells).

    stats[(y, flight, leg)] = [departures, capacity, flown]
    tree[sector][destination] = {(flight, leg)}
    cells[(y, flight, leg, date)] = (capacity, flown)   — for the daily grids
    """
    stats: dict[tuple, list] = defaultdict(lambda: [0, 0.0, 0.0])
    cells: dict[tuple, tuple] = {}
    dates_by_year: dict[str, set] = defaultdict(set)
    legs_of_flight: dict[str, set] = defaultdict(set)
    for r in df.itertuples():
        k = (r.y, r.flight, r.leg)
        s = stats[k]
        s[0] += 1
        s[1] += float(r.capacity)
        s[2] += float(r.flown)
        cells[(r.y, r.flight, r.leg, r.d)] = (float(r.capacity), float(r.flown))
        dates_by_year[r.y].add(r.d)
        legs_of_flight[r.flight].add(r.leg)

    # a service touching both BD-BD and foreign legs flies its BD-BD sector on an
    # internationally-sized aircraft — that sector is NOT domestic flying
    mixed = {f for f, ls in legs_of_flight.items()
             if any(is_domestic_leg(x) for x in ls)
             and any(not is_domestic_leg(x) for x in ls)}
    intl_dest = {f: "/".join(sorted({destination_of(l) for l in legs_of_flight[f]
                                     if not is_domestic_leg(l)})) or "?"
                 for f in mixed}

    tree: dict[str, dict[str, set]] = {s: defaultdict(set) for s in SECTORS}
    for (_y, f, leg) in stats:
        if not is_domestic_leg(leg):
            tree[INTL][destination_of(leg)].add((f, leg))
        elif f in mixed:
            tree[TAG][intl_dest[f]].add((f, leg))
        else:
            tree[DOM][destination_of(leg)].add((f, leg))
    return stats, tree, dates_by_year, cells, mixed, intl_dest


def _put(ws, r, c, v, *, bold=False, fill=None, color=None, fmt=None, align=None,
         size=None, border=False):
    x = ws.cell(r, c, v)
    if bold or color or size:
        x.font = Font(bold=bold, color=color or "000000", size=size or 11)
    if fill:
        x.fill = fill
    if fmt:
        x.number_format = fmt
    if align:
        x.alignment = Alignment(horizontal=align, vertical="center")
    if border:
        x.border = BORDER
    return x


def _metrics(ws, r, c0, flights, cap, flown, *, bold=False, fill=None):
    """The eight metric columns of one year block."""
    empty = cap - flown
    _put(ws, r, c0 + 2, int(flights) or None, bold=bold, fill=fill, fmt="#,##0",
         align="center", border=True, size=9)
    for k, v in ((3, cap / flights if flights else None),
                 (4, flown / flights if flights else None)):
        _put(ws, r, c0 + k, v, bold=bold, fill=fill, fmt="#,##0.0", align="right",
             border=True, size=9)
    _put(ws, r, c0 + 5, flown / cap if cap else None, bold=bold, fill=fill,
         fmt="0.0%", align="right", border=True, size=9)
    _put(ws, r, c0 + 6, empty / flights if flights else None, bold=bold, fill=fill,
         fmt="#,##0.0", align="right", border=True, size=9)
    for k, v in ((7, cap), (8, flown), (9, empty)):
        _put(ws, r, c0 + k, v or None, bold=bold, fill=fill, fmt="#,##0",
             align="right", border=True, size=9)


def _agg(stats, year, pairs):
    fl = cap = flown = 0.0
    for f, leg in pairs:
        s = stats.get((year, f, leg))
        if s:
            fl += s[0]
            cap += s[1]
            flown += s[2]
    return fl, cap, flown


def _capacity_note(meta: dict | None) -> str:
    """Spell out, on the sheet, how capacity was resolved for a daily-load run."""
    if not meta:
        return ""
    bits = []
    if meta.get("estimated_capacity"):
        bits.append(f"{meta['estimated_capacity']:,} departures use their flight+leg's "
                    "TYPICAL capacity (the source files carry none), so their Fill % "
                    "and Empty Seats are estimates")
    if meta.get("exact_capacity"):
        bits.append(f"{meta['exact_capacity']:,} use the exact capacity recorded for "
                    "that date")
    if meta.get("dropped_no_capacity"):
        bits.append(f"{meta['dropped_no_capacity']:,} departures are EXCLUDED because no "
                    "capacity is known for that flight+leg — ingest their load files to "
                    "include them")
    return ("   SOURCE: daily flight-load snapshots (seats sold).  " + ";  ".join(bits) + "."
            if bits else "")


def build(stats, tree, dates_by_year, cells, mixed, intl_dest, years,
          meta: dict | None = None) -> Workbook:
    wb = Workbook()
    ws = wb.active
    ws.title = "Seats Summary"
    ws.sheet_view.showGridLines = False

    # shared row skeleton so the same flight lands on the same row in every year
    skeleton: list[tuple] = []
    for sector in SECTORS:
        dests = sorted(d for d in tree[sector] if tree[sector][d])
        if not dests:
            continue
        skeleton.append(("sector", sector))
        skeleton.append(("cols", None))
        for dst in dests:
            pairs = sorted(tree[sector][dst])
            skeleton.append(("dest", dst))
            skeleton.extend(("flight", p) for p in pairs)
            skeleton.append(("dtotal", (dst, pairs)))
            skeleton.append(("blank", None))
        skeleton.append(("stotal",
                         (sector, [p for d in dests for p in sorted(tree[sector][d])])))
        skeleton.append(("blank", None))

    total_w = STRIDE * max(1, len(years)) - 1
    _put(ws, 1, 1, "LOAD FACTOR IN SEATS — domestic vs international, years side by side",
         bold=True, fill=NAVY, color=WHITE, size=12)
    for c in range(2, total_w + 1):
        ws.cell(1, c).fill = NAVY
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=total_w)
    _put(ws, 2, 1,
         "Counted in SEATS, not a percentage.  Empty Seats = Capacity − Flown over the dates each "
         "leg actually operated; averages are per operated flight; Fill % = filled ÷ offered.  "
         "A BD-BD sector flown by an international service (e.g. BS343 DAC-CGP-DXB) is listed "
         "separately — that aircraft is sized for the international leg, so its empty seats are "
         "NOT a domestic-network shortfall.  Rebuilt from the ops history: ingest more load files "
         "and re-run to refresh."
         + _capacity_note(meta),
         size=8, color="595959")
    ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=total_w)

    HEAD_R = 4
    for yi, year in enumerate(years):
        c0 = 1 + yi * STRIDE
        _put(ws, HEAD_R, c0, f"Year: {year}", bold=True, fill=NAVY, color=WHITE, size=11)
        for c in range(c0 + 1, c0 + NC):
            ws.cell(HEAD_R, c).fill = NAVY
        ws.merge_cells(start_row=HEAD_R, start_column=c0, end_row=HEAD_R, end_column=c0 + 1)
        r = HEAD_R + 1
        _put(ws, r, c0, "Sector", bold=True, fill=GREY, align="center", size=9, border=True)
        _put(ws, r, c0 + 1, "", fill=GREY, border=True)
        for j, h in enumerate(HDR[2:], 2):
            _put(ws, r, c0 + j, h, bold=True, fill=GREY, align="center", size=9, border=True)
        r += 1
        for sector in SECTORS:
            pairs = [p for d in tree[sector] for p in tree[sector][d]]
            _put(ws, r, c0, SECTOR_LABELS[sector], bold=True, fill=DESTF, size=9, border=True)
            _put(ws, r, c0 + 1, "", fill=DESTF, border=True)
            _metrics(ws, r, c0, *_agg(stats, year, pairs), bold=True, fill=DESTF)
            r += 1
        every = [p for s in SECTORS for d in tree[s] for p in tree[s][d]]
        _put(ws, r, c0, "All flights", bold=True, fill=BAND, size=9, border=True)
        _put(ws, r, c0 + 1, "", fill=BAND, border=True)
        _metrics(ws, r, c0, *_agg(stats, year, every), bold=True, fill=BAND)

    START = HEAD_R + 7
    for yi, year in enumerate(years):
        c0 = 1 + yi * STRIDE
        r = START
        for kind, payload in skeleton:
            if kind == "sector":
                _put(ws, r, c0, f"{payload}  ·  {year}", bold=True, fill=SECT,
                     color=WHITE, size=10)
                for c in range(c0 + 1, c0 + NC):
                    ws.cell(r, c).fill = SECT
                ws.merge_cells(start_row=r, start_column=c0, end_row=r, end_column=c0 + 1)
            elif kind == "cols":
                for j, h in enumerate(HDR):
                    _put(ws, r, c0 + j, h, bold=True, fill=GREY, align="center",
                         size=8, border=True)
            elif kind == "dest":
                _put(ws, r, c0, f"Destination: {payload}", bold=True, fill=DESTF, size=9)
                for c in range(c0 + 1, c0 + NC):
                    ws.cell(r, c).fill = DESTF
                ws.merge_cells(start_row=r, start_column=c0, end_row=r, end_column=c0 + 1)
            elif kind == "flight":
                f, leg = payload
                shown = (f"{leg} → {intl_dest[f]}"
                         if f in mixed and is_domestic_leg(leg) else leg)
                _put(ws, r, c0, f, size=9, border=True)
                _put(ws, r, c0 + 1, shown, size=9, border=True)
                s = stats.get((year, f, leg))
                if s and s[0]:
                    _metrics(ws, r, c0, s[0], s[1], s[2])
                else:
                    for j in range(2, NC):
                        _put(ws, r, c0 + j, None, border=True)
            elif kind == "dtotal":
                dst, pairs = payload
                _put(ws, r, c0, f"{dst} total", bold=True, fill=BAND, size=9, border=True)
                _put(ws, r, c0 + 1, "", fill=BAND, border=True)
                _metrics(ws, r, c0, *_agg(stats, year, pairs), bold=True, fill=BAND)
            elif kind == "stotal":
                sector, pairs = payload
                _put(ws, r, c0, f"{sector} TOTAL", bold=True, fill=SECT, color=WHITE,
                     size=9, border=True)
                _put(ws, r, c0 + 1, "", fill=SECT, border=True)
                _metrics(ws, r, c0, *_agg(stats, year, pairs), bold=True, fill=SECT)
                for c in range(c0, c0 + NC):
                    ws.cell(r, c).font = Font(bold=True, color=WHITE, size=9)
            r += 1

    for yi in range(len(years)):
        c0 = 1 + yi * STRIDE
        for j, w in enumerate((11, 14, 8, 12, 12, 8, 12, 13, 13, 13)):
            ws.column_dimensions[get_column_letter(c0 + j)].width = w
        if yi < len(years) - 1:
            ws.column_dimensions[get_column_letter(c0 + NC)].width = 2
    ws.freeze_panes = ws.cell(START, 1).coordinate

    _daily_grids(wb, stats, dates_by_year, cells, years)
    return wb


def _daily_grids(wb, stats, dates_by_year, cells, years) -> None:
    """One flight x date grid per year, SEATS FLOWN in each cell, shaded by fill."""
    for year in years:
        dates = sorted(dates_by_year.get(year, ()))
        if not dates:
            continue
        legs = sorted({(f, l) for (y, f, l) in stats if y == year})
        ws = wb.create_sheet(f"{year} Daily Seats")
        ws.sheet_view.showGridLines = False
        t = ws.cell(1, 1, f"{year} — SEATS FLOWN per flight per day (numbers, not %).  "
                          "Colour = how full (red → green).  Blank = did not operate.")
        t.font = Font(bold=True, color=WHITE, size=11)
        t.fill = NAVY
        ws.merge_cells(start_row=1, start_column=1, end_row=1,
                       end_column=min(5 + len(dates), 12))
        for c in range(2, min(5 + len(dates), 12) + 1):
            ws.cell(1, c).fill = NAVY
        for j, h in enumerate(["Flight No", "Leg/Sector", "Avg Seats", "Total Flown",
                               "Total Empty"], 1):
            x = ws.cell(2, j, h)
            x.font = Font(bold=True, color=WHITE, size=9)
            x.fill = SECT
            x.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        for j, d in enumerate(dates, 6):
            x = ws.cell(2, j, f"{d:%d/%m/%Y}\n{d:%A}")
            x.font = Font(bold=True, color=WHITE, size=8)
            x.fill = SECT
            x.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        r = 3
        for f, leg in legs:
            ws.cell(r, 1, f).font = Font(size=9)
            ws.cell(r, 2, leg).font = Font(size=9)
            for j, d in enumerate(dates, 6):
                v = cells.get((year, f, leg, d))
                if not v:
                    continue
                cap, fl = v
                x = ws.cell(r, j, int(round(fl)))
                x.fill = lf_fill(fl / cap if cap else 0)
                x.font = Font(size=9)
                x.number_format = "#,##0"
                x.alignment = Alignment(horizontal="center")
            s = stats.get((year, f, leg))
            if s and s[0]:
                for c, val in ((3, round(s[1] / s[0])), (4, int(s[2])),
                               (5, int(s[1] - s[2]))):
                    x = ws.cell(r, c, val)
                    x.font = Font(size=9, bold=(c != 3))
                    x.number_format = "#,##0"
                    x.alignment = Alignment(horizontal="center")
                    x.fill = GREY
            r += 1
        ws.freeze_panes = "F3"
        ws.row_dimensions[2].height = 28
        for c, w in ((1, 10), (2, 11), (3, 8), (4, 10), (5, 10)):
            ws.column_dimensions[get_column_letter(c)].width = w
        for c in range(6, 6 + len(dates)):
            ws.column_dimensions[get_column_letter(c)].width = 7.5


def _save_locktolerant(wb: Workbook, path: Path) -> Path:
    """Never fail because the previous copy is open in Excel."""
    try:
        wb.save(path)
        return path
    except PermissionError:
        for i in range(1, 50):
            alt = path.with_name(f"{path.stem}__new{'' if i == 1 else i}{path.suffix}")
            try:
                wb.save(alt)
                return alt
            except PermissionError:
                continue
        raise


def generate(params: dict | None = None, cfg: Config | None = None) -> Path:
    params = params or {}
    cfg = cfg or load_config(validate=True)
    # explicit list wins; otherwise auto-pick the ops team's latest snapshot
    # workbooks. They span ~2 years, where the ingested ops history currently
    # covers weeks, so when both exist the snapshots are the better source.
    daily_files = params.get("daily_files")
    if daily_files is None:
        daily_files = discover_daily_load_files()
    daily_files = list(daily_files or [])
    meta: dict = {}
    if daily_files:
        df, meta = fetch_daily_files(cfg, daily_files, params.get("date_from"),
                                     params.get("date_to"))
    else:
        df = fetch(cfg, params.get("date_from"), params.get("date_to"))
    if df.empty:
        raise ValueError(
            "No operated departures in the ops history for that range — ingest the "
            "Zenith load files (scripts/ingest_flight_history.py) and try again.")
    stats, tree, dates_by_year, cells, mixed, intl_dest = shape(df)
    years = sorted(dates_by_year)
    wb = build(stats, tree, dates_by_year, cells, mixed, intl_dest, years, meta=meta)
    lo, hi = df.d.min(), df.d.max()
    out_dir = Path(params.get("out_dir") or cfg.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    name = f"Load_Factor_Seats_{lo:%Y-%m-%d}_to_{hi:%Y-%m-%d}.xlsx"
    return _save_locktolerant(wb, out_dir / name)
