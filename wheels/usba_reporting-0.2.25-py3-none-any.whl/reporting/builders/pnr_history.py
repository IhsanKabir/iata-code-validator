"""
reporting.builders.pnr_history — the full life of a booking, seen from BOTH sides.

THE QUESTION THIS ANSWERS
-------------------------
"What happened on this PNR — from the agency's point of view, and from the airline's?"

Those are two different answers, and the difference is the whole point of this report.

  AGENCY LENS   only the rows carrying that agency's Customer ID. It is what the agency's own
                sale-details export shows, what it gets paid on, and what the Agent sheet
                counts. It stops at the edge of what that agency did.

  AIRLINE LENS  every row on the PNR, whoever made it. A ticket sold by an agency can later be
                voided, reissued, refunded or re-priced by a DIFFERENT customer id — a counter,
                the call centre, BO-1 Central Reservation, or another agency. Those rows never
                appear in the agency's own export, so the agency's story is TRUE but PARTIAL:
                it shows the sale and not the cancellation.

An agency ringing up about "my ticket" is asking the airline question. Answering it from the
agency lens is how you tell someone their ticket is live when it was voided at a counter weeks
ago.

WHICH FIELD IS "THE PNR"
------------------------
The 6-character code everyone quotes (098I2V) is ``Record Locator`` — the key here.
``PNR Zenith`` is its numeric twin (15513223). ``PNR GDS`` is the GDS's own locator, populated
only for GDS bookings (~28%) and blank for EXTRANET/WEB. All three are printed.

HOW A TICKET IS FOLLOWED THROUGH A CHANGE
-----------------------------------------
A reissue REPLACES a ticket, it does not edit one:

    Original ticket number  --->  Ticket number      (on the Reissuance Adjustment row)

so a passenger's history is a CHAIN of ticket numbers. ``Exchanged ticket number`` carries the
same predecessor and is the more reliable marker that a row IS a change. The pre-change
itinerary columns (``Exchanged Departure Airport`` / ``Exchanged Flight date``) are populated
on well under half of those rows, so "Route before" is often blank — a source gap, not a bug.

DATE COLUMN — "Date", NEVER "Pure Date"
---------------------------------------
In curated/sales ``Pure Date`` is only ~25% populated; ``Date`` is 100%. Filtering a PNR window
on Pure Date silently halves the answer (one agency over Jan-Apr 2026: 42 PNRs on Pure Date vs
85 on Date). ``Pure Date`` IS complete in gold — this warning is about curated only.

THREE WAYS TO SCOPE IT
----------------------
  params["pnrs"]      an explicit list of Record Locators
  params["customer"]  every PNR that agency touched between date_from and date_to
  neither             EXCEPTION MODE — the default in the desktop app, where there is nobody
                      to type a PNR. Selects only bookings whose history is NOT a clean single
                      sale: serviced by more than one customer id, reissued, or voided/refunded.
                      A clean sale has no history worth reading; these are the ones that do.
                      Ranked worst-first and CAPPED (params["max_pnrs"], default 3000) because
                      a single month holds ~25,000 of them. The cap is printed on the sheet and
                      in Notes — never silently applied.
"""
from __future__ import annotations

import re
from datetime import date, datetime
from pathlib import Path

import duckdb
import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side

from ..config import Config, load_config

NAVY, BLUE, WHITE = "1F3864", "2E5395", "FFFFFF"
AMBER, GREENL, REDL, LILAC = "FFF2CC", "E2EFDA", "FCE4E4", "E4DFEC"
FI, FM = "#,##0", "#,##0.00"
BORDER = Border(*([Side(style="thin", color="BFBFBF")] * 4))

DEFAULT_MAX_PNRS = 3000

# Transactions that put a ticket into the world, and the ones that take it back out.
SALE_TXNS = ("Ticket payment", "Reissuance Adjustment")
KILL_TXNS = ("Ticket void", "Refund", "Cancel refund")

# Passenger name = the LAST bracketed group of the Heading narrative:
#   "Ticket sale [OW] DAC>JED [PORIKHIT CHANDRA SUTRADHAR]" -> PORIKHIT CHANDRA SUTRADHAR
#   "Commission   [MD SOMUN MIA]"                           -> MD SOMUN MIA
_PAX_RE = re.compile(r"\[([^\[\]]+)\]\s*$")


def _c(ws, r, col, v, *, bold=False, fill=None, fmt=None, color="000000", size=9, wrap=False):
    cell = ws.cell(row=r, column=col, value=v)
    cell.font = Font(bold=bold, color=color, size=size)
    cell.border = BORDER
    if fill:
        cell.fill = PatternFill("solid", fgColor=fill)
    if fmt:
        cell.number_format = fmt
    if wrap:
        cell.alignment = Alignment(wrap_text=True, vertical="top")
    return cell


def _norm_id(v) -> str:
    """'11650769.0' / ' 11650769 ' -> '11650769'; blank-ish -> ''."""
    s = "" if v is None else str(v).strip()
    if not s or s.lower() in {"nan", "none", "nat"}:
        return ""
    return s[:-2] if s.endswith(".0") else s


def _pax(heading) -> str:
    """Passenger name out of the Heading narrative, '' when it does not carry one."""
    m = _PAX_RE.search(("" if heading is None else str(heading)).strip())
    return m.group(1).strip() if m else ""


def _sql_list(values) -> str:
    return ", ".join("'" + str(v).replace("'", "''") + "'" for v in values)


def _widths(ws, widths: dict[str, float]) -> None:
    for col, w in widths.items():
        ws.column_dimensions[col].width = w


# ---------------------------------------------------------------------------------------
# scope
# ---------------------------------------------------------------------------------------
def resolve_pnrs(con, sales_glob: str, params: dict) -> tuple[list[str], str, int]:
    """(pnr list, human description, how many were dropped by the cap)."""
    lo = params.get("date_from")
    hi = params.get("date_to")
    where_date = ""
    if lo and hi:
        where_date = f" AND \"Date\"::DATE BETWEEN DATE '{lo}' AND DATE '{hi}'"
    elif lo:
        where_date = f" AND \"Date\"::DATE >= DATE '{lo}'"
    elif hi:
        where_date = f" AND \"Date\"::DATE <= DATE '{hi}'"
    window = f"{lo or 'start'} to {hi or 'latest'}"

    given = params.get("pnrs")
    if given:
        pnrs = sorted({str(p).strip().upper() for p in given if str(p).strip()})
        return pnrs, f"{len(pnrs)} PNR(s) supplied", 0

    cust = _norm_id(params.get("customer"))
    if cust:
        # NOTE the date column: "Date", never "Pure Date" — see the module docstring.
        got = con.sql(f"""
            SELECT DISTINCT CAST("Record Locator" AS VARCHAR) AS rl
            FROM read_parquet('{sales_glob}', hive_partitioning=1, union_by_name=1)
            WHERE regexp_replace(CAST("Customer ID" AS VARCHAR), '\\.0$', '') = '{cust}'
              AND "Record Locator" IS NOT NULL{where_date}
        """).df()
        return (sorted(str(v) for v in got.rl),
                f"every PNR customer {cust} touched, {window}", 0)

    # ---- EXCEPTION MODE (the desktop default) ----------------------------------------
    # A booking that was sold once and never touched again has no history worth reading.
    # These are the ones that do: handled by someone else, changed, or cancelled.
    cap = int(params.get("max_pnrs") or DEFAULT_MAX_PNRS)
    ranked = con.sql(f"""
        WITH p AS (
            SELECT CAST("Record Locator" AS VARCHAR) AS rl,
                   COUNT(DISTINCT regexp_replace(CAST("Customer ID" AS VARCHAR),'\\.0$','')) AS n_cust,
                   COUNT(*) FILTER (WHERE "Exchanged ticket number" IS NOT NULL) AS n_exch,
                   COUNT(*) FILTER (WHERE CAST("Transaction" AS VARCHAR) IN {KILL_TXNS}) AS n_kill,
                   SUM(ABS(COALESCE(CAST("Balance (base currency)" AS DOUBLE), 0))) AS gross
            FROM read_parquet('{sales_glob}', hive_partitioning=1, union_by_name=1)
            WHERE "Record Locator" IS NOT NULL{where_date}
            GROUP BY 1
        )
        SELECT rl, n_cust, gross FROM p
        WHERE n_cust > 1 OR n_exch > 0 OR n_kill > 0
        -- serviced-elsewhere first (rarest and most misleading if missed), then by money
        ORDER BY (n_cust > 1) DESC, gross DESC
    """).df()
    total = len(ranked)
    keep = ranked.head(cap)
    dropped = max(total - len(keep), 0)
    note = (f"EXCEPTION MODE — {total:,} booking(s) in {window} whose history is not a clean "
            f"single sale (serviced by more than one customer id, reissued, or "
            f"voided/refunded)")
    if dropped:
        note += (f"; showing the worst {len(keep):,} "
                 f"({dropped:,} not shown — raise max_pnrs to see them)")
    return sorted(str(v) for v in keep.rl), note, dropped


# ---------------------------------------------------------------------------------------
# data
# ---------------------------------------------------------------------------------------
def fetch_timeline(con, sales_glob: str, pnrs: list[str]) -> pd.DataFrame:
    """EVERY row on those PNRs — no customer filter, no date filter. That IS the airline lens.

    Deliberately unfiltered: the moment a customer id or a date window is applied here, the
    report can no longer show that somebody else cancelled the ticket, which is the single
    most useful thing it has to say.
    """
    return con.sql(f"""
        SELECT CAST("Record Locator" AS VARCHAR)                          AS pnr,
               CAST("PNR Zenith" AS VARCHAR)                              AS pnr_zenith,
               CAST("PNR GDS" AS VARCHAR)                                 AS pnr_gds,
               "Date"                                                     AS ts,
               "Date"::DATE                                               AS d,
               CAST("Transaction" AS VARCHAR)                             AS txn,
               regexp_replace(CAST("Customer ID" AS VARCHAR), '\\.0$', '') AS cid,
               CAST("Customer" AS VARCHAR)                                AS cust_name,
               CAST("Point of sales" AS VARCHAR)                          AS pos,
               CAST("Sale agent" AS VARCHAR)                              AS sale_agent,
               CAST("PNR Creator" AS VARCHAR)                             AS pnr_creator,
               CAST("Ticket number" AS VARCHAR)                           AS tkt,
               CAST("Original ticket number" AS VARCHAR)                  AS orig_tkt,
               CAST("Exchanged ticket number" AS VARCHAR)                 AS exch_tkt,
               CAST("Departure airport" AS VARCHAR)                       AS dep,
               CAST("Arrival airport" AS VARCHAR)                         AS arr,
               CAST("Exchanged Departure Airport" AS VARCHAR)             AS was_dep,
               CAST("Exchanged Arrival Airport" AS VARCHAR)               AS was_arr,
               "Flight date"::DATE                                        AS flight_date,
               "Exchanged Flight date"::DATE                              AS was_flight_date,
               CAST("Journey type" AS VARCHAR)                            AS journey,
               CAST("Heading" AS VARCHAR)                                 AS heading,
               CAST("Payment Type" AS VARCHAR)                            AS pay_type,
               CAST("Balance (base currency)" AS DOUBLE)                  AS bdt
        FROM read_parquet('{sales_glob}', hive_partitioning=1, union_by_name=1)
        WHERE CAST("Record Locator" AS VARCHAR) IN ({_sql_list(pnrs)})
        ORDER BY pnr, ts, tkt
    """).df()


def enrich(tl: pd.DataFrame, anchor: str | None) -> pd.DataFrame:
    """Derived columns both lenses need: passenger, route, seller, SELLER/OTHER tag."""
    tl = tl.copy()
    tl["cid"] = tl.cid.map(_norm_id)
    tl["passenger"] = tl.heading.map(_pax)
    tl["route"] = (tl.dep.fillna("") + ">" + tl.arr.fillna("")).str.strip(">")
    tl["was_route"] = (tl.was_dep.fillna("") + ">" + tl.was_arr.fillna("")).str.strip(">")
    # WHO IS "US"? With a customer, the anchor is that agency. Without one, the anchor is
    # whoever made the FIRST ticket sale on each PNR — the seller — so the SELLER/OTHER split
    # stays meaningful when the scope is a plain list of codes.
    if anchor:
        seller = {p: anchor for p in tl.pnr.unique()}
    else:
        sales = tl[tl.txn.isin(SALE_TXNS)].sort_values("ts")
        seller = sales.groupby("pnr").cid.first().to_dict()
    tl["seller_cid"] = tl.pnr.map(seller).fillna("")
    tl["lens"] = ["SELLER" if c and c == s else "OTHER" for c, s in zip(tl.cid, tl.seller_cid)]
    return tl


def summarise(tl: pd.DataFrame, dim: pd.DataFrame, today: date) -> pd.DataFrame:
    """One row per PNR with the agency figures and the airline figures side by side."""
    out = []
    for pnr, b in tl.groupby("pnr", sort=False):
        ours = b[b.lens == "SELLER"]
        sale_rows, kill_rows = b[b.txn.isin(SALE_TXNS)], b[b.txn.isin(KILL_TXNS)]
        tickets = {t for t in sale_rows.tkt if t and str(t).lower() != "nan"}
        killed = {t for t in kill_rows.tkt if t and str(t).lower() != "nan"}
        reissued = {t for t in b.exch_tkt if t and str(t).lower() != "nan"}
        pax = sorted({p for p in b.passenger if p})
        # DuckDB returns Timestamps; compare dates with dates (Timestamp < date raises).
        flights = [pd.Timestamp(f).date() for f in b.flight_date.dropna()]
        last_flight = max(flights) if flights else None
        live = tickets - killed
        out.append({
            "pnr": pnr,
            "pnr_zenith": _norm_id(b.pnr_zenith.iloc[0]),
            "pnr_gds": next((g for g in b.pnr_gds if g and str(g).lower() != "nan"), ""),
            "booked": b.d.min(), "last_action": b.d.max(),
            "seller_cid": b.seller_cid.iloc[0],
            "journey": next((j for j in b.journey if j and str(j).lower() != "nan"), ""),
            "routes": ", ".join(sorted({r for r in b.route if r and ">" in r}))[:60],
            "flight_date": last_flight,
            "pax_n": len(pax), "pax_names": ", ".join(pax)[:80],
            # ---- AGENCY LENS -------------------------------------------------------
            "our_rows": int(len(ours)),
            "our_tickets": len({t for t in ours[ours.txn.isin(SALE_TXNS)].tkt
                                if t and str(t).lower() != "nan"}),
            "our_net": float(ours.bdt.sum()),
            # ---- AIRLINE LENS ------------------------------------------------------
            "all_rows": int(len(b)),
            "tickets_issued": len(tickets), "tickets_killed": len(killed),
            "tickets_live": len(live),
            "reissues": int((b.txn == "Reissuance Adjustment").sum()),
            "penalty_bdt": float(b[b.txn == "Penalty"].bdt.sum()),
            "refund_bdt": float(b[b.txn.isin(("Refund", "Cancel refund"))].bdt.sum()),
            "void_bdt": float(b[b.txn == "Ticket void"].bdt.sum()),
            "net_airline": float(b.bdt.sum()),
            # ---- FLAGS -------------------------------------------------------------
            "other_hands": "YES" if (b.lens == "OTHER").any() else "",
            "n_customers": int(b.cid.nunique()), "n_pos": int(b.pos.nunique()),
            "changed": "YES" if reissued else "",
            "cancelled": "YES" if tickets and not live else "",
            # "no - cancelled" is only honest when tickets WERE issued and none survived. A
            # PNR with no ticket rows at all (a stray Commission/ACM row) is not a
            # cancellation — say so rather than print a verdict the data cannot support.
            "flown": ("" if last_flight is None else
                      "no - future" if last_flight >= today else
                      "YES" if live else
                      "no - cancelled" if tickets else "unknown - no ticket rows"),
        })
    s = pd.DataFrame(out)
    if len(s) and len(dim):
        s = s.merge(dim, left_on="seller_cid", right_on="cid", how="left").drop(columns=["cid"])
    for c in ("agent_name", "zone", "sales_person"):
        if c not in s.columns:
            s[c] = ""
    return s.sort_values(["other_hands", "booked", "pnr"], ascending=[False, True, True])


def ticket_chain(tl: pd.DataFrame) -> pd.DataFrame:
    """original ticket -> its replacement, who did it, and what it cost the passenger.

    Keyed off `Exchanged ticket number`, not `Transaction`: that field is set on the Penalty
    row as well as the Reissuance Adjustment row and is the more reliable change marker.
    """
    ch = tl[tl.exch_tkt.notna() & (tl.exch_tkt.astype(str).str.lower() != "nan")].copy()
    if not len(ch):
        return pd.DataFrame()
    ch["pen"] = ch.bdt.where(ch.txn == "Penalty", 0.0)   # penalty + adjustment arrive apart
    return (ch.groupby(["pnr", "exch_tkt", "tkt"], dropna=False)
              .agg(reissued_on=("d", "min"), by_cid=("cid", "first"), pos=("pos", "first"),
                   sale_agent=("sale_agent", "first"), passenger=("passenger", "first"),
                   route_after=("route", "first"), route_before=("was_route", "first"),
                   flight_after=("flight_date", "first"),
                   flight_before=("was_flight_date", "first"),
                   penalty=("pen", "sum"), adj=("bdt", "sum"))
              .reset_index()
              .rename(columns={"exch_tkt": "from_ticket", "tkt": "to_ticket"})
              .sort_values(["pnr", "reissued_on"]))


# ---------------------------------------------------------------------------------------
# workbook
# ---------------------------------------------------------------------------------------
def _title(ws, text: str, ncol: int) -> None:
    _c(ws, 1, 1, text, bold=True, fill=NAVY, color=WHITE, size=13)
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=ncol)
    ws.row_dimensions[1].height = 22


def _banner(ws, text: str, ncol: int, height: int = 44) -> None:
    _c(ws, 2, 1, text, wrap=True)
    ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=ncol)
    ws.row_dimensions[2].height = height


def _head(ws, r: int, heads: list[str]) -> None:
    for j, h in enumerate(heads, start=1):
        _c(ws, r, j, h, bold=True, fill=BLUE, color=WHITE, wrap=True)
    ws.row_dimensions[r].height = 30


def _write_summary(wb, s: pd.DataFrame, note: str) -> None:
    heads = ["PNR", "PNR Zenith", "GDS PNR", "Booked", "Last action",
             "Seller ID", "Seller (agency)", "Zone", "Sales Manager",
             "Journey", "Route(s)", "Flight date", "Pax", "Passenger(s)",
             "AGENCY: rows", "AGENCY: tickets", "AGENCY: net BDT",
             "AIRLINE: rows", "AIRLINE: tickets", "Cancelled tkts", "Live tkts",
             "Reissues", "Penalty BDT", "Refund BDT", "Void BDT", "AIRLINE: net BDT",
             "Other hands?", "# cust ids", "# POS", "Changed?", "Fully cancelled?", "Flown?"]
    ws = wb.create_sheet("PNR Summary")
    _title(ws, "PNR SUMMARY — what the agency sees vs what the airline sees", len(heads))
    _banner(ws, note + ".  AGENCY columns count only the seller's own rows — that is the "
                       "agency's own export. AIRLINE columns count every row on the booking, "
                       "whoever made it. Where they differ, somebody else touched the ticket: "
                       "those rows are flagged amber under 'Other hands?'. A red row is a "
                       "booking where every ticket issued was later voided or refunded.",
            len(heads))
    _head(ws, 3, heads)
    money, ints = {17, 23, 24, 25, 26}, {13, 15, 16, 18, 19, 20, 21, 22, 28, 29}
    r = 4
    for x in s.to_dict("records"):
        vals = [x["pnr"], x["pnr_zenith"], x["pnr_gds"], x["booked"], x["last_action"],
                x["seller_cid"], str(x.get("agent_name") or "")[:40], x.get("zone", ""),
                str(x.get("sales_person") or "")[:34], x["journey"], x["routes"],
                x["flight_date"], x["pax_n"], x["pax_names"],
                x["our_rows"], x["our_tickets"], x["our_net"],
                x["all_rows"], x["tickets_issued"], x["tickets_killed"], x["tickets_live"],
                x["reissues"], x["penalty_bdt"], x["refund_bdt"], x["void_bdt"],
                x["net_airline"], x["other_hands"], x["n_customers"], x["n_pos"],
                x["changed"], x["cancelled"], x["flown"]]
        red = x["cancelled"] == "YES"
        for j, v in enumerate(vals, start=1):
            fill = REDL if red else (AMBER if (x["other_hands"] == "YES" and j in (27, 28, 29))
                                     else None)
            _c(ws, r, j, v, fmt=FM if j in money else (FI if j in ints else None), fill=fill)
        r += 1
    ws.auto_filter.ref = f"A3:AF{max(r - 1, 3)}"
    ws.freeze_panes = "C4"
    _widths(ws, {"A": 11, "B": 12, "C": 10, "D": 11, "E": 11, "F": 12, "G": 34, "H": 10,
                 "I": 24, "J": 9, "K": 26, "L": 11, "M": 6, "N": 34})


def _write_timeline(wb, tl: pd.DataFrame) -> None:
    heads = ["PNR", "#", "Date", "Transaction", "Lens", "Customer ID", "Customer",
             "Point of sales", "Sale agent", "PNR creator", "Ticket number",
             "Original ticket", "Exchanged (from) ticket", "Route", "Flight date",
             "Passenger", "Payment", "Amount BDT"]
    ws = wb.create_sheet("PNR Timeline")
    _title(ws, "PNR TIMELINE — every transaction on the booking, whoever made it", len(heads))
    _banner(ws, "Rows tagged OTHER were NOT made by the agency that sold the ticket. They are "
                "exactly what an agency-only export cannot show — a void at a counter, a "
                "reissue by the call centre, a refund by another office. Amounts are "
                "\"Balance (base currency)\" signed as the source has them: sales positive, "
                "voids and refunds negative.", len(heads), 32)
    _head(ws, 3, heads)
    r, seq, cur = 4, 0, None
    for x in tl.to_dict("records"):
        if x["pnr"] != cur:
            cur, seq = x["pnr"], 0
        seq += 1
        vals = [x["pnr"], seq, x["ts"], x["txn"], x["lens"], x["cid"],
                str(x["cust_name"] or "")[:34], x["pos"], x["sale_agent"], x["pnr_creator"],
                x["tkt"], x["orig_tkt"], x["exch_tkt"], x["route"], x["flight_date"],
                x["passenger"], x["pay_type"], x["bdt"]]
        txn_fill = (REDL if x["txn"] in KILL_TXNS else
                    LILAC if x["txn"] in ("Reissuance Adjustment", "Penalty") else
                    GREENL if x["txn"] == "Ticket payment" else None)
        other = x["lens"] == "OTHER"
        for j, v in enumerate(vals, start=1):
            fill = txn_fill if j == 4 else (AMBER if (other and j in (5, 6, 7, 8)) else None)
            _c(ws, r, j, v, fmt=FM if j == 18 else None, fill=fill)
        r += 1
    ws.auto_filter.ref = f"A3:R{max(r - 1, 3)}"
    ws.freeze_panes = "C4"
    _widths(ws, {"A": 11, "B": 4, "C": 18, "D": 21, "E": 8, "F": 12, "G": 30, "H": 22,
                 "I": 14, "J": 14, "K": 16, "L": 16, "M": 18, "N": 11, "O": 11, "P": 26,
                 "Q": 14, "R": 14})


def _write_chain(wb, ch: pd.DataFrame) -> None:
    heads = ["PNR", "From ticket", "To ticket", "Reissued on", "By customer", "Point of sales",
             "Sale agent", "Passenger", "Route before", "Route after",
             "Flight before", "Flight after", "Penalty BDT", "Adjustment BDT"]
    ws = wb.create_sheet("Ticket Chain")
    _title(ws, "TICKET CHAIN — a reissue REPLACES a ticket, it does not edit one", len(heads))
    _banner(ws, "Follow a passenger across a change with Original ticket number -> Ticket "
                "number. 'Route before' / 'Flight before' come from the Exchanged* columns, "
                "which the source fills on well under half of change rows — blank there means "
                "the source did not say, NOT that nothing changed.", len(heads), 32)
    _head(ws, 3, heads)
    r = 4
    for x in ch.to_dict("records"):
        vals = [x["pnr"], x["from_ticket"], x["to_ticket"], x["reissued_on"], x["by_cid"],
                x["pos"], x["sale_agent"], x["passenger"], x["route_before"],
                x["route_after"], x["flight_before"], x["flight_after"],
                x["penalty"], x["adj"]]
        for j, v in enumerate(vals, start=1):
            _c(ws, r, j, v, fmt=FM if j in (13, 14) else None)
        r += 1
    if r == 4:
        _c(ws, 4, 1, "No reissues on the bookings in this run.")
    ws.auto_filter.ref = f"A3:N{max(r - 1, 3)}"
    _widths(ws, {"A": 11, "B": 16, "C": 16, "D": 12, "E": 12, "F": 22, "G": 14, "H": 26,
                 "I": 13, "J": 13, "K": 12, "L": 12, "M": 13, "N": 14})


def _write_notes(wb, note: str, stats: dict, dropped: int) -> None:
    ws = wb.create_sheet("Notes")
    _title(ws, "HOW TO READ THIS", 2)
    lines = [
        ("Scope", note),
        ("", ""),
        ("AGENCY lens", "Only rows carrying the seller's Customer ID. This is what the agency's "
                        "own sale-details export shows and what it is paid on. It is true, and "
                        "it is partial."),
        ("AIRLINE lens", "Every row on the PNR, whoever made it. A ticket sold by an agency can "
                         "be voided, reissued or refunded later by a counter, the call centre, "
                         "BO-1 Central Reservation, or a different agency. Those rows carry a "
                         "different Customer ID and never appear in the agency's own export."),
        ("Why it matters", "Answering an agency's question from the agency lens is how you tell "
                           "them a ticket is live when it may already be cancelled."),
        ("", ""),
        ("Other hands?", "YES = at least one transaction was made by someone other than the "
                         "seller. Read those before replying to the agency."),
        ("Changed?", "YES = at least one ticket was reissued. See Ticket Chain — the "
                     "passenger's history spans more than one ticket number."),
        ("Fully cancelled?", "Every ticket issued was later voided or refunded (row shaded red)."),
        ("Flown?", "A judgement, NOT a source field: last flight date is past AND at least one "
                   "ticket is still live. Never treat it as money."),
        ("", ""),
        ("PNR fields", "Record Locator (098I2V) is the code everyone quotes and the key here. "
                       "PNR Zenith is its numeric twin. PNR GDS is the GDS's own locator and is "
                       "blank for EXTRANET/WEB bookings."),
        ("Date column", "Scoped on \"Date\". \"Pure Date\" is only ~25% populated in curated and "
                        "silently halves any window."),
        ("Money", "\"Balance (base currency)\" in BDT, signed as the source has it. The AIRLINE "
                  "net is their sum. It is NOT the DSR net — the DSR also nets out commission."),
        ("", ""),
        ("Counts this run", " · ".join(f"{k}: {v:,}" for k, v in stats.items())),
    ]
    if dropped:
        lines.append(("NOT SHOWN", f"{dropped:,} further exception booking(s) matched but were "
                                   f"outside the cap. This sheet is a worst-first sample, not "
                                   f"the whole set — raise max_pnrs to widen it."))
    r = 3
    for k, v in lines:
        _c(ws, r, 1, k, bold=True, color=NAVY)
        _c(ws, r, 2, v, wrap=True)
        ws.row_dimensions[r].height = 30 if len(str(v)) > 90 else 15
        r += 1
    _widths(ws, {"A": 18, "B": 108})


def _save_locktolerant(wb, path: Path) -> Path:
    """Save; if the file is open in Excel, fall back to a '__new' sibling rather than fail."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        wb.save(path)
        return path
    except PermissionError:
        for i in range(1, 50):
            alt = path.with_name(f"{path.stem}__new{'' if i == 1 else i}{path.suffix}")
            try:
                wb.save(alt)
                return alt
            except PermissionError:
                continue
        raise


# ---------------------------------------------------------------------------------------
def generate(params: dict | None = None, cfg: Config | None = None) -> Path:
    params = params or {}
    cfg = cfg or load_config(validate=True)
    sales_glob = (cfg.data_root / "curated" / "sales" / "**" / "*.parquet").as_posix()

    with duckdb.connect() as con:
        pnrs, note, dropped = resolve_pnrs(con, sales_glob, params)
        if not pnrs:
            raise RuntimeError("no PNRs in scope — nothing to build")
        tl = enrich(fetch_timeline(con, sales_glob, pnrs), _norm_id(params.get("customer")))

    if not len(tl):
        raise RuntimeError("those PNRs are not in the sales data")

    # dim_customer is optional: it ships with the Data Kit, and the report is still correct
    # without it (the seller shows as an id rather than a name).
    dim = pd.DataFrame()
    dimf = cfg.data_root / "curated" / "dim_customer" / "dim_customer.parquet"
    if dimf.is_file():
        try:
            dim = pd.read_parquet(dimf, columns=["customer_id", "customer_name", "zone",
                                                 "sales_person"])
            dim["cid"] = dim.customer_id.map(_norm_id)
            dim = (dim.rename(columns={"customer_name": "agent_name"})
                      [["cid", "agent_name", "zone", "sales_person"]].drop_duplicates("cid"))
        except Exception:                     # a partial Data Kit must not fail the report
            dim = pd.DataFrame()

    s = summarise(tl, dim, date.today())
    ch = ticket_chain(tl)
    stats = {
        "PNRs": len(s), "transactions": len(tl),
        "tickets issued": int(s.tickets_issued.sum()),
        "tickets cancelled": int(s.tickets_killed.sum()),
        "PNRs touched by someone other than the seller": int((s.other_hands == "YES").sum()),
        "PNRs with a reissue": int((s.changed == "YES").sum()),
        "PNRs fully cancelled": int((s.cancelled == "YES").sum()),
    }

    wb = Workbook()
    wb.remove(wb.active)
    _write_summary(wb, s, note)
    _write_timeline(wb, tl)
    if len(ch):
        _write_chain(wb, ch)
    _write_notes(wb, note, stats, dropped)

    out_dir = Path(params.get("out_dir") or cfg.output_dir)
    tag = _norm_id(params.get("customer")) or ("list" if params.get("pnrs") else "exceptions")
    stamp = datetime.now().strftime("%Y%m%d_%H%M")
    return _save_locktolerant(wb, out_dir / f"PNR_History_{tag}_{stamp}.xlsx")
