"""
reporting.builders.visit_tracking — turn the per-salesperson "Daily Agency Visit Report"
workbook into one tracking report and tie it to actual agency sales from the gold.

INPUT: the visit workbook (one sheet per sales rep; each sheet has a header block then rows of
       Date | Sl | Name of Agent | Contact | Designation | Contact No | Location | Productivity |
       Most Selling Route). Column positions are detected from each sheet's own header row —
       the sheets are NOT uniform. `params["source"]` selects the workbook; when omitted the
       newest "Daily Agency Visit Report*.xlsx" in ~/Downloads is used (the analyst drops the
       fresh export there before the morning publish run).
OUTPUT (cfg.output_dir): Agency_Visit_Tracking_<MonYYYY>.xlsx with sheets:
   Summary · Day-wise · By Salesperson · Rep x Day · Rep Agency Detail ·
   Top 15 Domestic · Top 15 International · Data Quality · Visit Log.

Top-15 agents are ranked by 2026-YTD net sales per SECTOR from the gold (BD agencies), then
matched to the visit log by a NORMALISED-name fuzzy match (see _match for the rules — each one
fixes a real false-positive/-negative found in the Jun-2026 audit). The matched names are shown
in the sheet for eyeball verification, and every parser correction lands on the Data Quality
sheet so the numbers stay auditable.

Public entry point: ``generate(params, cfg) -> Path``.
CLI wrapper: ``scripts/_build_visit_tracking_report.py ["path\\to\\visit.xlsx"]``.
"""
from __future__ import annotations

import re
import sys
from difflib import SequenceMatcher
from pathlib import Path

import duckdb
import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from ..config import Config, load_config

DOWNLOADS = Path.home() / "Downloads"
RANK_START = "2026-01-01"          # rank top agents by 2026-YTD sales
CR = 1e7

NAVY, WHITE, GREEN, RED = "1F3864", "FFFFFF", "C6EFCE", "FFC7CE"
AMBER = "FFF2CC"          # "look at this", not "this is wrong" - used for duplicate rep names
BORDER = Border(*[Side(style="thin", color="D9D9D9")] * 4)
# generic words dropped before name matching (keep the distinctive token(s))
GEN = set("LTD LIMITED PVT TOURS TOUR TRAVELS TRAVEL AIR INTERNATIONAL INTL AND OVERSEAS AVIATION "
          "SERVICES SERVICE HOLIDAYS COM BEST4FLY TRADING ENTERPRISE AGENCY TICKETING CORPORATION "
          "CO THE NON IATA COMPANY TOURISM LLC".split())
# Gulf sheets prefix agency names with the station country (AE Akbar..., OM Akbar...) — the same
# brand's Dubai and Muscat branches are DIFFERENT agencies, so a prefix mismatch vetoes the match
_CTRY_PFX = {"AE", "OM", "SA", "QA", "KW", "BH", "MY", "SG"}


def _norm(s) -> str:
    toks = [t for t in re.sub(r"[^A-Z0-9 ]", " ", str(s).upper()).split() if t and t not in GEN]
    # collapse initialism runs so 'T.A. Air Service' ('T','A') meets 'Ta Air' ('TA') as one token
    out: list[str] = []
    buf: list[str] = []
    for t in toks:
        if len(t) == 1:
            buf.append(t)
        else:
            if buf:
                out.append("".join(buf)); buf = []
            out.append(t)
    if buf:
        out.append("".join(buf))
    return " ".join(out)


# legal-suffix tokens stripped off the END of the full form (keeps generic words like AIR/TOURS
# so all-generic names — e.g. "International Travel Corporation" — still have something to match on)
_SUFFIX = {"LTD", "LIMITED", "PVT", "CO", "COMPANY", "IATA", "NON", "LLC"}


def _fullform(s) -> str:
    """Cleaned FULL name (generic words kept, trailing legal suffixes dropped)."""
    toks = re.sub(r"[^A-Z0-9 ]", " ", str(s).upper()).split()
    while toks and toks[-1] in _SUFFIX:
        toks.pop()
    return " ".join(toks)


def _vowel_typo(a: str, b: str) -> bool:
    """Same-length strings whose (1-2) differing characters are ALL vowels — the classic
    Bangla-name transliteration wobble (Shapon/Shopon), never a different brand."""
    if len(a) != len(b) or a == b:
        return False
    diffs = [(x, y) for x, y in zip(a, b) if x != y]
    return len(diffs) <= 2 and all(x in "AEIOU" and y in "AEIOU" for x, y in diffs)


def _match(target: str, vmap: dict) -> list[str]:
    """Visit-agent names matching `target`. vmap: raw name -> (_norm, _fullform).

    Rules (each fixes a real failure seen in the Jun-2026 audits):
      - norm equality: a SINGLE-token norm additionally needs full-name ratio>=0.75 OR a
        compact-fullform prefix ('TA AIR' <-> 'T.A. Air Service'), else 'The Star Travels'
        swallows Star Holidays / Air Star Travel (all norm to 'STAR').
      - 2+-token subset either way (Be Fresh Ltd <-> BE FRESH LIMITED).
      - norm ratio>=0.86 only when both norms are >=6 chars — 4-letter norms false-matched
        SUMA to SURMA Overseas (0.89). A 0.80-0.86 score still passes when the two norms
        differ ONLY in vowels (Shapon/Shopon = typo, 0.833) — consonant changes are a
        different name (Shapon vs ShaWon), vowel swaps are how these names get mistyped.
      - lead-initialism veto: when both norms START with a <=2-letter initialism they must
        agree — 'M A World' is not 'SM World' (collapsing initialisms made them 0.875-close).
      - compact prefix, VISIT-side only (>=6 chars): 'BdFare' abbreviates BDFAREBANGLADESH.
        The reverse direction is banned: a LONGER log name extending the target's stem is a
        different agency ('Jashore Exclusive' is not 'Jashore Air ...'; extra brand tokens
        distinguish, abbreviations don't).
      - all-generic fallback: when the norm is EMPTY (International Travel Corporation) match
        on the full form instead — equality / containment / ratio>=0.9.
    """
    tn, tf = _norm(target), _fullform(target)
    ts = set(tn.split())
    tc = tn.replace(" ", "")
    tfc = tf.replace(" ", "")
    t_pfx = tf.split()[0] if tf and tf.split()[0] in _CTRY_PFX else None
    out = []
    for raw, (an, af) in vmap.items():
        a = set(an.split())
        ac = an.replace(" ", "")
        afc = af.replace(" ", "")
        a_pfx = af.split()[0] if af and af.split()[0] in _CTRY_PFX else None
        if t_pfx and a_pfx and t_pfx != a_pfx:           # AE Akbar != OM Akbar (branch veto)
            continue
        t0 = tn.split()[0] if tn else ""
        a0 = an.split()[0] if an else ""
        if t0 and a0 and len(t0) <= 2 and len(a0) <= 2 and t0 != a0:
            continue                                     # initialism brands must agree (MA != SM)
        if not ts:                                       # all-generic target name
            if tf and af and (tf == af or tf in af or af in tf
                              or SequenceMatcher(None, tf, af).ratio() >= 0.9):
                out.append(raw)
            continue
        if not a:
            continue
        ok = False
        if tn == an:
            ok = (len(ts) >= 2 or SequenceMatcher(None, tf, af).ratio() >= 0.75
                  or (min(len(tfc), len(afc)) >= 4
                      and (tfc.startswith(afc) or afc.startswith(tfc))))
        if not ok and ((ts <= a and len(ts) >= 2) or (a <= ts and len(a) >= 2)):
            ok = True
        if not ok and min(len(tn), len(an)) >= 6:
            sim = SequenceMatcher(None, tn, an).ratio()
            ok = sim >= 0.86 or (sim >= 0.80 and _vowel_typo(tn, an))
        if not ok and min(len(tc), len(ac)) >= 6 and _vowel_typo(tc, ac):
            ok = True                                    # compact vowel typo (Shapon/Shopon one-worded)
        if not ok and min(len(tc), len(ac)) >= 6 and tc.startswith(ac):
            ok = True
        if ok:
            out.append(raw)
    return out


def _rep_name(raw, fallback: str) -> str:
    """The rep's real name from the 'Name:' label in the sheet header block; else the sheet name."""
    for _, hr in raw.head(5).iterrows():
        cells = hr.tolist()
        for k, cv in enumerate(cells):
            if isinstance(cv, str) and cv.strip().lower().startswith("name") and ":" in cv and "agent" not in cv.lower():
                after = cv.split(":", 1)[1].strip()
                if after:
                    return after
                for nx in cells[k + 1:]:
                    if isinstance(nx, str) and nx.strip():
                        return nx.strip()
    return fallback


# A rep sheet is a STACK OF DAY-BLOCKS, not one table. Each block has its own header row, and a
# block is either an AGENCY visit list ("Name of Agent") or a CORPORATE one ("Name of Corporate"),
# which carry different columns. 17 of the 33 July sheets contain both kinds.
AGENT_HDRS = ("name of agent", "name of corporate")


def _col_map(raw) -> dict | None:
    """First block's column map. Kept for callers that only need "does this sheet have a table".

    See _blocks() for the real parse. This used to be the WHOLE parser, which is why seven reps
    reported zero visits in July: it scanned only the first 8 rows and applied that one header's
    column positions to every row on the sheet.
    """
    b = _blocks(raw)
    return b[0] if b else None


def _header_cols(row) -> dict | None:
    """Column map from a header row, or None if this row is not a header."""
    cells = {j: str(v).strip().lower() for j, v in enumerate(row.tolist()) if isinstance(v, str)}
    agent = next((j for j, v in cells.items() if v in AGENT_HDRS), None)
    if agent is None:
        return None
    kind = "corporate" if cells[agent] == "name of corporate" else "agency"

    def find(*needles, exact=False):
        for j, v in cells.items():
            if (v in needles) if exact else any(n in v for n in needles):
                return j
        return None

    return {"agent": agent, "kind": kind,
            "date": find("date", exact=True),
            "location": find("location", exact=True),
            # 'Most Selling Route' / 'Most selling routes' / 'Discussion' vary by rep
            "route": find("route"),
            # captured so the NORMALISED workbook is a true replacement for the source,
            # not a subset of it. Header wording varies per rep, hence substring matching.
            "contact": find("contact person"),
            "designation": find("designation"),
            "phone": find("contact no", "mobile", "phone"),
            "productivity": find("productivity", "monthly sale"),
            "remarks": find("remark", "discussion", "comment")}


def _blocks(raw) -> list[dict]:
    """Every day-block on a sheet, in order: its header row, kind and column map.

    Scans EVERY row, not the first eight. One rep (MAUNG) puts a "Flight Disruption" note above
    the first table, which pushed the header past row 8 and made the whole sheet invisible.
    """
    out = []
    for idx, r in raw.iterrows():
        cm = _header_cols(r)
        if cm:
            cm["hdr_row"] = idx
            out.append(cm)
    return out


def _block_date(raw, hdr_row: int, month, sheet: str, notes: list | None) -> "pd.Timestamp":
    """The date belonging to the block whose header is at `hdr_row`.

    Looked for in the few rows ABOVE the header, in two forms, because reps write it both ways:
      labelled   'Date & Day:'  <value>      (most sheets)
      bare       just the date in a cell     (SUBHAJIT, rathin -- no label at all)
    The labelled form wins when both are present. Searching upward from the header is what makes
    this work per block rather than per sheet.
    """
    for i in range(hdr_row - 1, max(hdr_row - 6, -1), -1):
        vals = raw.iloc[i].tolist()
        for k, v in enumerate(vals):
            if isinstance(v, str) and "date" in v.lower() and "day" in v.lower():
                nxt = next((x for x in vals[k + 1:] if pd.notna(x) and str(x).strip()), None)
                if nxt is not None:
                    d = _clean_dates(pd.Series([nxt]), month, sheet, notes).iloc[0]
                    if pd.notna(d):
                        return d
    # Bare date, no label. BOTH real datetimes AND date-like TEXT, because the two forms appear
    # in the SAME column of the same sheet: a rep typing D/M gets a real date up to the 12th
    # (Excel reads 8/7 as August-7) and then TEXT from the 13th on, since 13 is not a valid
    # month. Accepting only datetimes therefore dated the first third of the month and silently
    # dropped the rest -- 9 of rathin's 14 blocks, 71 visits.
    for i in range(hdr_row - 1, max(hdr_row - 6, -1), -1):
        for v in raw.iloc[i].tolist():
            if isinstance(v, (pd.Timestamp,)) or type(v).__name__ == "datetime":
                return _clean_dates(pd.Series([v]), month, sheet, notes).iloc[0]
            if isinstance(v, str) and _DATE_TEXT.match(v.strip()):
                d = _clean_dates(pd.Series([v]), month, sheet, notes).iloc[0]
                if pd.notna(d):
                    return d
    return pd.NaT


def _clean_dates(col: pd.Series, month: pd.Timestamp, sheet: str = "", notes: list | None = None) -> pd.Series:
    """Parse a Date column defensively, forcing everything into the report month.

    Real-world junk this absorbs: Sl. integers (pd would read them as 1970 epoch dates),
    day-range strings like '23-28jun' (take the first day), and wrong-month typos like
    2026-01-25 in a June book (keep the day, remap the month). Anything else -> NaT.
    Every correction is appended to `notes` so the report can show its work (DQ sheet).
    """
    out = []
    for v in col:
        d = pd.NaT
        if isinstance(v, (pd.Timestamp,)) or type(v).__name__ == "datetime":
            d = pd.Timestamp(v)
        elif isinstance(v, str):
            # Reps append the weekday to the date: '01/07/2026   (Wednesday)', '01/07/2026 (Wed)'.
            # pandas cannot parse that and returned NaT, which silently emptied two whole sheets.
            v = re.sub(r"\s*\([^)]*\)\s*$", "", v).strip()
            m = re.match(r"\s*(\d{1,2})\s*[-–]", v)          # '23-28jun' day-range banner
            if m:
                d = month.replace(day=int(m.group(1)))
                if notes is not None:
                    notes.append({"sheet": sheet, "issue": "day-range banner",
                                  "detail": f"'{v}' -> all its visits attributed to {d:%b %d}"})
            else:
                d = pd.to_datetime(v, errors="coerce", dayfirst=True)
                if pd.isna(d):
                    # Reps append the weekday or the month name to the value itself:
                    # '05 July 2026 & Sunday', '13/07/2026 - July'. pandas rejects the whole
                    # string, so pull the date OUT of it rather than parsing around it.
                    m2 = (re.search(r"\d{1,2}\s*[/.\-]\s*\d{1,2}\s*[/.\-]\s*\d{2,4}", v)
                          or re.search(r"\d{1,2}\s+[A-Za-z]{3,9}\s+\d{2,4}", v)
                          or re.search(r"[A-Za-z]{3,9}\s+\d{1,2},?\s+\d{4}", v))
                    if m2:
                        d = pd.to_datetime(m2.group(0), errors="coerce", dayfirst=True)
        # DAY/MONTH SWAPPED BY EXCEL. A rep typing 1/7, 2/7, 6/7 (D/M, July) on a machine set to
        # M/D gets 2026-01-07, 2026-02-07, 2026-06-07 stored instead. The fingerprint is that the
        # DAY field equals the report-month number while the MONTH field walks: 7 stays put and
        # 1,2,6,8,11 move. It is confirmed by the next entry in the same sheet, 13/7/2026, which
        # Excel left as TEXT precisely because 13 is not a valid month.
        # Treating this as an ordinary wrong-month typo collapsed a rep's whole month onto the
        # 7th; swapping the fields restores 1, 2, 6, 8 and 11 July.
        if (pd.notna(d) and d.day == month.month
                and (d.year, d.month) != (month.year, month.month)):
            try:
                swapped = month.replace(day=d.month)
                if notes is not None:
                    notes.append({"sheet": sheet, "issue": "day/month swapped by Excel",
                                  "detail": f"{d:%Y-%m-%d} read as {swapped:%Y-%m-%d} "
                                            f"(D/M typed, M/D stored)"})
                out.append(swapped)
                continue
            except ValueError:
                pass
        if pd.notna(d) and (d.year, d.month) != (month.year, month.month):
            try:                                              # wrong-month typo: trust the day
                fixed = month.replace(day=d.day)
                if notes is not None:
                    notes.append({"sheet": sheet, "issue": "wrong-month date remapped",
                                  "detail": f"{d:%Y-%m-%d} -> {fixed:%Y-%m-%d}"})
                d = fixed
            except ValueError:
                d = pd.NaT
        out.append(d)
    return pd.Series(out, index=col.index)


def _banner_dates(raw, month: pd.Timestamp, sheet: str = "", notes: list | None = None) -> pd.Series:
    """Per-row dates from 'Date & Day:' block banners (sheets with no Date column)."""
    marks = pd.Series(pd.NaT, index=raw.index)
    for idx, r in raw.iterrows():
        vals = r.tolist()
        for k, v in enumerate(vals):
            if isinstance(v, str) and "date & day" in v.lower():
                nxt = next((x for x in vals[k + 1:] if pd.notna(x) and str(x).strip()), None)
                if nxt is not None:
                    marks.loc[idx] = _clean_dates(pd.Series([nxt]), month, sheet, notes).iloc[0]
                break
    return marks.ffill()


def parse_visits(path: Path) -> pd.DataFrame:
    """One row per visit across all rep sheets.

    The visit Date is written only on the FIRST row of each day-block; the agencies listed below it
    (blank Date, incrementing Sl.) belong to the SAME day. So we forward-fill the date down each
    sheet, then take every row that has a real agency name. (Requiring a date per row — the naive
    read — drops ~90% of the visits.) Column positions come from each sheet's own header row, and
    all dates are coerced into the report month (see _clean_dates for the junk this absorbs).
    """
    import warnings as _w
    _w.filterwarnings("ignore", category=UserWarning)
    allsh = pd.read_excel(path, sheet_name=None, header=None)   # one parse, all sheets

    # report month = the calendar month the workbook is about, taken as the mode over every
    # cell that is ALREADY a real datetime (typed cells can't be Sl. numbers or typo strings)
    stamps = [v for raw in allsh.values() for col in raw.columns
              for v in raw[col] if isinstance(v, pd.Timestamp) or type(v).__name__ == "datetime"]
    per = pd.Series([pd.Timestamp(t).to_period("M") for t in stamps])
    month = per.mode().iloc[0].to_timestamp() if len(per) else pd.Timestamp.today().replace(day=1)

    HDR = {"name of agent", "name of corporate", "date", ""}
    SKIP = ("daily agency", "daily sales", "daily corporate", "name of agent",
            "name of corporate")
    rows, roster, notes = [], [], []
    for sh, raw in allsh.items():
        if str(sh).strip().lower() in ("sheet1", "template", "sheet"):
            continue                   # the workbook's blank template tab, not a rep
        blocks = _blocks(raw)
        if not blocks:                # empty / template sheet — no visit table at all
            roster.append({"salesperson": sh, "rep_name": sh, "has_table": False,
                           "zone": _rep_zone(raw)})
            notes.append({"sheet": sh, "issue": "no visit table",
                          "detail": "sheet is empty or has no 'Name of Agent' / "
                                    "'Name of Corporate' header"})
            continue
        rep = _rep_name(raw, sh)
        zone = _rep_zone(raw)                    # from the sheet banner; may be None
        roster.append({"salesperson": sh, "rep_name": rep, "has_table": True, "zone": zone})
        undated = 0
        # Each block owns the rows between its header and the next block's header, and its OWN
        # column map. Applying one sheet-wide map was what hid every corporate block and every
        # rep whose layout shifted part-way down the sheet.
        for bi, cmap in enumerate(blocks):
            end = blocks[bi + 1]["hdr_row"] if bi + 1 < len(blocks) else len(raw) + 1
            if cmap["date"] is not None:                      # per-row Date column
                col = raw[cmap["date"]].loc[cmap["hdr_row"] + 1:end - 1]
                dates = _clean_dates(col, month, sh, notes).ffill()
            else:                                             # one date for the whole block
                dates = None
                bd = _block_date(raw, cmap["hdr_row"], month, sh, notes)
            for idx in range(cmap["hdr_row"] + 1, min(end, len(raw))):
                r = raw.iloc[idx]
                a = r.get(cmap["agent"])
                if not isinstance(a, str):
                    continue
                an = a.strip()
                if not an or an.lower() in HDR or an.lower().startswith(SKIP):
                    continue
                d = dates.loc[idx] if dates is not None else bd
                if pd.isna(d):
                    undated += 1
                    continue
                def col(key):
                    j = cmap.get(key)
                    v = r.get(j) if j is not None else None
                    return None if (v is None or (isinstance(v, float) and pd.isna(v))) else v

                rows.append({
                    "salesperson": sh, "rep_name": rep, "date": d.date(), "agent": an,
                    "visit_type": cmap["kind"], "zone": zone,
                    "location": col("location"), "route": col("route"),
                    "contact": col("contact"), "designation": col("designation"),
                    "phone": col("phone"), "productivity": col("productivity"),
                    "remarks": col("remarks")})
        if undated:
            # Real fieldwork that cannot be placed on a day. Reported, not silently dropped:
            # the rep has to add dates to their sheet before it can be counted.
            notes.append({"sheet": sh, "issue": "visits with no date",
                          "detail": f"{undated} row(s) have an agency name but no date anywhere "
                                    f"in their block — not counted; the rep must date the blocks"})
    return pd.DataFrame(rows), pd.DataFrame(roster), notes


def _cell(ws, row, col, val, *, bold=False, size=10, color=None, fill=None, align="center", fmt=None, wrap=False):
    c = ws.cell(row, col, val)
    c.font = Font(bold=bold, size=size, color=color or "000000")
    c.alignment = Alignment(horizontal=align, vertical="center", wrap_text=wrap)
    c.border = BORDER
    if fill:
        c.fill = PatternFill("solid", fgColor=fill)
    if fmt:
        c.number_format = fmt
    return c


def _headers(ws, row, heads, widths):
    for j, (h, w) in enumerate(zip(heads, widths), 1):
        _cell(ws, row, j, h, bold=True, color=WHITE, fill=NAVY, size=9, wrap=True)
        ws.column_dimensions[get_column_letter(j)].width = w
    ws.row_dimensions[row].height = 26


# tokens dropped when reducing a name to its compact BRAND key for the sibling merge.
# COMPACT (spaces removed) so 'GoZayaan LTD' and 'Go Zayaan Limited (Non IATA)' group.
_KEY_DROP = {"IATA", "NON", "LTD", "LIMITED", "PVT", "CO", "COMPANY", "LLC", "THE", "MERGED"}

# CANONICAL cross-zone merges (customer-id -> key). Name matching handles same-zone siblings,
# but these brands run accounts in DIFFERENT zones, so zone-scoped sheets need an explicit
# pairing; the merged row lands in the DOMINANT (higher-net) account's zone/KAM block.
CANON_MERGE = {"10502007": "GOZAYAAN", "12084060": "GOZAYAAN"}
CANON_NAME = {"GOZAYAAN": "Go Zayaan Limited (merged)"}


def _row_cids(row) -> list:
    """Member customer-IDs behind a row (survives repeated merge passes)."""
    v = row["cids"] if "cids" in row.index else None
    return v if isinstance(v, list) else [row.cid]


def _brand_key(nm) -> str:
    toks = re.sub(r"[^A-Z0-9 ]", " ", str(nm).upper()).split()
    return "".join(t for t in toks if t not in _KEY_DROP)


def _merge_siblings(df: pd.DataFrame, num_cols: list[str], gate_station: bool = True) -> pd.DataFrame:
    """Fold same-brand sibling accounts (IATA + Non-IATA) into one row.

    Same rules as the Top-Agents workbook: compact brand key, and (optionally) at most one
    distinct non-null Station — 'Al Amin' DAC vs BZL are different agencies in different
    cities. Keeps a `cids` list of member IDs (MOCAT lookups test every member).
    Sums must be exact: a booking lives in exactly one account.
    """
    df = df.copy()
    df["bkey"] = df.nm.map(_brand_key)
    out = []
    for _, g in df.groupby("bkey", sort=False):
        if len(g) == 1 or (gate_station and "stn" in g and g.stn.dropna().nunique() > 1):
            for _, row in g.iterrows():
                row = row.copy(); row["cids"] = _row_cids(row)
                out.append(row)
            continue
        dom = g.loc[g[num_cols[0]].fillna(0).idxmax()].copy()
        for c in num_cols:
            dom[c] = g[c].fillna(0).sum()
        dom["cids"] = [c for _, m in g.iterrows() for c in _row_cids(m)]
        base = str(dom.cid).split(" ")[0]              # dominant id, minus any earlier "(+n)" tag
        dom["cid"] = f"{base} (+{len(dom['cids']) - 1})" if len(dom["cids"]) > 1 else dom.cid
        if "(merged)" not in str(dom.nm):
            dom["nm"] = f"{dom.nm} (merged)"
        out.append(dom)
    return pd.DataFrame(out).drop(columns="bkey").reset_index(drop=True)


# ---- rank sources -----------------------------------------------------------------
# On the ANALYST machine the rankings come from gold. On a colleague's machine (the
# exe's Instant Reports) there is no gold and never will be — so the Data Kit ships
# small PRE-COMPUTED rank packs built from gold by build_rank_packs() at publish time.
# Both paths produce the SAME frame shape; every python-side step (name filters,
# sibling merges, ranking) is shared, so the two modes cannot drift.
RANK_AGENCY_PACK = "reference/visit_rank_agency.parquet"
RANK_KAMZONE_PACK = "reference/visit_rank_kamzone.parquet"
MOCAT_PACK = "reference/mocat_ids.parquet"


def _agency_sql(GOLD: str) -> str:
    return f"""
        WITH a AS (
          SELECT regexp_replace(CAST("Customer ID" AS VARCHAR), '[.]0+$', '') cid, ANY_VALUE("Customer") nm,
                 SUM("Balance (base currency)") FILTER (WHERE "sector"='Domestic')/{CR}      dom_cr,
                 SUM("Balance (base currency)") FILTER (WHERE "sector"='International')/{CR}  intl_cr,
                 MAX("Agency Country") ctry, MODE("Station") stn
          FROM {GOLD} WHERE "Channel"='AGENCY' AND "Pure Date" >= DATE '{RANK_START}' GROUP BY 1)
        SELECT cid, nm, dom_cr, intl_cr, stn FROM a WHERE (ctry IS NULL OR upper(ctry)='BANGLADESH')
    """


def _kamzone_sql(GOLD: str) -> str:
    return f"""
        SELECT "Sales Person" kam, "Zone" zn,
               regexp_replace(CAST("Customer ID" AS VARCHAR), '[.]0+$', '') cid,
               ANY_VALUE("Customer") nm,
               SUM("Balance (base currency)")/1e5 ytd_lac,
               SUM("Balance (base currency)") FILTER (
                   WHERE date_trunc('month',"Pure Date")=(SELECT date_trunc('month',max("Pure Date")) FROM {GOLD})
               )/1e5 mon_lac
        FROM {GOLD}
        WHERE "Channel"='AGENCY' AND "Pure Date" >= DATE '{RANK_START}'
          AND "Sales Person" IS NOT NULL AND "Zone" IS NOT NULL
          AND ("Customer" IS NULL OR "Customer" NOT ILIKE 'CORP %')
          AND ("Customer" IS NOT NULL AND NOT regexp_matches(lower("Customer"),
               'gds|galileo|sabre|abacus|travelsky|extranet|autogen| web|mobiapp|counter'))
        GROUP BY 1,2,3
    """


def _fetch_or_pack(con, cfg: Config, sql: str, pack_rel: str) -> pd.DataFrame:
    """Gold when this machine has it; the Data-Kit rank pack otherwise."""
    if (cfg.data_root / "gold" / "sales_bi.parquet").is_file():
        return con.execute(sql).df()
    pack = cfg.data_root / pack_rel
    if not pack.is_file():
        raise FileNotFoundError(
            f"no gold data and no rank pack ({pack_rel}) — refresh the Data Kit on the "
            f"share (publish_reports data_kit) and re-assemble.")
    return con.execute(f"SELECT * FROM read_parquet('{pack.as_posix()}')").df()


def build_rank_packs(cfg: Config | None = None) -> list[Path]:
    """ANALYST-side: materialise the rank packs + MOCAT ids for the Data Kit.

    Called by the data_kit builder on every publish, so colleague machines rank
    against yesterday's gold even though they only upload a few days of sales.
    """
    import duckdb as _duck
    cfg = cfg or load_config(validate=True)
    GOLD = f"read_parquet('{(cfg.data_root / 'gold' / 'sales_bi.parquet').as_posix()}')"
    con = _duck.connect()
    out: list[Path] = []
    for sql, rel in ((_agency_sql(GOLD), RANK_AGENCY_PACK), (_kamzone_sql(GOLD), RANK_KAMZONE_PACK)):
        dest = cfg.data_root / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        con.execute(sql).df().to_parquet(dest, index=False)
        out.append(dest)
    ids = _mocat_ids([])                              # from the Downloads zone lists
    if ids:
        dest = cfg.data_root / MOCAT_PACK
        pd.DataFrame({"customer_id": sorted(ids)}).to_parquet(dest, index=False)
        out.append(dest)
    return out


def top_by_sector(con, GOLD: str, cfg: Config) -> tuple[pd.DataFrame, pd.DataFrame]:
    ag = _fetch_or_pack(con, cfg, _agency_sql(GOLD), RANK_AGENCY_PACK)
    ag = ag[~ag.nm.astype(str).str.lower().str.contains(
        "gds|galileo|sabre|abacus|travelsky|extranet|autogen| web|mobiapp", regex=True, na=False)]
    ag = _merge_siblings(ag, ["dom_cr", "intl_cr"])   # one row per BRAND (Talon/BD Fare were listed twice)
    return (ag.sort_values("dom_cr", ascending=False).head(15).reset_index(drop=True),
            ag.sort_values("intl_cr", ascending=False).head(15).reset_index(drop=True))


def _mocat_ids(notes: list, cfg: Config | None = None) -> set[str] | None:
    """Customer IDs onboarded on MOCAT (the licensed-agency zone lists).

    Source: Downloads/ZONE/New folder/zones_output_Zone-*.xlsx (the analyst machine);
    falls back to the Data-Kit pack (reference/mocat_ids.parquet) on colleague machines.
    Returns None (column shows 'n/a') when neither exists, with a DQ note.
    """
    zone_dir = DOWNLOADS / "ZONE" / "New folder"
    files = [f for f in zone_dir.glob("zones_output_Zone*.xlsx") if not f.name.startswith("~$")]
    if not files:
        pack = (cfg.data_root / MOCAT_PACK) if cfg else None
        if pack and pack.is_file():
            return set(pd.read_parquet(pack)["customer_id"].astype(str))
        notes.append({"sheet": "(all)", "issue": "MOCAT lists not found",
                      "detail": f"no zones_output_Zone-*.xlsx under {zone_dir} and no data-kit "
                                f"mocat pack - MOCAT column shows n/a"})
        return None
    ids: set[str] = set()
    for f in files:
        try:
            df = pd.read_excel(f, sheet_name="DATA", dtype=str)
        except Exception:
            continue
        if "Zenith ID" in df.columns:
            ids |= {re.sub(r"\.0+$", "", str(x).strip()) for x in df["Zenith ID"].dropna()}
    return {i for i in ids if i.isdigit()}


def kam_zone_top10(con, GOLD: str, cfg: Config) -> pd.DataFrame:
    """Per (KAM, zone): the top-10 agencies by 2026-YTD net, with the activity columns.

    active = the agency sold in the report month (month net != 0); the month net is shown
    beside the flag so the cutoff is transparent. NULL-KAM zones (unmapped) are skipped.
    Same-brand siblings are merged WITHIN each zone (a brand split ACROSS zones stays
    per-zone — each KAM still sees only the account that belongs to their book).
    """
    a = _fetch_or_pack(con, cfg, _kamzone_sql(GOLD), RANK_KAMZONE_PACK)
    # canonical CROSS-ZONE merges first: collapse each CANON group onto its dominant
    # (highest-YTD) account's zone/KAM block, keeping every member id for MOCAT lookups
    canon = a[a.cid.isin(CANON_MERGE)]
    if len(canon):
        keep = []
        for key, g in canon.groupby(canon.cid.map(CANON_MERGE)):
            dom = g.loc[g.ytd_lac.fillna(0).idxmax()].copy()
            dom["ytd_lac"] = g.ytd_lac.fillna(0).sum()
            dom["mon_lac"] = g.mon_lac.fillna(0).sum()
            dom["nm"] = CANON_NAME.get(key, dom.nm)
            dom["cids"] = list(g.cid)
            dom["cid"] = f"{dom.cid} (+{len(g) - 1})" if len(g) > 1 else dom.cid
            keep.append(dom)
        a = pd.concat([a[~a.cid.isin(CANON_MERGE)], pd.DataFrame(keep)], ignore_index=True)

    parts = []                       # explicit loop: pandas' groupby.apply hides the key columns
    for (kam, zn), g in a.groupby(["kam", "zn"], sort=False):
        m = _merge_siblings(g, ["ytd_lac", "mon_lac"], gate_station=False)
        m["kam"], m["zn"] = kam, zn
        parts.append(m)
    merged = pd.concat(parts, ignore_index=True)
    merged["rk"] = merged.groupby(["kam", "zn"]).ytd_lac.rank(ascending=False, method="first").astype(int)
    merged = merged[merged.rk <= 10]
    ztot = merged.groupby(["kam", "zn"]).ytd_lac.transform("sum")
    return (merged.assign(_zt=ztot)
            .sort_values(["_zt", "kam", "zn", "rk"], ascending=[False, True, True, True])
            .drop(columns="_zt").reset_index(drop=True))


# Month names as they appear in the analyst's filenames ("... Jul 2026.xlsx").
_MONTHS = {m.lower(): i for i, m in enumerate(
    ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
     "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"], start=1)}
_MONTH_RE = re.compile(r"\b(" + "|".join(_MONTHS) + r")[a-z]*\s*(\d{4})\b", re.I)


def _month_in_name(p: Path) -> tuple[int, int] | None:
    """(year, month) parsed out of a filename, or None. 'Jul 2026' -> (2026, 7)."""
    m = _MONTH_RE.search(p.stem)
    return (int(m.group(2)), _MONTHS[m.group(1).lower()]) if m else None


def pick_visit_workbook(folder: Path | None = None) -> Path:
    """The month's visit workbook out of Downloads, chosen by the MONTH IN ITS NAME.

    TWO BUGS THIS EXISTS TO PREVENT, both of which produced a confident report for the WRONG
    MONTH rather than an error:

    1. The pattern used to be "Daily Agency Visit Report*.xlsx", anchored on the word "Daily".
       A file saved as "Agency Visit Report Jul 2026.xlsx" therefore did not match at all, and
       the builder silently fell back to the newest file that DID match: a June workbook. The
       run looked perfectly healthy and rebuilt June for the third time. The pattern is now
       "*Agency Visit Report*.xlsx", so the "Daily" prefix is optional.

    2. Selection used to be newest-MODIFIED. Re-opening or re-downloading an old month makes it
       the newest file, so June could beat July purely by being touched last. Selection is now
       by the month IN THE FILENAME, with mtime only as a tie-break between copies of the same
       month (so "... Jun 2026 (3).xlsx" still beats "... Jun 2026.xlsx").

    Anything skipped is printed, so the choice is visible rather than assumed.
    """
    folder = folder or DOWNLOADS
    cands = [p for p in folder.glob("*Agency Visit Report*.xlsx")
             if not p.name.startswith("~$")]          # skip Excel lock files
    if not cands:
        raise FileNotFoundError(
            f"no '*Agency Visit Report*.xlsx' in {folder} — drop the month's visit workbook "
            f"there (or pass source=<path>).")
    dated = [(mm, p) for p in cands if (mm := _month_in_name(p))]
    if dated:
        newest_month = max(mm for mm, _ in dated)
        same = [p for mm, p in dated if mm == newest_month]
        src = max(same, key=lambda p: p.stat().st_mtime)     # tie-break within the month
        others = [p for p in cands if p != src]
        print(f"[pick] {src.name}  ->  {newest_month[0]}-{newest_month[1]:02d} "
              f"(latest month found among {len(cands)} file(s))")
        for p in sorted(others, key=lambda x: x.name):
            mm = _month_in_name(p)
            tag = f"{mm[0]}-{mm[1]:02d}" if mm else "no month in name"
            print(f"       skipped: {p.name}  ({tag})")
    else:
        # No month in any filename: fall back to newest-modified, and SAY so.
        src = max(cands, key=lambda p: p.stat().st_mtime)
        print(f"[pick] {src.name}  (no month in any filename — fell back to newest modified; "
              f"name the file like 'Agency Visit Report Jul 2026.xlsx' to be sure)")
    return src


# Bangladesh's working week, CONFIRMED FROM THE DATA rather than assumed: across July 2026,
# Friday carried 1.0% of visits and Saturday 2.1%, against 26%+ on Wednesday and Thursday.
WEEKEND = ("Friday", "Saturday")
MOCAT_FILE = "mocat_agency_list.xlsx"


# A cell that LOOKS like a date: 13/7/2026, 1-7-26, 20.07.2026. Anchored and bounded so a
# phone number (9176354582) or a sales figure (400000) can never be mistaken for one.
_DATE_TEXT = re.compile(r"^\s*\d{1,2}\s*[/.\-]\s*\d{1,2}\s*[/.\-]\s*\d{2,4}\s*$")

_ZONE_RE = re.compile(r"zone\s*#?\s*[-]?\s*(\d+)\s*([A-Za-z]?)", re.I)


def _rep_zone(raw) -> str | None:
    """The rep's zone from their sheet banner: 'Zone #22', 'Zone 02', 'Zone-11'.

    Scans the WHOLE sheet, not the top: several reps carry no zone in their first block but do
    in a later one. Resolves 23 of 32 July sheets on its own.
    """
    for i in range(len(raw)):
        for v in raw.iloc[i].tolist():
            if isinstance(v, str):
                m = _ZONE_RE.search(v)
                if m:
                    return f"Zone-{int(m.group(1))}{m.group(2).upper()}"
    return None


def zone_countries(cfg: Config) -> dict[str, str]:
    """zone_code -> country, from the canonical dim_zone."""
    p = cfg.reference / "dim_zone.parquet"
    if not p.is_file():
        return {}
    try:
        z = pd.read_parquet(p, columns=["zone_code", "country"])
    except Exception:
        return {}
    return {str(a): str(b) for a, b in zip(z.zone_code, z.country) if pd.notna(b)}


def _zone_country(z: str | None, cmap: dict) -> str | None:
    """Country for a zone label, falling back to the BASE zone.

    dim_zone carries Zone-11A and Zone-11B but not Zone-11, and Zone-24 but not the Zone-24S
    sub-zone a rep writes. Sub-zones are salesperson splits of one territory, so the base zone's
    country is correct; the fallback only fires when every sibling agrees.
    """
    # pandas turns a column of None into float NaN, so guard on type not truthiness
    if z is None or not isinstance(z, str) or not z.strip():
        return None
    z = z.strip()
    if z in cmap:
        return cmap[z]
    base = re.sub(r"[A-Z]+$", "", z)
    if base in cmap:
        return cmap[base]
    sibs = {c for k, c in cmap.items() if re.sub(r"[A-Z]+$", "", k) == base}
    return sibs.pop() if len(sibs) == 1 else None


def load_bd_registry(cfg: Config) -> set[str]:
    """Normalised names that the BANGLADESH GOVERNMENT REGISTRY confirmed exist.

    A second, stronger opinion than the MOCAT spreadsheet: it is the registry itself, matched by
    the app's lookup with a score. Only EXACT / CONTAINS / high-scoring FUZZY rows are trusted,
    because a weak fuzzy hit would wrongly promote an unknown agency to 'registered'.
    """
    p = cfg.reference / "bd_agency_registry_lookup.xlsx"
    if not p.is_file():
        return set()
    try:
        d = pd.read_excel(p)
    except Exception:
        return set()
    d.columns = [str(c).strip() for c in d.columns]
    if "Searched Input" not in d.columns:
        return set()
    ok = d[d.get("Agency Name").notna()]
    score = pd.to_numeric(ok.get("Match Score"), errors="coerce").fillna(0)
    ok = ok[(ok.get("Match Method").isin(["EXACT", "CONTAINS"])) | (score >= 90)]
    return {_norm(n).replace(" ", "") for n in ok["Searched Input"].dropna()}


def load_agency_directory(cfg: Config) -> tuple[pd.DataFrame, pd.DataFrame]:
    """(our agencies, MOCAT-registered agencies that are NOT ours).

    reference/agency_directory.xlsx is the analyst-maintained consolidation and is a better
    answer than either raw source on its own:
      sheet 'Agency Directory'  6,201 of OUR agencies, each already tagged MOCAT / Non-MOCAT,
                                and carrying Country -- so "is this agency overseas" is a fact
                                about the AGENCY rather than an inference from its rep's zone
      sheet 'MOCAT only'          787 agencies on the register with NO match to us. That IS the
                                prospect pool, already reconciled; deriving it by fuzzy-matching
                                two lists at report time would only re-do work with less care.
    """
    p = cfg.reference / "agency_directory.xlsx"
    if not p.is_file():
        return pd.DataFrame(), pd.DataFrame()
    try:
        ours = pd.read_excel(p, sheet_name="Agency Directory")
        pros = pd.read_excel(p, sheet_name="MOCAT only")
    except Exception:
        return pd.DataFrame(), pd.DataFrame()
    ours.columns = [str(c).strip() for c in ours.columns]
    pros.columns = [str(c).strip() for c in pros.columns]
    if "Agency Name" in ours:
        ours = ours[ours["Agency Name"].notna()].copy()
        # 'Bangladesh' and 'BANGLADESH' are the same country; left as-is the overseas split
        # would call half our Dhaka book foreign.
        ours["country_n"] = ours.get("Country", pd.Series(dtype=str)).astype(str).str.strip().str.title()
    if "MOCAT Agency Name" in pros:
        pros = pros[pros["MOCAT Agency Name"].notna()].copy()
    return ours, pros


def load_mocat(cfg: Config) -> pd.DataFrame:
    """The ministry's registered-agency list: the only thing that knows who we have NOT signed.

    Everything in dim_customer is by definition someone we already have a record for, so our own
    data can never answer "did the rep visit an agency we have not onboarded". This list can:
    6,112 registered agencies, of which 'BS Enlisted' = No is the prospect pool.

    Returns empty (and the coverage sheets degrade) when the file is absent, because a missing
    regulator list must not block the whole visit report.
    """
    p = cfg.reference / MOCAT_FILE
    if not p.is_file():
        return pd.DataFrame()
    try:
        d = pd.read_excel(p, sheet_name="MOCAT")
    except Exception:
        return pd.DataFrame()
    d.columns = [str(c).strip() for c in d.columns]
    keep = {"Agency Name": "agency", "Zone": "mocat_zone", "BS Enlisted": "enlisted",
            "Zenith ID": "zenith_id", "Sub Area": "sub_area", "District": "district"}
    d = d[[c for c in keep if c in d.columns]].rename(columns=keep)
    d["enlisted"] = d.enlisted.astype(str).str.strip().str.title().eq("Yes")
    d["agency"] = d.agency.astype(str).str.strip()
    return d[d.agency.ne("") & d.agency.ne("nan")]


def classify_visits(v: pd.DataFrame, ours: pd.DataFrame, prospects: pd.DataFrame,
                    zone_ctry: dict | None = None) -> pd.DataFrame:
    """Tag every visit against OUR OWN agency database first, the register second.

    The order matters. A visit is judged by whether the agency is already a customer of ours,
    which our directory answers directly; only then does the question "is this a registered
    agency we have not signed" arise. An earlier version asked the register first and reported
    331 Bangladesh visits as unmatched that our own book knew perfectly well.

      onboarded            in reference/agency_directory.xlsx -> already our customer, wherever
                           in the world it is
      prospect             on the MOCAT register with no match to us ('MOCAT only') -> the
                           reason to make a visit
      not matched (BD)     neither, and the agency sits in Bangladesh -> a branch, a corporate
                           call, or a spelling we cannot resolve. NOT called a prospect
      not matched (overseas)  neither, and it is outside Bangladesh -> MOCAT never covered it,
                           so its absence from the register says nothing at all

    Country comes from the matched directory row (a fact about the agency). Only when nothing
    matches do we fall back to the rep's zone, and we say so by labelling the bucket.
    """
    v = v.copy()
    if ours.empty:
        v["agency_class"] = "unknown (no agency directory)"
        v["agency_country"] = None
        return v
    zone_ctry = zone_ctry or {}
    omap = {n: (_norm(n), _fullform(n)) for n in ours["Agency Name"].dropna().unique()}
    o_by = ours.drop_duplicates("Agency Name").set_index("Agency Name")
    pmap = ({n: (_norm(n), _fullform(n)) for n in prospects["MOCAT Agency Name"].dropna().unique()}
            if len(prospects) else {})

    def _txt(row, col):
        val = row.get(col)
        return None if val is None or pd.isna(val) or str(val).strip() in ("", "nan") \
            else str(val).strip()

    cls, ctry, azone, asp = [], [], [], []
    cache: dict[str, tuple] = {}
    rep_ctry = (v["zone_country"] if "zone_country" in v else pd.Series([None] * len(v)))
    kinds = (v["visit_type"] if "visit_type" in v else pd.Series(["agency"] * len(v)))
    for a, rc, kind in zip(v.agent, rep_ctry, kinds):
        # CORPORATES ARE NOT AGENCIES and are settled before any matching runs. Left in the
        # agency pool the fuzzy matcher paired 12 of them with travel agencies and reported
        # them as onboarded customers: "New Zealand Dairy", "NRBC Bank", "Mcdonald". Two more
        # became prospects. A corporate is on no agency register, so asking the question at all
        # can only produce a wrong answer.
        if str(kind) == "corporate":
            cls.append("corporate")
            ctry.append(rc if isinstance(rc, str) else None)
            azone.append(None)
            asp.append(None)
            continue
        if a not in cache:
            hit = _match(a, omap)
            if hit:
                row = o_by.loc[hit[0]]
                # Zone, Sales Person and Country are taken from the AGENCY's own directory row.
                # They are facts about the agency, so they beat anything inferred from which
                # rep happened to write the visit down.
                cache[a] = ("onboarded", _txt(row, "country_n"),
                            _txt(row, "Zone"), _txt(row, "Sales Person"))
            elif pmap and _match(a, pmap):
                cache[a] = ("prospect", "Bangladesh", None, None)   # register is Bangladeshi
            else:
                cache[a] = (None, None, None, None)        # decided per-row below
        c, cc, zz, sp = cache[a]
        if c is None:
            # `rc` arrives from a pandas column, so an unresolved zone is float NaN, NOT None.
            # NaN is TRUTHY, so `cc or rc` kept it and `NaN == "Bangladesh"` was False: every
            # unmatched visit by a rep with no zone was labelled OVERSEAS. That put 51 Dhaka
            # visits outside Bangladesh purely because their rep's sheet had no zone banner.
            home = cc if cc else (rc if isinstance(rc, str) and rc.strip() else None)
            c = ("not matched (BD)" if (home or "Bangladesh") == "Bangladesh"
                 else "not matched (overseas)")
            cc = home
        cls.append(c)
        ctry.append(cc or rc)
        azone.append(zz)
        asp.append(sp)
    v["agency_class"] = cls
    v["agency_country"] = ctry
    v["agency_zone"] = azone
    v["agency_sales_person"] = asp

    # A rep whose sheet carries no zone still gets a country, from the agencies they actually
    # visited. That is how Saikat Kumar Shil is resolved: he is absent from dim_sales_person,
    # but 142 of his visits matched agencies in our directory and those agencies have a country.
    if "rep_name" in v:
        for rep, blk in v.groupby("rep_name"):
            known = blk.agency_country.dropna()
            if len(known) and v.loc[blk.index, "agency_country"].isna().any():
                v.loc[blk.index, "agency_country"] = (
                    v.loc[blk.index, "agency_country"].fillna(known.mode().iloc[0]))
    return v


def _zkey(z) -> str:
    """One canonical zone label. MOCAT writes 'Zone-01', we write 'Zone-1', the visit sheets
    write 'Zone # 1' and 'Zone 02'. Left unnormalised, the coverage join silently produced an
    all-NaN sheet: every MOCAT zone sat beside, never on, its own commercial zone.
    Sub-zone suffixes are kept (11A stays 11A) because they are different territories.
    """
    s = str(z).strip().upper()
    m = re.search(r"(\d+)\s*([A-Z]?)$", s.replace("#", " "))
    if not m:
        return s.title()
    return f"Zone-{int(m.group(1))}{m.group(2)}"


def _sheet_coverage(wb, v, mocat_reg, dim_ag, active_ids) -> None:
    """Per zone: how big is the market, how much of it is ours, how much did we visit.

    Three populations, deliberately kept apart because they answer different questions:
      MOCAT total / enlisted / prospects   the REGULATOR's view of the market in that zone
      our agencies / active                OUR commercial view (dim_customer + gold sales)
      visited                              what the reps actually did this month

    MOCAT's zone and ours are NOT the same thing -- theirs is geographic, ours is a commercial
    territory that drives payout -- so the two blocks are shown side by side and never summed
    into one "coverage" number that would silently mix them.
    """
    ws = wb.create_sheet("Zone Coverage"); ws.sheet_view.showGridLines = False
    _cell(ws, 1, 1, "ZONE COVERAGE — the market, our share of it, and what we visited",
          bold=True, size=12, color=WHITE, fill=NAVY)
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=9)
    _cell(ws, 2, 1, "MOCAT columns are the ministry register (geographic zones). OUR columns are "
                    "dim_customer and gold (commercial zones). The two zone schemes are "
                    "different by design, so they are shown apart and never added together.",
          size=9, align="left", wrap=True)
    ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=9)
    ws.row_dimensions[2].height = 28
    heads = ["Zone", "MOCAT total", "BS enlisted", "Prospects (not enlisted)",
             "Our agencies", "Active (sold)", "Visited", "Visits", "Active visited %"]
    _headers(ws, 3, heads, [12, 11, 11, 14, 11, 11, 9, 8, 13])

    # EVERY side is pushed through _zkey first (see why above).
    if len(mocat_reg):
        mr = mocat_reg.copy(); mr["zk"] = mr.mocat_zone.map(_zkey)
        mo = mr.groupby("zk").agg(total=("agency", "size"), enl=("enlisted", "sum")).reset_index()
        mo["prospects"] = mo.total - mo.enl
    else:
        mo = pd.DataFrame(columns=["zk", "total", "enl", "prospects"])
    if dim_ag is not None and len(dim_ag):
        da = dim_ag.copy(); da["zk"] = da.zone.map(_zkey)
        ours = da.groupby("zk").size().rename("ours").reset_index()
        act = (da[da.customer_id.astype(str).isin(active_ids)]
               .groupby("zk").size().rename("active").reset_index())
    else:
        ours = pd.DataFrame(columns=["zk", "ours"])
        act = pd.DataFrame(columns=["zk", "active"])
    if "agency_zone" in v and v.agency_zone.notna().any():
        vv = v[v.agency_zone.notna()].copy(); vv["zk"] = vv.agency_zone.map(_zkey)
        vz = vv.groupby("zk").agg(visited=("agent", "nunique"),
                                  visits=("agent", "size")).reset_index()
    else:
        vz = pd.DataFrame(columns=["zk", "visited", "visits"])

    def _n(z):
        m = re.search(r"(\d+)", str(z))
        return (int(m.group(1)) if m else 999, str(z))
    zones = sorted({*mo.zk, *ours.zk}, key=_n)
    r = 4
    for z in zones:
        m_ = mo[mo.zk == z]
        o_ = ours[ours.zk == z]
        a_ = act[act.zk == z]
        v_ = vz[vz.zk == z] if len(vz) else vz
        n_act = int(a_.active.iloc[0]) if len(a_) else 0
        n_vis = int(v_.visited.iloc[0]) if len(v_) else 0
        _cell(ws, r, 1, str(z), align="left")
        _cell(ws, r, 2, int(m_.total.iloc[0]) if len(m_) else None)
        _cell(ws, r, 3, int(m_.enl.iloc[0]) if len(m_) else None)
        _cell(ws, r, 4, int(m_.prospects.iloc[0]) if len(m_) else None)
        _cell(ws, r, 5, int(o_.ours.iloc[0]) if len(o_) else None)
        _cell(ws, r, 6, n_act or None)
        _cell(ws, r, 7, n_vis or None)
        _cell(ws, r, 8, int(v_.visits.iloc[0]) if len(v_) else None)
        _cell(ws, r, 9, (n_vis / n_act) if n_act else None, fmt="0.0%",
              fill=GREEN if n_act and n_vis / n_act >= 0.5 else (RED if n_act else None))
        r += 1


def _sheet_agency_split(wb, v) -> None:
    """Who the reps actually spent the month with: customers, prospects, or neither."""
    ws = wb.create_sheet("Agency Split"); ws.sheet_view.showGridLines = False
    _cell(ws, 1, 1, "AGENCY SPLIT — onboarded vs prospect vs not on the register",
          bold=True, size=12, color=WHITE, fill=NAVY)
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=12)
    _cell(ws, 2, 1, "onboarded = already in our own agency directory, wherever in the world it "
                    "is. prospect = on the MOCAT register with NO match to us (the 'MOCAT only' "
                    "sheet of the directory) — the reason to make a visit. not matched = neither, "
                    "split by whether the agency is in Bangladesh: outside Bangladesh the "
                    "register never covered it, so its absence means nothing. A visit we cannot "
                    "place is NEVER counted as a prospect, because we cannot evidence that "
                    "opportunity.", size=9, align="left", wrap=True)
    ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=12)
    ws.row_dimensions[2].height = 46

    # The bucket names are read from the DATA, and whatever is left over lands in 'Other'. Twice
    # now a rename in classify_visits left this sheet counting a label that no longer existed,
    # silently zeroing a column and losing 939 visits while every cell still looked plausible.
    # Deriving the last bucket by subtraction means the row cannot fail to add up again.
    BUCKETS = [("Onboarded", "onboarded"), ("Prospect", "prospect"),
               ("NOT FOUND in our database (BD)", "not matched (BD)"),
               ("NOT FOUND in our database (overseas)", "not matched (overseas)"),
               ("Corporate", "corporate")]
    heads = (["Sales person", "Zone", "Country", "Visits"]
             + [lbl for lbl, _k in BUCKETS] + ["Other",
                                               "Prospect % of BD", "Distinct agencies"])
    _headers(ws, 3, heads, [22, 9, 13, 8, 10, 9, 14, 15, 10, 8, 13, 13])

    def _counts(blk):
        n = len(blk)
        got = [int((blk.agency_class == key).sum()) for _lbl, key in BUCKETS]
        return got + [n - sum(got)]                       # 'Other' = everything unaccounted for

    r = 4
    for sp, blk in v.groupby("rep_name"):
        onb, pro, nor, ovs, corp, oth = _counts(blk)
        bd = onb + pro + nor              # the Bangladesh AGENCY book: no corporates, no overseas
        z = blk.agency_zone.dropna() if "agency_zone" in blk else blk.zone.dropna()
        ctry = blk.agency_country.dropna()
        _cell(ws, r, 1, sp, align="left")
        _cell(ws, r, 2, str(z.iloc[0]) if len(z) else "", align="left")
        _cell(ws, r, 3, str(ctry.iloc[0]) if len(ctry) else "unknown", align="left",
              fill=None if len(ctry) else RED)
        for j, val in enumerate([len(blk), onb, pro, nor, ovs, corp, oth], start=4):
            _cell(ws, r, j, val or None)
        _cell(ws, r, 11, pro / bd if bd else None, fmt="0.0%",
              fill=GREEN if bd and pro / bd >= 0.20 else None)
        _cell(ws, r, 12, blk.agent.nunique())
        r += 1

    onb, pro, nor, ovs, corp, oth = _counts(v)
    bd = onb + pro + nor
    _cell(ws, r, 1, "TOTAL", bold=True, align="left", fill=NAVY, color=WHITE)
    for j in (2, 3):
        _cell(ws, r, j, "", fill=NAVY)
    for j, val in enumerate([len(v), onb, pro, nor, ovs, corp, oth], start=4):
        _cell(ws, r, j, val, bold=True, fill=NAVY, color=WHITE)
    _cell(ws, r, 11, pro / bd if bd else None, bold=True, fmt="0.0%", fill=NAVY, color=WHITE)
    _cell(ws, r, 12, v.agent.nunique(), bold=True, fill=NAVY, color=WHITE)
    r += 2
    _cell(ws, r, 1, f"Prospect % is measured against the BANGLADESH AGENCY book only "
                    f"({bd:,} visits): it excludes the {ovs:,} overseas visit(s), which no "
                    f"Bangladeshi register covers, and the {corp:,} corporate visit(s), which "
                    f"are not agencies at all. Measuring it against all {len(v):,} would "
                    f"understate the field force by more than half.", align="left", wrap=True)
    ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=12)
    ws.row_dimensions[r].height = 32

    # ---- not found in the database ----------------------------------------------------
    # Named plainly and listed by name, because this is a WORKLIST, not a statistic: each line
    # is either an agency missing from our directory, a branch we hold under another name, or a
    # spelling the matcher cannot bridge. Only the analyst can tell which.
    nf = v[v.agency_class.str.startswith("not matched")] if "agency_class" in v else v.iloc[0:0]
    r += 2
    _cell(ws, r, 1, f"NOT FOUND IN OUR DATABASE — {len(nf)} visit(s) to "
                    f"{nf.agent.nunique() if len(nf) else 0} distinct name(s). These matched "
                    f"neither reference/agency_directory.xlsx nor the MOCAT register. They are "
                    f"NOT counted as prospects.",
          bold=True, size=11, color=WHITE, fill=NAVY, align="left")
    ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=12)
    r += 1
    if len(nf):
        _headers(ws, r, ["Agency name as written", "Visits", "Visited by", "Country",
                         "Location", "Most selling route"], [40, 8, 26, 14, 22, 30])
        r += 1
        agg = (nf.groupby("agent")
                 .agg(visits=("agent", "size"),
                      reps=("rep_name", lambda s: ", ".join(sorted(set(map(str, s))))[:60]),
                      country=("agency_country", lambda s: next((str(x) for x in s
                                                                 if isinstance(x, str)), "")),
                      loc=("location", lambda s: next((str(x) for x in s
                                                       if isinstance(x, str)), "")),
                      route=("route", lambda s: next((str(x) for x in s
                                                      if isinstance(x, str)), "")))
                 .reset_index().sort_values("visits", ascending=False))
        for x in agg.to_dict("records"):
            _cell(ws, r, 1, x["agent"], align="left", fill=RED)
            _cell(ws, r, 2, x["visits"])
            _cell(ws, r, 3, x["reps"], align="left")
            _cell(ws, r, 4, x["country"], align="left")
            _cell(ws, r, 5, str(x["loc"])[:40], align="left")
            _cell(ws, r, 6, str(x["route"])[:40], align="left")
            r += 1

    # ---- corporate detail -------------------------------------------------------------
    # Separated out entirely: a corporate is a direct-sales call on a company, a different
    # activity from an agency visit, and it belongs to no agency register.
    corp_rows = v[v.agency_class == "corporate"] if "agency_class" in v else v.iloc[0:0]
    r += 2
    _cell(ws, r, 1, f"CORPORATE VISITS — {len(corp_rows)} visit(s) to "
                    f"{corp_rows.agent.nunique() if len(corp_rows) else 0} distinct compan"
                    f"{'y' if (len(corp_rows) and corp_rows.agent.nunique() == 1) else 'ies'}",
          bold=True, size=11, color=WHITE, fill=NAVY, align="left")
    ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=12)
    r += 1
    if not len(corp_rows):
        _cell(ws, r, 1, "None this month.", align="left")
        return
    _headers(ws, r, ["Sales person", "Company", "Date", "Location", "Remarks"],
             [22, 34, 11, 20, 60])
    r += 1
    for x in corp_rows.sort_values(["rep_name", "date"]).to_dict("records"):
        _cell(ws, r, 1, x.get("rep_name"), align="left")
        _cell(ws, r, 2, x.get("agent"), align="left")
        _cell(ws, r, 3, x.get("date"), fmt="yyyy-mm-dd")
        _cell(ws, r, 4, x.get("location"), align="left")
        _cell(ws, r, 5, str(x.get("remarks") or "")[:180], align="left", wrap=True)
        r += 1


def _sheet_weekday(wb, v) -> None:
    """Which days the field force actually works, and whether the dates are believable."""
    ws = wb.create_sheet("Weekday"); ws.sheet_view.showGridLines = False
    _cell(ws, 1, 1, "WEEKDAY PATTERN — and a date-sanity check", bold=True, size=12,
          color=WHITE, fill=NAVY)
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=6)
    _cell(ws, 2, 1, f"Weekend here is {' and '.join(WEEKEND)}, taken from the data itself rather "
                    f"than assumed. Visits logged on a weekend are not necessarily wrong, but a "
                    f"cluster of them usually means a mistyped date, so they are flagged for a "
                    f"look.", size=9, align="left", wrap=True)
    ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=6)
    ws.row_dimensions[2].height = 30
    _headers(ws, 3, ["Weekday", "Visits", "Dates", "Visits per date", "Share", "Note"],
             [12, 9, 8, 13, 9, 34])
    order = ["Saturday", "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]
    d = v.copy()
    d["dow"] = pd.to_datetime(d.date).dt.day_name()
    tot = len(d)
    r = 4
    for day in order:
        blk = d[d.dow == day]
        nd = blk.date.nunique()
        wknd = day in WEEKEND
        _cell(ws, r, 1, day, align="left", fill=RED if wknd else None)
        _cell(ws, r, 2, len(blk))
        _cell(ws, r, 3, nd)
        _cell(ws, r, 4, round(len(blk) / nd, 1) if nd else None)
        _cell(ws, r, 5, len(blk) / tot if tot else None, fmt="0.0%")
        _cell(ws, r, 6, "weekend — check these dates" if wknd and len(blk) else
              ("weekend" if wknd else ""), align="left")
        r += 1
    wknd_n = int(d.dow.isin(WEEKEND).sum())
    r += 1
    _cell(ws, r, 1, "CHECK", bold=True, fill=NAVY, color=WHITE, align="left")
    _cell(ws, r, 2, f"{wknd_n} visit(s) fall on a {' or '.join(WEEKEND)} "
                    f"({wknd_n / tot * 100:.1f}% of the month). "
                    + ("Low enough to be genuine weekend work."
                       if tot and wknd_n / tot < 0.05 else
                       "HIGH — likely mistyped dates, check the reps below."),
          bold=True, align="left")
    ws.merge_cells(start_row=r, start_column=2, end_row=r, end_column=6)
    r += 1
    for sp, blk in d[d.dow.isin(WEEKEND)].groupby("rep_name"):
        _cell(ws, r, 1, sp, align="left")
        _cell(ws, r, 2, f"{len(blk)} weekend visit(s) on "
                        f"{', '.join(sorted({str(x)[:10] for x in blk.date}))[:70]}",
              align="left")
        ws.merge_cells(start_row=r, start_column=2, end_row=r, end_column=6)
        r += 1


def generate(params: dict | None = None, cfg: Config | None = None) -> Path:
    """Build the visit-tracking workbook; return the written path.

    params["source"]: path to the visit workbook. Omitted/None -> the workbook for the LATEST
    MONTH named in a "*Agency Visit Report*.xlsx" filename in ~/Downloads (see
    pick_visit_workbook for why it is month-in-name and not newest-modified).
    """
    try:                                     # frozen exe redirects stdout; don't crash on it
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, OSError):
        pass
    params = params or {}
    cfg = cfg or load_config(validate=True)
    GOLD = f"read_parquet('{(cfg.data_root / 'gold' / 'sales_bi.parquet').as_posix()}')"

    if params.get("source"):
        src = Path(params["source"])
    else:
        src = pick_visit_workbook()
    if not src.is_file():
        raise FileNotFoundError(f"visit workbook not found: {src}")
    print(f"[reading] {src.name}")

    v, roster, notes = parse_visits(src)
    if v.empty:
        raise ValueError(f"parsed 0 visits from {src.name} — is it the right workbook?")
    v["date"] = pd.to_datetime(v["date"])

    # exact duplicate rows (same rep, same day, same agency spelling) are copy-paste artefacts —
    # a whole 8-agency block appeared twice on one sheet in Jun-2026. Metrics use the deduped set;
    # what was dropped is disclosed on the Data Quality sheet.
    dup_mask = v.duplicated(["salesperson", "date", "agent"], keep="first")
    dupes = v[dup_mask].copy()
    v = v[~dup_mask].reset_index(drop=True)
    for r in dupes.groupby(["salesperson", "date", "agent"]).size().reset_index(name="extra").itertuples():
        notes.append({"sheet": r.salesperson, "issue": "duplicate rows dropped",
                      "detail": f"{r.agent} on {r.date:%b %d} listed {r.extra + 1}x -> counted once"})

    # TWO TABS, ONE NAME. The rep name is typed into each tab's header, so a copied template
    # carries the wrong person's name and the report prints that person twice with different
    # numbers. Only the source can settle which tab is whose, so it is reported, never merged:
    # the two books are genuinely different work (in July the tabs shared only 7 of ~48 agencies).
    _byname: dict[str, list[str]] = {}
    for _r in roster.itertuples():
        nm = str(getattr(_r, "rep_name", "") or "").strip()
        if nm and nm != _r.salesperson:
            _byname.setdefault(nm, []).append(_r.salesperson)
    for nm, tabs in _byname.items():
        if len(tabs) > 1:
            notes.append({"sheet": ", ".join(tabs), "issue": "two tabs, same rep name",
                          "detail": f"tabs {tabs} all carry Name: '{nm}'. They are shown as "
                                    f"separate rows because their agency lists differ; fix the "
                                    f"Name cell on whichever tab is wrong."})

    # cluster key so spelling variants ('Holiday Planner Travels' x3 casings) count as ONE agency
    v["akey"] = v.agent.map(lambda a: _norm(a).replace(" ", "") or _fullform(a))

    # ---- market context for the coverage sheets -----------------------------------
    # All three degrade to empty rather than failing the report: a colleague's machine may
    # have neither gold nor the ministry list, and the visit sheets must still build.
    # ---- rep zone -> country (decides whether MOCAT even applies) ------------------
    cmap = zone_countries(cfg)
    v["zone_country"] = [_zone_country(z, cmap) for z in v.get("zone", pd.Series([None]*len(v)))]
    miss = v[v.zone_country.isna()].rep_name.dropna().unique() if "zone_country" in v else []
    if len(miss) and (cfg.reference / "dim_sales_person.parquet").is_file():
        # Sheets with no zone banner: fall back to the salesperson roster. Guarded on a NON-EMPTY
        # rep name -- an empty name matched the first roster row and put a China-based rep in
        # Zone-1 Bangladesh, which would have sent his visits to the MOCAT judgement.
        try:
            _sp = pd.read_parquet(cfg.reference / "dim_sales_person.parquet")
            _nm = lambda x: re.sub(r"[^a-z]", "", str(x).lower())
            look = {}
            for _, rr in _sp.iterrows():
                for person in str(rr.sales_persons).split(","):
                    if _nm(person):
                        look[_nm(person)] = str(rr.zone_code)
            fixed = {}
            for rep in miss:
                if not _nm(rep):
                    continue
                for person, zc_ in look.items():
                    if person in _nm(rep) or _nm(rep) in person:
                        c = _zone_country(zc_, cmap)
                        if c:
                            fixed[rep] = c
                        break
            if fixed:
                v.loc[v.zone_country.isna() & v.rep_name.isin(fixed), "zone_country"] = (
                    v.loc[v.zone_country.isna() & v.rep_name.isin(fixed), "rep_name"].map(fixed))
                print(f"[visit] zone resolved from the salesperson roster for "
                      f"{len(fixed)} rep(s) whose sheet carries no zone")
        except Exception:
            pass
    _unres = sorted(set(v[v.zone_country.isna()].rep_name.dropna()))
    if _unres:
        print(f"[visit] zone UNRESOLVED for {len(_unres)} rep(s): {_unres} "
              f"— their visits are not judged against MOCAT")

    ours_dir, prospects_dir = load_agency_directory(cfg)
    if len(ours_dir):
        print(f"[visit] agency directory: {len(ours_dir):,} of our agencies "
              f"({int((ours_dir.get('MOCAT Status') == 'MOCAT').sum()):,} on the MOCAT register) "
              f"+ {len(prospects_dir):,} registered agencies that are NOT ours "
              f"— classifying visits ...")
    else:
        print("[visit] WARN: no reference/agency_directory.xlsx — the split sheet will be blank")
    v = classify_visits(v, ours_dir, prospects_dir, cmap)
    mocat_reg = load_mocat(cfg)          # register totals for the Zone Coverage sheet only
    dim_ag, active_ids = pd.DataFrame(), set()
    dimf = cfg.data_root / "curated" / "dim_customer" / "dim_customer.parquet"
    if dimf.is_file():
        try:
            _d = pd.read_parquet(dimf, columns=["customer_id", "zone", "primary_channel",
                                                "agent_type"])
            dim_ag = _d[(_d.primary_channel == "AGENCY")
                        | (_d.agent_type.isin(["BSP", "Non-IATA", "Non BSP"]))]
            dim_ag = dim_ag[dim_ag.zone.notna()]
        except Exception:
            dim_ag = pd.DataFrame()
    goldf = cfg.data_root / "gold" / "sales_bi.parquet"
    if goldf.is_file():
        try:
            import duckdb as _dk
            with _dk.connect() as _c:
                active_ids = set(_c.execute(f"""
                    SELECT DISTINCT regexp_replace(CAST("Customer ID" AS VARCHAR),'\\.0$','')
                    FROM read_parquet('{goldf.as_posix()}')
                    WHERE "Channel"='AGENCY' AND "Pure Date" >= DATE '{RANK_START}'
                """).df().iloc[:, 0].astype(str))
        except Exception:
            active_ids = set()

    dmin, dmax = v.date.min(), v.date.max()
    tag = dmin.strftime("%b%Y")
    total = len(v)
    dw = v.groupby(v.date.dt.date).size()
    active = dw.shape[0]
    span = (dmax - dmin).days + 1
    # BD working week is Sun-Thu (Fri+Sat = weekend) — the fair per-day denominator
    workdays = sum(1 for d in pd.date_range(dmin, dmax) if d.weekday() not in (4, 5))
    vmap = {a: (_norm(a), _fullform(a)) for a in v.agent.unique()}

    con = duckdb.connect()
    top_dom, top_intl = top_by_sector(con, GOLD, cfg)

    def status(name):
        hits = _match(name, vmap)
        sub = v[v.agent.isin(hits)]
        return (len(sub), ", ".join(sorted(sub.agent.unique())[:4]),
                ", ".join(sorted(sub.date.dt.strftime("%b %d").unique())))

    dom_cov = sum(1 for r in top_dom.itertuples() if status(r.nm)[0] > 0)
    intl_cov = sum(1 for r in top_intl.itertuples() if status(r.nm)[0] > 0)

    wb = Workbook()

    # ---- Summary ----
    ws = wb.active; ws.title = "Summary"; ws.sheet_view.showGridLines = False
    _cell(ws, 1, 1, f"AGENCY VISIT TRACKING - {dmin:%b %Y}", bold=True, size=14, color=NAVY, align="left")
    ws.merge_cells("A1:C1")
    rows = [
        ("Report period", f"{dmin:%d %b} to {dmax:%d %b %Y}"),
        ("Total visits (deduped)", total),
        ("Active days", active),
        ("Avg visits / active day", round(total / active, 1)),
        ("Avg visits / working day (Sun-Thu)", round(total / workdays, 1)),
        ("Avg visits / calendar day", round(total / span, 1)),
        ("Distinct agencies visited (normalized)", v.akey.nunique()),
        ("  · raw spellings in the log", v.agent.nunique()),
        ("Sales reps with visits", v.salesperson.nunique()),
        ("  · sheets submitted (incl. zero-visit)", len(roster)),
        ("Top-15 DOMESTIC agents visited", f"{dom_cov} / 15"),
        ("Top-15 INTERNATIONAL agents visited", f"{intl_cov} / 15"),
        ("Duplicate rows dropped", len(dupes)),
    ]
    for i, (k, val) in enumerate(rows, 3):
        _cell(ws, i, 1, k, bold=True, align="left"); _cell(ws, i, 2, val, align="left")
    ws.column_dimensions["A"].width = 36; ws.column_dimensions["B"].width = 28

    # ---- Day-wise ----
    ws = wb.create_sheet("Day-wise"); ws.sheet_view.showGridLines = False
    _cell(ws, 1, 1, "VISITS BY DAY", bold=True, size=13, color=NAVY, align="left"); ws.merge_cells("A1:C1")
    _headers(ws, 3, ["Date", "Day", "Visits"], [14, 12, 10])
    rr = 4
    for d, n in dw.items():
        _cell(ws, rr, 1, pd.Timestamp(d).strftime("%Y-%m-%d")); _cell(ws, rr, 2, pd.Timestamp(d).strftime("%A"))
        _cell(ws, rr, 3, int(n)); rr += 1
    _cell(ws, rr, 1, "TOTAL", bold=True, fill="F2F2F2"); _cell(ws, rr, 2, "", fill="F2F2F2")
    _cell(ws, rr, 3, total, bold=True, fill="F2F2F2")

    repmap = v.groupby("salesperson")["rep_name"].first().to_dict()

    # ---- By Salesperson (summary) ----
    ws = wb.create_sheet("By Salesperson"); ws.sheet_view.showGridLines = False
    _cell(ws, 1, 1, "VISITS BY SALES REP", bold=True, size=13, color=NAVY, align="left"); ws.merge_cells("A1:G1")
    # ONE ROW PER TAB, and the tab is shown. Rows are a rep's own book of work, so two tabs stay
    # two rows even when they carry the same name. In July the 'fahad' tab had "Name: SM KANJUL
    # ISLAM" typed in its header (a copied template), so the report printed SM KANJUL ISLAM
    # twice with different numbers and no way to tell which was which. The tab column is what
    # makes that legible, and the duplicate is flagged on Data Quality.
    _cell(ws, 2, 1, "One row per source TAB. Two rows with the same name mean two tabs carry "
                    "that name - see Data Quality.", size=9, align="left")
    ws.merge_cells("A2:G2")
    _headers(ws, 3, ["Sales rep", "Sheet (tab)", "Visits", "Active days", "Avg / active day",
                     "Distinct agencies", "First to last"],
             [24, 13, 9, 12, 15, 16, 18])
    dup_names = {n for n, c in
                 pd.Series([repmap.get(s, s) for s in v.salesperson.unique()]).value_counts().items()
                 if c > 1}
    rr = 4
    for sp, sub in sorted(v.groupby("salesperson"), key=lambda kv: -len(kv[1])):
        ad = sub.date.dt.date.nunique()
        nm = repmap.get(sp, sp)
        _cell(ws, rr, 1, nm, align="left", fill=AMBER if nm in dup_names else None)
        _cell(ws, rr, 2, sp, align="left", fill=AMBER if nm in dup_names else None)
        _cell(ws, rr, 3, len(sub)); _cell(ws, rr, 4, ad)
        _cell(ws, rr, 5, round(len(sub) / ad, 1)); _cell(ws, rr, 6, sub.akey.nunique())
        _cell(ws, rr, 7, f"{sub.date.min():%b %d} to {sub.date.max():%b %d}", align="left"); rr += 1
    # reps who submitted a sheet but logged NO visits — previously they vanished from the report,
    # which hid exactly the people a visit-tracking report should surface
    seen = set(v.salesperson.unique())
    for r in roster.itertuples():
        if r.salesperson in seen:
            continue
        _cell(ws, rr, 1, r.rep_name if r.rep_name != r.salesperson else r.salesperson, align="left", fill=RED)
        _cell(ws, rr, 2, r.salesperson, align="left", fill=RED)
        for _j in (3, 4, 5, 6):
            _cell(ws, rr, _j, 0, fill=RED)
        _cell(ws, rr, 7, "no visits logged" if r.has_table else "empty sheet", align="left", fill=RED)
        rr += 1

    # ---- Rep x Day matrix (day-wise count + avg/day, per rep) ----
    ws = wb.create_sheet("Rep x Day"); ws.sheet_view.showGridLines = False
    _cell(ws, 1, 1, "VISITS BY REP × DAY", bold=True, size=13, color=NAVY, align="left")
    days = sorted(v.date.dt.date.unique())
    ct = pd.crosstab(v.salesperson, v.date.dt.date).reindex(columns=days, fill_value=0)
    ct = ct.loc[ct.sum(axis=1).sort_values(ascending=False).index]
    heads = ["Sales rep"] + [pd.Timestamp(d).strftime("%b %d") for d in days] + ["Total", "Days", "Avg/day"]
    _headers(ws, 3, heads, [22] + [6] * len(days) + [7, 6, 8])
    rr = 4
    for sp in ct.index:
        _cell(ws, rr, 1, repmap.get(sp, sp), align="left")
        vals = [int(ct.loc[sp, d]) for d in days]
        for j, val in enumerate(vals, 2):
            _cell(ws, rr, j, val if val else "")
        tot = sum(vals); ad = sum(1 for x in vals if x)
        _cell(ws, rr, 2 + len(days), tot, bold=True); _cell(ws, rr, 3 + len(days), ad)
        _cell(ws, rr, 4 + len(days), round(tot / ad, 1) if ad else 0)
        rr += 1
    _cell(ws, rr, 1, "TOTAL", bold=True, fill="F2F2F2")
    for j, d in enumerate(days, 2):
        _cell(ws, rr, j, int(ct[d].sum()), bold=True, fill="F2F2F2")
    _cell(ws, rr, 2 + len(days), total, bold=True, fill="F2F2F2")
    ws.freeze_panes = "B4"

    # ---- Rep -> Agency detail (which agencies each rep visited, how often) ----
    ws = wb.create_sheet("Rep Agency Detail"); ws.sheet_view.showGridLines = False
    _cell(ws, 1, 1, "WHICH AGENCIES EACH REP VISITED (frequency)", bold=True, size=13, color=NAVY, align="left")
    ws.merge_cells("A1:D1")
    _headers(ws, 3, ["Sales rep", "Agency", "# visits", "Visit dates"], [20, 34, 9, 26])
    rr = 4
    # group on the normalized key so 'Holiday Planner Travels/travels' count as one agency;
    # display the spelling the rep used most often
    det = v.groupby(["salesperson", "akey"]).agg(
        agent=("agent", lambda s: s.mode().iloc[0]),
        n=("date", "size"),
        dates=("date", lambda s: ", ".join(sorted(pd.to_datetime(s).dt.strftime("%b %d").unique())))).reset_index()
    for sp in ct.index:
        for r in det[det.salesperson == sp].sort_values("n", ascending=False).itertuples():
            _cell(ws, rr, 1, repmap.get(sp, sp), align="left"); _cell(ws, rr, 2, str(r.agent)[:60], align="left")
            _cell(ws, rr, 3, int(r.n)); _cell(ws, rr, 4, r.dates, align="left"); rr += 1
    ws.freeze_panes = "A4"

    # ---- KAM Zone Top 10 (per KAM: their zone's top-10 agencies + visit/activity status) ----
    ws = wb.create_sheet("KAM Zone Top 10"); ws.sheet_view.showGridLines = False
    _cell(ws, 1, 1, "KAM WISE - EACH ZONE'S TOP 10 AGENCIES: VISITS, SALES, ACTIVITY, MOCAT",
          bold=True, size=13, color=NAVY, align="left"); ws.merge_cells("A1:J1")
    _cell(ws, 2, 1, "Top 10 by 2026-YTD net per (KAM, zone). Active = sold in the report month "
                    "(month net shown). Visits counted from the whole visit log via name match. "
                    "MOCAT = agency ID present in the MOCAT licensed-agency zone lists.",
          align="left", size=9, color="7F7F7F"); ws.merge_cells("A2:J2")
    _headers(ws, 4, ["#", "Agency", "Customer ID", "YTD net (lac)", "Month net (lac)",
                     "Status", "Visits", "Visit dates", "Matched to (visit log)", "MOCAT"],
             [4, 34, 12, 12, 12, 10, 7, 22, 26, 10])
    mocat = _mocat_ids(notes, cfg)
    kz = kam_zone_top10(con, GOLD, cfg)
    rr = 5
    for (kam, zn), blk in kz.groupby(["kam", "zn"], sort=False):
        _cell(ws, rr, 1, f"{kam}   |   {zn}   |   zone top-10 YTD {blk.ytd_lac.sum()/100:,.1f} cr",
              bold=True, color=WHITE, fill="2E5E9E", align="left", size=10)
        ws.merge_cells(start_row=rr, start_column=1, end_row=rr, end_column=10)
        rr += 1
        for r in blk.itertuples():
            n, mname, dates = status(r.nm)
            is_active = (r.mon_lac or 0) != 0        # NB: do not shadow the outer `active` (days count)
            _cell(ws, rr, 1, int(r.rk)); _cell(ws, rr, 2, str(r.nm)[:55], align="left")
            _cell(ws, rr, 3, r.cid)
            _cell(ws, rr, 4, r.ytd_lac, fmt="#,##0.0")
            _cell(ws, rr, 5, r.mon_lac or 0, fmt="#,##0.0")
            _cell(ws, rr, 6, "Active" if is_active else "Inactive", bold=not is_active,
                  fill=GREEN if is_active else RED)
            _cell(ws, rr, 7, n, bold=n > 0)
            _cell(ws, rr, 8, dates, align="left")
            _cell(ws, rr, 9, mname, align="left")
            # merged rows carry every member ID in cids — onboarded if ANY member is listed
            members = getattr(r, "cids", None) or [r.cid]
            on = any(c in mocat for c in members) if mocat is not None else None
            _cell(ws, rr, 10, ("n/a" if on is None else ("Onboarded" if on else "Not onboarded")),
                  fill=(None if on is None else (GREEN if on else RED)))
            rr += 1
    ws.freeze_panes = "A5"

    # ---- Top 15 per sector ----
    for title, top, col in [("Top 15 Domestic", top_dom, "dom_cr"), ("Top 15 International", top_intl, "intl_cr")]:
        ws = wb.create_sheet(title); ws.sheet_view.showGridLines = False
        _cell(ws, 1, 1, f"{title.upper()} AGENTS - VISIT STATUS (ranked by 2026-YTD {('domestic' if 'Dom' in title else 'international')} net)",
              bold=True, size=12, color=NAVY, align="left"); ws.merge_cells("A1:G1")
        _headers(ws, 3, ["#", "Agency", "2026 net (cr)", "Visited?", "# visits", "Visit dates", "Matched to (visit log)"],
                 [4, 34, 13, 10, 9, 26, 32])
        rr = 4
        for i, r in enumerate(top.itertuples(), 1):
            n, mname, dates = status(r.nm)
            _cell(ws, rr, 1, i); _cell(ws, rr, 2, str(r.nm)[:60], align="left")
            _cell(ws, rr, 3, round(getattr(r, col), 1), fmt="#,##0.0")
            _cell(ws, rr, 4, "YES" if n else "NO", bold=True, fill=GREEN if n else RED)
            _cell(ws, rr, 5, n); _cell(ws, rr, 6, dates, align="left"); _cell(ws, rr, 7, mname, align="left")
            rr += 1

    # ---- Data Quality (every correction the parser made, so the numbers are auditable) ----
    # ---- Zone Coverage · Agency Split · Weekday --------------------------------------
    _sheet_coverage(wb, v, mocat_reg, dim_ag, active_ids)
    _sheet_agency_split(wb, v)
    _sheet_weekday(wb, v)

    ws = wb.create_sheet("Data Quality"); ws.sheet_view.showGridLines = False
    _cell(ws, 1, 1, "DATA QUALITY - CORRECTIONS APPLIED WHILE PARSING", bold=True, size=13, color=NAVY, align="left")
    ws.merge_cells("A1:C1")
    _headers(ws, 3, ["Sheet / rep", "Issue", "Detail"], [16, 26, 70])
    rr = 4
    for nte in notes:
        _cell(ws, rr, 1, nte["sheet"], align="left"); _cell(ws, rr, 2, nte["issue"], align="left")
        _cell(ws, rr, 3, nte["detail"], align="left"); rr += 1
    if not notes:
        _cell(ws, rr, 1, "clean parse - no corrections needed", align="left")

    # ---- Visit Log ----
    ws = wb.create_sheet("Visit Log"); ws.sheet_view.showGridLines = False
    _cell(ws, 1, 1, "VISIT LOG (all visits)", bold=True, size=13, color=NAVY, align="left"); ws.merge_cells("A1:E1")
    _headers(ws, 3, ["Date", "Sales rep", "Agency visited", "Location", "Most selling route"], [12, 14, 34, 18, 22])
    rr = 4
    for r in v.sort_values(["date", "salesperson"]).itertuples():
        _cell(ws, rr, 1, r.date.strftime("%Y-%m-%d")); _cell(ws, rr, 2, str(r.salesperson), align="left")
        _cell(ws, rr, 3, str(r.agent), align="left")
        _cell(ws, rr, 4, "" if pd.isna(r.location) else str(r.location), align="left")
        _cell(ws, rr, 5, "" if pd.isna(r.route) else str(r.route), align="left"); rr += 1
    ws.freeze_panes = "A4"

    out = cfg.output_dir / f"Agency_Visit_Tracking_{tag}.xlsx"
    out.parent.mkdir(parents=True, exist_ok=True)
    for suffix in ("", "__new", "__new2"):
        cand = out.with_name(out.stem + suffix + ".xlsx") if suffix else out
        try:
            wb.save(cand); out = cand; break
        except PermissionError:
            continue
    else:
        raise PermissionError(f"could not write {out} — is the file open in Excel?")
    print(f"[OK] {out}")
    print(f"     {total} visits (deduped, -{len(dupes)}) · {active} active days · "
          f"avg {total/active:.1f}/active day, {total/workdays:.1f}/working day · "
          f"top-15 visited: Dom {dom_cov}/15, Intl {intl_cov}/15")
    zero = [r.salesperson for r in roster.itertuples() if r.salesperson not in set(v.salesperson)]
    if zero:
        print(f"     zero-visit sheets: {', '.join(zero)}")
    if notes:
        print(f"     data-quality notes: {len(notes)} (see the Data Quality sheet)")
    return out
