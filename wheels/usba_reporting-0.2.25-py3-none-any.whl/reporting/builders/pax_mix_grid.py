"""
reporting.builders.pax_mix_grid: the passenger mix laid out the way the network team asks for
it, one row per directional route and one column group per month, split Adult / Child / Infant.

This is the SAME numbers as reporting.builders.pax_mix, in the shape of the blank template that
circulates as "City wise" style grids (SL, Sector, then Month -> Adult|Child|Infant). Keeping it
a separate module rather than another sheet on pax_mix keeps each file about one thing: pax_mix
decides WHO each ticket is, this decides HOW IT IS LAID OUT.

THE COUNTS ARE TICKETS ON A DIRECTIONAL LEG, AND THAT IS THE RIGHT GRAIN HERE
----------------------------------------------------------------------------
97.3% of ticket-payment rows carry seg=1 and a ticket is exactly one row, so "DAC-CGP" counts
tickets whose leg is DAC to CGP. The template lists both directions of every route separately,
which matches. The domestic pairs come out near-symmetric (DAC-CGP 188,607 against CGP-DAC
189,751), which is the check that this grain is behaving: if round trips were hiding their
return leg, the reverse rows would be systematically thin. They are not. The Gulf routes ARE
lopsided (MCT-DAC 48,776 against DAC-MCT 28,463) and that is real labour-corridor behaviour,
not an artefact.

WHY SOLO TICKETS ARE COUNTED AS ADULTS HERE WITHOUT A CAVEAT COLUMN
------------------------------------------------------------------
53% of tickets sit alone on their booking, so there is no second fare to infer a type from and
they fall to adult. That default was measured against truth, not assumed: on 18,871 solo
tickets carrying a real date of birth, 99.90% were adults, 0.10% children and none infants.
Children essentially do not fly alone. So a straight Adult/Child/Infant count over every ticket
is the true passenger mix, which is exactly what this template wants, and the grid needs no
"unassessable" column. The workbook still states this on its Notes sheet, because a grid of
bare counts invites the question and it should not need asking.
"""
from __future__ import annotations

from datetime import datetime
from pathlib import Path

import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from ..config import Config, load_config
from .pax_mix import fetch_mix, partial_months

NAVY, BLUE, WHITE, GREY = "1F3864", "2E5395", "FFFFFF", "F2F2F2"
AMBER = "FFF2CC"
THIN = Side(style="thin", color="9E9E9E")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
FI = "#,##0"

# The template's route list, in the template's order, so the filled grid drops straight onto
# the network team's own sheet row for row. Directional and deliberately paired: every route
# appears both ways round. Kept here rather than read from the sample workbook because that
# file lives in Downloads and is not a repo input; if the network is extended, add rows here.
TEMPLATE_ROUTES = [
    "DAC-CGP", "CGP-DAC", "DAC-ZYL", "ZYL-DAC", "DAC-RJH", "RJH-DAC",
    "DAC-SPD", "SPD-DAC", "DAC-CXB", "CXB-DAC", "DAC-CCU", "CCU-DAC",
    "DAC-MAA", "MAA-DAC", "DAC-BKK", "BKK-DAC", "DAC-SIN", "SIN-DAC",
    "DAC-KUL", "KUL-DAC", "DAC-CAN", "CAN-DAC", "DAC-MLE", "MLE-DAC",
    "DAC-DOH", "DOH-DAC", "DAC-MCT", "MCT-DAC", "DAC-JED", "JED-DAC",
    "DAC-RUH", "RUH-DAC", "DAC-DXB", "DXB-DAC", "DAC-SHJ", "SHJ-DAC",
    "DAC-AUH", "AUH-DAC",
]

TYPES = ("Adult", "Child", "Infant")

# Any route outside TEMPLATE_ROUTES needs this many tickets before it earns a row in the
# extra block. Below it the tail is thousands of one-off interline and mis-keyed pairs, which
# would bury the 38 rows the reader actually came for. The dropped total is printed, never
# silently swallowed.
OTHER_ROUTE_MIN = 500


def _month_labels(yms: list[str]) -> list[tuple[str, str]]:
    """['2025-05', ...] -> [("May'25", '2025-05'), ...] in the template's own header style."""
    out = []
    for ym in yms:
        d = datetime.strptime(ym, "%Y-%m")
        out.append((f"{d.strftime('%b')}'{d.strftime('%y')}", ym))
    return out


def build_grid(mix: pd.DataFrame) -> pd.DataFrame:
    """Tickets per (route, month, passenger type). Solo tickets fold into Adult.

    The fold is the whole point of the layout: the template has three columns, not four, and
    the measurement above says an unbenchmarkable ticket is an adult 99.90% of the time.
    """
    m = mix.copy()
    m["kind"] = m.pax_type.map({"child": "Child", "infant": "Infant"}).fillna("Adult")
    g = m.groupby(["route", "ym", "kind"]).size().rename("n").reset_index()
    return g.pivot_table(index="route", columns=["ym", "kind"], values="n",
                         aggfunc="sum", fill_value=0)


def _write_grid(ws, grid: pd.DataFrame, months: list[tuple[str, str]],
                routes: list[str], partial: set[str]) -> int:
    """Header rows 2-3 and the body, matching the template's cell geometry exactly.

    The template starts at B2 (column A and row 1 are left empty as a margin), merges each
    month label across its three type columns, and merges SL and Sector down over both header
    rows. Reproduced literally so the result can be pasted into their file.
    """
    _cell(ws, 2, 2, "SL", head=True)
    _cell(ws, 2, 3, "Sector", head=True)
    ws.merge_cells(start_row=2, start_column=2, end_row=3, end_column=2)
    ws.merge_cells(start_row=2, start_column=3, end_row=3, end_column=3)
    ws.column_dimensions["A"].width = 2.5
    ws.column_dimensions["B"].width = 5
    ws.column_dimensions["C"].width = 11

    col = 4
    for label, ym in months:
        # a short month is labelled in the header, so nobody reads eight days as a collapse
        shown = f"{label} (part)" if ym in partial else label
        _cell(ws, 2, col, shown, head=True,
              fill=AMBER if ym in partial else BLUE,
              color="000000" if ym in partial else WHITE)
        ws.merge_cells(start_row=2, start_column=col, end_row=2, end_column=col + 2)
        for k, t in enumerate(TYPES):
            _cell(ws, 3, col + k, t, head=True)
            ws.column_dimensions[get_column_letter(col + k)].width = 7.5
        col += 3

    r = 4
    for sl, route in enumerate(routes, start=1):
        _cell(ws, r, 2, sl)
        _cell(ws, r, 3, route, bold=True)
        for j, (_, ym) in enumerate(months):
            for k, t in enumerate(TYPES):
                v = int(grid.get((ym, t), {}).get(route, 0)) if len(grid) else 0
                _cell(ws, r, 4 + j * 3 + k, v, fmt=FI)
        r += 1

    # TOTAL is over the rows PRINTED ABOVE IT, not over the whole book. A total that silently
    # included the routes filtered out below would not add up to its own column.
    _cell(ws, r, 2, "", head=True)
    _cell(ws, r, 3, "TOTAL", head=True)
    for j, (_, ym) in enumerate(months):
        for k, t in enumerate(TYPES):
            s = sum(int(grid.get((ym, t), {}).get(rt, 0)) for rt in routes) if len(grid) else 0
            _cell(ws, r, 4 + j * 3 + k, s, head=True, fmt=FI)
    ws.freeze_panes = "D4"
    return r


def _cell(ws, r, c, v, *, head=False, bold=False, fmt=None, fill=None, color=None):
    cell = ws.cell(row=r, column=c, value=v)
    cell.font = Font(bold=head or bold, size=9,
                     color=color or (WHITE if head else "000000"))
    cell.border = BORDER
    cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=head)
    if head or fill:
        cell.fill = PatternFill("solid", fgColor=fill or BLUE)
    if fmt:
        cell.number_format = fmt
    return cell


def _sheet_notes(wb, mix: pd.DataFrame, dropped: pd.DataFrame, months, partial,
                 printed_total: int) -> None:
    """What a grid of bare counts cannot say for itself.

    Carries the RECONCILIATION from the book total down to what the grid actually prints. A
    route grid can only show a ticket that has a route, and 0.9% of tickets carry no airport
    pair at all, so the two numbers genuinely differ. Printing the book total alone next to a
    grid that sums to something smaller is how a reader loses trust in both.
    """
    ws = wb.create_sheet("Notes")
    ws.column_dimensions["A"].width = 26
    ws.column_dimensions["B"].width = 108
    ws.cell(row=1, column=1, value="HOW THIS GRID WAS BUILT").font = Font(bold=True, size=12,
                                                                         color=WHITE)
    ws.cell(row=1, column=1).fill = PatternFill("solid", fgColor=NAVY)
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=2)

    ch = int((mix.pax_type == "child").sum())
    inf = int((mix.pax_type == "infant").sum())
    n = len(mix)
    notes = [
        ("What a cell counts", "Tickets sold on that directional leg in that month, split "
                               "Adult / Child / Infant. One ticket is one row and 97.3% of "
                               "tickets are a single leg, so DAC-CGP and CGP-DAC are counted "
                               "separately, as the template lists them."),
        ("Where the type comes from", "The sales data holds no passenger type. A child is sold "
                                      "at 75% of the adult fare and an infant at 10% or 25%, so "
                                      "each ticket is compared with the dearest ticket on its "
                                      "own booking. Measured 99.54% accurate against 26,913 "
                                      "passengers whose real date of birth we hold."),
        ("Tickets booked alone", "53% of tickets sit alone on their booking, so there is no "
                                 "second fare to compare against and they are counted as "
                                 "adults. CHECKED against truth: on 18,871 solo tickets with a "
                                 "real date of birth, 99.90% were adults, 0.10% children and "
                                 "none infants. Children essentially do not fly alone, so these "
                                 "counts are the true passenger mix, not an undercount."),
        ("What it is not for", "Anything per-passenger. About 2.4% of predicted children are "
                               "adults on a cheap fare. Good for a distribution, wrong for "
                               "naming an individual traveller."),
        ("Period", f"{months[0][0]} to {months[-1][0]}. "
                   + (f"Months marked (part) are not complete months: "
                      f"{', '.join(l for l, y in months if y in partial)}."
                      if partial else "All months are complete.")),
        ("Whole-book totals", f"{n:,} tickets · {ch:,} children ({ch/n*100:.2f}%) · "
                              f"{inf:,} infants ({inf/n*100:.2f}%). The grid prints fewer than "
                              f"this, and the reconciliation is the next two rows."),
    ]
    # RECONCILIATION, so the grid's own total can be walked back to the book total.
    routeless = int(mix.route.isna().sum())
    rl = mix[mix.route.isna()]
    rl_ch = int((rl.pax_type == "child").sum())
    rl_inf = int((rl.pax_type == "infant").sum())
    below = int(dropped.n.sum()) if len(dropped) else 0
    notes += [
        ("No airport pair", f"{routeless:,} tickets ({routeless/n*100:.2f}%) carry NO departure "
                            f"or arrival airport in the source, so they cannot sit on any route "
                            f"and no route grid can show them. They are real sales (one-way and "
                            f"return, sold through the extranet, the GDSs and the web) and they "
                            f"include {rl_ch:,} children and {rl_inf:,} infants. Present in "
                            f"every month, though far fewer from May 2026 onward. Use the "
                            f"by-month report, not this grid, for a complete child count."),
        ("Grid reconciliation", f"{n:,} tickets in the book, less {routeless:,} with no airport "
                                f"pair, less {below:,} on routes below the volume floor, leaves "
                                f"{printed_total:,} printed on the 'Route x Month (all)' sheet."),
    ]
    r = 3
    for a, b in notes:
        c1 = ws.cell(row=r, column=1, value=a)
        c1.font = Font(bold=True, size=9, color=NAVY)
        c1.alignment = Alignment(vertical="top", wrap_text=True)
        c2 = ws.cell(row=r, column=2, value=b)
        c2.font = Font(size=9)
        c2.alignment = Alignment(vertical="top", wrap_text=True)
        ws.row_dimensions[r].height = 44
        r += 1

    r += 1
    ws.cell(row=r, column=1, value="ROUTES NOT PRINTED").font = Font(bold=True, size=11,
                                                                    color=WHITE)
    ws.cell(row=r, column=1).fill = PatternFill("solid", fgColor=NAVY)
    ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=2)
    r += 1
    tot = int(dropped.n.sum()) if len(dropped) else 0
    ws.cell(row=r, column=1, value="Below the floor")
    ws.cell(row=r, column=2, value=(
        f"{len(dropped):,} route(s) carried fewer than {OTHER_ROUTE_MIN:,} tickets over the "
        f"whole period and are not printed, {tot:,} tickets in total "
        f"({tot/n*100:.2f}% of the book). This tail is one-off interline and mis-keyed "
        f"airport pairs. Stated here rather than dropped silently."))
    ws.cell(row=r, column=2).alignment = Alignment(vertical="top", wrap_text=True)
    ws.row_dimensions[r].height = 44


def generate(params: dict | None = None, cfg: Config | None = None) -> Path:
    params = params or {}
    cfg = cfg or load_config(validate=False)
    print("[pax-mix-grid] classifying every ticket ...", flush=True)
    mix = fetch_mix(cfg)
    if mix.empty:
        raise RuntimeError("no ticket rows found in curated/sales")
    partial = partial_months(cfg)

    grid = build_grid(mix)
    yms = sorted(mix.ym.unique())
    months = _month_labels(yms)

    # Routes beyond the template, ranked by volume, so a real route the template predates is
    # visible rather than lost. The floor keeps the long mis-keyed tail out of the sheet.
    vol = mix.groupby("route").size().rename("n").reset_index()
    extra = vol[~vol.route.isin(TEMPLATE_ROUTES) & (vol.n >= OTHER_ROUTE_MIN)]
    extra = extra.sort_values("n", ascending=False)
    dropped = vol[~vol.route.isin(TEMPLATE_ROUTES) & (vol.n < OTHER_ROUTE_MIN)]

    wb = Workbook()
    wb.remove(wb.active)

    # Sheet 1 is the template, exactly: the 38 rows, in order, nothing added. This is the one
    # that gets pasted into the network team's file.
    ws = wb.create_sheet("Route x Month")
    _write_grid(ws, grid, months, TEMPLATE_ROUTES, partial)

    # Sheet 2 carries the same grid plus every other route above the floor, because the
    # template's 38 do not cover the whole network and a reader asking "where is the rest"
    # should not have to come back for it.
    if len(extra):
        ws2 = wb.create_sheet("Route x Month (all)")
        _write_grid(ws2, grid, months, TEMPLATE_ROUTES + extra.route.tolist(), partial)

    # What the widest sheet actually prints, computed the same way the sheet computes it, so
    # the reconciliation row on Notes is measured rather than asserted from theory.
    printed_routes = TEMPLATE_ROUTES + extra.route.tolist()
    printed_total = int(mix[mix.route.isin(printed_routes)].shape[0])
    _sheet_notes(wb, mix, dropped, months, partial, printed_total)

    # The three buckets must account for every ticket. If this ever trips, a ticket has gone
    # missing between the book and the grid and the Notes reconciliation would be quietly wrong.
    routeless = int(mix.route.isna().sum())
    below = int(dropped.n.sum()) if len(dropped) else 0
    if printed_total + routeless + below != len(mix):
        raise RuntimeError(
            f"grid reconciliation failed: printed {printed_total:,} + routeless {routeless:,} "
            f"+ below-floor {below:,} != book {len(mix):,}")

    missing = [r for r in TEMPLATE_ROUTES
               if not any(int(grid.get((ym, t), {}).get(r, 0)) for ym in yms for t in TYPES)]
    print(f"    {len(mix):,} tickets · {len(months)} month(s) · "
          f"{len(TEMPLATE_ROUTES)} template routes")
    if missing:
        print(f"    [check] {len(missing)} template route(s) with NO traffic at all: "
              f"{', '.join(missing)}")
    if len(extra):
        print(f"    {len(extra)} further route(s) above {OTHER_ROUTE_MIN} tickets on the "
              f"'(all)' sheet")
    if len(dropped):
        print(f"    {len(dropped)} route(s) below the floor not printed "
              f"({int(dropped.n.sum()):,} tickets, {dropped.n.sum()/len(mix)*100:.2f}%)")
    if routeless:
        rl = mix[mix.route.isna()]
        print(f"    [note] {routeless:,} tickets ({routeless/len(mix)*100:.2f}%) carry NO "
              f"airport pair and cannot sit on any route, including "
              f"{int((rl.pax_type=='child').sum()):,} children. Stated on the Notes sheet.")

    out_dir = Path(params.get("out_dir") or cfg.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    out = out_dir / f"Passenger_Mix_Route_Month_{datetime.now():%Y%m%d}.xlsx"
    # House convention across the packaged builders: a workbook left open in Excel must not
    # kill the run. Excel holds an exclusive lock, wb.save raises PermissionError, and a whole
    # rebuild is lost to a window somebody forgot to close. Fall back to a sibling name and
    # SAY which file was written, so nobody keeps reading the stale copy on screen.
    try:
        wb.save(out)
    except PermissionError:
        out = out.with_name(out.stem + "__new.xlsx")
        wb.save(out)
        print("    [note] the previous workbook is open in Excel, wrote a __new sibling instead")
    print(f"[OK] -> {out}")
    return out
