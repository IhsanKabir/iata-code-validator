"""
reporting.builders.city_market — the city-wise market sheet, built from the cited store.

WHAT IT EMITS (two files, deliberately)
    City_wise_data_SUBMISSION.xlsx
        The template's ORIGINAL shape and nothing else: No, Destinations, and the six columns
        as they were asked for. This is the file that gets sent. It carries no working, because
        the recipient asked for a filled template, not our evidence.
    City_wise_data_EVIDENCE.xlsx
        The same rows plus, for every figure, its source, its year, how far it can be trusted
        and how it was derived, then the BS demand columns and a Sources sheet. This is what
        defends the submission when someone asks where a number came from.

    Splitting them is not tidiness. A submission carrying our confidence vocabulary invites the
    reader to argue with the method instead of reading the answer, and an evidence pack squeezed
    into seven columns cannot defend anything.

HOW A CELL IS CHOSEN
    Facts are stored long, so one (entity, metric) can hold several competing values: UN DESA
    and BMET both answer "Bangladeshi living in Country" and disagree by design. The winner is
    picked by CONFIDENCE first (measured > official_estimate > apportioned > press_estimate),
    then by the most recent as_of_year. Whatever wins, the Remarks column names the basis, so
    the sheet never quietly presents a modelled figure as a counted one.

WHAT STAYS BLANK, AND WHY THAT IS THE POINT
    * values held at use=0 (apportioned or press, not yet signed off) are NOT printed
    * where a source genuinely has no figure the cell is empty and Remarks says which source
      was silent
    A blank with a stated reason is worth more than a plausible number, because the reader can
    act on the first and cannot audit the second. Every blank is counted in the run summary.
"""
from __future__ import annotations

from datetime import datetime
from pathlib import Path

import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side

from ..config import Config, load_config

NAVY, BLUE, WHITE, GREY = "1F3864", "2E5395", "FFFFFF", "F2F2F2"
AMBER, GREENL, REDL = "FFF2CC", "E2EFDA", "FCE4E4"
BORDER = Border(*([Side(style="thin", color="BFBFBF")] * 4))
FI = "#,##0"

# best first. A value only beats another if it is MORE trustworthy, never merely newer.
CONF_RANK = {"measured": 0, "official_estimate": 1, "apportioned": 2, "press_estimate": 3}
CONF_LABEL = {"measured": "counted", "official_estimate": "official estimate",
              "apportioned": "APPORTIONED, not a count", "press_estimate": "press estimate"}

BD_AIRPORTS = ("DAC", "CGP", "CXB", "ZYL", "JSR", "RJH", "BZL", "SPD")


def _c(ws, r, col, v, *, bold=False, fill=None, fmt=None, color="000000", size=9, wrap=False):
    cell = ws.cell(row=r, column=col, value=v)
    cell.font = Font(bold=bold, color=color, size=size)
    cell.border = BORDER
    if fill:
        cell.fill = PatternFill("solid", fgColor=fill)
    if fmt:
        cell.number_format = fmt
    if wrap:
        cell.alignment = Alignment(wrap_text=True, vertical="top")
    return cell


def _widths(ws, m: dict[str, float]) -> None:
    for k, v in m.items():
        ws.column_dimensions[k].width = v


# ---------------------------------------------------------------------------------------
def load_store(cfg: Config) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """(facts, crosswalk, sources). Missing store is a hard error: an empty sheet that looks
    built is worse than one that refuses to build."""
    facts_p = cfg.data_root / "curated" / "market_facts" / "market_facts.parquet"
    cw_p = cfg.reference / "market_geo_crosswalk.xlsx"
    src_p = cfg.reference / "market_sources.xlsx"
    if not facts_p.is_file():
        raise FileNotFoundError(
            f"no market store at {facts_p}\n"
            f"  run: .venv/Scripts/python.exe scripts/10_ingest_market_intel.py")
    if not cw_p.is_file():
        raise FileNotFoundError(
            f"no crosswalk at {cw_p}\n"
            f"  run: .venv/Scripts/python.exe scripts/_build_market_geo_crosswalk.py")
    facts = pd.read_parquet(facts_p)
    cw = pd.read_excel(cw_p, sheet_name="crosswalk")
    sources = pd.read_excel(src_p, sheet_name="sources") if src_p.is_file() else pd.DataFrame()
    return facts, cw, sources


def best_values(facts: pd.DataFrame) -> dict[tuple[str, str], dict]:
    """(entity_key, metric) -> the winning row. use=0 values are excluded entirely."""
    live = facts[facts["use"] == 1].copy()
    live["_rank"] = live.confidence.map(CONF_RANK).fillna(9)
    live = live.sort_values(["_rank", "as_of_year"], ascending=[True, False])
    out: dict[tuple[str, str], dict] = {}
    for r in live.to_dict("records"):
        out.setdefault((str(r["entity_key"]), str(r["metric"])), r)
    return out


def bs_evidence(cfg: Config, cw: pd.DataFrame) -> dict[str, dict]:
    """Per destination: do we sell it, and how much. Degrades to empty without gold."""
    gold = cfg.data_root / "gold" / "sales_bi.parquet"
    if not gold.is_file():
        return {}
    try:
        import duckdb
        con = duckdb.connect()
        d = con.execute(f"""
            SELECT "Arrival airport" AS apt,
                   COUNT(DISTINCT "Ticket number") AS tickets,
                   SUM("Balance (base currency)") AS net
            FROM read_parquet('{gold.as_posix()}')
            WHERE "Transaction" = 'Ticket payment' AND "Arrival airport" IS NOT NULL
              AND "Pure Date" >= DATE '{datetime.now().year}-01-01'
            GROUP BY 1""").df().set_index("apt")
    except Exception:                       # a mid-rebuild gold must not block the sheet
        return {}
    out = {}
    for r in cw.to_dict("records"):
        apts = [a.strip() for a in str(r.get("airport_codes") or "").split(",") if a.strip()]
        hit = [a for a in apts if a in d.index]
        if hit:
            out[str(r["code_given"])] = {
                "serves": True,
                "tickets": int(d.loc[hit, "tickets"].sum()),
                "net_cr": float(d.loc[hit, "net"].sum()) / 1e7,
                "airports": ", ".join(hit)}
        else:
            out[str(r["code_given"])] = {"serves": False}
    return out


def assemble(facts, cw, cfg) -> pd.DataFrame:
    """One row per destination with the chosen value AND its provenance side by side."""
    best = best_values(facts)
    bs = bs_evidence(cfg, cw)
    rows = []
    for r in cw.to_dict("records"):
        code, iso = str(r["code_given"]), str(r["country_iso3"])
        rec = {"no": r.get("no"), "template_label": r["template_label"],
               "city": r["city_name"], "code": code, "country": r["country_name_template"],
               "iso3": iso, "tier": r.get("tier", "")}
        picks = {
            "country_pop": best.get((iso, "population_total")),
            "country_dia": best.get((iso, "bd_diaspora_stock"))
                           or best.get((iso, "bd_overseas_employment_cum")),
            "city_pop": best.get((code, "population_total")),
            "city_dia": best.get((code, "bd_diaspora_city")),
        }
        for name, p in picks.items():
            rec[name] = float(p["value"]) if p else None
            rec[f"{name}_src"] = p["source_id"] if p else ""
            rec[f"{name}_yr"] = int(p["as_of_year"]) if p else ""
            rec[f"{name}_conf"] = p["confidence"] if p else ""
            rec[f"{name}_note"] = p["method_note"] if p else ""
        e = bs.get(code, {})
        rec["bs_serves"] = "Y" if e.get("serves") else "N"
        rec["bs_tickets"] = e.get("tickets")
        rec["bs_net_cr"] = e.get("net_cr")
        rec["remarks"] = _remarks(rec, picks, e, r)
        rows.append(rec)
    return pd.DataFrame(rows)


def _remarks(rec: dict, picks: dict, e: dict, cwrow: dict) -> str:
    """The one free column the template gives us. Spend it on what the reader cannot see:
    which basis the diaspora figure uses, what is missing and why, and our own demand."""
    bits = []
    p = picks["country_dia"]
    if p is not None:
        basis = ("UN DESA resident stock" if p["metric"] == "bd_diaspora_stock"
                 else "BMET cumulative departures (not residents)")
        bits.append(f"Diaspora basis: {basis} {p['as_of_year']}")
    else:
        bits.append("No Bangladeshi-diaspora figure published for this country")
    if picks["city_dia"] is None:
        bits.append("no city-level Bangladeshi figure exists")
    elif picks["city_dia"]["confidence"] in ("apportioned", "press_estimate"):
        bits.append(f"city figure is {CONF_LABEL[picks['city_dia']['confidence']]}")
    if picks["city_pop"] is None:
        note = str(cwrow.get("notes") or "")
        bits.append(f"no city population in UN WUP"
                    + (f" ({note})" if note and "METRO" not in note else ""))
    if str(cwrow.get("code_kind")) == "metro":
        bits.append(f"{rec['code']} is a metro code covering {cwrow.get('airport_codes')}")
    if e.get("serves"):
        bits.append(f"BS flies this: {e['tickets']:,} tickets YTD, {e['net_cr']:,.1f} cr")
    else:
        bits.append("BS does not serve it")
    return ". ".join(bits) + "."


# ---------------------------------------------------------------------------------------
def write_submission(df: pd.DataFrame, out: Path) -> Path:
    """The template's original shape. Nothing added, nothing renamed."""
    wb = Workbook()
    ws = wb.active
    ws.title = "Sheet1"
    heads = ["", "Destinations", "Total Population in Country",
             "Bangladeshi living in Country", "Total population in City ",
             "Bangladeshi living in City ", "Most connected City By Air ", "Remarks "]
    for j, h in enumerate(heads, start=1):
        _c(ws, 1, j, h, bold=True, fill=BLUE, color=WHITE, wrap=True)
    ws.row_dimensions[1].height = 32
    r = 2
    for x in df.to_dict("records"):
        for j, v in enumerate([x["no"], x["template_label"], x["country_pop"],
                               x["country_dia"], x["city_pop"], x["city_dia"],
                               None,                       # air column: not sourced yet
                               x["remarks"]], start=1):
            _c(ws, r, j, v, fmt=FI if j in (3, 4, 5, 6) else None, wrap=(j == 8))
        r += 1
    _widths(ws, {"A": 5, "B": 26, "C": 18, "D": 20, "E": 18, "F": 20, "G": 20, "H": 74})
    ws.freeze_panes = "C2"
    wb.save(out)
    return out


def write_evidence(df: pd.DataFrame, sources: pd.DataFrame, out: Path, stats: dict) -> Path:
    wb = Workbook()
    ws = wb.active
    ws.title = "City Wise Data"
    heads = [("#", 5), ("Destination", 24), ("City", 15), ("IATA", 7), ("Country", 15),
             ("ISO3", 7),
             ("Country population", 15), ("src", 12), ("yr", 6), ("basis", 20),
             ("BD in country", 15), ("src", 12), ("yr", 6), ("basis", 22),
             ("City population", 15), ("src", 12), ("yr", 6), ("basis", 20),
             ("BD in city", 15), ("src", 12), ("yr", 6), ("basis", 22),
             ("BS serves", 9), ("BS tickets YTD", 12), ("BS net cr", 10),
             ("Remarks", 70)]
    _c(ws, 1, 1, "CITY WISE DATA - EVIDENCE PACK  ·  every figure with its source, year and "
                 "how far it can be trusted", bold=True, size=12, color=WHITE, fill=NAVY)
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=len(heads))
    _c(ws, 2, 1, "'basis' is the confidence attached to that value. APPORTIONED means WE split "
                 "a country figure across cities: it is a model, not a count, and it is only "
                 "here at all if an analyst signed it off. A blank cell means the source was "
                 "silent, and the Remarks column says which one.", wrap=True)
    ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=len(heads))
    ws.row_dimensions[2].height = 40
    for j, (h, w) in enumerate(heads, start=1):
        _c(ws, 3, j, h, bold=True, fill=BLUE, color=WHITE, wrap=True)
        ws.column_dimensions[ws.cell(row=3, column=j).column_letter].width = w
    ws.row_dimensions[3].height = 30
    r = 4
    for x in df.to_dict("records"):
        vals = [x["no"], x["template_label"], x["city"], x["code"], x["country"], x["iso3"]]
        for k in ("country_pop", "country_dia", "city_pop", "city_dia"):
            vals += [x[k], x[f"{k}_src"], x[f"{k}_yr"],
                     CONF_LABEL.get(x[f"{k}_conf"], "")]
        vals += [x["bs_serves"], x["bs_tickets"], x["bs_net_cr"], x["remarks"]]
        for j, v in enumerate(vals, start=1):
            fmt = FI if j in (7, 11, 15, 19, 24) else ("#,##0.0" if j == 25 else None)
            fill = None
            if j in (10, 14, 18, 22) and isinstance(v, str) and "APPORTION" in v:
                fill = AMBER
            if j in (7, 11, 15, 19) and v is None:
                fill = REDL
            _c(ws, r, j, v, fmt=fmt, fill=fill, wrap=(j == len(heads)))
        r += 1
    ws.auto_filter.ref = f"A3:Z{r-1}"
    ws.freeze_panes = "G4"

    s = wb.create_sheet("Sources")
    _c(s, 1, 1, "SOURCES", bold=True, size=12, color=WHITE, fill=NAVY)
    s.merge_cells(start_row=1, start_column=1, end_row=1, end_column=7)
    if len(sources):
        cols = [c for c in sources.columns]
        for j, h in enumerate(cols, start=1):
            _c(s, 2, j, str(h), bold=True, fill=BLUE, color=WHITE, wrap=True)
        for i, rec in enumerate(sources.to_dict("records"), start=3):
            for j, cname in enumerate(cols, start=1):
                _c(s, i, j, rec.get(cname), wrap=True)
        _widths(s, {"A": 18, "B": 34, "C": 22, "D": 40, "E": 30, "F": 12, "G": 10, "H": 14,
                    "I": 60})

    n = wb.create_sheet("Coverage")
    _c(n, 1, 1, "WHAT IS FILLED, AND WHAT IS NOT", bold=True, size=12, color=WHITE, fill=NAVY)
    n.merge_cells(start_row=1, start_column=1, end_row=1, end_column=3)
    for j, h in enumerate(["Column", "Filled", "Gap and why"], start=1):
        _c(n, 2, j, h, bold=True, fill=BLUE, color=WHITE)
    for i, (a, b, c) in enumerate(stats["coverage"], start=3):
        _c(n, i, 1, a, bold=True)
        _c(n, i, 2, b)
        _c(n, i, 3, c, wrap=True)
        n.row_dimensions[i].height = 30
    _widths(n, {"A": 30, "B": 12, "C": 96})
    wb.save(out)
    return out


# ---------------------------------------------------------------------------------------
def generate(params: dict | None = None, cfg: Config | None = None) -> Path:
    params = params or {}
    cfg = cfg or load_config(validate=False)
    facts, cw, sources = load_store(cfg)
    df = assemble(facts, cw, cfg)

    filled = {k: int(df[k].notna().sum()) for k in
              ("country_pop", "country_dia", "city_pop", "city_dia")}
    held = int((facts["use"] == 0).sum())
    cov = [
        ("Total Population in Country", f"{filled['country_pop']}/63", "World Bank WDI."),
        ("Bangladeshi living in Country", f"{filled['country_dia']}/63",
         "UN DESA publishes a Bangladesh-origin row only where the destination country's own "
         "statistics identify country of birth. Where it is silent, BMET is used if present "
         "and the Remarks column says so."),
        ("Total population in City", f"{filled['city_pop']}/63",
         "UN WUP 2025 urban centre. Sharjah is absent because DEGURBA merges it into the Dubai "
         "urban centre, so it is left blank rather than given Dubai's figure."),
        ("Bangladeshi living in City", f"{filled['city_dia']}/63",
         "Published for the UK, US, Canada, Australia and New Zealand only. Everywhere else it "
         "can only be apportioned from the country figure, which is a model, not a count, and "
         "is withheld until signed off."),
        ("Most connected City By Air", "0/63",
         "Means: where does this city's population travel to most. That is origin-destination "
         "traffic and needs a traffic source per country."),
        ("Values held pending sign-off", str(held),
         "apportioned or press values sitting at use=0. They are in the store but not on any "
         "sheet."),
    ]
    out_dir = Path(params.get("out_dir") or cfg.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    sub = write_submission(df, out_dir / "City_wise_data_SUBMISSION.xlsx")
    write_evidence(df, sources, out_dir / "City_wise_data_EVIDENCE.xlsx", {"coverage": cov})
    print(f"[city-market] {len(df)} destinations")
    for a, b, _ in cov:
        print(f"    {a:<32} {b}")
    return sub
