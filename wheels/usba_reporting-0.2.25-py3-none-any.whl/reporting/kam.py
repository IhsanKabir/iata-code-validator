"""
reporting/kam.py — THE single rule for turning a sales-person cell into a KAM bucket.

THE PROBLEM
-----------
`dim_customer.sales_person` does not always hold one person. For 1,552 agencies it holds TWO,
comma-joined in a single cell — "Md Atikur Rahman, Nafiuzzaman" — because the source agency list
assigns some accounts to a pair rather than an individual. 73.49 cr of July sales (10.8%) sits
on such a cell.

Reports that group by that raw string produce three wrong things:

  1. A two-name cell becomes a "KAM" in its own right, so the summary lists people who do not
     exist as individuals.
  2. A person who owns some agencies alone AND shares others appears in TWO rows, and neither
     shows their real book. Shubajit Ganguly, Rathin Bepary and Yeachir Arafat were each split
     this way on the July DSR.
  3. Worse, when two people share a cell, that shared revenue is counted in BOTH their lines if
     anything sums per person — Shubajit's and Rathin's rows both carried the same +769,981.

THE RULE
--------
Group by `bucket()`:
  * a single-name cell  -> that person
  * a two-or-more-name cell -> one SHARED bucket, labelled "SHARED — A + B" (names sorted, so
    "A, B" and "B, A" land in the same bucket)
  * an empty cell -> "(no KAM assigned)"

So every agency belongs to exactly ONE bucket, every person appears in at most one solo row,
and shared revenue is reported once, visibly, instead of being silently doubled or invented.

WHY NOT SPLIT THE MONEY 50/50: because nobody has told us the split. Halving an agency's
revenue between two people would be a fabricated number that could feed a payout. Reporting it
once, clearly labelled as shared, is the honest answer — and it makes the size of the
unattributed pool obvious, which is what gets it fixed at source.
"""
from __future__ import annotations

import re

NO_KAM = "(no KAM assigned)"
SHARED_PREFIX = "SHARED — "

# The source uses a comma between names. A slash or ampersand shows up occasionally too.
_SPLIT = re.compile(r"\s*[,/&]\s*|\s+and\s+", re.I)


def people(value) -> list[str]:
    """Every individual named in a sales-person cell, in stable sorted order.

    '' / NaN -> []. 'A' -> ['A']. 'B, A' -> ['A', 'B'] (sorted so the pair keys identically
    however it was typed).
    """
    s = "" if value is None else str(value).strip()
    if not s or s.lower() in {"nan", "none", "nat"} or s == NO_KAM:
        return []
    parts = [p.strip() for p in _SPLIT.split(s) if p.strip()]
    return sorted(dict.fromkeys(parts))          # de-dup, keep deterministic order


def is_shared(value) -> bool:
    """True when the cell names more than one person."""
    return len(people(value)) > 1


def bucket(value) -> str:
    """The label a report should GROUP BY. One agency -> exactly one bucket."""
    p = people(value)
    if not p:
        return NO_KAM
    if len(p) == 1:
        return p[0]
    return SHARED_PREFIX + " + ".join(p)


def owners(value) -> list[str]:
    """Who to notify about this agency — both names on a shared cell.

    Use for MAILING (each owner should receive their shared agencies), never for summing money,
    because the same agency appears under both owners here.
    """
    return people(value)


def is_shared_bucket(label) -> bool:
    """True when a bucket label produced by bucket() is the shared kind."""
    return str(label).startswith(SHARED_PREFIX)
