"""
_build_june2026_target_capacity.py
==================================

A CAPACITY-AWARE June 2026 target, replacing the old bottom-up number.

WHY THIS EXISTS
---------------
The previous target (554.7 cr) was built bottom-up (agent history x growth tiers)
and was never:
  * de-seasonalised for June's genuine demand slump, or
  * checked against the moving Eid/Hajj holidays, or
  * reconciled to total seat capacity.

This report fixes all three and tells the story so a non-technical reader gets it.

METHODOLOGY (researched - airline revenue management + moving-holiday seasonal adj)
----------------------------------------------------------------------------------
We blend three signals into ONE commit target, then test it against capacity.

  Signal A  Trailing x Seasonal (multiplicative decomposition, the RM standard):
              trailing 5-mo average (Dec-Apr)  x  June seasonal index
              June index = June-2025 / 12-month average  (June runs ~0.91 of avg)

  Signal B  Eid/Hajj-adjusted YoY anchor (anchor to the HOLIDAY, not the calendar):
              June-2025 actual  x  (1 + network growth)  x  Hajj-overlap factor
              -> June 2025 had Eid mid-month + Hajj May15-Jun15 (15 in-month days);
                 June 2026 has Eid at the very start + Hajj ends Jun 1 (~1 in-month
                 day), so international Hajj demand is LOWER -> small downward factor.

  Commit target = weighted blend of A and B.

Then the CAPACITY lens (the part that was missing):
  * convert the revenue target to seat-legs via realised per-sector YIELD,
  * express as a LOAD FACTOR (capacity fulfilment %),
  * set a STRETCH target at the proven peak load factor,
  * project a roadmap toward OPTIMAL load factor (~88% - NOT 100%; research shows
    100% is never the goal: best-in-class Ryanair ~96%, optimal LF balances yield).

OUTPUT
------
  logs/June2026_Target_Capacity.xlsx
    1. Target Summary        the number, how full it makes the planes, the story
    2. Methodology           every input + the blend, in plain words, with sources
    3. Zone-wise             per zone: target, Dom/Int split, share of capacity fill
    4. Route Utilisation     per route: capacity, target fill, gap (agent/route view)
    5. Roadmap & Projection  commit -> stretch -> optimal, and years-to-optimal

Run:
    .venv/Scripts/python.exe scripts/_build_june2026_target_capacity.py

Stack: duckdb + pandas + openpyxl (pinned).
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

import duckdb
import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from ..config import load_config
from ..common import build_rate_sql as _rate_sql

_CFG = load_config()                       # frozen-aware data root (ANALYSIS_HOME -> settings -> dev)
WAREHOUSE = _CFG.warehouse
SALES_GLOB = _CFG.sales_glob
ROOT = _CFG.data_root
LOGS = _CFG.logs
FLIGHT_LOADS = (_CFG.data_root / "curated" / "flight_loads" / "flight_loads.parquet").as_posix()
TARGET_WB = LOGS / "Agent_Targets_2026-06.xlsx"
OUTPUT = _CFG.output_dir / "June2026_Target_Capacity.xlsx"


def build_rate_sql() -> str:               # keep existing no-arg call sites working
    return _rate_sql(_CFG)
CR = 1e7
DOM = "('DAC','CGP','CXB','ZYL','JSR','RJH','BZL','SPD')"
# Latest Zenith forward snapshot (current June load) — AUTO-PICKED: the newest
# zenith_flight_loads_*.xlsx in Documents/Downloads (timestamp in the filename),
# so a fresh pull is used automatically. None -> the live section is skipped.
def _newest_zenith_pull() -> "Path | None":
    candidates = []
    for folder in (Path.home() / "Documents", Path.home() / "Downloads"):
        try:
            candidates += list(folder.glob("zenith_flight_loads_*.xlsx"))
        except OSError:
            pass
    return max(candidates, key=lambda p: p.name) if candidates else None


CURRENT_LOADS = _newest_zenith_pull()
# flights on/before the pull's capture date are near-final; after = still building
SNAPSHOT_CUTOFF = (f"{CURRENT_LOADS.name[20:24]}-{CURRENT_LOADS.name[24:26]}-{CURRENT_LOADS.name[26:28]}"
                   if CURRENT_LOADS else "2026-06-07")
# human labels derived from the cutoff so sheet text always matches the data
# (these used to be hardcoded "Jun 7" and silently went stale on a fresh pull)
_CUT_DAY = int(SNAPSHOT_CUTOFF[8:10])
CUT_LBL = f"Jun {_CUT_DAY}"                  # e.g. "Jun 10"  (snapshot day)
SELL_LBL = f"Jun {_CUT_DAY + 1}-30"          # e.g. "Jun 11-30" (still-selling window)
DOM_SET = {"DAC", "CGP", "CXB", "ZYL", "JSR", "RJH", "BZL", "SPD"}

# ---- METHODOLOGY KNOBS (transparent + tunable) ------------------------------
TRAILING = ("2025-12-01", "2026-04-30")   # 5-month baseline window
YOY_GROWTH = 0.00      # network YoY growth (May'26 vs May'25 ran -3%; hold flat — growth applied as GROWTH_UPLIFT below)
HAJJ_FACTOR = 0.97     # June'26 has far less in-month Hajj overlap than June'25
W_SEASONAL, W_YOY = 0.50, 0.50            # blend weights for signals A and B
PROVEN_STRETCH = None  # set from data (proven peak LF)
OPTIMAL_LF = 0.90      # research-backed optimal (NOT 100%; best-in-class ~96%); above proven peak
GROWTH_UPLIFT = 1.05   # +5% growth on the target AMOUNT (analyst directive 2026-06-12). Applied to the
                       # per-seat YIELD so every revenue figure (commit, gross, channel split, zone/route/
                       # agent cascade) rises 5% together while seats & 90% LF stay fixed.
PROJ_SCENARIOS = [("Conservative", 0.015), ("Moderate", 0.025), ("Aggressive", 0.040)]

# ---- palette ----------------------------------------------------------------
NAVY="1F3864"; BLUE_MED="2E5395"; BLUE_LIGHT="D9E1F2"; GREY_L="F2F2F2"; GREY_T="7F7F7F"
GREEN="00B050"; GREEN_F="C6EFCE"; GREEN_T="006100"; AMBER="FFC000"; AMBER_F="FFEB9C"
AMBER_T="9C6500"; RED="C00000"; RED_F="FFC7CE"; WHITE="FFFFFF"; BLACK="000000"; TEAL="2E8B9E"
THIN=Side(style="thin",color="BFBFBF"); BORDER=Border(left=THIN,right=THIN,top=THIN,bottom=THIN)
F_INT="#,##0"; F_CR='#,##0.0" cr"'; F_PCT="0.0%"; F_TK="#,##0"


# ======================================================================= #
def parse_current() -> dict | None:
    """Parse the latest Zenith forward snapshot into the current June load.

    The 'Seats Available' column reads like '5/410 99%' = available / capacity /
    load-factor. Booked = capacity - available. We split the month at the snapshot
    cutoff: flights on/before are near-final (realised), after are still building.
    """
    if not CURRENT_LOADS or not CURRENT_LOADS.exists():
        return None
    df = pd.read_excel(CURRENT_LOADS, sheet_name="Flight Loads")
    df.columns = [str(c).strip() for c in df.columns]
    sa = next(c for c in df.columns if "Seats Available" in c)
    o = next(c for c in df.columns if c == "Origin")
    dd = next(c for c in df.columns if c == "Destination")
    dcol = next(c for c in df.columns if "Flight Date" in c)

    def p(s):
        m = re.match(r"\s*(\d+)\s*/\s*(\d+)\s+(\d+)%", str(s))
        return (int(m.group(1)), int(m.group(2))) if m else (None, None)

    df["avail"], df["cap"] = zip(*df[sa].map(p))
    df = df.dropna(subset=["cap"]).copy()
    df["booked"] = df["cap"] - df["avail"]
    df["sector"] = df.apply(
        lambda r: "Domestic" if str(r[o]).strip() in DOM_SET and str(r[dd]).strip() in DOM_SET
        else "International", axis=1)
    df["dt"] = pd.to_datetime(df[dcol], format="%d/%m/%Y", errors="coerce")
    df["flown"] = df["dt"] <= pd.Timestamp(SNAPSHOT_CUTOFF)

    def lf(g):
        c = g["cap"].sum(); return (c, g["booked"].sum(), g["booked"].sum() / c if c else 0)
    cap, bk, total_lf = lf(df)
    out = {"seats": cap, "booked": bk, "total_lf": total_lf,
           "lo": df["dt"].min(), "hi": df["dt"].max()}
    for sec in ["Domestic", "International"]:
        _, _, out[f"{sec.lower()}_lf"] = lf(df[df["sector"] == sec])
    _, _, out["flown_lf"] = lf(df[df["flown"]])
    _, _, out["building_lf"] = lf(df[~df["flown"]])
    out["flown_seats"] = df[df["flown"]]["cap"].sum()
    out["building_seats"] = df[~df["flown"]]["cap"].sum()
    # upcoming-only (not yet flown) seat LF — the true forward position
    up = df[~df["flown"]]
    out["upcoming_lf"] = up["booked"].sum() / up["cap"].sum() if up["cap"].sum() else 0
    out["upcoming_seats"] = up["cap"].sum()
    # per-route CURRENT bookings (whole month) — replaces the stale parquet routes
    rt = (df.groupby([df["Leg Route"] if "Leg Route" in df.columns else df.iloc[:, 7], "sector"])
            .agg(cap=("cap", "sum"), booked=("booked", "sum")).reset_index())
    rt.columns = ["leg_route", "sector", "cap", "booked"]
    rt["available"] = rt["cap"] - rt["booked"]
    rt["fill"] = rt["booked"] / rt["cap"]
    out["routes"] = rt
    # per-day load factor (the booking curve) + per-sector-period matrix
    daily = (df.groupby(df["dt"].dt.date)
               .agg(cap=("cap", "sum"), booked=("booked", "sum"),
                    dow=("Day", "first") if "Day" in df.columns else ("cap", "size"))
               .reset_index())
    daily.columns = ["date", "cap", "booked", "dow"]
    daily["lf"] = daily["booked"] / daily["cap"]
    daily["flown"] = pd.to_datetime(daily["date"]) <= pd.Timestamp(SNAPSHOT_CUTOFF)
    out["daily"] = daily
    sp = (df.groupby(["sector", "flown"]).agg(cap=("cap", "sum"), booked=("booked", "sum")))
    out["sector_period"] = sp  # index (sector, flown) -> cap, booked
    # raw per-flight-per-date frame for the by-flight x by-date load-factor matrix
    # (one row per leg per day; the sheet pivots dates into columns to the right)
    lr = "Leg Route" if "Leg Route" in df.columns else df.columns[7]
    out["flights"] = pd.DataFrame({
        "flight": df["Flight Number"].astype(str).str.strip() if "Flight Number" in df.columns else "",
        "route": df[lr].astype(str).str.strip(),
        "sector": df["sector"].values,
        "date": df["dt"].dt.date,
        "cap": df["cap"].astype(int),
        "booked": df["booked"].astype(int),
        "aircraft": df["Aircraft"].astype(str).str.strip() if "Aircraft" in df.columns else "",
        "std": df["Departure Time"].astype(str).str.strip() if "Departure Time" in df.columns else "",
    })
    return out


def gather() -> dict:
    con = duckdb.connect(str(WAREHOUSE), read_only=True); rate = build_rate_sql()

    def sale_expr(prefix=""):
        # PRIMARY SALE MEASURE = NET sale, ALL transactions (DSR net).
        # NET = (base fare - commission) + tax = balance - commission   [user's definition]
        # Ticket payment & Reissuance -> fare*(1-rate)+(bal-fare);  Refund/Void/Cancel/
        # Penalty -> balance (a NEGATIVE, so cancellations are netted out). Counting
        # refunds keeps revenue matched to actual flown seats (a refunded ticket's seat
        # is released, so it must not be credited). Same expression flows everywhere.
        b=f'{prefix}bal'; f=f'{prefix}fare'; r=f'{prefix}rate'; t=f'{prefix}txn'
        return (f"CASE WHEN {t} IN ('Ticket payment','Reissuance Adjustment') THEN {f}*(1-{r})+({b}-{f}) "
                f"WHEN {t} IN ('Refund','Ticket void','Cancel refund','Penalty') THEN {b} ELSE 0 END")

    base_cte = f"""
        SELECT "Date"::DATE d, CAST("Transaction" AS VARCHAR) txn,
               CAST("Balance (base currency)" AS DOUBLE) bal,
               CAST("Total without taxe (base currency)" AS DOUBLE) fare, ({rate}) rate,
               CAST("Departure airport" AS VARCHAR) dep, CAST("Arrival airport" AS VARCHAR) arr,
               CASE WHEN CAST("Departure airport" AS VARCHAR) IN {DOM}
                     AND CAST("Arrival airport" AS VARCHAR) IN {DOM} THEN 'Domestic'
                    ELSE 'International' END sector,
               CASE WHEN CAST("Customer ID" AS VARCHAR)='BO-1 Central Reservation' THEN '11246131'
                    ELSE regexp_replace(CAST("Customer ID" AS VARCHAR),'[.]0$','') END customer_id
        FROM read_parquet('{SALES_GLOB}', hive_partitioning=1, union_by_name=1) WHERE "Date" IS NOT NULL
    """

    # Monthly net sale (for trailing avg, June 2025, seasonal index)
    monthly = con.execute(f"""
        WITH s AS ({base_cte})
        SELECT date_trunc('month',d) m, SUM({sale_expr()}) net FROM s GROUP BY 1 ORDER BY 1
    """).df()
    monthly["cr"] = monthly["net"] / CR
    mser = monthly.set_index(monthly["m"].astype(str).str[:7])["cr"]

    trailing = mser.loc["2025-12":"2026-04"].mean()
    june25 = mser.loc["2025-06"]
    avg12 = mser.loc["2025-06":"2026-05"].mean()
    june_index = june25 / avg12

    # June 2025 Dom/Int split
    j25 = con.execute(f"""
        WITH s AS ({base_cte})
        SELECT sector, SUM({sale_expr()}) net FROM s
        WHERE d BETWEEN DATE '2025-06-01' AND DATE '2025-06-30' GROUP BY 1
    """).df().set_index("sector")["net"]
    dom_share = j25.get("Domestic", 0) / j25.sum()

    # Per-sector realised yield — FARE WINDOW = Apr 1-May 30 (recent fares; March ran
    # higher and was over-stating it). NET sale (all transactions) divided by the seats
    # actually booked in the SAME window, so refunds and their released seats cancel.
    #   NET   = balance - commission per booked seat (PRIMARY, drives the whole engine)
    #   GROSS = full balance per booked seat (kept ONLY for the commission bridge note)
    YIELD_WIN = ("2026-04-01", "2026-05-30")
    # GROSS (Ticket Payment) = full balance of ticket-payment rows, before commission =
    # the topline ticket revenue. Shown beside NET on the summary & Road-to-90% sheets.
    tp_gross_expr = "CASE WHEN txn='Ticket payment' THEN bal ELSE 0 END"
    sec = con.execute(f"""
        WITH s AS ({base_cte})
        SELECT sector, SUM({sale_expr()}) net, SUM({tp_gross_expr}) gross FROM s
        WHERE d BETWEEN DATE '{YIELD_WIN[0]}' AND DATE '{YIELD_WIN[1]}' GROUP BY 1
    """).df().set_index("sector")
    sec_net = sec["net"]   # primary net sale by sector
    # seats booked in the SAME fare window (matched denominator for the yield)
    legs_y = con.execute(f"""
        SELECT sector, SUM(booked) bk FROM read_parquet('{FLIGHT_LOADS}')
        WHERE flight_date BETWEEN DATE '{YIELD_WIN[0]}' AND DATE '{YIELD_WIN[1]}' GROUP BY 1
    """).df().set_index("sector")
    # full historical fill (Mar5-May30) = the proven-PEAK load factor (best-ever)
    legs = con.execute(f"""
        SELECT sector, SUM(booked) bk, SUM(capacity) cap
        FROM read_parquet('{FLIGHT_LOADS}') WHERE UPPER(period)='HISTORICAL' GROUP BY 1
    """).df().set_index("sector")
    # net/gross TK per seat (realised Apr-May), uplifted by GROWTH_UPLIFT so the target amount
    # carries the +5% growth while seats & load factor stay fixed. gr = gross/net is unaffected.
    yld = {s: sec.loc[s, "net"] / legs_y.loc[s, "bk"] * GROWTH_UPLIFT for s in ["Domestic", "International"]}       # net TK/seat (PRIMARY, +5%)
    yld_gross = {s: sec.loc[s, "gross"] / legs_y.loc[s, "bk"] * GROWTH_UPLIFT for s in ["Domestic", "International"]}  # gross TK/seat (+5%)
    proven_lf = {s: legs.loc[s, "bk"] / legs.loc[s, "cap"] for s in ["Domestic", "International"]}

    # June capacity by sector — RECONCILED to the LIVE Jun-7 flight-load file
    # (the parquet FORWARD pull was a stale, larger schedule). One capacity number
    # now flows through the whole report. Falls back to the parquet if no file.
    cur = parse_current()
    if cur is not None and cur.get("routes") is not None:
        cap = (cur["routes"].groupby("sector")
               .agg(cap=("cap", "sum"), booked=("booked", "sum"), available=("available", "sum")))
    else:
        cap = con.execute(f"""
            SELECT sector, SUM(capacity) cap, SUM(booked) booked, SUM(available) available
            FROM read_parquet('{FLIGHT_LOADS}') WHERE UPPER(period)='FORWARD' GROUP BY 1
        """).df().set_index("sector")
    routes = con.execute(f"""
        SELECT leg_route, sector, SUM(capacity) cap, SUM(booked) booked, SUM(available) available,
               SUM(booked)*1.0/SUM(capacity) fill
        FROM read_parquet('{FLIGHT_LOADS}') WHERE UPPER(period)='FORWARD'
        GROUP BY leg_route, sector HAVING SUM(capacity) > 500 ORDER BY cap DESC
    """).df()

    # Per-zone x sector baseline (Dec-Apr) for allocation + Dom/Int split.
    # Full channel bucketing so EVERY channel is counted (geographic Zone-N +
    # Z-Counter / Z-Web / Z-Mobi App / Z-Unmapped / Z-Corporate). Same precedence
    # as the DSR / daily_zone_sales; amounts are net ticket sales (sale_expr).
    zone = con.execute(f"""
        WITH s AS ({base_cte})
        SELECT
          CASE
            WHEN c.customer_name ILIKE 'CORP %'    THEN 'Z-Corporate'
            WHEN c.primary_channel = 'OFFICE'      THEN 'Z-Counter'
            WHEN c.primary_channel = 'CALL_CENTER' THEN 'Z-Counter'
            WHEN c.primary_channel = 'WEB'         THEN 'Z-Web'
            WHEN c.primary_channel = 'MOBILE'      THEN 'Z-Mobi App'
            WHEN c.zone LIKE 'Zone-%'              THEN c.zone
            WHEN c.primary_channel = 'AGENCY'      THEN 'Z-Unmapped'
            ELSE 'Z-Unmapped'
          END AS zone,
          s.sector, SUM({sale_expr('s.')}) net,
          COUNT(*) FILTER (WHERE s.txn='Ticket payment') tickets
        FROM s LEFT JOIN dim_customer c ON s.customer_id=c.customer_id
        WHERE s.d BETWEEN DATE '{TRAILING[0]}' AND DATE '{TRAILING[1]}'
        GROUP BY 1,2
    """).df()

    bucket = """CASE
        WHEN c.customer_name ILIKE 'CORP %'    THEN 'Z-Corporate'
        WHEN c.primary_channel = 'OFFICE'      THEN 'Z-Counter'
        WHEN c.primary_channel = 'CALL_CENTER' THEN 'Z-Counter'
        WHEN c.primary_channel = 'WEB'         THEN 'Z-Web'
        WHEN c.primary_channel = 'MOBILE'      THEN 'Z-Mobi App'
        WHEN c.zone LIKE 'Zone-%'              THEN c.zone
        WHEN c.primary_channel = 'AGENCY'      THEN 'Z-Unmapped'
        ELSE 'Z-Unmapped' END"""
    # June month-to-date actual by zone (Jun 1 -> snapshot) — for the achievement sheet
    mtd = con.execute(f"""
        WITH s AS ({base_cte})
        SELECT {bucket} AS zone, s.sector, SUM({sale_expr('s.')}) net
        FROM s LEFT JOIN dim_customer c ON s.customer_id=c.customer_id
        WHERE s.d BETWEEN DATE '2026-06-01' AND DATE '{SNAPSHOT_CUTOFF}'
        GROUP BY 1,2
    """).df()
    # Group key: B2C web/mobile -> 'App/Web', counters -> 'Counter', corporate ->
    # 'Corporate'; real agencies stay individual (their own customer_id).
    akey = """CASE
        WHEN c.primary_channel IN ('WEB','MOBILE')        THEN 'App/Web'
        WHEN c.primary_channel IN ('OFFICE','CALL_CENTER') THEN 'Counter'
        WHEN c.customer_name ILIKE 'CORP %'                THEN 'Corporate'
        ELSE s.customer_id END"""
    BUCKETS = "('App/Web','Counter','Corporate')"
    # Per-agent 5-mo Dom/Int baseline — for the per-agent target sheet
    agents = con.execute(f"""
        WITH s AS ({base_cte}),
        e AS (
            SELECT s.txn, s.bal, s.fare, s.rate, s.sector, s.d,
                   {akey} AS akey, c.customer_name cn, c.zone cz,
                   c.agent_type catype, c.sales_person csp, c.primary_channel cchan
            FROM s LEFT JOIN dim_customer c ON s.customer_id=c.customer_id
            WHERE s.d BETWEEN DATE '{TRAILING[0]}' AND DATE '{TRAILING[1]}'
        )
        SELECT akey AS customer_id,
               MAX(CASE WHEN akey IN {BUCKETS} THEN akey ELSE cn END) AS customer_name,
               MAX(CASE WHEN akey IN {BUCKETS} THEN akey ELSE cz END) AS "zone",
               MAX(CASE WHEN akey IN {BUCKETS} THEN 'B2C/Direct' ELSE catype END) AS agent_type,
               MAX(csp) AS sales_person, MAX(cchan) AS channel,
               SUM({sale_expr('e.')}) FILTER (WHERE e.sector='Domestic')     dom,
               SUM({sale_expr('e.')}) FILTER (WHERE e.sector='International') intl
        FROM e GROUP BY akey
    """).df()
    # REAL June actual sales — read straight from the parquet, Jun 1 -> whatever the
    # latest ingested day is (auto-extends as more June days land). No file dependency.
    JUNE_START = "2026-06-01"
    mtd_actual = con.execute(f"""
        WITH s AS ({base_cte})
        SELECT {bucket} AS zone, s.sector, SUM({sale_expr('s.')}) net,
               COUNT(*) FILTER (WHERE s.txn='Ticket payment') tickets
        FROM s LEFT JOIN dim_customer c ON s.customer_id=c.customer_id
        WHERE s.d >= DATE '{JUNE_START}'
        GROUP BY 1,2
    """).df()
    jinfo = con.execute(f"""SELECT MAX("Date"::DATE), COUNT(DISTINCT "Date"::DATE)
        FROM read_parquet('{SALES_GLOB}', hive_partitioning=1, union_by_name=1)
        WHERE "Date"::DATE >= DATE '{JUNE_START}'""").fetchone()
    june_hi, june_days = (str(jinfo[0]), int(jinfo[1])) if jinfo and jinfo[1] else (None, 0)
    # June ACTUAL sales by route (from parquet)
    june_route = con.execute(f"""
        WITH s AS ({base_cte})
        SELECT (s.dep||'-'||s.arr) AS route, SUM({sale_expr('s.')}) net,
               COUNT(*) FILTER (WHERE s.txn='Ticket payment') tickets
        FROM s WHERE s.d >= DATE '{JUNE_START}' GROUP BY 1
    """).df()
    # Per-route revenue-per-seat (net ticket-sale basis): scale route avg_fare to the sector net yield
    rf = con.execute(f"""
        SELECT leg_route, sector, SUM(capacity) cap,
               SUM(capacity*avg_fare)/NULLIF(SUM(capacity),0) avg_fare
        FROM read_parquet('{FLIGHT_LOADS}') WHERE UPPER(period)='FORWARD' GROUP BY 1,2
    """).df()
    # Per-agent-per-route 5-mo sales (net + tickets) — for the agent route breakdown
    agent_routes = con.execute(f"""
        WITH s AS ({base_cte}),
        e AS (
            SELECT s.txn, s.bal, s.fare, s.rate, s.sector, s.dep, s.arr,
                   {akey} AS akey, c.customer_name cn, c.zone cz
            FROM s LEFT JOIN dim_customer c ON s.customer_id=c.customer_id
            WHERE s.d BETWEEN DATE '{TRAILING[0]}' AND DATE '{TRAILING[1]}' AND s.txn='Ticket payment'
        )
        SELECT akey AS customer_id,
               MAX(CASE WHEN akey IN {BUCKETS} THEN akey ELSE cn END) AS "name",
               MAX(CASE WHEN akey IN {BUCKETS} THEN akey ELSE cz END) AS zn,
               (e.dep||'-'||e.arr) AS route, e.sector,
               SUM({sale_expr('e.')}) net,
               COUNT(*) FILTER (WHERE e.txn='Ticket payment') tickets
        FROM e GROUP BY akey, route, e.sector
    """).df()
    # (con stays open — the network-growth queries near the end still need it)
    # route yield dict (scale avg_fare so each sector still totals to its net yield)
    route_yield = {}
    if len(rf):
        sec_af = {s: (g['cap']*g['avg_fare']).sum()/g['cap'].sum() for s,g in rf.groupby('sector')}
        for _,x in rf.iterrows():
            base = sec_af.get(x['sector'],0)
            route_yield[x['leg_route']] = (x['avg_fare']*yld[x['sector']]/base) if base else yld[x['sector']]

    # Zone Area + Sales Person (zone manager) labels
    zlabels = {}
    try:
        zm = pd.read_excel(ROOT / "reference" / "zone_managers.xlsx", sheet_name="zone_managers")
        for _, row in zm.iterrows():
            zlabels[str(row["Zone"])] = (str(row.get("Area", "") or "").replace("nan", ""),
                                         str(row.get("Zone Manager", "") or "").replace("nan", ""))
    except Exception:
        pass

    # ---- the blend ----------------------------------------------------------
    sig_a = trailing * june_index                       # trailing x seasonal
    sig_b = june25 * (1 + YOY_GROWTH) * HAJJ_FACTOR     # Eid/Hajj-adjusted YoY
    commit = W_SEASONAL * sig_a + W_YOY * sig_b          # cr

    # split commit Dom/Int by June-2025 demand mix
    commit_dom = commit * dom_share
    commit_int = commit * (1 - dom_share)

    # capacity fulfilment of the commit target, by sector
    def lf(rev_cr, sector):
        legs_needed = (rev_cr * CR) / yld[sector]
        return legs_needed, legs_needed / cap.loc[sector, "cap"]
    dom_legs, dom_lf = lf(commit_dom, "Domestic")
    int_legs, int_lf = lf(commit_int, "International")
    total_cap = cap["cap"].sum()
    commit_lf = (dom_legs + int_legs) / total_cap

    # stretch target = proven peak LF per sector (revenue at current yield)
    stretch_dom = cap.loc["Domestic", "cap"] * proven_lf["Domestic"] * yld["Domestic"] / CR
    stretch_int = cap.loc["International", "cap"] * proven_lf["International"] * yld["International"] / CR
    stretch = stretch_dom + stretch_int
    peak_lf = (proven_lf["Domestic"] * cap.loc["Domestic", "cap"]
               + proven_lf["International"] * cap.loc["International", "cap"]) / cap["cap"].sum()
    # ---- COMMITTED TARGET: fill BOTH sectors to 90% load factor ------------
    # Per directive: the target is 90% LF on Domestic AND 90% on International.
    # The demand blend is kept as the FLOOR; proven-peak stretch is a milestone.
    demand_floor, demand_floor_lf = commit, commit_lf
    demand_a, demand_b = sig_a, sig_b
    TARGET_LF = 0.90
    commit_dom = cap.loc["Domestic", "cap"] * TARGET_LF * yld["Domestic"] / CR
    commit_int = cap.loc["International", "cap"] * TARGET_LF * yld["International"] / CR
    commit = commit_dom + commit_int
    commit_lf = TARGET_LF
    dom_lf, int_lf = TARGET_LF, TARGET_LF
    dom_legs = cap.loc["Domestic", "cap"] * TARGET_LF
    int_legs = cap.loc["International", "cap"] * TARGET_LF
    # sector-consistent revenue at each ladder rung (avoids the 'optimal < peak' artefact)
    optimal_rev = (cap.loc["Domestic", "cap"] * OPTIMAL_LF * yld["Domestic"]
                   + cap.loc["International", "cap"] * OPTIMAL_LF * yld["International"]) / CR
    full_rev = (cap.loc["Domestic", "cap"] * yld["Domestic"]
                + cap.loc["International", "cap"] * yld["International"]) / CR

    # ---- GROSS (Ticket Payment) counterparts, shown beside NET on the sheets ----
    # gr[sector] = gross-up factor (gross ticket fare / net fare). Gross of any sale =
    # Dom-part x gr_dom + Int-part x gr_int. Capacity rungs scale gross yld directly.
    gr = {s: yld_gross[s] / yld[s] for s in ["Domestic", "International"]}
    commit_gross = commit_dom * gr["Domestic"] + commit_int * gr["International"]
    stretch_gross = stretch_dom * gr["Domestic"] + stretch_int * gr["International"]   # proven-peak milestone
    demand_floor_gross = demand_floor * (commit_gross / commit) if commit else demand_floor
    full_rev_g = (cap.loc["Domestic", "cap"] * yld_gross["Domestic"]
                  + cap.loc["International", "cap"] * yld_gross["International"]) / CR
    optimal_rev_g = OPTIMAL_LF * full_rev_g

    # ---- "both sectors at 90% LF" sale, split by sales channel ---------------
    # Whole engine is NET ticket-payment, so the headline yld IS net. Seats x 90% x
    # net Rev/seat, then peel off the 3 DIRECT channels (Counter / Web / Mobile) via
    # the baseline mix to leave the AGENT sale. lf90_gross uses the gross yield purely
    # for the 'gross incl. commission' reference in the bridge note.
    DIRECT_Z = ["Z-Counter", "Z-Web", "Z-Mobi App"]
    lf90, lf90_excl, lf90_gross, direct_share = {}, {}, {}, {}
    for s in ["Domestic", "International"]:
        g = cap.loc[s, "cap"] * OPTIMAL_LF * yld[s] / CR         # all-channel NET sale @ 90% LF (cr)
        zs = zone[zone["sector"] == s]; tot = zs["net"].sum()
        dsh = zs[zs["zone"].isin(DIRECT_Z)]["net"].sum() / tot if tot else 0.0
        direct_share[s] = dsh; lf90[s] = g; lf90_excl[s] = g * (1 - dsh)
        lf90_gross[s] = cap.loc[s, "cap"] * OPTIMAL_LF * yld_gross[s] / CR

    # ---- Network-growth evidence (Mar5-May30 realised, completed flights) ----
    # International routes that flew >=90% full = proven, demand-constrained (spill).
    growth_add = con.execute(f"""
        SELECT leg_route, COUNT(*) legs, SUM(capacity) cap, SUM(booked) booked,
               SUM(booked)*1.0/SUM(capacity) lf, MEDIAN(capacity) acseats
        FROM read_parquet('{FLIGHT_LOADS}') WHERE UPPER(period)='HISTORICAL' AND capacity>0 AND sector='International'
        GROUP BY 1 HAVING SUM(capacity)>2000 AND SUM(booked)*1.0/SUM(capacity)>=0.90
        ORDER BY lf DESC, cap DESC
    """).df()
    growth_add["yld"] = growth_add["leg_route"].map(lambda r: route_yield.get(r) or yld["International"])
    # Chronically empty domestic routes (do NOT add — candidates to trim / redeploy).
    growth_trim = con.execute(f"""
        SELECT leg_route, SUM(capacity) cap, SUM(booked) booked, SUM(booked)*1.0/SUM(capacity) lf
        FROM read_parquet('{FLIGHT_LOADS}') WHERE UPPER(period)='HISTORICAL' AND capacity>0 AND sector='Domestic'
        GROUP BY 1 HAVING SUM(capacity)>2000 AND SUM(booked)*1.0/SUM(capacity)<0.60 ORDER BY cap DESC
    """).df()
    # Where the empty seats sit (drives the 'why 90% is the ceiling' block).
    cl = con.execute(f"""
        WITH legs AS (SELECT booked, capacity, booked*1.0/capacity lf FROM read_parquet('{FLIGHT_LOADS}')
                      WHERE UPPER(period)='HISTORICAL' AND capacity>0)
        SELECT SUM(capacity-booked) empty,
               SUM(CASE WHEN lf<0.70 THEN capacity-booked ELSE 0 END) empty_low,
               SUM(CASE WHEN lf>=0.90 THEN capacity-booked ELSE 0 END) empty_full FROM legs
    """).df().iloc[0]
    ceiling = {"empty": float(cl["empty"]), "empty_low": float(cl["empty_low"]), "empty_full": float(cl["empty_full"])}
    con.close()

    return dict(
        monthly=mser, trailing=trailing, june25=june25, avg12=avg12, june_index=june_index,
        sig_a=sig_a, sig_b=sig_b, commit=commit, commit_dom=commit_dom, commit_int=commit_int,
        dom_share=dom_share, yld=yld, proven_lf=proven_lf, cap=cap, routes=routes, zone=zone,
        dom_lf=dom_lf, int_lf=int_lf, commit_lf=commit_lf, total_cap=total_cap,
        dom_legs=dom_legs, int_legs=int_legs,
        stretch=stretch, stretch_dom=stretch_dom, stretch_int=stretch_int,
        peak_lf=peak_lf, optimal_rev=optimal_rev, full_rev=full_rev,
        j25=j25, sec_net=sec_net, cur=cur,
        demand_floor=demand_floor, demand_floor_lf=demand_floor_lf,
        demand_a=demand_a, demand_b=demand_b,
        mtd=mtd, agents=agents, zlabels=zlabels, legs=legs, mtd_actual=mtd_actual,
        june_route=june_route, route_yield=route_yield, agent_routes=agent_routes,
        june_days=june_days, june_hi=june_hi,
        lf90=lf90, lf90_excl=lf90_excl, lf90_gross=lf90_gross, direct_share=direct_share,
        yld_gross=yld_gross, legs_y=legs_y,
        commit_gross=commit_gross, demand_floor_gross=demand_floor_gross,
        full_rev_g=full_rev_g, optimal_rev_g=optimal_rev_g, stretch_gross=stretch_gross,
        growth_add=growth_add, growth_trim=growth_trim, ceiling=ceiling,
    )


def zone_sort_key(z):
    """Natural order: Zone-1, Zone-2 ... Zone-11A, then the Z- channel buckets."""
    m = re.match(r"Zone-(\d+)([A-Za-z]*)$", str(z))
    if m:
        return (0, int(m.group(1)), m.group(2))
    return (1, 0, str(z))


# ======================================================================= #
def cell(ws,r,c,v,*,fmt=None,bold=False,size=11,color=BLACK,fill=None,align="left",
         wrap=False,border=False,italic=False):
    x=ws.cell(row=r,column=c,value=v)
    x.font=Font(bold=bold,size=size,color=color,name="Calibri",italic=italic)
    x.alignment=Alignment(horizontal=align,vertical="center",wrap_text=wrap)
    if fmt: x.number_format=fmt
    if fill: x.fill=PatternFill("solid",fgColor=fill)
    if border: x.border=BORDER
    return x

def bar(ws,row,c0,n,pct,color):
    f=max(0,min(n,round(pct*n)))
    for i in range(n):
        cc=ws.cell(row=row,column=c0+i)
        cc.fill=PatternFill("solid",fgColor=(color if i<f else "E7E6E6"))


# ======================================================================= #
def s_summary(wb,d):
    ws=wb.active; ws.title="Target Summary"; ws.sheet_view.showGridLines=False
    for c in range(1,16): ws.column_dimensions[get_column_letter(c)].width=8.4
    ws.merge_cells("A1:O1")
    cell(ws,1,1,"US-BANGLA AIRLINES  •  JUNE 2026 SALES TARGET (capacity-aware)",
         bold=True,size=16,color=WHITE,fill=NAVY,align="center"); ws.row_dimensions[1].height=30
    ws.merge_cells("A2:O2")
    cell(ws,2,1,"All amounts = NET sale (base fare − commission + tax = balance − commission), all transactions incl. refunds.  "
                "Per-seat fares from Apr–May. Built from trailing avg + Eid/Hajj-adjusted last-June + seasonality, set on seat capacity.",
         size=9.5,color=GREY_T,fill=BLUE_LIGHT,align="center",italic=True)
    cards=[("TARGET (90% LF)",f"{d['commit']:,.0f} cr",f"net · gross {d['commit_gross']:,.0f} · Dom {d['commit_dom']:,.0f} + Intl {d['commit_int']:,.0f}",BLUE_MED),
           ("FILLS THE PLANE",f"{d['commit_lf']*100:.0f}%",f"of {int(d['total_cap']):,} seats (90% both sectors)",GREEN),
           ("DEMAND FLOOR",f"{d['demand_floor']:,.0f} cr",f"with no push ({d['demand_floor_lf']*100:.0f}% LF)",GREY_T)]
    for i,(lab,val,sub,acc) in enumerate(cards):
        c0=1+i*5; c1=c0+4
        for rr,(txt,sz,col,fl) in zip((4,5,6),[(lab,9.5,WHITE,acc),(val,18,acc,GREY_L),(sub,8.5,GREY_T,GREY_L)]):
            ws.merge_cells(start_row=rr,start_column=c0,end_row=rr,end_column=c1)
            cell(ws,rr,c0,txt,bold=(rr<6),size=sz,color=col,fill=fl,align="center",wrap=(rr==6))
    ws.row_dimensions[5].height=28; ws.row_dimensions[6].height=22
    cur=d.get('cur') or {}; jd=int(d.get('june_days',6) or 6)
    sold=(d['mtd_actual']['net'].sum()/CR) if d.get('mtd_actual') is not None else 0
    # Numbers at a glance (your simplified table)
    cell(ws,8,1,"THE NUMBERS AT A GLANCE",bold=True,size=12,color=NAVY)
    glance=[("Seat capacity (June)",f"{int(d['total_cap']):,}",""),
            (f"Load factor now (Jun {jd} snapshot)",f"{cur.get('total_lf',0)*100:.0f}%","incl. flown 88% + upcoming 41%"),
            (f"Sold so far (Jun 1-{jd})",f"{sold:,.0f} cr",f"{sold/d['commit']*100:.0f}% of target — on pace"),
            ("Usual trend (demand floor)",f"{d['demand_floor']:,.0f} cr","what June does on its own"),
            (f"★ Target ({d['commit_lf']*100:.0f}% LF both sectors)",f"{d['commit']:,.0f} cr",f"≈ {d['commit_gross']:,.0f} cr gross (ticket pmt)  ·  Dom {d['commit_dom']:,.0f} + Intl {d['commit_int']:,.0f}"),
            ("Stretch to close (variance)",f"{d['commit']-d['demand_floor']:,.0f} cr","mostly domestic fare action")]
    r=9
    for lab,val,note in glance:
        star=lab.startswith("★"); fl=AMBER_F if star else GREY_L
        ws.merge_cells(start_row=r,start_column=1,end_row=r,end_column=6)
        cell(ws,r,1,lab,bold=True,size=10.5,color=AMBER_T if star else NAVY,fill=fl,border=True)
        ws.merge_cells(start_row=r,start_column=7,end_row=r,end_column=9)
        cell(ws,r,7,val,bold=True,size=11.5,color=AMBER_T if star else BLACK,fill=fl,align="center",border=True)
        ws.merge_cells(start_row=r,start_column=10,end_row=r,end_column=15)
        cell(ws,r,10,note,size=9,color=GREY_T,fill=fl,border=True)
        ws.row_dimensions[r].height=18; r+=1
    r+=1
    # The roadmap ladder (merged below the summary)
    cell(ws,r,1,"THE ROADMAP — empty plane → full   (Net & Gross-Ticket Payment)",bold=True,size=12,color=NAVY); r+=1
    clf=cur.get('total_lf',0)
    rungs=[(f"Booked now ({CUT_LBL})",clf,clf*d['full_rev'],clf*d['full_rev_g']),
           ("Demand floor (no push)",d['demand_floor_lf'],d['demand_floor'],d['demand_floor_gross']),
           ("Proven peak (last year's best)",d['peak_lf'],d['stretch'],d['stretch_gross']),
           ("★ TARGET — 90% both sectors",d['commit_lf'],d['commit'],d['commit_gross']),
           ("Full capacity (reference only)",1.0,d['full_rev'],d['full_rev_g'])]
    for h,(c0,c1) in zip(["Level","Load\nfactor","Seats filled","Net (cr)","Gross-Ticket\nPmt (cr)"],[(1,4),(5,6),(7,9),(10,12),(13,15)]):
        ws.merge_cells(start_row=r,start_column=c0,end_row=r,end_column=c1)
        cell(ws,r,c0,h,bold=True,size=9,color=NAVY,fill=BLUE_LIGHT,align="center",wrap=True,border=True)
    ws.row_dimensions[r].height=24; r+=1
    for lab,lf,rev,gross in rungs:
        star=lab.startswith("★"); fl=AMBER_F if star else (RED_F if "Full" in lab else None)
        ws.merge_cells(start_row=r,start_column=1,end_row=r,end_column=4)
        cell(ws,r,1,lab,bold=star,size=10,color=AMBER_T if star else (RED if "Full" in lab else NAVY),fill=fl,border=True)
        ws.merge_cells(start_row=r,start_column=5,end_row=r,end_column=6)
        cell(ws,r,5,lf,fmt=F_PCT,align="center",bold=True,fill=fl,border=True)
        ws.merge_cells(start_row=r,start_column=7,end_row=r,end_column=9)
        cell(ws,r,7,int(d['total_cap']*lf),fmt=F_INT,align="center",fill=fl,border=True)
        ws.merge_cells(start_row=r,start_column=10,end_row=r,end_column=12)
        cell(ws,r,10,rev,fmt=F_CR,align="center",bold=star,fill=fl,border=True)
        ws.merge_cells(start_row=r,start_column=13,end_row=r,end_column=15)
        cell(ws,r,13,gross,fmt=F_CR,align="center",bold=star,color=(AMBER_T if star else BLUE_MED),fill=fl,border=True)
        r+=1
    ws.merge_cells(start_row=r,start_column=1,end_row=r+1,end_column=15)
    cell(ws,r,1,f"TARGET = 90% load factor on BOTH sectors ({d['commit']:,.0f} cr net / {d['commit_gross']:,.0f} cr gross) — above our proven peak ({d['peak_lf']*100:.0f}%). "
                f"The job is to fill the empty DOMESTIC seats (today ~{d['proven_lf']['Domestic']*100:.0f}% → 90%); going PAST 90% needs more flights, not lower fares.",size=9.5,color=NAVY,wrap=True)
    r+=2
    # --- IF BOTH SECTORS HIT 90% LF — NET sale + GROSS, split by channel ---
    cell(ws,r,1,"THE TARGET BY CHANNEL — 90% LF both sectors  (net, with gross beside)",bold=True,size=12,color=NAVY); r+=1
    lf90=d.get('lf90',{}); lf90e=d.get('lf90_excl',{}); lf90g=d.get('lf90_gross',{}); dsh=d.get('direct_share',{})
    dom90=lf90.get('Domestic',0); int90=lf90.get('International',0); tot90=dom90+int90
    dome=lf90e.get('Domestic',0); inte=lf90e.get('International',0); tote=dome+inte
    # GROSS (ticket payment) versions, incl. the excl-direct split
    dom90g=lf90g.get('Domestic',0); int90g=lf90g.get('International',0); tot90g=dom90g+int90g
    domeg=dom90g*(1-dsh.get('Domestic',0)); integ=int90g*(1-dsh.get('International',0)); toteg=domeg+integ
    for h,(c0,c1) in zip(["Net sale at 90% LF","Domestic","International","Total","Gross-Ticket\nPmt (cr)"],
                         [(1,5),(6,8),(9,11),(12,15),(16,22)]):
        ws.merge_cells(start_row=r,start_column=c0,end_row=r,end_column=c1)
        cell(ws,r,c0,h,bold=True,size=9.5,color=NAVY,fill=BLUE_LIGHT,align="center",wrap=True,border=True)
    r+=1
    rows90=[("All channels (Seats × 90% × Rev/seat)",dom90,int90,tot90,tot90g,None),
            ("Less direct: Counter / Web / Mobile",-(dom90-dome),-(int90-inte),-(tot90-tote),-(tot90g-toteg),GREY_L),
            ("★ Agent / agency sale (excl. direct)",dome,inte,tote,toteg,AMBER_F)]
    for lab,dv,iv,tv,gv,fl in rows90:
        star=lab.startswith("★")
        ws.merge_cells(start_row=r,start_column=1,end_row=r,end_column=5)
        cell(ws,r,1,lab,bold=star,size=10,color=AMBER_T if star else NAVY,fill=fl,border=True)
        for v,(c0,c1) in zip((dv,iv,tv),[(6,8),(9,11),(12,15)]):
            ws.merge_cells(start_row=r,start_column=c0,end_row=r,end_column=c1)
            cell(ws,r,c0,v,fmt=F_CR,align="center",bold=star,color=AMBER_T if star else BLACK,fill=fl,border=True)
        ws.merge_cells(start_row=r,start_column=16,end_row=r,end_column=22)
        cell(ws,r,16,gv,fmt=F_CR,align="center",bold=star,color=(AMBER_T if star else BLUE_MED),fill=fl,border=True)
        r+=1
    ws.merge_cells(start_row=r,start_column=1,end_row=r,end_column=15)
    cell(ws,r,1,f"This IS the target: 90% LF on both sectors = {tot90:,.0f} cr net (≈ {tot90g:,.0f} cr gross, before commission). "
                f"Stripping out OUR OWN direct channels — Counter/Web/App (≈{dsh.get('Domestic',0)*100:.0f}% of domestic, "
                f"{dsh.get('International',0)*100:.0f}% of international baseline) — leaves {tote:,.0f} cr net that AGENTS / AGENCIES must drive.",
         size=9,color=GREY_T,wrap=True)
    ws.row_dimensions[r].height=26; r+=2
    # Short story
    cell(ws,r,1,"WHAT TO DO (plain words)",bold=True,size=12,color=NAVY); r+=1
    cd=cur.get('domestic_lf',0); yratio=d['yld']['International']/d['yld']['Domestic']
    story=[
        f"•  June is normally quiet (Eid & Hajj fell in MAY), so the easy number is only {d['demand_floor']:,.0f} cr. The TARGET is {d['commit']:,.0f} cr — fill EVERY plane to 90% on both sectors.",
        f"•  The extra {d['commit']-d['demand_floor']:,.0f} cr is almost all DOMESTIC — those flights are only ~{cd*100:.0f}% booked and must roughly double. That needs FARE PROMOTIONS, not just agent effort.",
        f"•  A domestic seat earns ~{yratio:.0f}x less than international, so domestic fills the plane while international brings the money: push domestic for load factor, protect international for revenue.",
    ]
    for line in story:
        ws.merge_cells(start_row=r,start_column=1,end_row=r,end_column=15)
        cell(ws,r,1,line,size=10,wrap=True,fill=GREEN_F if line==story[0] else None)
        ws.row_dimensions[r].height=28; r+=1


def s_method(wb,d):
    ws=wb.create_sheet("Methodology"); ws.sheet_view.showGridLines=False
    ws.column_dimensions["A"].width=34; ws.column_dimensions["B"].width=20; ws.column_dimensions["C"].width=58
    cell(ws,1,1,"How the target was built (and why)",bold=True,size=14,color=NAVY)
    rows=[
        ("INPUT","VALUE","WHAT IT IS / WHY",True),
        ("Trailing 5-mo average (Dec-Apr)",f"{d['trailing']:,.0f} cr","Recent demand level, before seasonality.",False),
        ("June seasonal index",f"{d['june_index']:.2f}","June-2025 ÷ 12-month average. June runs below the year average (slump).",False),
        ("Signal A = Trailing × Seasonal",f"{d['sig_a']:,.0f} cr","Multiplicative decomposition — the revenue-management standard.",False),
        ("Last June (2025) actual",f"{d['june25']:,.0f} cr","Same-month-last-year anchor.",False),
        ("Network YoY growth",f"{YOY_GROWTH*100:+.0f}%","May'26 vs May'25 ran -3%; held flat (conservative).",False),
        ("Hajj-overlap factor",f"{HAJJ_FACTOR:.2f}","June'26 has far fewer in-month Hajj days than June'25 → less intl lift.",False),
        ("Signal B = Eid/Hajj-adjusted YoY",f"{d['sig_b']:,.0f} cr","Anchored to the HOLIDAY, not the calendar (Eid moved to May).",False),
        ("Blend weights (A : B)",f"{W_SEASONAL:.0%} : {W_YOY:.0%}","Equal trust in the seasonal model and the adjusted YoY.",False),
        ("Demand FLOOR (blend of A & B)",f"{d['demand_floor']:,.0f} cr","Organic June demand. The FLOOR — not the target.",True),
        ("Proven-peak load factor",f"{d['commit_lf']*100:.0f}%","Best-ever sector LF (Dom 81% / Int 89%) — what the planes can fill.",False),
        ("★ AGGRESSIVE TARGET",f"{d['commit']:,.0f} cr","Fill to proven peak. The committed June number (needs domestic fare action).",True),
        ("Domestic yield / seat",f"{d['yld']['Domestic']:,.0f} TK","Net sale per flown domestic seat (cheap).",False),
        ("International yield / seat",f"{d['yld']['International']:,.0f} TK","Net sale per flown international seat (~6× domestic).",False),
        ("Capacity fulfilment",f"{d['commit_lf']*100:.0f}%","Aggressive target ÷ yield → seats ÷ capacity = proven-peak LF.",True),
    ]
    r=3
    for a,b,c,hl in rows:
        fl=NAVY if (hl and a.startswith("★")) else (BLUE_LIGHT if hl else None)
        col=WHITE if (hl and a.startswith("★")) else NAVY if hl else BLACK
        cell(ws,r,1,a,bold=hl,size=10.5,color=col,fill=fl,border=True,wrap=True)
        cell(ws,r,2,b,bold=hl,size=10.5,color=col,fill=fl,border=True,align="center")
        cell(ws,r,3,c,size=10,color=col if hl else GREY_T,fill=fl,border=True,wrap=True)
        ws.row_dimensions[r].height=26; r+=1
    r+=1
    cell(ws,r,1,"Research basis (airline revenue management):",bold=True,color=NAVY); r+=1
    for note in [
        "• Moving holidays (Eid/Ramadan) must be anchored to the holiday, not the month — naive YoY 'can be off by weeks'. (US Census moving-holiday adjustment; ARIMAX Ramadan calendar-variation models.)",
        "• Multiplicative trend×seasonal index (ratio-to-moving-average) is the standard for seasonal sales. (Forecasting: Principles & Practice.)",
        "• 100% load factor is never the goal: best-in-class Ryanair ~96%; optimal LF balances yield vs fill. We target ~88%. (Seeking Alpha; PROS; easietech.)",
        "• Forward bookings look low now and build on a curve — judge fill vs the booking curve, not vs the final target. (Embark Aviation; Reuters Events.)",
    ]:
        ws.merge_cells(start_row=r,start_column=1,end_row=r,end_column=3)
        cell(ws,r,1,note,size=9.5,color=GREY_T,wrap=True); ws.row_dimensions[r].height=30; r+=1


CHANNEL_LABEL = {"Z-Counter": ("Airport & city counters", "Counter team"),
                 "Z-Web": ("Website (B2C)", "Digital team"),
                 "Z-Mobi App": ("Mobile app (B2C)", "Digital team"),
                 "Z-Corporate": ("Corporate accounts", "Corporate desk"),
                 "Z-Unmapped": ("Unassigned agencies", "")}


def s_zone(wb,d):
    ws=wb.create_sheet("Zone-wise"); ws.sheet_view.showGridLines=False
    cell(ws,1,1,"Zone-wise target — Domestic / International + capacity share",bold=True,size=14,color=NAVY)
    cell(ws,2,1,f"Each zone's slice of the {d['commit']:.0f} cr aggressive target, who owns it, and how much of the plane it fills.",size=10,color=GREY_T)
    z=d['zone'].pivot_table(index='zone',columns='sector',values='net',aggfunc='sum').fillna(0)
    for s in ['Domestic','International']:
        if s not in z.columns: z[s]=0.0
    # SECTOR-SPECIFIC scaling so zone Dom totals = aggressive Dom, Int = aggressive Int
    dom_scale=(d['commit_dom']*CR)/z['Domestic'].sum() if z['Domestic'].sum() else 0
    int_scale=(d['commit_int']*CR)/z['International'].sum() if z['International'].sum() else 0
    z['tgt_dom']=z['Domestic']*dom_scale/CR
    z['tgt_int']=z['International']*int_scale/CR
    z['tgt_total']=z['tgt_dom']+z['tgt_int']
    z['legs']=z['tgt_dom']*CR/d['yld']['Domestic']+z['tgt_int']*CR/d['yld']['International']
    z['cap_share']=z['legs']/d['total_cap']
    z=z.sort_values('tgt_total',ascending=False)
    heads=["Zone","Area","Sales Person","Target Dom\n(cr)","Target Intl\n(cr)","Target Total\n(cr)","Dom %","Int %","Capacity\nfill share"]
    widths=[11,30,20,11,11,12,8,8,11]
    for j,(h,w) in enumerate(zip(heads,widths),1):
        cell(ws,4,j,h,bold=True,size=9.5,color=NAVY,fill=BLUE_LIGHT,align="center",wrap=True,border=True)
        ws.column_dimensions[get_column_letter(j)].width=w
    ws.row_dimensions[4].height=28
    zl=d.get('zlabels',{})
    r=5
    for zn,row in z.iterrows():
        if row['tgt_total']<0.3: continue
        stripe=GREY_L if r%2==0 else None
        area,sp=zl.get(zn, CHANNEL_LABEL.get(zn,("","")))
        cell(ws,r,1,zn,bold=True,size=10,color=NAVY,fill=stripe,border=True)
        cell(ws,r,2,area,size=9,fill=stripe,border=True,wrap=True)
        cell(ws,r,3,sp,size=9,fill=stripe,border=True)
        cell(ws,r,4,row['tgt_dom'],fmt=F_CR,align="center",fill=stripe,border=True)
        cell(ws,r,5,row['tgt_int'],fmt=F_CR,align="center",fill=stripe,border=True)
        cell(ws,r,6,row['tgt_total'],fmt=F_CR,align="center",bold=True,fill=stripe,border=True)
        dompct=row['tgt_dom']/row['tgt_total'] if row['tgt_total'] else 0
        cell(ws,r,7,dompct,fmt=F_PCT,align="center",fill=AMBER_F if dompct>0.3 else stripe,border=True)
        cell(ws,r,8,1-dompct,fmt=F_PCT,align="center",fill=stripe,border=True)
        cell(ws,r,9,row['cap_share'],fmt=F_PCT,align="center",fill=stripe,border=True)
        r+=1
    cell(ws,r,1,"TOTAL",bold=True,color=WHITE,fill=NAVY,border=True)
    for cc in (2,3): cell(ws,r,cc,"",fill=NAVY,border=True)
    cell(ws,r,4,z['tgt_dom'].sum(),fmt=F_CR,bold=True,color=WHITE,fill=NAVY,align="center",border=True)
    cell(ws,r,5,z['tgt_int'].sum(),fmt=F_CR,bold=True,color=WHITE,fill=NAVY,align="center",border=True)
    cell(ws,r,6,z['tgt_total'].sum(),fmt=F_CR,bold=True,color=WHITE,fill=NAVY,align="center",border=True)
    cell(ws,r,7,z['tgt_dom'].sum()/z['tgt_total'].sum(),fmt=F_PCT,bold=True,color=WHITE,fill=NAVY,align="center",border=True)
    cell(ws,r,8,z['tgt_int'].sum()/z['tgt_total'].sum(),fmt=F_PCT,bold=True,color=WHITE,fill=NAVY,align="center",border=True)
    cell(ws,r,9,z['cap_share'].sum(),fmt=F_PCT,bold=True,color=WHITE,fill=NAVY,align="center",border=True)


def s_routes(wb,d):
    ws=wb.create_sheet("Route Utilisation"); ws.sheet_view.showGridLines=False
    cell(ws,1,1,"Route-wise target · live bookings · June 1-6 actual",bold=True,size=14,color=NAVY)
    cell(ws,2,1,"Each route's target = its Seats × Target fill % × its OWN Rev/seat. Rev/seat differs by route "
                "(e.g. DAC-DXB earns more per seat than DAC-MCT). 'Booked now' & 'Current fill' are the live Jun-7 snapshot; "
                "'Sold Jun 1-6' is real sales. Amounts in NET (balance − commission) and GROSS (ticket payment).",size=9.5,color=NAVY,wrap=True)
    ws.merge_cells("A2:K2"); ws.row_dimensions[2].height=30
    jd=int(d.get('june_days',6) or 6); pace=jd/30.0
    gr={s:d['yld_gross'][s]/d['yld'][s] for s in ['Domestic','International']}
    heads=["Route","Sector","Seats","Booked\nnow","Current\nfill","Rev/seat\n(TK)","Target\nfill","Target net\n(cr)",f"Sold MTD\n(Jun 1-{jd}, cr)","% sold\nvs target","Target gross\n(cr)"]
    widths=[11,12,9,8,8,10,8,11,12,10,11]
    for j,(h,w) in enumerate(zip(heads,widths),1):
        cell(ws,4,j,h,bold=True,size=9.5,color=NAVY,fill=BLUE_LIGHT,align="center",wrap=True,border=True)
        ws.column_dimensions[get_column_letter(j)].width=w
    ws.row_dimensions[4].height=28
    cur=d.get('cur') or {}
    rdf=cur['routes'].copy() if cur.get('routes') is not None else d['routes'].copy()
    ry=d.get('route_yield',{}); jr=d.get('june_route')
    sold={} if jr is None else dict(zip(jr['route'], jr['net']/CR))
    tgt_lf={'Domestic':d['dom_lf'],'International':d['int_lf']}
    rt=rdf.copy()
    rt['ryield']=rt.apply(lambda x: ry.get(x['leg_route']) if ry.get(x['leg_route']) else d['yld'][x['sector']], axis=1)
    rt['raw']=rt['cap']*rt['sector'].map(tgt_lf)*rt['ryield']
    rt['tgt_sales']=0.0
    for sec,goal in [('Domestic',d['commit_dom']),('International',d['commit_int'])]:
        m=rt['sector']==sec; s=rt.loc[m,'raw'].sum()
        if s: rt.loc[m,'tgt_sales']=rt.loc[m,'raw']/s*goal
    rt['sold']=rt['leg_route'].map(lambda r: sold.get(r,0.0))
    rt['pct']=rt.apply(lambda x: x['sold']/x['tgt_sales'] if x['tgt_sales']>0 else 0,axis=1)
    rt['gross']=rt['tgt_sales']*rt['sector'].map(gr)
    rt=rt[rt['cap']>500]
    r=5; gc=gb=gsale=gsold=ggross=0.0
    def secrow(rr,lab,scap,sbk,ryld,tlf,ssale,ssold,fill,sgross=None):
        cell(ws,rr,1,lab,bold=True,size=11,color=WHITE,fill=fill,border=True)
        cell(ws,rr,2,"",fill=fill,border=True)
        cell(ws,rr,3,int(scap),fmt=F_INT,bold=True,color=WHITE,fill=fill,align="center",border=True)
        cell(ws,rr,4,int(sbk),fmt=F_INT,bold=True,color=WHITE,fill=fill,align="center",border=True)
        cell(ws,rr,5,sbk/scap if scap else 0,fmt=F_PCT,bold=True,color=WHITE,fill=fill,align="center",border=True)
        cell(ws,rr,6,(int(ryld) if ryld else ""),fmt=F_INT,bold=True,color=WHITE,fill=fill,align="center",border=True)
        cell(ws,rr,7,(tlf if tlf else ""),fmt=F_PCT,bold=True,color=WHITE,fill=fill,align="center",border=True)
        cell(ws,rr,8,ssale,fmt=F_CR,bold=True,color=WHITE,fill=fill,align="center",border=True)
        cell(ws,rr,9,ssold,fmt=F_CR,bold=True,color=WHITE,fill=fill,align="center",border=True)
        cell(ws,rr,10,ssold/ssale if ssale else 0,fmt=F_PCT,bold=True,color=WHITE,fill=fill,align="center",border=True)
        cell(ws,rr,11,(sgross if sgross is not None else ""),fmt=F_CR,bold=True,color=WHITE,fill=fill,align="center",border=True)
    for sec in ['Domestic','International']:
        srt=rt[rt['sector']==sec].sort_values('tgt_sales',ascending=False)
        if not len(srt): continue
        scap=srt['cap'].sum(); sbk=srt['booked'].sum(); ssale=srt['tgt_sales'].sum(); ssold=srt['sold'].sum()
        secrow(r,sec,scap,sbk,d['yld'][sec],tgt_lf[sec],ssale,ssold,BLUE_MED,srt['gross'].sum()); r+=1
        for _,x in srt.iterrows():
            stripe=GREY_L if r%2==0 else None
            cell(ws,r,1,x['leg_route'],bold=True,size=10,color=NAVY,fill=stripe,border=True)
            cell(ws,r,2,x['sector'],size=9,fill=stripe,border=True)
            cell(ws,r,3,int(x['cap']),fmt=F_INT,align="center",fill=stripe,border=True)
            cell(ws,r,4,int(x['booked']),fmt=F_INT,align="center",fill=stripe,border=True)
            fc=RED_F if x['fill']<0.4 else AMBER_F if x['fill']<0.7 else GREEN_F
            cell(ws,r,5,x['fill'],fmt=F_PCT,align="center",fill=fc,border=True)
            cell(ws,r,6,int(x['ryield']),fmt=F_INT,align="center",size=9,fill=stripe,border=True)
            cell(ws,r,7,tgt_lf[x['sector']],fmt=F_PCT,align="center",fill=stripe,border=True)
            cell(ws,r,8,x['tgt_sales'],fmt=F_CR,align="center",bold=True,color=NAVY,fill=stripe,border=True)
            cell(ws,r,9,x['sold'],fmt=F_CR,align="center",fill=stripe,border=True)
            pc=x['pct']; pf=GREEN_F if pc>=pace else AMBER_F if pc>=pace*0.5 else RED_F
            cell(ws,r,10,pc,fmt=F_PCT,align="center",fill=pf,border=True)
            cell(ws,r,11,x['gross'],fmt=F_CR,align="center",color=BLUE_MED,fill=stripe,border=True); r+=1
        gc+=scap; gb+=sbk; gsale+=ssale; gsold+=ssold; ggross+=srt['gross'].sum()
    secrow(r,"GRAND TOTAL",gc,gb,None,None,gsale,gsold,NAVY,ggross); r+=2
    ws.merge_cells(start_row=r,start_column=1,end_row=r+1,end_column=11)
    cell(ws,r,1,f"Routes grouped by sector with subtotals. Current fill is the live Jun-7 booking (total {gb/gc*100:.0f}%). 'Rev/seat' is each route's own "
                "revenue per seat (international routes vary a lot), so two routes with the same seats can have very different targets. "
                f"'% sold' = real Jun 1-{jd} sales ÷ the route's whole-month target ({pace*100:.0f}% = on pace).",size=10,color=GREY_T,wrap=True)


def s_roadmap(wb,d):
    ws=wb.create_sheet("Roadmap & Projection"); ws.sheet_view.showGridLines=False
    cell(ws,1,1,"Roadmap — from this target toward full capacity",bold=True,size=14,color=NAVY)
    cell(ws,2,1,f"June seat capacity = {int(d['total_cap']):,} (Domestic {int(d['cap'].loc['Domestic','cap']):,} / International {int(d['cap'].loc['International','cap']):,}). "
                "Each rung shows how many of those seats get filled.",size=10,color=GREY_T,wrap=True)
    ws.merge_cells("A2:G2"); ws.row_dimensions[2].height=24
    dc=d['cap'].loc['Domestic','cap']; ic=d['cap'].loc['International','cap']
    dy=d['yld']['Domestic']; iy=d['yld']['International']; ds=d['dom_share']
    c=d.get("cur") or {}
    rungs=[]
    if d.get("cur"):
        rungs.append((f"Booked now ({CUT_LBL})",c['total_lf'],
                      dc*c.get('domestic_lf',0)*dy/CR, ic*c.get('international_lf',0)*iy/CR,
                      f"All-June {c['total_lf']*100:.0f}% incl. Jun1-7 already flown ({c.get('flown_lf',0)*100:.0f}%); seats still to sell are {c.get('upcoming_lf',0)*100:.0f}% booked"))
    rungs+=[("Demand floor (no push)",d['demand_floor_lf'],d['demand_floor']*ds,d['demand_floor']*(1-ds),
             "Where June drifts on its own"),
            ("★ AGGRESSIVE TARGET",d['commit_lf'],d['commit_dom'],d['commit_int'],
             "Fill to best-ever load factor — the commitment"),
            ("Optimal LF (ceiling)",OPTIMAL_LF,dc*OPTIMAL_LF*dy/CR,ic*OPTIMAL_LF*iy/CR,
             "Research best practice (~90%)"),
            ("Full capacity (100%)",1.0,dc*dy/CR,ic*iy/CR,
             "Reference only — never the goal")]
    heads=["Level","Load\nfactor","Seats\nfilled","Domestic\n(cr)","Intl\n(cr)","Total\n(cr)","What it means"]
    widths=[20,8,11,10,10,11,26]
    for j,(h,w) in enumerate(zip(heads,widths),1):
        cell(ws,4,j,h,bold=True,size=9.5,color=NAVY,fill=BLUE_LIGHT,align="center",wrap=True,border=True)
        ws.column_dimensions[get_column_letter(j)].width=w
    ws.row_dimensions[4].height=26
    r=5
    for lab,lfv,drev,irev,mean in rungs:
        star=lab.startswith("★"); fl=AMBER_F if star else (RED_F if "Full" in lab else None)
        cell(ws,r,1,lab,bold=True,size=10.5,color=AMBER_T if star else (RED if "Full" in lab else NAVY),fill=fl,border=True)
        cell(ws,r,2,lfv,fmt=F_PCT,align="center",bold=True,fill=fl,border=True)
        cell(ws,r,3,int(d['total_cap']*lfv),fmt=F_INT,align="center",fill=fl,border=True)
        cell(ws,r,4,drev,fmt=F_CR,align="center",fill=fl,border=True)
        cell(ws,r,5,irev,fmt=F_CR,align="center",fill=fl,border=True)
        cell(ws,r,6,drev+irev,fmt=F_CR,align="center",bold=True,fill=fl,border=True)
        cell(ws,r,7,mean,size=9.5,fill=fl,border=True,wrap=True)
        ws.row_dimensions[r].height=22; r+=1
    r+=2
    cell(ws,r,1,"WHEN DO WE REACH OPTIMAL CAPACITY (88% LF)?",bold=True,size=12,color=NAVY); r+=1
    cell(ws,r,1,f"Starting point: June's ORGANIC level ~{d['demand_floor_lf']*100:.0f}% LF (the aggressive target is a one-month stretch to "
                f"{d['commit_lf']*100:.0f}%). To make ~{OPTIMAL_LF*100:.0f}% the SUSTAINED norm, gap = {(OPTIMAL_LF-d['demand_floor_lf'])*100:.0f} points, "
                "closed via demand growth + filling empty domestic seats year on year.",
         size=10,color=GREY_T,wrap=True)
    ws.merge_cells(start_row=r,start_column=1,end_row=r,end_column=4); ws.row_dimensions[r].height=38; r+=2
    for j,h in enumerate(["Growth pace","LF gain / yr","Years to 90%","Reaches optimal in"],1):
        cell(ws,r,j,h,bold=True,size=10,color=NAVY,fill=BLUE_LIGHT,align="center",border=True)
    r+=1
    gap=OPTIMAL_LF-d['demand_floor_lf']
    base_year=2026
    for name,pace in PROJ_SCENARIOS:
        yrs=gap/pace
        cell(ws,r,1,name,bold=True,size=10,color=NAVY,border=True)
        cell(ws,r,2,pace,fmt=F_PCT,align="center",border=True)
        cell(ws,r,3,round(yrs,1),align="center",border=True)
        cell(ws,r,4,f"~ June {base_year+int(round(yrs))}",align="center",border=True,
             fill=GREEN_F if yrs<=4 else AMBER_F if yrs<=7 else RED_F)
        r+=1
    r+=1
    cell(ws,r,1,"NOTE: the goal is OPTIMAL load factor (~88%), not 100%. Beyond ~90% the marginal seat sells at a loss and "
                "denied-boardings rise. 'Full capacity' here is a reference line, not a destination.",
         size=9.5,color=RED,italic=True,wrap=True)
    ws.merge_cells(start_row=r,start_column=1,end_row=r+1,end_column=4)


def s_calc(wb,d):
    ws=wb.create_sheet("Calculations"); ws.sheet_view.showGridLines=False
    ws.column_dimensions["A"].width=30; ws.column_dimensions["B"].width=46; ws.column_dimensions["C"].width=16
    cell(ws,1,1,"Methodology & Calculations — how every number is built",bold=True,size=14,color=NAVY)
    cell(ws,2,1,"The whole method in one place: blend a demand FLOOR, show the proven-peak fill as a milestone, then set the TARGET at 90% LF on BOTH sectors. "
                "Headline amounts are NET sale (balance − commission); the GROSS (ticket payment, before commission) is shown beside. Per-seat fares from Apr–May.",
         size=10,color=GREY_T,wrap=True); ws.merge_cells("A2:C2"); ws.row_dimensions[2].height=34
    dn=d['sec_net']['Domestic']/CR; intn=d['sec_net']['International']/CR
    dby=d['legs_y'].loc['Domestic','bk']; iby=d['legs_y'].loc['International','bk']   # Apr-May booked (yield denom)
    db=d['legs'].loc['Domestic','bk']; dcp=d['legs'].loc['Domestic','cap']           # full hist (fill rate)
    ib=d['legs'].loc['International','bk']; icp=d['legs'].loc['International','cap']
    dy=d['yld']['Domestic']; iy=d['yld']['International']
    djc=d['cap'].loc['Domestic','cap']; ijc=d['cap'].loc['International','cap']
    rows=[
        ("STEP","THE MATH","ANSWER",True),
        ("1) Revenue per seat — Domestic",f"{dn:,.1f} cr net ÷ {int(dby):,} seats (Apr-May) × {GROWTH_UPLIFT:g} growth",f"{dy:,.0f} net / {d['yld_gross']['Domestic']:,.0f} gross TK",False),
        ("1) Revenue per seat — International",f"{intn:,.1f} cr ÷ {int(iby):,} seats booked × {GROWTH_UPLIFT:g} growth",f"{iy:,.0f} net / {d['yld_gross']['International']:,.0f} gross TK",False),
        ("2) Best-ever fill — Domestic",f"{int(db):,} seats sold ÷ {int(dcp):,} seats flown",f"{d['proven_lf']['Domestic']*100:.0f}%",False),
        ("2) Best-ever fill — International",f"{int(ib):,} ÷ {int(icp):,}",f"{d['proven_lf']['International']*100:.0f}%",False),
        ("2) Best-ever fill — Blended (milestone)",f"weighted by each sector's seats",f"{d['peak_lf']*100:.0f}%",True),
        ("3) Hajj-overlap factor","June-2025 had 15 Hajj-season days IN June (May15-Jun15);",f"15 days",False),
        (" ","June-2026 has only 1 Hajj day IN June (Hajj ends Jun 1).",f"1 day",False),
        (" ","Fewer Hajj days = less international lift → small -3% cut",f"× 0.97",True),
        ("4) Signal B (last June, adjusted)",f"Last June {d['june25']:,.0f} cr × growth {1+YOY_GROWTH:.2f} × Hajj 0.97",f"{d['demand_b']:,.0f} cr",True),
        ("5) Signal A (average × season)",f"5-mo avg {d['trailing']:,.0f} cr × June season {d['june_index']:.2f} (9% below avg)",f"{d['demand_a']:,.0f} cr",True),
        ("6) Demand FLOOR (easy number)",f"(Signal A {d['demand_a']:,.0f} + Signal B {d['demand_b']:,.0f}) ÷ 2",f"{d['demand_floor']:,.0f} cr",True),
        ("7) TARGET — Domestic",f"{int(djc):,} June seats × {d['dom_lf']*100:.0f}% LF × {dy:,.0f} TK",f"{d['commit_dom']:,.1f} cr",False),
        ("7) TARGET — International",f"{int(ijc):,} seats × {d['int_lf']*100:.0f}% LF × {iy:,.0f} TK",f"{d['commit_int']:,.1f} cr",False),
        ("7) TARGET — TOTAL (net)",f"Domestic {d['commit_dom']:,.0f} + International {d['commit_int']:,.0f}  (90% LF both)",f"{d['commit']:,.0f} cr",True),
        ("7) TARGET — GROSS",f"Same seats × gross ticket fare (before commission)",f"{d['commit_gross']:,.0f} cr",True),
        ("8) Capacity fulfilment",f"target seats {int(d['commit_dom']*CR/dy+d['commit_int']*CR/iy):,} ÷ {int(d['total_cap']):,} June seats",f"{d['commit_lf']*100:.0f}%",True),
    ]
    r=4
    for a,b,c,hl in rows:
        head = a=="STEP"
        fl = NAVY if head else (BLUE_LIGHT if hl else None)
        col = WHITE if head else (NAVY if hl else BLACK)
        cell(ws,r,1,a,bold=(hl or head),size=10,color=col,fill=fl,border=True,wrap=True)
        cell(ws,r,2,b,size=9.5,color=col if (hl or head) else GREY_T,fill=fl,border=True,wrap=True)
        cell(ws,r,3,c,bold=(hl or head),size=10.5,color=col,fill=fl,border=True,align="center")
        ws.row_dimensions[r].height=26; r+=1
    r+=1
    cell(ws,r,1,"Why this method (airline revenue-management basis):",bold=True,size=10,color=NAVY); r+=1
    for note in [
        "• Moving holidays (Eid/Hajj) are anchored to the holiday, not the calendar — Eid & Hajj fell in MAY this year, so June loses their lift (US Census moving-holiday adjustment).",
        "• We blend recent average × season (Signal A) with last-June adjusted for the holiday shift (Signal B) — the standard multiplicative-seasonal approach.",
        "• The FLOOR is what June does on its own; the TARGET is set on CAPACITY (fill to proven-peak load factor) — that's what makes it aggressive but achievable.",
        "• 100% load factor is never the goal: best-in-class ~96%, optimal balances fill vs yield. We aim at our proven peak (~86%).",
    ]:
        ws.merge_cells(start_row=r,start_column=1,end_row=r,end_column=3)
        cell(ws,r,1,note,size=9,color=GREY_T,wrap=True); ws.row_dimensions[r].height=26; r+=1
    # --- WHY ~90% IS THE CEILING (fares fill it once; flights move it) ---
    r+=1
    ce=d.get('ceiling',{}); emp=ce.get('empty',0) or 1; low=ce.get('empty_low',0); full=ce.get('empty_full',0)
    fare_push=d['optimal_rev']-d['commit']
    cell(ws,r,1,"WHY ~90% IS THE CEILING  (fares vs flights)",bold=True,size=11,color=NAVY); r+=1
    crows=[
        ("Empty seats at proven peak (Mar-May)",f"{int(emp):,} seats","",False),
        ("   on chronically-LOW flights (<70%)",f"{int(low):,} = {low/emp*100:.0f}% of empties","fares can't fill — no demand there",False),
        ("   on already-FULL flights (>=90%)",f"{int(full):,} = {full/emp*100:.0f}%","no room to add",False),
        ("   the FILLABLE pool (the rest)",f"{int(emp-low-full):,} = {(emp-low-full)/emp*100:.0f}%","this IS the 86%->90% move",True),
        ("FARE lever (86%->90%, one-time)",f"+{fare_push:.0f} cr net","caps out the fillable pool",True),
        ("FLIGHT lever (repeatable growth)","+16 to +47 cr/mo each","add intl frequency — see Network Growth sheet",True),
    ]
    for a,b,note,hl in crows:
        fl=BLUE_LIGHT if hl else None
        cell(ws,r,1,a,bold=hl,size=9.5,color=NAVY if hl else BLACK,fill=fl,border=True)
        cell(ws,r,2,b,bold=hl,size=9.5,color=NAVY if hl else BLACK,fill=fl,align="center",border=True)
        cell(ws,r,3,note,size=9,color=GREY_T,fill=fl,border=True,wrap=True)
        ws.row_dimensions[r].height=22; r+=1


def zone_achievement_frame(d) -> "pd.DataFrame":
    """Zone-level June target vs achievement — the math behind the 'Target vs
    Achievement' sheet, exposed as a function so other builders (the per-sales-person
    Target Packs) reuse EXACTLY the same numbers instead of re-deriving them.

    Index = zone.  Columns: btd/bti = baseline tickets per month (Dom/Intl, 5-mo avg),
    bs = baseline sales (cr/mo), td/ti/tt = June TARGET net (cr) Dom/Intl/Total,
    ttk = target tickets, sn = sold net (cr) June-to-date, stk = tickets sold,
    ach = sn/tt achievement ratio, leg = target seat-legs, cap = share of June capacity.
    """
    zn_net=d['zone'].pivot_table(index='zone',columns='sector',values='net',aggfunc='sum').fillna(0)
    zn_tkt=d['zone'].pivot_table(index='zone',columns='sector',values='tickets',aggfunc='sum').fillna(0)
    for s in ['Domestic','International']:
        if s not in zn_net: zn_net[s]=0.0
        if s not in zn_tkt: zn_tkt[s]=0.0
    ma=d.get('mtd_actual')
    sold_net=(ma.groupby('zone')['net'].sum()) if ma is not None else {}
    sold_tkt=(ma.groupby('zone')['tickets'].sum()) if ma is not None else {}
    dsc=(d['commit_dom']*CR)/zn_net['Domestic'].sum(); isc=(d['commit_int']*CR)/zn_net['International'].sum()
    tdt=d['cap'].loc['Domestic','cap']*d['proven_lf']['Domestic']     # target dom tickets ~ seat-legs
    tit=d['cap'].loc['International','cap']*d['proven_lf']['International']
    dts=tdt/zn_tkt['Domestic'].sum() if zn_tkt['Domestic'].sum() else 0
    its=tit/zn_tkt['International'].sum() if zn_tkt['International'].sum() else 0
    Z=pd.DataFrame(index=zn_net.index)
    Z['btd']=zn_tkt['Domestic']/5; Z['bti']=zn_tkt['International']/5
    Z['bs']=(zn_net['Domestic']+zn_net['International'])/5/CR
    Z['td']=zn_net['Domestic']*dsc/CR; Z['ti']=zn_net['International']*isc/CR; Z['tt']=Z['td']+Z['ti']
    Z['ttk']=zn_tkt['Domestic']*dts+zn_tkt['International']*its
    Z['sn']=[ (sold_net.get(i,0.0)/CR if hasattr(sold_net,'get') else 0.0) for i in Z.index]
    Z['stk']=[ (sold_tkt.get(i,0.0) if hasattr(sold_tkt,'get') else 0.0) for i in Z.index]
    Z['ach']=[ (s/t if t>0 else 0) for s,t in zip(Z['sn'],Z['tt'])]
    Z['leg']=Z['td']*CR/d['yld']['Domestic']+Z['ti']*CR/d['yld']['International']
    Z['cap']=Z['leg']/d['total_cap']
    return Z[Z['tt']>=0.001].sort_index(key=lambda idx: idx.map(zone_sort_key))


def s_achievement(wb,d):
    ws=wb.create_sheet("Target vs Achievement"); ws.sheet_view.showGridLines=False
    jd=int(d.get('june_days',6) or 6); pace=jd/30.0
    cell(ws,1,1,"Zone-wise Target vs Achievement — June 2026",bold=True,size=14,color=NAVY)
    cell(ws,2,1,f"Baseline = monthly average of the last 5 months. Target = June (aggressive). Achieved = REAL sales for Jun 1-{jd} "
                f"({pace*100:.0f}% of the month, so ~{pace*100:.0f}% achieved = on pace). Tickets + sales, Domestic + International. "
                f"All amounts = net sale (balance − commission, all transactions).",
         size=9.5,color=GREY_T,wrap=True); ws.merge_cells("A2:N2"); ws.row_dimensions[2].height=32
    Z=zone_achievement_frame(d)
    zl=d.get('zlabels',{})
    # grouped header (row 4 bands, row 5 sub-labels)
    bands=[("",1,3,NAVY),("BASELINE (avg/mo)",4,6,BLUE_MED),("JUNE TARGET",7,10,NAVY),("ACHIEVED (Jun 1-%d)"%jd,11,13,BLUE_MED),("Cap",14,14,NAVY)]
    for lab,a,b,fl in bands:
        ws.merge_cells(start_row=4,start_column=a,end_row=4,end_column=b)
        cell(ws,4,a,lab,bold=True,size=9,color=WHITE,fill=fl,align="center",border=True)
    subs=["Zone","Area","Sales Person","Tkt Dom","Tkt Intl","Sales\n(cr)","Dom\n(cr)","Intl\n(cr)","Total\n(cr)","Tickets","Tickets","Sales\n(cr)","Ach\n%","Fill\n%"]
    widths=[10,22,15,8,8,8,8,8,9,9,9,9,8,7]
    for j,(h,w) in enumerate(zip(subs,widths),1):
        cell(ws,5,j,h,bold=True,size=8.5,color=NAVY,fill=BLUE_LIGHT,align="center",wrap=True,border=True)
        ws.column_dimensions[get_column_letter(j)].width=w
    ws.row_dimensions[5].height=24
    r=6
    for zn,x in Z.iterrows():
        stripe=GREY_L if r%2==0 else None
        area,sp=zl.get(zn, CHANNEL_LABEL.get(zn,("","")))
        vals=[zn,area,sp,x['btd'],x['bti'],x['bs'],x['td'],x['ti'],x['tt'],x['ttk'],x['stk'],x['sn'],None,x['cap']]
        fmts=[None,None,None,F_INT,F_INT,'#,##0.0',F_CR,F_CR,F_CR,F_INT,F_INT,F_CR,F_PCT,F_PCT]
        for j,(v,fm) in enumerate(zip(vals,fmts),1):
            al="left" if j<=3 else "center"
            cell(ws,r,j,v if v is not None else x['ach'],fmt=fm,align=al,size=9,
                 bold=(j in (1,9)),color=NAVY if j==1 else BLACK,fill=stripe,border=True,wrap=(j==2))
        ach=x['ach']; ws.cell(r,13).fill=PatternFill("solid",fgColor=(GREEN_F if ach>=pace else AMBER_F if ach>=pace*0.6 else RED_F))
        r+=1
    # TOTAL
    tot=Z.sum()
    cell(ws,r,1,"TOTAL",bold=True,color=WHITE,fill=NAVY,border=True)
    for cc in (2,3): cell(ws,r,cc,"",fill=NAVY,border=True)
    tv=[("4",tot['btd'],F_INT),("5",tot['bti'],F_INT),("6",tot['bs'],'#,##0.0'),("7",tot['td'],F_CR),("8",tot['ti'],F_CR),
        ("9",tot['tt'],F_CR),("10",tot['ttk'],F_INT),("11",tot['stk'],F_INT),("12",tot['sn'],F_CR),
        ("13",tot['sn']/tot['tt'],F_PCT),("14",tot['cap'],F_PCT)]
    for cc,v,fm in tv:
        cell(ws,r,int(cc),v,fmt=fm,bold=True,color=WHITE,fill=NAVY,align="center",border=True)
    r+=2
    c=d.get("cur") or {}
    ws.merge_cells(start_row=r,start_column=1,end_row=r+1,end_column=14)
    cell(ws,r,1,f"Sold {tot['sn']:,.0f} cr in {jd} days = {tot['sn']/tot['tt']*100:.0f}% of the {d['commit']:.0f} cr target — on pace. "
                f"Forward seat bookings: {c.get('total_lf',0)*100:.0f}% all-June (incl. Jun1-7 flown {c.get('flown_lf',0)*100:.0f}%); "
                f"seats still to sell are {c.get('upcoming_lf',0)*100:.0f}% booked — that's the real gap.",size=9.5,color=GREY_T,wrap=True)
    # --- Seats / Booked now / Current fill — the seat inventory behind the target.
    # Zones are sales territories (their agents sell across many routes), so seats
    # and fill can only be shown by SECTOR, not per zone. Same source as Load Factor.
    r+=3
    capf=d.get('cap')
    if capf is not None and 'Domestic' in capf.index:
        cell(ws,r,1,f"SEATS BEHIND THE TARGET  (capacity is by route/sector, not by zone — {CUT_LBL} snapshot)",
             bold=True,size=11,color=NAVY); ws.merge_cells(start_row=r,start_column=1,end_row=r,end_column=6); r+=1
        for j,h in enumerate(["Sector","Seats","Booked now","Current fill","Seats to sell"],1):
            cell(ws,r,j,h,bold=True,size=10,color=NAVY,fill=BLUE_LIGHT,align="center",border=True)
        r+=1
        def crow(rr,lab,cc,bb,fill):
            totrow=(lab=="TOTAL"); fc=WHITE if totrow else BLACK
            cell(ws,rr,1,lab,bold=totrow,size=10,color=fc,fill=fill,border=True)
            cell(ws,rr,2,int(cc),fmt=F_INT,align="center",bold=totrow,color=fc,fill=fill,border=True)
            cell(ws,rr,3,int(bb),fmt=F_INT,align="center",bold=totrow,color=fc,fill=fill,border=True)
            v=bb/cc if cc else 0
            cell(ws,rr,4,v,fmt=F_PCT,align="center",bold=totrow,color=fc,
                 fill=(fill if totrow else (RED_F if v<0.5 else AMBER_F if v<0.8 else GREEN_F)),border=True)
            cell(ws,rr,5,int(cc-bb),fmt=F_INT,align="center",bold=totrow,color=fc,fill=fill,border=True)
        tc=tb=0.0
        for i,sec in enumerate(['Domestic','International']):
            cc=float(capf.loc[sec,'cap']); bb=float(capf.loc[sec,'booked']); tc+=cc; tb+=bb
            crow(r,sec,cc,bb,WHITE if i==0 else GREY_L); r+=1
        crow(r,"TOTAL",tc,tb,NAVY); r+=2
        cell(ws,r,1,"A zone's agents sell across many routes, so seats/fill can't be split by zone — shown by sector above.",
             size=9,italic=True,color=GREY_T); ws.merge_cells(start_row=r,start_column=1,end_row=r,end_column=6); r+=2
    # --- TARGET BY BASIS: net, gross & a separate total WITHOUT Web/Mobile/Counter ---
    gr={s:d['yld_gross'][s]/d['yld'][s] for s in ['Domestic','International']}
    def tg(block): return block['td'].sum()*gr['Domestic']+block['ti'].sum()*gr['International']
    dmask=Z.index.isin(['Z-Counter','Z-Web','Z-Mobi App'])
    cell(ws,r,1,"TARGET BY BASIS — net, gross & a separate total without Web/Mobile/Counter",bold=True,size=11,color=NAVY)
    ws.merge_cells(start_row=r,start_column=1,end_row=r,end_column=9); r+=1
    for (c0,c1),h in [((1,4),"Channel"),((5,6),"Net (cr)"),((7,9),"Gross-Ticket Pmt (cr)")]:
        ws.merge_cells(start_row=r,start_column=c0,end_row=r,end_column=c1)
        cell(ws,r,c0,h,bold=True,size=9.5,color=NAVY,fill=BLUE_LIGHT,align="center",border=True)
    r+=1
    brows=[("All channels",Z['tt'].sum(),tg(Z),None),
           ("less Web / Mobile / Counter",-Z.loc[dmask,'tt'].sum(),-tg(Z.loc[dmask]),GREY_L),
           ("★ Excl. direct — agents / agencies only",Z.loc[~dmask,'tt'].sum(),tg(Z.loc[~dmask]),AMBER_F)]
    for lab,nv,gv,fl in brows:
        star=lab.startswith("★")
        ws.merge_cells(start_row=r,start_column=1,end_row=r,end_column=4)
        cell(ws,r,1,lab,bold=star,size=10,color=AMBER_T if star else NAVY,fill=fl,border=True)
        ws.merge_cells(start_row=r,start_column=5,end_row=r,end_column=6)
        cell(ws,r,5,nv,fmt=F_CR,align="center",bold=star,color=AMBER_T if star else BLACK,fill=fl,border=True)
        ws.merge_cells(start_row=r,start_column=7,end_row=r,end_column=9)
        cell(ws,r,7,gv,fmt=F_CR,align="center",bold=star,color=AMBER_T if star else BLUE_MED,fill=fl,border=True)
        r+=1


def s_agents(wb,d):
    ws=wb.create_sheet("Agent Targets"); ws.sheet_view.showGridLines=False
    cell(ws,1,1,"Per-agent June targets (aggressive 593 cr cascaded down)",bold=True,size=14,color=NAVY)
    a=d['agents'].copy()
    a['dom']=a['dom'].fillna(0); a['intl']=a['intl'].fillna(0)
    a=a[(a['dom']>0)|(a['intl']>0)]
    sum_dom=a['dom'].sum()/CR; sum_int=a['intl'].sum()/CR
    dom_f=d['commit_dom']/sum_dom; int_f=d['commit_int']/sum_int   # share-of-total factors
    a['tgt_dom']=a['dom']/CR*dom_f; a['tgt_int']=a['intl']/CR*int_f
    a['tgt_total']=a['tgt_dom']+a['tgt_int']
    a=a.sort_values('tgt_total',ascending=False)
    # calculation note
    cell(ws,2,1,"HOW EACH AGENT'S TARGET IS SET:  take the agent's last-5-months sales, split Domestic vs International, "
                "and give them their SHARE of the sector goal — so a bigger (and more international) recent seller gets a bigger target.",
         size=9.5,color=NAVY,wrap=True); ws.merge_cells("A2:K2"); ws.row_dimensions[2].height=26
    cell(ws,3,1,f"Target Dom = (your 5-mo Domestic ÷ {sum_dom:,.0f} cr all-agents) × 57.7 cr   "
                f"[= 5-mo Dom × {dom_f:.3f}].    "
                f"Target Intl = (your 5-mo Intl ÷ {sum_int:,.0f} cr) × 535.3 cr   [= 5-mo Intl × {int_f:.3f}].",
         size=9,color=GREY_T,italic=True); ws.merge_cells("A3:K3"); ws.row_dimensions[3].height=16
    heads=["#","Zone","Customer ID","Agent Name","Type","Sales Person","5mo Dom\n(cr)","5mo Intl\n(cr)","Target Dom\n(cr)","Target Intl\n(cr)","Target Total\n(cr)"]
    widths=[5,9,11,30,10,18,10,10,11,11,12]
    for j,(h,w) in enumerate(zip(heads,widths),1):
        cell(ws,5,j,h,bold=True,size=9.5,color=NAVY,fill=BLUE_LIGHT,align="center",wrap=True,border=True)
        ws.column_dimensions[get_column_letter(j)].width=w
    ws.row_dimensions[5].height=28
    ws.freeze_panes="A6"
    r=6; idx=1
    for _,x in a.iterrows():
        if x['tgt_total']<0.001: continue
        stripe=GREY_L if idx%2==0 else None
        cell(ws,r,1,idx,align="center",size=9,fill=stripe,border=True)
        cell(ws,r,2,str(x['zone'] or ''),size=9,fill=stripe,border=True)
        cell(ws,r,3,str(x['customer_id'] or ''),size=9,fill=stripe,border=True)
        cell(ws,r,4,str(x['customer_name'] or '')[:44],size=9,fill=stripe,border=True)
        cell(ws,r,5,str(x['agent_type'] or x['channel'] or ''),size=9,fill=stripe,border=True)
        cell(ws,r,6,str(x['sales_person'] or ''),size=9,fill=stripe,border=True)
        cell(ws,r,7,x['dom']/CR,fmt='#,##0.00',align="center",size=9,fill=stripe,border=True)
        cell(ws,r,8,x['intl']/CR,fmt='#,##0.00',align="center",size=9,fill=stripe,border=True)
        cell(ws,r,9,x['tgt_dom'],fmt='#,##0.00',align="center",size=9,fill=stripe,border=True)
        cell(ws,r,10,x['tgt_int'],fmt='#,##0.00',align="center",size=9,fill=stripe,border=True)
        cell(ws,r,11,x['tgt_total'],fmt='#,##0.00',align="center",size=9,bold=True,fill=stripe,border=True)
        r+=1; idx+=1
    cell(ws,r,1,f"TOTAL — {idx-1:,} agents",bold=True,color=WHITE,fill=NAVY,border=True,align="left")
    ws.merge_cells(start_row=r,start_column=1,end_row=r,end_column=6)
    cell(ws,r,7,"",fill=NAVY,border=True); cell(ws,r,8,"",fill=NAVY,border=True)
    cell(ws,r,9,a['tgt_dom'].sum(),fmt=F_CR,bold=True,color=WHITE,fill=NAVY,align="center",border=True)
    cell(ws,r,10,a['tgt_int'].sum(),fmt=F_CR,bold=True,color=WHITE,fill=NAVY,align="center",border=True)
    cell(ws,r,11,a['tgt_total'].sum(),fmt=F_CR,bold=True,color=WHITE,fill=NAVY,align="center",border=True)


def agent_route_frame(d):
    """Per-agent, per-route June targets — the math behind the 'Agent Route Target'
    sheet, exposed as a function so the per-sales-person Target Packs reuse EXACTLY
    the same cascade (5-month route sales × sector factor; +growth already inside yld).

    Returns ``(ar, agg, dom_f, int_f)``:
      ar  = display-ready route rows (sorted; cols: customer_id, name, zn, route,
            sector, tickets, net, tgt_tkt, tgt_amt (net cr), tgt_gross (cr), atot)
      agg = per-agent rollup (name, zn, tk5, s5, ttk, tamt, tgr, pct of commit)
      dom_f / int_f = the sector scale factors (for the explanatory subtitle).
    ``ar`` is None when no agent-route data is available.
    """
    ar=d.get('agent_routes')
    if ar is None or not len(ar):
        return None, None, 0.0, 0.0
    ar=ar.copy(); ar=ar[ar['net']>0]
    gr={s:d['yld_gross'][s]/d['yld'][s] for s in ['Domestic','International']}
    sum_dom=ar.loc[ar.sector=='Domestic','net'].sum()/CR; sum_int=ar.loc[ar.sector=='International','net'].sum()/CR
    dom_f=d['commit_dom']/sum_dom if sum_dom else 0; int_f=d['commit_int']/sum_int if sum_int else 0
    ar['scale']=ar['sector'].map({'Domestic':dom_f,'International':int_f}).fillna(0)
    ar['tgt_amt']=ar['net']/CR*ar['scale']; ar['tgt_tkt']=(ar['tickets']*ar['scale']).round().astype(int)
    ar['tgt_gross']=ar['tgt_amt']*ar['sector'].map(gr)
    agg=ar.groupby('customer_id').agg(name=('name','max'),zn=('zn','max'),
        tk5=('tickets','sum'),s5=('net','sum'),ttk=('tgt_tkt','sum'),tamt=('tgt_amt','sum'),tgr=('tgt_gross','sum'))
    agg['pct']=agg['tamt']/d['commit']
    ar=ar.merge(agg[['tamt']].rename(columns={'tamt':'atot'}),on='customer_id')
    ar['domf']=(ar['sector']!='Domestic').astype(int)   # Domestic (0) sorts before International (1)
    ar=ar[ar['tgt_amt']>=0.005].sort_values(['atot','customer_id','domf','tgt_amt'],ascending=[False,True,True,False])
    return ar, agg, dom_f, int_f


def s_agent_routes(wb,d):
    ws=wb.create_sheet("Agent Route Target"); ws.sheet_view.showGridLines=False
    cell(ws,1,1,"Agent targets with route breakdown (tickets & sales)",bold=True,size=14,color=NAVY)
    ar, agg, dom_f, int_f = agent_route_frame(d)
    if ar is None or not len(ar):
        cell(ws,3,1,"No data.",size=10,color=GREY_T); return
    cell(ws,2,1,f"GRAND TOTAL on top. Then each agent (biggest first): a subtotal row with its % of the {d['commit']:.0f} cr target, followed by its routes — "
                f"DOMESTIC first, then International. Each route target = 5-month route sales × sector factor (Dom ×{dom_f:.3f}, Intl ×{int_f:.3f}). "
                f"{len(agg):,} agents.",size=9.5,color=NAVY,wrap=True); ws.merge_cells("A2:J2"); ws.row_dimensions[2].height=30
    heads=["#","Agent / Route","Zone","Sector","5mo\nTickets","5mo Sales\n(cr)","Target\nTickets","Target Net\n(cr)","% of\ntarget","Target Gross\n(cr)"]
    widths=[5,34,9,12,10,11,10,12,8,12]
    for j,(h,w) in enumerate(zip(heads,widths),1):
        cell(ws,3,j,h,bold=True,size=9.5,color=NAVY,fill=BLUE_LIGHT,align="center",wrap=True,border=True)
        ws.column_dimensions[get_column_letter(j)].width=w
    ws.row_dimensions[3].height=28; ws.freeze_panes="A4"
    # GRAND TOTAL on top
    r=4
    cell(ws,r,1,"",fill=AMBER_F,border=True)
    cell(ws,r,2,"GRAND TOTAL — all agents",bold=True,size=10.5,color=NAVY,fill=AMBER_F,border=True)
    for cc in (3,4): cell(ws,r,cc,"",fill=AMBER_F,border=True)
    cell(ws,r,5,int(agg['tk5'].sum()),fmt=F_INT,align="center",bold=True,fill=AMBER_F,border=True)
    cell(ws,r,6,agg['s5'].sum()/CR,fmt=F_CR,align="center",bold=True,fill=AMBER_F,border=True)
    cell(ws,r,7,int(agg['ttk'].sum()),fmt=F_INT,align="center",bold=True,fill=AMBER_F,border=True)
    cell(ws,r,8,agg['tamt'].sum(),fmt=F_CR,align="center",bold=True,color=NAVY,fill=AMBER_F,border=True)
    cell(ws,r,9,1.0,fmt=F_PCT,align="center",bold=True,fill=AMBER_F,border=True)
    cell(ws,r,10,agg['tgr'].sum(),fmt=F_CR,align="center",bold=True,color=NAVY,fill=AMBER_F,border=True)
    r+=1; idx=1; prev=None
    for _,x in ar.iterrows():
        cid=x['customer_id']
        if cid!=prev:
            prev=cid; a=agg.loc[cid]
            cell(ws,r,1,idx,align="center",size=9,bold=True,fill=BLUE_LIGHT,border=True)
            cell(ws,r,2,str(a['name'] or '')[:42],bold=True,size=9.5,color=NAVY,fill=BLUE_LIGHT,border=True)
            cell(ws,r,3,str(a['zn'] or ''),size=9,fill=BLUE_LIGHT,border=True)
            cell(ws,r,4,"",fill=BLUE_LIGHT,border=True)
            cell(ws,r,5,int(a['tk5']),fmt=F_INT,align="center",size=9,bold=True,fill=BLUE_LIGHT,border=True)
            cell(ws,r,6,a['s5']/CR,fmt='#,##0.00',align="center",size=9,bold=True,fill=BLUE_LIGHT,border=True)
            cell(ws,r,7,int(a['ttk']),fmt=F_INT,align="center",size=9,bold=True,fill=BLUE_LIGHT,border=True)
            cell(ws,r,8,a['tamt'],fmt='#,##0.00',align="center",size=9,bold=True,color=NAVY,fill=BLUE_LIGHT,border=True)
            cell(ws,r,9,a['pct'],fmt='0.00%',align="center",size=9,bold=True,fill=BLUE_LIGHT,border=True)
            cell(ws,r,10,a['tgr'],fmt='#,##0.00',align="center",size=9,bold=True,color=BLUE_MED,fill=BLUE_LIGHT,border=True)
            idx+=1; r+=1
        cell(ws,r,1,"",border=True)
        cell(ws,r,2,"      "+str(x['route'] or ''),size=9,color=NAVY,border=True)
        cell(ws,r,3,"",border=True)
        cell(ws,r,4,x['sector'],size=9,border=True)
        cell(ws,r,5,int(x['tickets']),fmt=F_INT,align="center",size=9,border=True)
        cell(ws,r,6,x['net']/CR,fmt='#,##0.00',align="center",size=9,border=True)
        cell(ws,r,7,int(x['tgt_tkt']),fmt=F_INT,align="center",size=9,border=True)
        cell(ws,r,8,x['tgt_amt'],fmt='#,##0.00',align="center",size=9,border=True)
        cell(ws,r,9,"",border=True)
        cell(ws,r,10,x['tgt_gross'],fmt='#,##0.00',align="center",size=9,color=BLUE_MED,border=True)
        r+=1
    # excl. direct channels (App/Web + Counter) totals row — net & gross
    dmask=agg['name'].astype(str).isin(['App/Web','Counter']) | agg.index.isin(['App/Web','Counter'])
    en=agg.loc[~dmask,'tamt'].sum(); eg=agg.loc[~dmask,'tgr'].sum(); etk=int(agg.loc[~dmask,'ttk'].sum())
    cell(ws,r,1,"",fill=AMBER_F,border=True)
    cell(ws,r,2,"★ EXCL. App/Web + Counter (agents/agencies only)",bold=True,size=10,color=AMBER_T,fill=AMBER_F,border=True)
    for cc in (3,4,5): cell(ws,r,cc,"",fill=AMBER_F,border=True)
    cell(ws,r,6,"",fill=AMBER_F,border=True)
    cell(ws,r,7,etk,fmt=F_INT,align="center",bold=True,color=AMBER_T,fill=AMBER_F,border=True)
    cell(ws,r,8,en,fmt=F_CR,align="center",bold=True,color=AMBER_T,fill=AMBER_F,border=True)
    cell(ws,r,9,en/d['commit'],fmt=F_PCT,align="center",bold=True,color=AMBER_T,fill=AMBER_F,border=True)
    cell(ws,r,10,eg,fmt=F_CR,align="center",bold=True,color=AMBER_T,fill=AMBER_F,border=True)
    r+=1


def s_loadfactor(wb,d):
    ws=wb.create_sheet("Load Factor"); ws.sheet_view.showGridLines=False
    cur=d.get('cur')
    cell(ws,1,1,f"June 2026 Load Factor — by flight & date ({CUT_LBL} snapshot)",bold=True,size=14,color=NAVY)
    if not cur:
        cell(ws,3,1,"No flight-load snapshot available.",size=10,color=GREY_T); return
    cell(ws,2,1,"Load Factor = booked seats / capacity, shown per flight per day. Each new flight-date is a column to the RIGHT. "
                f"Cell colour: red <50%, amber 50-80%, green >=80%. Jun 1-{_CUT_DAY} already flew; later dates are still filling.",
         size=9.5,color=NAVY,wrap=True); ws.merge_cells("A2:H2"); ws.row_dimensions[2].height=30
    spr=cur.get('sector_period'); spd={}
    if spr is not None:
        for (sec,flown),row in spr.iterrows(): spd[(sec,bool(flown))]=(float(row['cap']),float(row['booked']))
    def lf(sec,p):
        if p=='whole': c=sum(spd.get((sec,f),(0,0))[0] for f in (True,False)); b=sum(spd.get((sec,f),(0,0))[1] for f in (True,False))
        elif p=='flown': c,b=spd.get((sec,True),(0,0))
        else: c,b=spd.get((sec,False),(0,0))
        return (b/c if c else 0),c,b
    cell(ws,4,1,"HOW FULL ARE THE PLANES?",bold=True,size=12,color=NAVY)
    for j,(h,w) in enumerate(zip(["Period","Domestic","International","All (Total)","Seats","Booked"],[27,12,14,12,12,12]),1):
        cell(ws,5,j,h,bold=True,size=9.5,color=NAVY,fill=BLUE_LIGHT,align="center",border=True); ws.column_dimensions[get_column_letter(j)].width=w
    r=6
    for lab,p,fl in [("Whole June (all flights)","whole",AMBER_F),(f"Flown (Jun 1-{_CUT_DAY}, already gone)","flown",GREY_L),(f"★ STILL TO SELL ({SELL_LBL})","up",GREEN_F)]:
        dlf,dc,db=lf('Domestic',p); ilf,ic,ib=lf('International',p); tc=dc+ic; tb=db+ib
        cell(ws,r,1,lab,bold=True,size=10,color=AMBER_T if lab.startswith("★") else NAVY,fill=fl,border=True)
        cell(ws,r,2,dlf,fmt=F_PCT,align="center",fill=fl,border=True)
        cell(ws,r,3,ilf,fmt=F_PCT,align="center",fill=fl,border=True)
        cell(ws,r,4,tb/tc if tc else 0,fmt=F_PCT,align="center",bold=True,fill=fl,border=True)
        cell(ws,r,5,int(tc),fmt=F_INT,align="center",fill=fl,border=True)
        cell(ws,r,6,int(tb),fmt=F_INT,align="center",fill=fl,border=True); r+=1
    r+=1
    # --- the by-flight x by-date matrix (each later flight-date = a column to the RIGHT) ---
    fl=cur.get('flights')
    if fl is None or len(fl)==0:
        return
    import datetime as _dt
    fl=fl.copy(); fl['lf']=fl['booked']/fl['cap'].replace(0,1)
    dates=sorted(x for x in fl['date'].unique())
    ident=(fl.groupby(['sector','route','flight'])
             .agg(cap=('cap','max'),ac=('aircraft','first'),std=('std','first'),
                  bk=('booked','sum'),cp=('cap','sum')).reset_index())
    ident['mlf']=ident['bk']/ident['cp'].replace(0,1)
    lfmat=fl.pivot_table(index=['sector','route','flight'],columns='date',values='lf',aggfunc='mean')
    cell(ws,r,1,"LOAD FACTOR BY FLIGHT & DATE  (scroll right for later dates)",bold=True,size=12,color=NAVY); r+=1
    hr=r
    cell(ws,hr,1,"#",bold=True,size=9,color=NAVY,fill=BLUE_LIGHT,align="center",border=True); ws.column_dimensions['A'].width=4
    for j,(h,w) in enumerate(zip(["Flight","Leg / Sector","Aircraft","Cap","STD","Month\nLF"],[10,15,12,6,8,8]),2):
        cell(ws,hr,j,h,bold=True,size=9,color=NAVY,fill=BLUE_LIGHT,align="center",wrap=True,border=True)
        ws.column_dimensions[get_column_letter(j)].width=w
    d0=8
    for k,dt in enumerate(dates):
        dd=dt if isinstance(dt,_dt.date) else _dt.date.fromisoformat(str(dt))
        cell(ws,hr,d0+k,f"{dd.day}\n{dd.strftime('%a')}",bold=True,size=8,color=NAVY,fill=BLUE_LIGHT,align="center",wrap=True,border=True)
        ws.column_dimensions[get_column_letter(d0+k)].width=5.4
    ws.row_dimensions[hr].height=26; ws.freeze_panes=ws.cell(hr+1,d0).coordinate
    r=hr+1
    def lfcell(rr,col,v):
        if v is None or (isinstance(v,float) and v!=v):       # NaN/none -> blank (no flight that day)
            cell(ws,rr,col,"",size=8,border=True); return
        cell(ws,rr,col,v,fmt='0%',align="center",size=8,
             fill=(RED_F if v<0.5 else AMBER_F if v<0.8 else GREEN_F),border=True)
    def daily_row(rr,sub):                                    # per-date fill across one row
        g=sub.groupby('date').agg(b=('booked','sum'),c=('cap','sum'))
        for k,dt in enumerate(dates):
            v=(g.loc[dt,'b']/g.loc[dt,'c']) if (dt in g.index and g.loc[dt,'c']) else None
            lfcell(rr,d0+k,v)
    # grand-total daily fill row
    cell(ws,r,2,"ALL FLIGHTS — daily fill",bold=True,size=9.5,color=WHITE,fill=NAVY,border=True)
    for cc in (1,3,4,5,6): cell(ws,r,cc,"",fill=NAVY,border=True)
    cell(ws,r,7,fl['booked'].sum()/fl['cap'].sum(),fmt='0%',align="center",bold=True,size=9,color=WHITE,fill=NAVY,border=True)
    daily_row(r,fl); r+=1
    idx=1
    for sec in ['Domestic','International']:
        sf=fl[fl['sector']==sec]
        if len(sf)==0: continue
        cell(ws,r,2,sec.upper(),bold=True,size=10,color=WHITE,fill=BLUE_MED,border=True)
        for cc in (1,3,4,5,6): cell(ws,r,cc,"",fill=BLUE_MED,border=True)
        cell(ws,r,7,sf['booked'].sum()/sf['cap'].sum(),fmt='0%',align="center",bold=True,size=9,color=WHITE,fill=BLUE_MED,border=True)
        daily_row(r,sf); r+=1
        for _,a in ident[ident['sector']==sec].sort_values(['route','flight']).iterrows():
            cell(ws,r,1,idx,align="center",size=8,border=True)
            cell(ws,r,2,a['flight'],size=8.5,bold=True,color=NAVY,border=True)
            cell(ws,r,3,a['route'],size=8.5,border=True)
            cell(ws,r,4,a['ac'],size=8,border=True)
            cell(ws,r,5,int(a['cap']),fmt=F_INT,align="center",size=8,border=True)
            cell(ws,r,6,a['std'],size=8,align="center",border=True)
            mv=a['mlf']
            cell(ws,r,7,mv,fmt='0%',align="center",size=8,bold=True,
                 fill=(RED_F if mv<0.5 else AMBER_F if mv<0.8 else GREEN_F),border=True)
            key=(sec,a['route'],a['flight'])
            row=lfmat.loc[key] if key in lfmat.index else None
            for k,dt in enumerate(dates):
                lfcell(r,d0+k,(row[dt] if row is not None and dt in row.index else None))
            idx+=1; r+=1


def s_road90(wb,d):
    # The TARGET is 90% LF on both sectors. This sheet distributes the seats
    # needed to hit it across every zone (by its historical ticket share).
    ws=wb.create_sheet("Road to 90% LF"); ws.sheet_view.showGridLines=False
    cell(ws,1,1,"The 90% Target — the seat goal & how it spreads by zone",bold=True,size=14,color=NAVY)
    cell(ws,2,1,"The TARGET is 90% load factor on both sectors. Here is the ticket quota each zone must sell to hit it "
                "(split by its own Domestic/International mix), with the NET sale and the "
                "GROSS (Ticket Payment, before commission) it brings. One seat ≈ one ticket ≈ one flown leg.",size=9.5,color=GREY_T,wrap=True)
    ws.merge_cells("A2:H2"); ws.row_dimensions[2].height=32
    cap=d['cap']; yld=d['yld']; yg=d['yld_gross']
    s90={s: cap.loc[s,'cap']*OPTIMAL_LF for s in ['Domestic','International']}
    bkd={s: float(cap.loc[s,'booked']) for s in ['Domestic','International']}
    pk={'Domestic':cap.loc['Domestic','cap']*d['proven_lf']['Domestic'],
        'International':cap.loc['International','cap']*d['proven_lf']['International']}  # proven-peak milestone
    def rev(dd,ii): return (dd*yld['Domestic']+ii*yld['International'])/CR
    def grev(dd,ii): return (dd*yg['Domestic']+ii*yg['International'])/CR     # gross (ticket payment)
    tcap=cap['cap'].sum()
    # --- headline seat ladder (whole network) ---
    cell(ws,4,1,"THE SEAT GOAL (whole network)",bold=True,size=12,color=NAVY)
    for j,(h,w) in enumerate(zip(["Milestone","Load\nfactor","Seats (tickets)","Net sale (cr)","Gross-Ticket\nPmt (cr)"],[30,10,15,13,14]),1):
        cell(ws,5,j,h,bold=True,size=9,color=NAVY,fill=BLUE_LIGHT,align="center",wrap=True,border=True)
        ws.column_dimensions[get_column_letter(j)].width=w
    ws.row_dimensions[5].height=24
    rungs=[(f"Booked now ({CUT_LBL} snapshot)",bkd['Domestic'],bkd['International'],None),
           ("Proven peak (last year's best)",pk['Domestic'],pk['International'],None),
           ("★ TARGET — 90% both sectors",s90['Domestic'],s90['International'],AMBER_F)]
    r=6
    for lab,dd,ii,fl in rungs:
        star=lab.startswith("★"); seats=dd+ii
        cell(ws,r,1,lab,bold=star,size=10,color=AMBER_T if star else NAVY,fill=fl,border=True)
        cell(ws,r,2,seats/tcap,fmt=F_PCT,align="center",bold=star,fill=fl,border=True)
        cell(ws,r,3,int(seats),fmt=F_INT,align="center",bold=star,fill=fl,border=True)
        cell(ws,r,4,rev(dd,ii),fmt=F_CR,align="center",bold=star,fill=fl,border=True)
        cell(ws,r,5,grev(dd,ii),fmt=F_CR,align="center",bold=star,color=(AMBER_T if star else BLUE_MED),fill=fl,border=True); r+=1
    gd=s90['Domestic']-bkd['Domestic']; gi=s90['International']-bkd['International']
    ws.merge_cells(start_row=r,start_column=1,end_row=r,end_column=5)
    cell(ws,r,1,f"STILL TO SELL to reach 90%: {int(gd+gi):,} seats  (Domestic {int(gd):,} + International {int(gi):,}). "
                f"Domestic is the gap — it's only ~{bkd['Domestic']/cap.loc['Domestic','cap']*100:.0f}% booked.",
         bold=True,size=10,color=NAVY,fill=GREEN_F,border=True); r+=2
    # --- distribution by zone (by historical ticket share) ---
    cell(ws,r,1,"HOW THE 90% SEAT GOAL DISTRIBUTES — by zone (each zone's historical ticket share)",bold=True,size=12,color=NAVY); r+=1
    z=d['zone']; zt=z.pivot_table(index='zone',columns='sector',values='tickets',aggfunc='sum').fillna(0)
    for s in ['Domestic','International']:
        if s not in zt: zt[s]=0.0
    TD=zt['Domestic'].sum() or 1; TI=zt['International'].sum() or 1
    zt['sd']=s90['Domestic']*zt['Domestic']/TD; zt['si']=s90['International']*zt['International']/TI
    zt['st']=zt['sd']+zt['si']
    zt['rev']=(zt['sd']*yld['Domestic']+zt['si']*yld['International'])/CR
    zt['grev']=(zt['sd']*yg['Domestic']+zt['si']*yg['International'])/CR
    zt=zt[zt['st']>=1].sort_values('rev',ascending=False)
    heads=["#","Zone","Dom seats","Int seats","Total seats","Net sale (cr)","Gross-Ticket Pmt (cr)","% of goal"]
    for j,(h,w) in enumerate(zip(heads,[5,22,11,11,12,12,14,8]),1):
        cell(ws,r,j,h,bold=True,size=9,color=NAVY,fill=BLUE_LIGHT,align="center",wrap=True,border=True)
        ws.column_dimensions[get_column_letter(j)].width=w
    ws.row_dimensions[r].height=24
    r+=1; ws.freeze_panes=ws.cell(r,1).coordinate
    gtot=zt['st'].sum() or 1; i=1
    for zn,x in zt.iterrows():
        stripe=GREY_L if r%2==0 else None
        cell(ws,r,1,i,align="center",size=9,fill=stripe,border=True)
        cell(ws,r,2,str(zn),size=9.5,color=NAVY,fill=stripe,border=True)
        cell(ws,r,3,int(round(x['sd'])),fmt=F_INT,align="center",size=9,fill=stripe,border=True)
        cell(ws,r,4,int(round(x['si'])),fmt=F_INT,align="center",size=9,fill=stripe,border=True)
        cell(ws,r,5,int(round(x['st'])),fmt=F_INT,align="center",size=9,bold=True,fill=stripe,border=True)
        cell(ws,r,6,x['rev'],fmt=F_CR,align="center",size=9,bold=True,color=NAVY,fill=stripe,border=True)
        cell(ws,r,7,x['grev'],fmt=F_CR,align="center",size=9,color=BLUE_MED,fill=stripe,border=True)
        cell(ws,r,8,x['st']/gtot,fmt=F_PCT,align="center",size=9,fill=stripe,border=True)
        i+=1; r+=1
    cell(ws,r,1,"",fill=NAVY,border=True)
    cell(ws,r,2,"TOTAL — 90% goal",bold=True,color=WHITE,fill=NAVY,border=True)
    cell(ws,r,3,int(round(zt['sd'].sum())),fmt=F_INT,align="center",bold=True,color=WHITE,fill=NAVY,border=True)
    cell(ws,r,4,int(round(zt['si'].sum())),fmt=F_INT,align="center",bold=True,color=WHITE,fill=NAVY,border=True)
    cell(ws,r,5,int(round(zt['st'].sum())),fmt=F_INT,align="center",bold=True,color=WHITE,fill=NAVY,border=True)
    cell(ws,r,6,zt['rev'].sum(),fmt=F_CR,align="center",bold=True,color=WHITE,fill=NAVY,border=True)
    cell(ws,r,7,zt['grev'].sum(),fmt=F_CR,align="center",bold=True,color=WHITE,fill=NAVY,border=True)
    cell(ws,r,8,1.0,fmt=F_PCT,align="center",bold=True,color=WHITE,fill=NAVY,border=True)
    r+=1
    # --- the SAME goal WITHOUT the direct channels (Counter / Web / Mobile) ---
    # Those 3 are the airline's OWN channels; this strips them to leave what the
    # AGENTS / AGENCIES must sell, in net AND gross (ticket payment).
    direct=['Z-Counter','Z-Web','Z-Mobi App']
    dz=zt[zt.index.isin(direct)]
    def srow(lab,sd,si,st,rv,gv,fill,fc):
        cell(ws,r,1,"",fill=fill,border=True)
        cell(ws,r,2,lab,bold=True,size=9.5,color=fc,fill=fill,border=True)
        cell(ws,r,3,int(round(sd)),fmt=F_INT,align="center",size=9,color=fc,fill=fill,border=True)
        cell(ws,r,4,int(round(si)),fmt=F_INT,align="center",size=9,color=fc,fill=fill,border=True)
        cell(ws,r,5,int(round(st)),fmt=F_INT,align="center",size=9,bold=True,color=fc,fill=fill,border=True)
        cell(ws,r,6,rv,fmt=F_CR,align="center",size=9,bold=True,color=fc,fill=fill,border=True)
        cell(ws,r,7,gv,fmt=F_CR,align="center",size=9,bold=True,color=fc,fill=fill,border=True)
        cell(ws,r,8,"",fill=fill,border=True)
    srow("less direct: Counter / Web / Mobile",-dz['sd'].sum(),-dz['si'].sum(),-dz['st'].sum(),
         -dz['rev'].sum(),-dz['grev'].sum(),GREY_L,BLACK); r+=1
    a_st=zt['st'].sum()-dz['st'].sum(); a_rev=zt['rev'].sum()-dz['rev'].sum(); a_grev=zt['grev'].sum()-dz['grev'].sum()
    srow("★ AGENT / AGENCY — excl. Counter / Web / Mobile",zt['sd'].sum()-dz['sd'].sum(),
         zt['si'].sum()-dz['si'].sum(),a_st,a_rev,a_grev,AMBER_F,AMBER_T); r+=1
    ws.merge_cells(start_row=r,start_column=1,end_row=r,end_column=8)
    cell(ws,r,1,f"Agents/agencies must sell {int(round(a_st)):,} of the 90% seats = {a_rev:,.0f} cr net / {a_grev:,.0f} cr gross "
                f"(ticket payment). Counter/Web/App fill the other {int(round(dz['st'].sum())):,} seats themselves.",
         size=9,italic=True,color=GREY_T)


def s_growth(wb,d):
    # The growth lever beyond the ~90% LF ceiling: add frequency where demand spills.
    ws=wb.create_sheet("Network Growth"); ws.sheet_view.showGridLines=False
    cell(ws,1,1,"Network Growth — where to add capacity (the lever past 90% LF)",bold=True,size=14,color=NAVY)
    cell(ws,2,1,"Fares fill the plane to ~90% once; real growth = add seats where demand already spills. Routes below flew "
                ">=90% FULL in Mar-May (completed flights) — proven, demand-constrained. '+1 daily' = that aircraft x 30 days x its proven LF x yield.",
         size=9.5,color=GREY_T,wrap=True); ws.merge_cells("A2:H2"); ws.row_dimensions[2].height=28
    ga=d.get('growth_add'); yld=d['yld']; ylg=d['yld_gross']; gr_int=ylg['International']/yld['International']
    cell(ws,4,1,"ADD FREQUENCY — international routes that flew >=90% full",bold=True,size=12,color=NAVY)
    heads=["Route","Proven\nLF","~daily\nnow","Aircraft\nseats","Yield/seat\n(net TK)","+1 daily\nnet (cr/mo)","+1 daily\ngross (cr/mo)","Priority"]
    for j,(h,w) in enumerate(zip(heads,[12,9,9,10,12,13,14,11]),1):
        cell(ws,5,j,h,bold=True,size=9,color=NAVY,fill=BLUE_LIGHT,align="center",wrap=True,border=True)
        ws.column_dimensions[get_column_letter(j)].width=w
    ws.row_dimensions[5].height=28
    r=6
    if ga is not None:
        for _,x in ga.iterrows():
            net=x['acseats']*30*x['lf']*x['yld']/CR; gross=net*gr_int
            pr=("★ Tier 1" if (x['lf']>=0.97 and x['acseats']>=300) else "Tier 2" if x['lf']>=0.95 else "Tier 3")
            fl=GREEN_F if pr.startswith("★") else (AMBER_F if pr=="Tier 2" else None)
            cell(ws,r,1,x['leg_route'],bold=True,size=10,color=NAVY,fill=fl,border=True)
            cell(ws,r,2,x['lf'],fmt=F_PCT,align="center",size=9,fill=fl,border=True)
            cell(ws,r,3,round(x['legs']/86.0,1),fmt='0.0',align="center",size=9,fill=fl,border=True)
            cell(ws,r,4,int(x['acseats']),fmt=F_INT,align="center",size=9,fill=fl,border=True)
            cell(ws,r,5,int(x['yld']),fmt=F_INT,align="center",size=9,fill=fl,border=True)
            cell(ws,r,6,net,fmt=F_CR,align="center",size=9,bold=True,color=NAVY,fill=fl,border=True)
            cell(ws,r,7,gross,fmt=F_CR,align="center",size=9,color=BLUE_MED,fill=fl,border=True)
            cell(ws,r,8,pr,size=9,align="center",fill=fl,border=True); r+=1
    fare_push=d['optimal_rev']-d['commit']
    ws.merge_cells(start_row=r,start_column=1,end_row=r+1,end_column=8)
    cell(ws,r,1,f"PUNCHLINE: one extra international frequency on a top route ≈ +16 to +47 cr/MONTH each. The ENTIRE fleet-wide fare push "
                f"86%->90% is only +{fare_push:.0f} cr, ONE-TIME. Fares hit the ceiling; frequencies move it.",
         size=10,color=NAVY,fill=GREEN_F,wrap=True,bold=True); r+=3
    gt=d.get('growth_trim')
    cell(ws,r,1,"DO NOT ADD / redeploy — chronically empty DOMESTIC routes (<60% full)",bold=True,size=12,color=RED); r+=1
    for j,h in enumerate(["Route","Proven LF","Seats (Mar-May)","Booked"],1):
        cell(ws,r,j,h,bold=True,size=9,color=NAVY,fill=BLUE_LIGHT,align="center",border=True)
        ws.column_dimensions[get_column_letter(j)].width=[12,11,15,12][j-1]
    r+=1
    if gt is not None:
        for _,x in gt.iterrows():
            cell(ws,r,1,x['leg_route'],bold=True,size=10,color=NAVY,fill=RED_F,border=True)
            cell(ws,r,2,x['lf'],fmt=F_PCT,align="center",size=9,fill=RED_F,border=True)
            cell(ws,r,3,int(x['cap']),fmt=F_INT,align="center",size=9,fill=RED_F,border=True)
            cell(ws,r,4,int(x['booked']),fmt=F_INT,align="center",size=9,fill=RED_F,border=True); r+=1


def generate(params=None, cfg=None):
    """Build the June capacity workbook (8 sheets) and return its path.

    (Phase 0: paths come from the module-level _CFG resolved at import; the cfg arg
    is accepted for interface parity. Set ANALYSIS_HOME before import to retarget.)
    """
    d = gather()
    wb = Workbook()
    s_summary(wb, d); s_calc(wb, d); s_achievement(wb, d); s_routes(wb, d)
    s_loadfactor(wb, d); s_road90(wb, d); s_growth(wb, d); s_agent_routes(wb, d)
    out = OUTPUT
    out.parent.mkdir(parents=True, exist_ok=True)
    try:
        wb.save(out)
    except PermissionError:
        out = out.with_name(out.stem + "_v2.xlsx")
        wb.save(out)
    return out
