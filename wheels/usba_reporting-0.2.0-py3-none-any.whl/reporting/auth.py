"""
reporting.auth — the 14-day rotating "Reports" password (the SECOND gate, after Zenith).

WHAT THIS IS (plan §4)
----------------------
A manager opens the exe, signs into Zenith, then must enter a **rotating password**
to reach the report list. The admin (you) generates that password; it is valid for
**14 days**, after which the record expires centrally and every client stops accepting
the old one until you rotate again.

SECURITY PROPERTIES
-------------------
* **Plaintext is NEVER stored** — only ``PBKDF2-HMAC-SHA256(salt, password)``.
* **Per-user random salt** (16 bytes) + **600,000 iterations** (OWASP 2023 guidance
  for PBKDF2-SHA256), so a stolen ``auth.json`` yields nothing usable.
* **Constant-time comparison** (``hmac.compare_digest``) — no timing oracle.
* **Central expiry**: each record carries ``valid_from`` / ``valid_to``; verification
  fails once the clock passes ``valid_to``.
* **Lockout** after N failed attempts (in-memory, per app session).
* **No username enumeration**: an unknown user still runs a dummy hash (constant work)
  and returns the same generic message as a wrong password.
* The plaintext is shown **once** at generation (you copy + distribute it by hand);
  it cannot be recovered from the stored file.

HARD TRUTH (plan §4): this gate is **deterrence + audit + a kill-switch, NOT the data
boundary**. The workbook still sits on disk; the real protection is the NTFS ACLs +
encryption in plan §5–§6. Use both — never rely on this login alone.

Stack note: everything here is Python **stdlib** (hashlib/hmac/secrets/json) — nothing
added to the pinned analytics stack.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import secrets
from dataclasses import dataclass, replace
from datetime import date, timedelta
from enum import Enum
from pathlib import Path

from ._io import atomic_write_text

# --- tunables -----------------------------------------------------------------
PBKDF2_ITERATIONS = 600_000          # OWASP 2023 minimum for PBKDF2-HMAC-SHA256
SALT_BYTES = 16
MIN_PASSWORD_LEN = 16                # plan §4: ">=16 chars, high entropy"
DEFAULT_ROTATION_DAYS = 14
DEFAULT_MAX_ATTEMPTS = 5
STORE_VERSION = 1

# Readable alphabet — drops ambiguous glyphs (0/O, 1/l/I) so the password survives
# being read aloud, typed, or pasted from a chat without transcription errors.
_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%*?"

# Dummy credential used to equalise work when a username does not exist, so an unknown
# user takes the SAME time as a wrong password (defeats timing-based username enumeration).
# Its VALUE is irrelevant (it never matches a real password) — the equalisation comes from
# _dummy_verify running ONE full-cost (600k-iteration) PBKDF2, exactly like a real check.
# Derived here at 1 iteration purely so it costs nothing at import.
_DUMMY_SALT = "00" * SALT_BYTES
_DUMMY_HASH = hashlib.pbkdf2_hmac("sha256", b"x", bytes.fromhex(_DUMMY_SALT), 1).hex()


# --- low-level primitives -----------------------------------------------------
def generate_password(length: int = 20) -> str:
    """A strong random password from the readable alphabet (CSPRNG via ``secrets``)."""
    if length < MIN_PASSWORD_LEN:
        raise ValueError(f"password length must be >= {MIN_PASSWORD_LEN} (plan §4)")
    return "".join(secrets.choice(_ALPHABET) for _ in range(length))


def hash_password(password: str, *, salt: bytes | None = None,
                  iterations: int = PBKDF2_ITERATIONS) -> tuple[str, str]:
    """Return ``(salt_hex, hash_hex)``. A fresh random salt is used unless one is given."""
    salt_b = salt if salt is not None else secrets.token_bytes(SALT_BYTES)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt_b, iterations)
    return salt_b.hex(), dk.hex()


def verify_hash(password: str, salt_hex: str, hash_hex: str,
                iterations: int = PBKDF2_ITERATIONS) -> bool:
    """Constant-time check of ``password`` against a stored salt+hash."""
    dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"),
                             bytes.fromhex(salt_hex), iterations)
    return hmac.compare_digest(dk.hex(), hash_hex)


def _dummy_verify(password: str) -> None:
    """Run ONE full-cost PBKDF2 against a fixed, never-matching credential.

    Called for UNKNOWN usernames so their response time matches an existing-user wrong
    password (the same 600k-iteration work) — otherwise the timing would reveal whether a
    username exists. No cold-start tell: every call does exactly one full-cost derive.
    """
    verify_hash(password, _DUMMY_SALT, _DUMMY_HASH)   # default iterations = PBKDF2_ITERATIONS


# --- credential record --------------------------------------------------------
@dataclass(frozen=True)
class Credential:
    """One user's current rotating-password record (hash only — never plaintext)."""

    username: str
    salt: str                       # hex
    hash: str                       # hex
    iterations: int
    valid_from: str                 # ISO date (YYYY-MM-DD)
    valid_to: str                   # ISO date (inclusive last valid day)
    disabled: bool = False

    def days_left(self, on: date) -> int:
        return (date.fromisoformat(self.valid_to) - on).days

    def is_active(self, on: date) -> bool:
        return (not self.disabled
                and date.fromisoformat(self.valid_from) <= on <= date.fromisoformat(self.valid_to))

    def to_dict(self) -> dict:
        return {
            "username": self.username, "salt": self.salt, "hash": self.hash,
            "iterations": self.iterations, "valid_from": self.valid_from,
            "valid_to": self.valid_to, "disabled": self.disabled,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "Credential":
        return cls(
            username=d["username"], salt=d["salt"], hash=d["hash"],
            iterations=int(d.get("iterations", PBKDF2_ITERATIONS)),
            valid_from=d["valid_from"], valid_to=d["valid_to"],
            disabled=bool(d.get("disabled", False)),
        )


# --- the store (immutable; updates return a NEW store) ------------------------
@dataclass(frozen=True)
class AuthStore:
    """All credentials + policy. Lives as an ACL-protected ``auth.json`` on the share.

    Immutable by design (per the project coding-style rule): every mutation returns a
    NEW ``AuthStore``; call :meth:`save` to persist.
    """

    users: tuple[Credential, ...] = ()
    rotation_days: int = DEFAULT_ROTATION_DAYS
    max_attempts: int = DEFAULT_MAX_ATTEMPTS

    def get(self, username: str) -> Credential | None:
        for c in self.users:
            if c.username == username:
                return c
        return None

    def usernames(self) -> tuple[str, ...]:
        return tuple(c.username for c in self.users)

    def upsert(self, cred: Credential) -> "AuthStore":
        kept = tuple(c for c in self.users if c.username != cred.username)
        return replace(self, users=kept + (cred,))

    def set_disabled(self, username: str, disabled: bool) -> "AuthStore":
        c = self.get(username)
        if c is None:
            raise KeyError(f"no such user: {username}")
        return self.upsert(replace(c, disabled=disabled))

    def set_password(self, username: str, password: str, *, on: date,
                     rotation_days: int | None = None) -> "AuthStore":
        """Set/rotate ``username``'s password; window = [on, on + rotation_days]."""
        days = rotation_days if rotation_days is not None else self.rotation_days
        salt_hex, hash_hex = hash_password(password)
        cred = Credential(
            username=username, salt=salt_hex, hash=hash_hex,
            iterations=PBKDF2_ITERATIONS,
            valid_from=on.isoformat(), valid_to=(on + timedelta(days=days)).isoformat(),
        )
        return self.upsert(cred)

    # --- persistence (atomic temp-in-dir -> os.replace) -----------------------
    @classmethod
    def load(cls, path: Path) -> "AuthStore":
        """Load from JSON; an absent file yields an empty store with default policy."""
        path = Path(path)
        if not path.is_file():
            return cls()
        d = json.loads(path.read_text(encoding="utf-8"))
        return cls(
            users=tuple(Credential.from_dict(u) for u in d.get("users", [])),
            rotation_days=int(d.get("rotation_days", DEFAULT_ROTATION_DAYS)),
            max_attempts=int(d.get("max_attempts", DEFAULT_MAX_ATTEMPTS)),
        )

    def save(self, path: Path) -> Path:
        payload = {
            "version": STORE_VERSION,
            "rotation_days": self.rotation_days,
            "max_attempts": self.max_attempts,
            "users": [c.to_dict() for c in sorted(self.users, key=lambda x: x.username)],
        }
        return atomic_write_text(Path(path), json.dumps(payload, indent=2))   # handles Path()+mkdir


# --- verification outcome -----------------------------------------------------
class AuthResult(Enum):
    OK = "ok"
    BAD_CREDENTIALS = "bad_credentials"   # wrong password OR unknown user (same message)
    EXPIRED = "expired"
    DISABLED = "disabled"
    LOCKED_OUT = "locked_out"

    @property
    def ok(self) -> bool:
        return self is AuthResult.OK

    @property
    def user_message(self) -> str:
        return {
            AuthResult.OK: "Welcome.",
            AuthResult.BAD_CREDENTIALS: "Wrong or expired password. Get the current one from your admin.",
            AuthResult.EXPIRED: "This password has expired. Ask your admin for the new one.",
            AuthResult.DISABLED: "This account is disabled. Contact your admin.",
            AuthResult.LOCKED_OUT: "Too many attempts. Reopen the app or contact your admin.",
        }[self]


class Authenticator:
    """Verifies entered credentials against a store, with in-memory session lockout.

    The exe holds one instance for the Reports tab. Lockout is per session (resets on
    app restart) — appropriate for a download convenience gate. ``clock`` is injectable
    so behaviour around the 14-day boundary is testable.
    """

    def __init__(self, store: AuthStore, *, max_attempts: int | None = None,
                 clock=None) -> None:
        self.store = store
        self.max_attempts = max_attempts if max_attempts is not None else store.max_attempts
        self._fails: dict[str, int] = {}
        self._clock = clock or date.today

    def is_locked(self, username: str) -> bool:
        return self._fails.get(username, 0) >= self.max_attempts

    def reset(self, username: str | None = None) -> None:
        if username is None:
            self._fails.clear()
        else:
            self._fails.pop(username, None)

    def attempt(self, username: str, password: str, on: date | None = None) -> AuthResult:
        on = on or self._clock()
        username = (username or "").strip()

        if self.is_locked(username):
            return AuthResult.LOCKED_OUT

        cred = self.store.get(username)
        if cred is None:
            # equalise work + message so unknown users are indistinguishable from wrong passwords
            _dummy_verify(password)
            return self._fail(username)

        if cred.disabled:
            self._bump(username)        # count toward lockout: a revoked account can't be probed forever
            return AuthResult.DISABLED
        if not (date.fromisoformat(cred.valid_from) <= on <= date.fromisoformat(cred.valid_to)):
            self._bump(username)        # expired attempts also count toward lockout
            return AuthResult.EXPIRED
        if verify_hash(password, cred.salt, cred.hash, cred.iterations):
            self._fails.pop(username, None)
            return AuthResult.OK
        return self._fail(username)

    def _bump(self, username: str) -> None:
        self._fails[username] = self._fails.get(username, 0) + 1

    def _fail(self, username: str) -> AuthResult:
        self._bump(username)
        return AuthResult.LOCKED_OUT if self.is_locked(username) else AuthResult.BAD_CREDENTIALS
