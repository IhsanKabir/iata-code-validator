"""
reporting.registry — the catalog of available reports.

Each entry maps a stable report KEY to a title, description, and parameter schema,
so BOTH the CLI and the desktop "Reports" tab can list and run reports generically
(no hardcoded report list in the GUI).

MIGRATION (Phase 0 -> 1)
------------------------
Builders are migrated incrementally. While a report is still produced by its original
standalone script under ``scripts/``, its entry carries ``status="script"`` and the
``cli_script`` name. As each builder is moved into ``reporting/builders/<key>.py`` with
a ``generate(params, cfg) -> Path`` function, flip ``status`` to ``"package"`` and set
``builder`` to the import path. The registry shape stays the same, so nothing downstream
changes.
"""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class Report:
    key: str
    title: str
    description: str
    params: dict = field(default_factory=dict)   # name -> {"type": ..., "default": ...}
    status: str = "script"                        # "package" (migrated) | "script" (legacy)
    cli_script: str = ""                          # scripts/<file>.py for legacy entries
    builder: str = ""                             # "reporting.builders.<key>:generate" when migrated


REPORTS: dict[str, Report] = {
    "june_target": Report(
        key="june_target",
        title="June 2026 Target (capacity-aware)",
        description="90% LF target on both sectors, NET & GROSS, cascaded to zone / route / agent.",
        status="package",   # ✅ migrated (gather() engine now lives here; underperformers imports it)
        cli_script="_build_june2026_target_capacity.py",
        builder="reporting.builders.june_target:generate",
    ),
    "salesperson_gross": Report(
        key="salesperson_gross",
        title="Sales-Person Gross Report",
        description="Per sales person (+ Unmapped); gross & net; excl. Web/App/Mobile/Counter; last 3 months + June month-to-date.",
        status="package",   # ✅ migrated
        cli_script="_build_salesperson_gross_report.py",
        builder="reporting.builders.salesperson_gross:generate",
    ),
    "salesperson_pack": Report(
        key="salesperson_pack",
        title="Sales-Person Target Packs (zip)",
        description="One xlsx per sales person: agent sales (3mo+MTD), zone target vs "
                    "achievement, agency route-wise targets; + bulk-mailer Email_Manifest. "
                    "Published as a single .zip bundle.",
        status="package",
        builder="reporting.builders.salesperson_pack:generate",
    ),
    "data_kit": Report(
        key="data_kit",
        title="Data Kit (instant-reports dimensions)",
        description="Prebuilt dim_customer + reference masters bundled for the exe's "
                    "Instant Reports tab. Published as a .zip with every morning run.",
        status="package",
        builder="reporting.builders.data_kit:generate",
    ),
    "underperformers": Report(
        key="underperformers",
        title="Zone Underperformers",
        description="Zones behind pace versus the committed target.",
        status="package",   # ✅ migrated (engine gather() imported transitionally until june_target moves)
        cli_script="_build_underperformers.py",
        builder="reporting.builders.underperformers:generate",
    ),
    "dsr": Report(
        key="dsr",
        title="Daily Sales Report (DSR)",
        description="DSR for a given month / date range (8 sheets: Dashboard, Agent, City Top-20, Day Wise, Top OTA, Top Corp, Zone Wise, directory).",
        params={"month": {"type": "month", "default": "2026-06"}},
        status="package",   # ✅ migrated (last builder — Phase 0 complete)
        cli_script="08_generate_dsr.py",
        builder="reporting.builders.dsr:generate",
    ),
    "daily_snapshot": Report(
        key="daily_snapshot",
        title="Daily Report",
        description="Yesterday + MTD by sector (gross & net, BDT lacs): totals with & without Counter/Web/App, top-8 countries, Counter/Web/Mobile rows, Top-10 OTA.",
        params={"date": {"type": "date", "default": None}},   # None -> latest data date
        status="package",
        cli_script="_build_daily_snapshot.py",
        builder="reporting.builders.daily_snapshot:generate",
    ),
    "load_report": Report(
        key="load_report",
        title="Flight Load",
        description="Flight x day matrix (history + forward): capacity, sold, flown, no-show, utilization & LF, with route/daily summaries.",
        params={"start": {"type": "date", "default": None}, "end": {"type": "date", "default": None}},
        status="package",
        cli_script="_build_load_report.py",
        builder="reporting.builders.load_report:generate",
    ),
    "iata_worklist": Report(
        key="iata_worklist",
        title="IATA Agencies — need name",
        description="Auto-named agencies that have an IATA number, for lookup & patching.",
        status="package",   # ✅ migrated
        cli_script="_export_iata_agencies_needname.py",
        builder="reporting.builders.iata_worklist:generate",
    ),
}


def list_reports() -> list[Report]:
    """Reports in a stable display order."""
    return list(REPORTS.values())
