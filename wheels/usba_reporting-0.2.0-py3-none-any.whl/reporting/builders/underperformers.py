"""
reporting.builders.underperformers — June zone laggard board ("who's behind").

Per zone: June target, real June 1-N sales, the pace it should be at, and the gap.
Worst-first. Reuses the capacity engine `gather()` so every number ties to the
June target report to the rupee.

TRANSITIONAL NOTE
-----------------
`gather()` (the capacity engine) still lives in the legacy script
``scripts/_build_june2026_target_capacity.py``. Until THAT report is migrated into
``reporting.builders.june_target``, we import the engine from there (the legacy module
resolves its own data paths). When june_target is migrated, move ``gather`` into the
package and switch the import below to ``from .june_target import gather`` etc.
"""
from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from ..config import Config, load_config

CR = 1e7
NAVY = "1F3864"; BLUE_LIGHT = "D9E1F2"; GREY_L = "F2F2F2"; GREY_T = "7F7F7F"
WHITE = "FFFFFF"; BLACK = "000000"; GREEN_F = "C6EFCE"; AMBER_F = "FFEB9C"; RED_F = "FFC7CE"; AMBER_T = "9C6500"
THIN = Side(style="thin", color="BFBFBF"); BORDER = Border(THIN, THIN, THIN, THIN)
F_CR = "#,##0.00"; F_PCT = "0%"


def _engine(cfg: Config):
    """Capacity engine + label helpers, now sourced from the package (june_target)."""
    from .june_target import gather, zone_sort_key, CHANNEL_LABEL
    return gather, zone_sort_key, CHANNEL_LABEL


def cell(ws, r, c, v, *, fmt=None, bold=False, size=10, color=BLACK, fill=None, align="left", wrap=False, border=True):
    x = ws.cell(row=r, column=c, value=v)
    x.font = Font(bold=bold, size=size, color=color, name="Calibri")
    x.alignment = Alignment(horizontal=align, vertical="center", wrap_text=wrap)
    if fmt:
        x.number_format = fmt
    if fill:
        x.fill = PatternFill("solid", fgColor=fill)
    if border:
        x.border = BORDER
    return x


def build_zone_board(d: dict) -> pd.DataFrame:
    """Per-zone committed target + June-MTD actual (mirrors the achievement engine)."""
    zn = d["zone"].pivot_table(index="zone", columns="sector", values="net", aggfunc="sum").fillna(0)
    for s in ("Domestic", "International"):
        if s not in zn:
            zn[s] = 0.0
    dsc = (d["commit_dom"] * CR) / zn["Domestic"].sum() if zn["Domestic"].sum() else 0
    isc = (d["commit_int"] * CR) / zn["International"].sum() if zn["International"].sum() else 0
    z = pd.DataFrame(index=zn.index)
    z["target"] = (zn["Domestic"] * dsc + zn["International"] * isc) / CR
    ma = d.get("mtd_actual")
    sold = ma.groupby("zone")["net"].sum() if ma is not None else {}
    z["sold"] = [(sold.get(i, 0.0) / CR if hasattr(sold, "get") else 0.0) for i in z.index]
    z = z[z["target"] >= 0.05].copy()
    z["ach"] = z.apply(lambda r: r["sold"] / r["target"] if r["target"] else 0, axis=1)
    return z


def generate(params: dict | None = None, cfg: Config | None = None) -> Path:
    cfg = cfg or load_config(validate=True)
    gather, zone_sort_key, CHANNEL_LABEL = _engine(cfg)
    d = gather()
    jd = int(d.get("june_days", 6) or 6)
    pace = jd / 30.0
    z = build_zone_board(d)
    z["gap_to_pace"] = z["target"] * pace - z["sold"]      # +ve = behind
    z = z.sort_values("ach")                                # worst first
    zl = d.get("zlabels", {})

    wb = Workbook(); ws = wb.active; ws.title = "Underperformers"
    ws.sheet_view.showGridLines = False
    cell(ws, 1, 1, "June 2026 — Who's Behind (zone laggard board)", bold=True, size=14, color=NAVY, border=False)
    cell(ws, 2, 1, f"Sorted worst-first. 'Pace' = {pace*100:.0f}% (Jun 1-{jd} of 30 days). 'Gap to pace' = target×pace − sold "
                   f"(positive = behind). Net sale. Fix the red rows first.",
         size=9.5, color=GREY_T, border=False)
    heads = ["#", "Zone", "Area", "Sales Person", "Target\n(cr)", f"Sold Jun1-{jd}\n(cr)", "Achieved\n%", "Gap to pace\n(cr)", "Status"]
    widths = [5, 11, 28, 18, 11, 12, 10, 12, 11]
    for j, (h, w) in enumerate(zip(heads, widths), 1):
        cell(ws, 4, j, h, bold=True, size=9.5, color=NAVY, fill=BLUE_LIGHT, align="center", wrap=True)
        ws.column_dimensions[get_column_letter(j)].width = w
    ws.row_dimensions[4].height = 26
    ws.freeze_panes = "A5"
    r = 5
    for i, (zn, x) in enumerate(z.iterrows(), 1):
        area, sp = zl.get(zn, CHANNEL_LABEL.get(zn, ("", "")))
        ach = x["ach"]
        if ach >= pace:
            status, fill = "On pace", GREEN_F
        elif ach >= pace * 0.6:
            status, fill = "Behind", AMBER_F
        else:
            status, fill = "WELL BEHIND", RED_F
        cell(ws, r, 1, i, align="center", size=9)
        cell(ws, r, 2, zn, bold=True, size=10, color=NAVY)
        cell(ws, r, 3, str(area)[:40], size=9, wrap=True)
        cell(ws, r, 4, str(sp), size=9)
        cell(ws, r, 5, x["target"], fmt=F_CR, align="center", size=9, bold=True)
        cell(ws, r, 6, x["sold"], fmt=F_CR, align="center", size=9)
        cell(ws, r, 7, ach, fmt=F_PCT, align="center", size=9, bold=True, fill=fill)
        cell(ws, r, 8, x["gap_to_pace"], fmt=F_CR, align="center", size=9, color=("C00000" if x["gap_to_pace"] > 0 else BLACK))
        cell(ws, r, 9, status, size=9, align="center", bold=True, fill=fill, color=AMBER_T if fill == AMBER_F else BLACK)
        r += 1
    tt = z["target"].sum(); ts = z["sold"].sum()
    cell(ws, r, 1, "TOTAL", bold=True, color=WHITE, fill=NAVY)
    for cc in (2, 3, 4):
        cell(ws, r, cc, "", fill=NAVY)
    cell(ws, r, 5, tt, fmt=F_CR, align="center", bold=True, color=WHITE, fill=NAVY)
    cell(ws, r, 6, ts, fmt=F_CR, align="center", bold=True, color=WHITE, fill=NAVY)
    cell(ws, r, 7, ts / tt if tt else 0, fmt=F_PCT, align="center", bold=True, color=WHITE, fill=NAVY)
    cell(ws, r, 8, tt * pace - ts, fmt=F_CR, align="center", bold=True, color=WHITE, fill=NAVY)
    cell(ws, r, 9, "", fill=NAVY)
    r += 2
    behind = z[z["ach"] < pace * 0.6]
    ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=9)
    cell(ws, r, 1, f"{len(behind)} zones are WELL BEHIND (<{pace*0.6*100:.0f}% achieved). They hold "
                   f"{behind['gap_to_pace'].clip(lower=0).sum():,.0f} cr of the gap-to-pace — that's where to push first.",
         size=10, color=NAVY, fill=AMBER_F, wrap=True, bold=True, border=False)

    out = cfg.output_dir / "June2026_Underperformers.xlsx"
    out.parent.mkdir(parents=True, exist_ok=True)
    try:
        wb.save(out)
    except PermissionError:
        out = out.with_name(out.stem + "_v2.xlsx")
        wb.save(out)
    return out
