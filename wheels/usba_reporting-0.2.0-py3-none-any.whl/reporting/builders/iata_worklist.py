"""
reporting.builders.iata_worklist — agencies with an IATA number but an AUTO-GENERATED name.

`name_source = 'auto_gds'` means a machine-derived placeholder name; when such a row also
carries an `iata_number`, the analyst can look it up and paste back the real agency name.
Busiest-first (by recent gross sale), with two blank columns to fill.

Public entry point: ``generate(params, cfg) -> Path``.
"""
from __future__ import annotations

from pathlib import Path

import duckdb
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from ..config import Config, load_config

WIN_LO, WIN_HI = "2026-03-01", "2026-06-06"   # recent activity window for prioritising
CR = 1e7
NAVY = "1F3864"; BLUE_LIGHT = "D9E1F2"; GREY_L = "F2F2F2"; GREY_T = "7F7F7F"
WHITE = "FFFFFF"; BLACK = "000000"; AMBER_F = "FFEB9C"
THIN = Side(style="thin", color="BFBFBF"); BORDER = Border(THIN, THIN, THIN, THIN)


def generate(params: dict | None = None, cfg: Config | None = None) -> Path:
    cfg = cfg or load_config(validate=True)
    con = duckdb.connect(str(cfg.warehouse), read_only=True)
    sales = f"""
        WITH s AS (
            SELECT CASE WHEN CAST("Customer ID" AS VARCHAR)='BO-1 Central Reservation' THEN '11246131'
                        ELSE regexp_replace(CAST("Customer ID" AS VARCHAR),'[.]0$','') END customer_id,
                   CASE WHEN CAST("Transaction" AS VARCHAR)='Ticket payment'
                        THEN CAST("Balance (base currency)" AS DOUBLE) ELSE 0 END g
            FROM read_parquet('{cfg.sales_glob}', hive_partitioning=1, union_by_name=1)
            WHERE "Date"::DATE BETWEEN DATE '{WIN_LO}' AND DATE '{WIN_HI}'
        ) SELECT customer_id, SUM(g) recent_gross FROM s GROUP BY 1
    """
    df = con.execute(f"""
        SELECT c.customer_id, c.iata_number, c.customer_name, c.agent_type, c.primary_channel,
               c.zone, c.station, c.district_state, c.country, c.transaction_count,
               c.first_seen_date, c.last_seen_date,
               COALESCE(sl.recent_gross, 0) AS recent_gross
        FROM dim_customer c
        LEFT JOIN ({sales}) sl ON c.customer_id = sl.customer_id
        WHERE c.name_source = 'auto_gds'
          AND c.iata_number IS NOT NULL AND TRIM(c.iata_number) <> ''
        ORDER BY recent_gross DESC, c.transaction_count DESC
    """).df()
    con.close()

    wb = Workbook(); ws = wb.active; ws.title = "IATA agencies — need name"
    ws.sheet_view.showGridLines = False

    def cell(r, c, v, *, fmt=None, bold=False, size=10, color=BLACK, fill=None, align="left", wrap=False, border=True):
        x = ws.cell(row=r, column=c, value=v)
        x.font = Font(bold=bold, size=size, color=color, name="Calibri")
        x.alignment = Alignment(horizontal=align, vertical="center", wrap_text=wrap)
        if fmt:
            x.number_format = fmt
        if fill:
            x.fill = PatternFill("solid", fgColor=fill)
        if border:
            x.border = BORDER
        return x

    cell(1, 1, "Agencies with an IATA number but an AUTO-GENERATED name — look up & fill", bold=True, size=14, color=NAVY, border=False)
    cell(2, 1, f"name_source = 'auto_gds' (placeholder name) AND an IATA number present.  {len(df):,} agencies, busiest first.  "
               f"Search each IATA number, then fill the yellow columns. Recent gross = ticket sales {WIN_LO} to {WIN_HI}.",
         size=9.5, color=GREY_T, border=False)
    heads = ["#", "Customer ID", "IATA Number", "Current name (auto)", "Type", "Channel", "Zone", "Station",
             "District/State", "Country", "Txns", "Recent gross (cr)", "First seen", "Last seen",
             "★ Real Agency Name (fill)", "Notes (fill)"]
    widths = [5, 13, 13, 30, 9, 10, 9, 9, 16, 11, 8, 13, 12, 12, 34, 24]
    for j, (h, w) in enumerate(zip(heads, widths), 1):
        fill = AMBER_F if h.startswith("★") or h == "Notes (fill)" else BLUE_LIGHT
        cell(4, j, h, bold=True, size=9.5, color=NAVY, fill=fill, align="center", wrap=True)
        ws.column_dimensions[get_column_letter(j)].width = w
    ws.row_dimensions[4].height = 28
    ws.freeze_panes = "A5"
    r = 5
    for i, (_, x) in enumerate(df.iterrows(), 1):
        stripe = GREY_L if i % 2 == 0 else None
        vals = [i, str(x["customer_id"]), str(x["iata_number"]), str(x["customer_name"] or "")[:40],
                str(x["agent_type"] or ""), str(x["primary_channel"] or ""), str(x["zone"] or ""),
                str(x["station"] or ""), str(x["district_state"] or ""), str(x["country"] or ""),
                int(x["transaction_count"] or 0), x["recent_gross"] / CR,
                str(x["first_seen_date"] or "")[:10], str(x["last_seen_date"] or "")[:10], "", ""]
        for j, v in enumerate(vals, 1):
            fmt = "#,##0.00" if j == 12 else ("#,##0" if j == 11 else None)
            al = "center" if j in (1, 3, 5, 6, 7, 8, 10, 11, 12, 13, 14) else "left"
            fl = AMBER_F if j in (15, 16) else stripe
            cell(r, j, v, fmt=fmt, align=al, size=9, fill=fl, bold=(j == 3),
                 color=NAVY if j == 3 else BLACK, wrap=(j in (4, 15)))
        r += 1

    out = cfg.output_dir / "IATA_Agencies_NeedName.xlsx"
    out.parent.mkdir(parents=True, exist_ok=True)
    try:
        wb.save(out)
    except PermissionError:
        out = out.with_name(out.stem + "_v2.xlsx")
        wb.save(out)
    return out
