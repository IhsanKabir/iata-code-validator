"""reporting.builders — one module per report; each exposes ``generate(params, cfg) -> Path``."""
