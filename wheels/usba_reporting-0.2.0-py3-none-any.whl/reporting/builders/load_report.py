"""
reporting.builders.load_report — the Flight Load Report, in the COMPANY's layout.

WHAT IT PRODUCES (3 sheets)
---------------------------
1. ``Ordered Data`` — the company's flight x day matrix: one row per flight+leg,
   one column block per day:
       Capacity | STD | Aircraft | Flown Seats | Sold | No-Show | Unsold
       | Utilization | Load Factor | Note
   Utilization (= Sold / Capacity) carries the company's traffic-light buckets
   (the ``load_bucket`` scheme that ships inside the parquet):
       >=100 Oversold (dark green) · 90-99 Full (green) · 75-90 Healthy (light
       green) · 50-75 Soft (amber) · 25-50 Weak (red) · <25 Empty (deep red)
2. ``Route Loads``  — per-route capacity/booked/LF summary with sector subtotals.
3. ``Daily Loads``  — per-day Dom/Int capacity/booked/LF + period totals.

DATA HONESTY — Flown Seats / No-Show / Load Factor
--------------------------------------------------
The curated Zenith pull (curated/flight_loads/flight_loads.parquet) carries
BOOKINGS (capacity / booked / unsold) — it has NO post-departure data, so
``Flown Seats``, ``No-Show`` and flown-based ``Load Factor`` CANNOT be computed
from it. Those columns are kept in the layout (so the sheet matches the company
template and can absorb a DCS/post-departure feed later) but are left blank, and
the title row says so. Utilization (booked basis) is the computed measure.

PERIOD
------
params: optional ``start`` / ``end`` (YYYY-MM-DD). Default = the FORWARD window
in the parquet (current bookings for upcoming flights). Pass historical dates for
a flown-period view (e.g. last month).
"""
from __future__ import annotations

import re
from datetime import date, datetime, timedelta
from pathlib import Path

import duckdb
import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from ..config import Config, load_config

# styling (same palette family as the other builders)
NAVY = "1F3864"; BLUE_LIGHT = "D9E1F2"; GREY_T = "7F7F7F"; GREY_L = "F2F2F2"
WHITE = "FFFFFF"; BLACK = "000000"
THIN = Side(style="thin", color="BFBFBF"); BORDER = Border(THIN, THIN, THIN, THIN)
F_INT = "#,##0"; F_PCT = "0%"

# Company load buckets (mirrors the parquet's `load_bucket` scheme) -> cell fill.
# Thresholds are LOWER bounds on utilization = booked/capacity.
BUCKET_FILLS: tuple[tuple[float, str], ...] = (
    (1.00, "548235"),   # Oversold >=100%  dark green
    (0.90, "70AD47"),   # Full 90-99%      green
    (0.75, "A9D08E"),   # Healthy 75-90%   light green
    (0.50, "FFC000"),   # Soft 50-75%      amber
    (0.25, "FF5050"),   # Weak 25-50%      red
    (0.00, "FF0000"),   # Empty <25%       deep red
)
# summary sheets keep the simpler 90/75 lights used by the target programme
LF_GREEN = 0.90; LF_AMBER = 0.75
GREEN_F = "C6EFCE"; AMBER_F = "FFEB9C"; RED_F = "FFC7CE"

# matrix day-block layout: 10 columns per day (Note closes each block, like the company file)
DAY_COLS = ["Capacity", "STD", "Aircraft", "Flown\nSeats", "Sold", "No-Show",
            "Unsold", "Utilization", "Load Factor", "Note"]


# ---------------------------------------------------------------------------
# pure helpers (unit-tested)
# ---------------------------------------------------------------------------
def load_factor(booked: float, capacity: float) -> float | None:
    """Capacity-weighted ratio; None when capacity is 0 (cannot divide)."""
    return (booked / capacity) if capacity else None


def util_fill(util: float | None) -> str | None:
    """Company-bucket traffic light for a Utilization cell (None -> no fill)."""
    if util is None:
        return None
    for lo, fill in BUCKET_FILLS:
        if util >= lo:
            return fill
    # only reachable when util < 0 (bad upstream data, e.g. negative booked):
    # fall back to the 'Empty' bucket rather than crash or leave the cell unstyled
    return BUCKET_FILLS[-1][1]


def lf_fill(lf: float | None) -> str | None:
    """Simple 90/75 light for the SUMMARY sheets (matches the 90%-LF programme)."""
    if lf is None:
        return None
    if lf >= LF_GREEN:
        return GREEN_F
    if lf >= LF_AMBER:
        return AMBER_F
    return RED_F


def flight_sort_key(flight_no: str) -> tuple[str, int]:
    """Natural sort for 'BS101' style numbers: ('BS', 101). Unparsable -> (str, big)."""
    m = re.match(r"^([A-Za-z]*)(\d+)$", str(flight_no).strip())
    if m:
        return (m.group(1).upper(), int(m.group(2)))
    return (str(flight_no).upper(), 10**9)


def resolve_period(params: dict, fwd_min: date | None, fwd_max: date | None,
                   hist_min: date | None = None) -> tuple[date, date, str]:
    """The reporting window: explicit start/end params win; else ONE continuous
    span from the start of the ingested ops history (flown data) through the end
    of the FORWARD bookings — so a single report carries past + future.
    Without any ingested history it falls back to the forward window alone."""
    if params.get("start") and params.get("end"):
        s = date.fromisoformat(str(params["start"]))
        e = date.fromisoformat(str(params["end"]))
        if s > e:                       # a swapped range would silently render 0 day columns
            raise ValueError(f"start {s} is after end {e} - swap the dates.")
        return s, e, "custom period"
    if fwd_min is None or fwd_max is None:
        raise ValueError("No FORWARD rows in flight_loads.parquet and no start/end params.")
    if hist_min is not None:
        return min(hist_min, fwd_min), fwd_max, "history + forward bookings"
    return fwd_min, fwd_max, "forward bookings"


# ---------------------------------------------------------------------------
# data
# ---------------------------------------------------------------------------
def _loads_path(cfg: Config) -> str:
    return (cfg.data_root / "curated" / "flight_loads" / "flight_loads.parquet").as_posix()


def _history_path(cfg: Config) -> str:
    """Post-departure ops history (Flown/No-Show), built by scripts/ingest_flight_history.py."""
    return (cfg.data_root / "curated" / "flight_history" / "flight_loads_history.parquet").as_posix()


def _fetch(con: duckdb.DuckDBPyConnection, cfg: Config, start: date, end: date
           ) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """(matrix_df, route_df, daily_df) for the window.

    matrix_df: one row per flight/leg/DAY (the parquet's native grain) with the
    fields the Ordered Data sheet shows.
    """
    src = _loads_path(cfg)
    where = (f"flight_date BETWEEN DATE '{start.isoformat()}' "
             f"AND DATE '{end.isoformat()}'")
    # post-departure history (Flown / No-Show) joins in when the ops file has been
    # ingested; absent file -> empty join table -> those columns stay NULL/blank.
    hist = _history_path(cfg)
    hist_cte = (f"SELECT flight_date AS d, flight_number, leg_route, flown, no_show "
                f"FROM read_parquet('{hist}')") if Path(hist).is_file() else \
               ("SELECT NULL::DATE d, NULL::VARCHAR flight_number, NULL::VARCHAR leg_route, "
                "NULL::DOUBLE flown, NULL::DOUBLE no_show WHERE FALSE")
    matrix = con.sql(f"""
        WITH z AS (
            SELECT flight_number, leg_route, flight_date::DATE AS d,
                   MIN(dep_time) AS std, MIN(aircraft_family) AS aircraft,
                   SUM(capacity) AS capacity, SUM(booked) AS booked, SUM(unsold) AS unsold
            FROM read_parquet('{src}') WHERE {where}
            GROUP BY 1, 2, 3
        ), h AS ({hist_cte})
        SELECT z.*, h.flown, h.no_show
        FROM z LEFT JOIN h USING (flight_number, leg_route, d)
    """).to_df()
    routes = con.sql(f"""
        SELECT sector, leg_route,
               COUNT(DISTINCT flight_date || flight_number) AS legs,
               SUM(capacity) AS capacity, SUM(booked) AS booked,
               SUM(available) AS available
        FROM read_parquet('{src}') WHERE {where}
        GROUP BY sector, leg_route ORDER BY sector, capacity DESC
    """).to_df()
    daily = con.sql(f"""
        SELECT flight_date::DATE AS d, sector,
               SUM(capacity) AS capacity, SUM(booked) AS booked
        FROM read_parquet('{src}') WHERE {where}
        GROUP BY 1, 2 ORDER BY 1, 2
    """).to_df()
    return matrix, routes, daily


# ---------------------------------------------------------------------------
# Excel writers
# ---------------------------------------------------------------------------
def _cell(ws, r, c, v, *, fmt=None, bold=False, size=10, color=BLACK, fill=None,
          align="left", border=True, wrap=False):
    x = ws.cell(row=r, column=c, value=v)
    x.font = Font(bold=bold, size=size, color=color, name="Calibri")
    x.alignment = Alignment(horizontal=align, vertical="center", wrap_text=wrap)
    if fmt:
        x.number_format = fmt
    if fill:
        x.fill = PatternFill("solid", fgColor=fill)
    if border:
        x.border = BORDER
    return x


def _write_matrix(ws, matrix: pd.DataFrame, start: date, end: date, label: str) -> None:
    """The company-format flight x day grid ('Ordered Data')."""
    ws.title = "Ordered Data"
    ws.sheet_view.showGridLines = False
    days = [start + timedelta(days=i) for i in range((end - start).days + 1)]
    n = len(DAY_COLS)

    _cell(ws, 1, 1, f"USBA Flight Load Report  ·  {label}: {start:%d/%m/%Y}–{end:%d/%m/%Y}  ·  "
                    f"Utilization = Sold/Capacity (bookings) · Load Factor = Flown/Capacity "
                    f"(filled where the ops history file has been ingested; blank = no "
                    f"post-departure data for that day yet).",
          size=9, color=GREY_T, border=False)
    # row 2: merged day headers; row 3: per-day column headers
    _cell(ws, 3, 1, "Flight\nNo", bold=True, color=WHITE, fill=NAVY, align="center", wrap=True)
    _cell(ws, 3, 2, "Leg/Sector", bold=True, color=WHITE, fill=NAVY, align="center", wrap=True)
    ws.column_dimensions["A"].width = 9
    ws.column_dimensions["B"].width = 11
    for di, d in enumerate(days):
        c0 = 3 + di * n
        ws.merge_cells(start_row=2, start_column=c0, end_row=2, end_column=c0 + n - 1)
        _cell(ws, 2, c0, f"{d:%d/%m/%Y} ({d:%A})", bold=True, align="center",
              fill=GREY_L if di % 2 else BLUE_LIGHT, color=NAVY)
        for j, h in enumerate(DAY_COLS):
            _cell(ws, 3, c0 + j, h, bold=True, size=8.5, color=WHITE, fill=NAVY,
                  align="center", wrap=True)
            ws.column_dimensions[get_column_letter(c0 + j)].width = \
                10 if h in ("Capacity", "Utilization", "Load Factor") else \
                13 if h == "Aircraft" else 8
    ws.row_dimensions[3].height = 26
    ws.freeze_panes = "C4"

    # cell lookup: (flight, leg) x date -> row dict.
    # NOTE: pandas gives flight_date back as a Timestamp, which SUBCLASSES datetime
    # (and date) — so test against datetime and call .date() to get a plain date key
    # that matches the generated `days` list. (Timestamp keys never equal date keys.)
    by_key: dict = {}
    for row in matrix.itertuples(index=False):
        d = row.d.date() if isinstance(row.d, datetime) else row.d
        by_key.setdefault((row.flight_number, row.leg_route), {})[d] = row
    flights = sorted(by_key, key=lambda k: (flight_sort_key(k[0]), k[1]))

    r = 4
    for key in flights:
        flight_no, leg = key
        _cell(ws, r, 1, flight_no, bold=True, size=9, align="center")
        _cell(ws, r, 2, leg, size=9, align="center", fill=GREY_L)
        for di, d in enumerate(days):
            c0 = 3 + di * n
            row = by_key[key].get(d)
            if row is None:                      # flight doesn't operate that day
                continue
            util = load_factor(row.booked, row.capacity)
            _cell(ws, r, c0 + 0, int(row.capacity), fmt=F_INT, align="right", size=9)
            _cell(ws, r, c0 + 1, row.std, align="center", size=9)
            _cell(ws, r, c0 + 2, str(row.aircraft)[:14], size=9)
            # post-departure fields — filled from the ingested ops history where present
            if pd.notna(row.flown):
                _cell(ws, r, c0 + 3, int(row.flown), fmt=F_INT, align="right", size=9)
            _cell(ws, r, c0 + 4, int(row.booked), fmt=F_INT, align="right", size=9)
            if pd.notna(row.no_show):
                _cell(ws, r, c0 + 5, int(row.no_show), fmt=F_INT, align="right", size=9)
            _cell(ws, r, c0 + 6, int(row.unsold), fmt=F_INT, align="right", size=9)
            if util is not None:
                _cell(ws, r, c0 + 7, util, fmt=F_PCT, align="center", size=9,
                      fill=util_fill(util))
            if pd.notna(row.flown):                       # real flown LF, company colours
                lf = load_factor(float(row.flown), row.capacity)
                if lf is not None:
                    _cell(ws, r, c0 + 8, lf, fmt=F_PCT, align="center", size=9,
                          fill=util_fill(lf))
        r += 1


def _num_row(ws, r, vals_cols, *, bold=False, fill=None, color=BLACK, size=9):
    for c, v, fmt in vals_cols:
        _cell(ws, r, c, v, fmt=fmt, align="right", bold=bold, fill=fill, color=color, size=size)


def _lf_cell(ws, r, c, lf, *, bold=False, override_fill=None, color=BLACK):
    _cell(ws, r, c, lf if lf is not None else "-", fmt="0.0%" if lf is not None else None,
          align="center", bold=bold, fill=override_fill or lf_fill(lf), color=color)


def _write_routes(wb, routes: pd.DataFrame, start: date, end: date) -> None:
    ws = wb.create_sheet("Route Loads")
    ws.sheet_view.showGridLines = False
    for j, w in enumerate([18, 9, 11, 11, 11, 9], 1):
        ws.column_dimensions[get_column_letter(j)].width = w
    _cell(ws, 1, 1, f"Route summary  ·  {start:%d %b} – {end:%d %b %Y}  ·  LF = booked/capacity",
          bold=True, size=12, color=NAVY, border=False)
    heads = ["Route", "Legs", "Capacity", "Booked", "Available", "LF %"]
    for j, h in enumerate(heads, 1):
        _cell(ws, 3, j, h, bold=True, size=9.5, color=NAVY, fill=BLUE_LIGHT,
              align="center" if j > 1 else "left")
    ws.freeze_panes = "A4"
    r = 4
    for sec in ("Domestic", "International"):
        sub = routes[routes["sector"] == sec]
        if sub.empty:
            continue
        ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=6)
        _cell(ws, r, 1, sec.upper(), bold=True, color=WHITE, fill=NAVY); r += 1
        for row in sub.itertuples(index=False):
            _cell(ws, r, 1, row.leg_route, size=9)
            _num_row(ws, r, [(2, int(row.legs), F_INT), (3, int(row.capacity), F_INT),
                             (4, int(row.booked), F_INT), (5, int(row.available), F_INT)])
            _lf_cell(ws, r, 6, load_factor(row.booked, row.capacity)); r += 1
        cap, bk = sub["capacity"].sum(), sub["booked"].sum()
        _cell(ws, r, 1, f"{sec} total", bold=True, fill=BLUE_LIGHT)
        _num_row(ws, r, [(2, int(sub['legs'].sum()), F_INT), (3, int(cap), F_INT),
                         (4, int(bk), F_INT), (5, int(sub['available'].sum()), F_INT)],
                 bold=True, fill=BLUE_LIGHT)
        _lf_cell(ws, r, 6, load_factor(bk, cap), bold=True); r += 1
    cap, bk = routes["capacity"].sum(), routes["booked"].sum()
    _cell(ws, r, 1, "GRAND TOTAL", bold=True, color=WHITE, fill=NAVY)
    _num_row(ws, r, [(2, int(routes['legs'].sum()), F_INT), (3, int(cap), F_INT),
                     (4, int(bk), F_INT), (5, int(routes['available'].sum()), F_INT)],
             bold=True, fill=NAVY, color=WHITE)
    _lf_cell(ws, r, 6, load_factor(bk, cap), bold=True, override_fill=NAVY, color=WHITE)


def _write_daily(wb, daily: pd.DataFrame) -> None:
    ws = wb.create_sheet("Daily Loads")
    ws.sheet_view.showGridLines = False
    for j, w in enumerate([12, 10, 11, 11, 9, 2, 11, 11, 9], 1):
        ws.column_dimensions[get_column_letter(j)].width = w
    _cell(ws, 1, 1, "Daily capacity / booked / LF by sector", bold=True, size=12,
          color=NAVY, border=False)
    ws.merge_cells(start_row=2, start_column=2, end_row=2, end_column=5)
    ws.merge_cells(start_row=2, start_column=7, end_row=2, end_column=9)
    _cell(ws, 2, 2, "Domestic", bold=True, color=WHITE, fill=NAVY, align="center")
    _cell(ws, 2, 7, "International", bold=True, color=WHITE, fill=NAVY, align="center")
    heads = ["Date", "Day", "Capacity", "Booked", "LF %", "", "Capacity", "Booked", "LF %"]
    for j, h in enumerate(heads, 1):
        if h:
            _cell(ws, 3, j, h, bold=True, size=9.5, color=NAVY, fill=BLUE_LIGHT, align="center")
    ws.freeze_panes = "A4"
    piv: dict = {}
    for row in daily.itertuples(index=False):
        # same Timestamp-vs-date normalization as the matrix (see note there)
        d = row.d.date() if isinstance(row.d, datetime) else row.d
        piv.setdefault(d, {})[row.sector] = (row.capacity, row.booked)
    r = 4
    for d in sorted(piv):
        _cell(ws, r, 1, d.strftime("%d %b %Y"), size=9)
        _cell(ws, r, 2, d.strftime("%a"), size=9, align="center",
              fill=GREY_L if d.weekday() >= 4 else None)   # Fri/Sat weekend shading (BD week)
        for base, sec in ((3, "Domestic"), (7, "International")):
            cap, bk = piv[d].get(sec, (0, 0))
            _num_row(ws, r, [(base, int(cap), F_INT), (base + 1, int(bk), F_INT)])
            _lf_cell(ws, r, base + 2, load_factor(bk, cap))
        r += 1
    # period TOTAL row — the headline figure managers look for first
    _cell(ws, r, 1, "TOTAL", bold=True, fill=BLUE_LIGHT)
    _cell(ws, r, 2, "", fill=BLUE_LIGHT)
    for base, sec in ((3, "Domestic"), (7, "International")):
        sub = daily[daily["sector"] == sec]
        cap, bk = float(sub["capacity"].sum()), float(sub["booked"].sum())
        _num_row(ws, r, [(base, int(cap), F_INT), (base + 1, int(bk), F_INT)],
                 bold=True, fill=BLUE_LIGHT)
        _lf_cell(ws, r, base + 2, load_factor(bk, cap), bold=True)


# ---------------------------------------------------------------------------
# entry point
# ---------------------------------------------------------------------------
def generate(params: dict | None = None, cfg: Config | None = None) -> Path:
    """Build the Flight Load Report (company 'Ordered Data' matrix + summaries).

    params: optional ``start``/``end`` (YYYY-MM-DD); default = the FORWARD window
    in flight_loads.parquet (current bookings for upcoming flights).
    """
    params = params or {}
    cfg = cfg or load_config(validate=True)
    src = _loads_path(cfg)
    if not Path(src).is_file():
        raise FileNotFoundError(f"flight loads parquet not found: {src} "
                                f"(run the flight-loads ingest first)")
    con = duckdb.connect()                       # parquet-only — no warehouse needed
    fwd = con.sql(f"""SELECT MIN(flight_date)::DATE, MAX(flight_date)::DATE
                      FROM read_parquet('{src}') WHERE UPPER(period)='FORWARD'""").fetchone()
    hist = _history_path(cfg)
    hist_min = (con.sql(f"SELECT MIN(flight_date) FROM read_parquet('{hist}')").fetchone()[0]
                if Path(hist).is_file() else None)
    start, end, label = resolve_period(params, fwd[0], fwd[1], hist_min)

    matrix, routes, daily = _fetch(con, cfg, start, end)
    if matrix.empty:
        raise ValueError(f"No flight-load rows between {start} and {end}.")

    wb = Workbook()
    _write_matrix(wb.active, matrix, start, end, label)
    _write_routes(wb, routes, start, end)
    _write_daily(wb, daily)

    out = cfg.output_dir / f"Load_Report_{start.isoformat()}_to_{end.isoformat()}.xlsx"
    out.parent.mkdir(parents=True, exist_ok=True)
    try:
        wb.save(out)
    except PermissionError:                      # file open in Excel -> sibling _v2
        out = out.with_name(out.stem + "_v2.xlsx")
        wb.save(out)
    return out
