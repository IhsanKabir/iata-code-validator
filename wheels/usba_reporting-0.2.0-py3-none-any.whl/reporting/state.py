"""
reporting.state — small client-side persistence for the Reports tab (Phase 3).

Two jobs, both local + stdlib-only + best-effort:
  * **"open last"** — remember each user's most-recently-opened report so the tab can
    offer a one-click "Open last downloaded" across sessions;
  * **audit trail** — append a local download/open log (the convenient-path trail named
    in plan §4). The AUTHORITATIVE audit is the OS file-access auditing on the share
    (§6.6); this client log is a supplementary, human-readable record.

Paths are injectable (env vars / args) so this is unit-testable without touching $HOME.
"""
from __future__ import annotations

import json
import os
from datetime import datetime
from pathlib import Path

from ._io import atomic_write_text


def state_path() -> Path:
    """Per-machine 'open last' state (override with $USBA_REPORTS_STATE)."""
    return Path(os.environ.get("USBA_REPORTS_STATE", str(Path.home() / ".usba_reports_state.json")))


def audit_path() -> Path:
    """Local audit JSONL (override with $USBA_REPORTS_AUDIT)."""
    return Path(os.environ.get("USBA_REPORTS_AUDIT", str(Path.home() / ".usba_reports_audit.jsonl")))


# --- "open last" state --------------------------------------------------------
def load_state(path: Path) -> dict:
    path = Path(path)
    if not path.is_file():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {}


def save_state(path: Path, state: dict) -> None:
    atomic_write_text(path, json.dumps(state, indent=2))


def record_open(path: Path, user: str, report: str, file_path: Path | str,
                *, now: datetime | None = None) -> dict:
    """Remember that ``user`` last opened ``report`` (at ``file_path``). Returns the new state."""
    entry = {
        "report": report,
        "path": str(file_path),
        "at": (now or datetime.now()).strftime("%Y-%m-%d %H:%M"),
    }
    updated = {**load_state(path), user: entry}   # build a NEW dict — no in-place mutation
    save_state(path, updated)
    return updated


def last_open(path: Path, user: str) -> dict | None:
    """Return ``{report, path, at}`` for ``user``'s last open, or None."""
    return load_state(path).get(user)


# --- audit trail (append-only JSONL) ------------------------------------------
def append_audit(path: Path, user: str, action: str, report: str, *, now: datetime | None = None) -> bool:
    """Append one audit line. Best-effort: returns False (no raise) if it can't write."""
    line = json.dumps({
        "ts": (now or datetime.now()).strftime("%Y-%m-%d %H:%M:%S"),
        "user": user, "action": action, "report": report,
    })
    try:
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        with open(p, "a", encoding="utf-8") as f:   # append, not replace (keep history)
            f.write(line + "\n")
        return True
    except OSError:
        return False


def read_audit(path: Path) -> list[dict]:
    """Parse the audit JSONL into a list of events (skips blank/corrupt lines)."""
    p = Path(path)
    if not p.is_file():
        return []
    out = []
    for ln in p.read_text(encoding="utf-8").splitlines():
        ln = ln.strip()
        if not ln:
            continue
        try:
            out.append(json.loads(ln))
        except json.JSONDecodeError:
            continue
    return out
