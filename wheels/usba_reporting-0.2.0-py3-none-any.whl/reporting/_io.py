"""
reporting._io — tiny shared, atomic file-write helpers (stdlib only).

The "write to a temp file in the SAME directory, then ``os.replace``" pattern is the
safe way to publish a file other processes may be reading: ``os.replace`` is atomic on a
single NTFS volume, so a reader never sees a half-written file, and a failed write never
clobbers the existing one. This used to be reimplemented in publish.py / auth.py /
state.py (some without temp cleanup); this module is the single source of truth.

stdlib-only by design, so importing it (transitively, via the package) never pulls in
the heavy analytics stack — keeping the download-only exe lean.
"""
from __future__ import annotations

import os
import shutil
from pathlib import Path


def _tmp_for(final: Path) -> Path:
    """A sibling temp path in the SAME directory (required for an atomic os.replace)."""
    return final.parent / f".{final.name}.{os.getpid()}.tmp"


def _silent_unlink(p: Path) -> None:
    try:
        p.unlink(missing_ok=True)
    except OSError:
        pass


def atomic_write_text(path: Path, text: str, *, encoding: str = "utf-8") -> Path:
    """Write ``text`` to ``path`` atomically. On any error, the temp is removed (never leaked)."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = _tmp_for(path)
    try:
        tmp.write_text(text, encoding=encoding)
        os.replace(tmp, path)
    except OSError:
        _silent_unlink(tmp)
        raise
    return path


def atomic_copy(src: Path, final: Path) -> Path:
    """Copy ``src`` -> ``final`` atomically (temp-in-dest then replace). Temp never leaked.

    Re-raises the original ``OSError`` (e.g. destination open/locked/read-only) so the
    caller's lock-safe handler can decide what to do.
    """
    final = Path(final)
    final.parent.mkdir(parents=True, exist_ok=True)
    tmp = _tmp_for(final)
    try:
        shutil.copy2(src, tmp)          # copy2 preserves mtime so "freshness" reflects the build
        os.replace(tmp, final)
    except OSError:
        _silent_unlink(tmp)
        raise
    return final
