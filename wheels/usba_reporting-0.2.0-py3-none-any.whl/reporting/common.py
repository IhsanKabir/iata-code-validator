"""
reporting.common — shared SQL/data helpers used by more than one builder.

Currently: the time-versioned commission-rate CASE expression (ported verbatim
from scripts/target.py, but parameterised on Config so it has no hidden paths).
"""
from __future__ import annotations

from .config import Config


def build_rate_sql(cfg: Config) -> str:
    """Return a ``CASE WHEN ... END`` snippet yielding the per-row commission_rate,
    honoring the time-versioned schema in ``reference/commission_rates.xlsx``.

    First matching rule (by ascending ``rule_order``) wins; each rule is gated by
    both its (field, values) match AND the transaction Date falling inside
    (effective_from, effective_to]. Missing file -> flat 0.07 fallback.
    """
    import pandas as pd   # lazy: keeps `import reporting` free of the heavy stack (lazy-import contract)

    rates_file = cfg.reference / "commission_rates.xlsx"
    if not rates_file.exists():
        return "0.07"
    rates = pd.read_excel(rates_file, sheet_name="rates").sort_values("rule_order")

    lines = ["CASE"]
    for _, row in rates.iterrows():
        field = str(row["match_field"])
        vals = str(row["match_values"])
        rate = float(row["commission_rate"])
        eff_from = (pd.Timestamp(row.get("effective_from"))
                    if pd.notna(row.get("effective_from")) else pd.Timestamp("1900-01-01"))
        eff_to = pd.Timestamp(row.get("effective_to")) if pd.notna(row.get("effective_to")) else None

        date_clauses = [f'"Date"::DATE >= DATE \'{eff_from.strftime("%Y-%m-%d")}\'']
        if eff_to is not None:
            date_clauses.append(f'"Date"::DATE <= DATE \'{eff_to.strftime("%Y-%m-%d")}\'')
        date_guard = " AND ".join(date_clauses)

        if field == "*":
            lines.append(f"WHEN {date_guard} THEN {rate}")
        else:
            in_clause = ", ".join(f"'{v.strip()}'" for v in vals.split(","))
            lines.append(f'WHEN CAST("{field}" AS VARCHAR) IN ({in_clause}) AND {date_guard} THEN {rate}')

    lines.append("ELSE 0.07")
    lines.append("END")
    return "\n".join(lines)
