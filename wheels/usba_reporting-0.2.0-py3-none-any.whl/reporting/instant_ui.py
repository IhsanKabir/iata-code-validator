"""
reporting.instant_ui — Tk windows for Instant Reports + the mail-list editor.

Both windows are opened from buttons that ReportsFrame shows ONLY AFTER the
rotating-password login (the analyst's requirement: "keep it under the report
showing password layer"). The module lazy-imports Tk and the heavy engine so
importing it costs nothing on machines/builds that never use it.

  InstantBuildWindow   pick raw sales xlsx file(s) -> reports build locally,
                       ONE BY ONE, from the published Data Kit. Pure client-side:
                       nothing is written to the share.
  RecipientsWindow     edit reference/report_email_list.xlsx (Name | Email |
                       Reports) — the morning-mail recipient list — without
                       hand-building the file. Analyst machines only (needs the
                       local data root).
"""
from __future__ import annotations

import queue
import threading
from pathlib import Path

NAVY = "#1F3864"; BLUE = "#2E5395"; GREY = "#7F7F7F"; WHITE = "#FFFFFF"
GREEN_BG = "#E2EFDA"; AMBER_BG = "#FFF2CC"

# morning-mail report keys (mirrors scripts/email_reports_graph.REPORT_MENU)
MAIL_REPORT_KEYS = ["daily_report", "flight_load", "june_target", "sales_person",
                    "sales_person_packs", "iata_worklist", "dsr_current"]


def open_instant_build(parent, reports_dir: Path) -> None:
    """The 'Build from data' window (sequential client-side report builds)."""
    import tkinter as tk
    from tkinter import filedialog, messagebox

    try:
        from . import instant                      # needs duckdb/pandas in THIS app
    except ImportError as exc:
        messagebox.showinfo("Instant reports",
                            f"This build of the app doesn't include the report engine ({exc}).")
        return

    kit = Path(reports_dir) / "Data_Kit_latest.zip"

    win = tk.Toplevel(parent); win.title("Build reports from raw data")
    win.geometry("700x540"); win.configure(bg=WHITE); win.grab_set()
    tk.Label(win, text="Instant Reports", bg=WHITE, fg=NAVY,
             font=("Segoe UI", 14, "bold")).pack(anchor="w", padx=18, pady=(14, 0))
    tk.Label(win, text=("Pick the raw Zenith sales export(s). Reports build ON THIS computer, "
                        "one by one, using the analyst's latest Data Kit — nothing is uploaded."),
             bg=WHITE, fg=GREY, font=("Segoe UI", 9), wraplength=650,
             justify="left").pack(anchor="w", padx=18, pady=(2, 8))

    kit_ok = kit.is_file()
    tk.Label(win, text=("Data Kit: " + (f"OK — {kit.name}" if kit_ok else
                        f"NOT FOUND on the share ({kit}) — ask the analyst to publish it")),
             bg=(GREEN_BG if kit_ok else AMBER_BG), fg=NAVY, anchor="w",
             font=("Segoe UI", 9)).pack(fill="x", padx=18, ipady=4)

    raw_files: list[Path] = []
    raw_lbl = tk.Label(win, text="No raw file selected.", bg=WHITE, fg=GREY, font=("Segoe UI", 9))

    def pick_raw():
        picks = filedialog.askopenfilenames(title="Raw Zenith sales export(s)",
                                            filetypes=[("Excel", "*.xlsx")])
        if picks:
            raw_files.clear(); raw_files.extend(Path(p) for p in picks)
            raw_lbl.config(text="Raw: " + ", ".join(p.name for p in raw_files)[:88])

    row = tk.Frame(win, bg=WHITE); row.pack(fill="x", padx=18, pady=(10, 0))
    tk.Button(row, text="Choose raw sales file(s)…", bg=BLUE, fg=WHITE, relief="flat",
              padx=12, pady=4, command=pick_raw).pack(side="left")
    raw_lbl.pack(anchor="w", padx=18, pady=(4, 8))

    # report checklist — built one by one, in this order
    checks = tk.Frame(win, bg=WHITE); checks.pack(anchor="w", padx=18)
    vars_: dict[str, tk.BooleanVar] = {}
    for key, label in instant.INSTANT_REPORTS.items():
        v = tk.BooleanVar(value=True); vars_[key] = v
        tk.Checkbutton(checks, text=label, variable=v, bg=WHITE, fg=NAVY,
                       font=("Segoe UI", 10), anchor="w").pack(anchor="w")
    tk.Label(checks, text="Sales-Person Target Packs — needs flight-load data (next phase)",
             bg=WHITE, fg=GREY, font=("Segoe UI", 9)).pack(anchor="w", pady=(2, 0))

    log = tk.Text(win, height=11, bg="#F8F9FB", fg="#222222", font=("Consolas", 9),
                  relief="flat", state="disabled")
    log.pack(fill="both", expand=True, padx=18, pady=(10, 6))
    q: "queue.Queue[str | tuple]" = queue.Queue()

    def log_line(msg: str):
        log.config(state="normal"); log.insert("end", msg + "\n")
        log.see("end"); log.config(state="disabled")

    btns = tk.Frame(win, bg=WHITE); btns.pack(fill="x", padx=18, pady=(0, 14))
    build_btn = tk.Button(btns, text="Build (one by one)", bg=NAVY, fg=WHITE,
                          font=("Segoe UI", 10, "bold"), relief="flat", padx=16, pady=6)
    build_btn.pack(side="left")
    open_btn = tk.Button(btns, text="Open output folder", relief="flat", bg=WHITE, fg=BLUE,
                         state="disabled",
                         command=lambda: __import__("os").startfile(str(instant.output_dir())))
    open_btn.pack(side="left", padx=10)

    def worker(keys: list[str]):
        try:
            instant.assemble_root(raw_files, kit, progress=lambda m: q.put(m))
            results = instant.build_reports(keys, progress=lambda m: q.put(m))
            q.put(("done", results))
        except Exception as exc:                   # noqa: BLE001 — show, don't crash the app
            q.put(("done_err", f"{type(exc).__name__}: {exc}"))

    def poll():
        try:
            while True:
                item = q.get_nowait()
                if isinstance(item, str):
                    log_line(item)
                elif item[0] == "done":
                    ok = sum(1 for _k, p, _m in item[1] if p)
                    log_line(f"— finished: {ok}/{len(item[1])} report(s) built —")
                    open_btn.config(state="normal"); build_btn.config(state="normal")
                    return
                else:
                    log_line(f"[ERROR] {item[1]}")
                    build_btn.config(state="normal")
                    return
        except queue.Empty:
            pass
        win.after(120, poll)

    def start():
        keys = [k for k, v in vars_.items() if v.get()]
        if not kit.is_file():
            messagebox.showerror("Instant reports", "Data Kit not found on the share."); return
        if not raw_files:
            messagebox.showerror("Instant reports", "Pick at least one raw sales xlsx first."); return
        if not keys:
            messagebox.showerror("Instant reports", "Tick at least one report."); return
        build_btn.config(state="disabled"); open_btn.config(state="disabled")
        log_line(f"building {len(keys)} report(s), one by one ...")
        threading.Thread(target=worker, args=(keys,), daemon=True).start()
        win.after(120, poll)

    build_btn.config(command=start)


def open_recipients_editor(parent, reference_dir: Path) -> None:
    """Grid editor for the morning-mail recipient list (no hand-built Excel needed)."""
    import tkinter as tk
    from tkinter import messagebox, ttk

    xlsx = Path(reference_dir) / "report_email_list.xlsx"

    win = tk.Toplevel(parent); win.title("Morning-mail recipients")
    win.geometry("680x460"); win.configure(bg=WHITE); win.grab_set()
    tk.Label(win, text="Report e-mail recipients", bg=WHITE, fg=NAVY,
             font=("Segoe UI", 14, "bold")).pack(anchor="w", padx=18, pady=(14, 0))
    tk.Label(win, text=(f"Saved to {xlsx.name} — the morning Graph mail reads it directly. "
                        "Reports: " + ", ".join(MAIL_REPORT_KEYS)),
             bg=WHITE, fg=GREY, font=("Segoe UI", 9), wraplength=640,
             justify="left").pack(anchor="w", padx=18, pady=(2, 8))

    cols = ("name", "email", "reports")
    tv = ttk.Treeview(win, columns=cols, show="headings", height=9)
    for c, h, w in (("name", "Name", 150), ("email", "Email", 220), ("reports", "Reports", 260)):
        tv.heading(c, text=h); tv.column(c, width=w, anchor="w")
    tv.pack(fill="both", expand=True, padx=18)

    # preload current file so editing is round-trip safe
    if xlsx.is_file():
        try:
            import openpyxl
            ws = openpyxl.load_workbook(xlsx, read_only=True).active
            for r in list(ws.iter_rows(values_only=True))[1:]:
                if r and (r[1] or "").strip():
                    tv.insert("", "end", values=(str(r[0] or ""), str(r[1]), str(r[2] or "")))
        except Exception:                          # noqa: BLE001 — start empty on a bad file
            pass

    form = tk.Frame(win, bg=WHITE); form.pack(fill="x", padx=18, pady=(8, 0))
    e_name, e_mail, e_rep = (tk.Entry(form, width=18), tk.Entry(form, width=26),
                             tk.Entry(form, width=30))
    for i, (lbl, ent) in enumerate((("Name", e_name), ("Email", e_mail),
                                    ("Reports (comma)", e_rep))):
        tk.Label(form, text=lbl, bg=WHITE, fg=GREY, font=("Segoe UI", 8)).grid(row=0, column=i, sticky="w")
        ent.grid(row=1, column=i, padx=(0, 8))
    e_rep.insert(0, "daily_report")

    def add_row():
        mail, reps = e_mail.get().strip(), e_rep.get().strip()
        if "@" not in mail or not reps:
            messagebox.showerror("Recipients", "Need a valid Email and at least one report key."); return
        tv.insert("", "end", values=(e_name.get().strip(), mail, reps))
        e_name.delete(0, "end"); e_mail.delete(0, "end")

    def remove_sel():
        for iid in tv.selection():
            tv.delete(iid)

    def save():
        import openpyxl
        wb = openpyxl.Workbook(); ws = wb.active; ws.title = "recipients"
        ws.append(["Name", "Email", "Reports"])
        for iid in tv.get_children():
            ws.append(list(tv.item(iid, "values")))
        for col, w in zip("ABC", (24, 34, 46)):
            ws.column_dimensions[col].width = w
        try:
            wb.save(xlsx)
        except PermissionError:
            messagebox.showerror("Recipients", f"{xlsx.name} is open in Excel — close it and Save again.")
            return
        messagebox.showinfo("Recipients", f"Saved {len(tv.get_children())} recipient(s) -> {xlsx}")

    btns = tk.Frame(win, bg=WHITE); btns.pack(fill="x", padx=18, pady=(8, 14))
    tk.Button(btns, text="Add", bg=BLUE, fg=WHITE, relief="flat", padx=14, command=add_row).pack(side="left")
    tk.Button(btns, text="Remove selected", relief="flat", bg=WHITE, fg=GREY,
              command=remove_sel).pack(side="left", padx=8)
    tk.Button(btns, text="Save", bg=NAVY, fg=WHITE, font=("Segoe UI", 10, "bold"),
              relief="flat", padx=18, command=save).pack(side="right")
