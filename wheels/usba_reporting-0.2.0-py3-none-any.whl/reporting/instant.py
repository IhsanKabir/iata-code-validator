"""
reporting.instant — build reports ON THIS MACHINE from uploaded raw files ("Instant Reports").

The pipeline machine publishes finished workbooks; THIS module lets any exe user
(behind the same Reports password) rebuild them locally from:

  * one or more RAW Zenith sales exports (the daily xlsx), plus
  * the published **Data Kit** (Data_Kit_latest.zip on the share) — the analyst's
    prebuilt dimension masters (dim_customer, zones, commission rates, OTA list),
    so client machines never rebuild the heavy mapping chain.

HOW IT WORKS
------------
1. ``assemble_root(raw_files, kit_zip)`` lays out a synthetic data root under
   %LOCALAPPDATA%/USBA_InstantReports/work/ that LOOKS exactly like E:\\Analysis:
       curated/sales/year=*/month=*/day=*/*.parquet   <- ingested raw files
       curated/dim_customer/dim_customer.parquet      <- from the kit
       reference/...                                  <- from the kit
       warehouse.duckdb                               <- dim_customer table only
2. ``build_reports(keys, progress)`` points ANALYSIS_HOME at that root and runs
   the SAME builder code that publishes the official reports — one by one (the
   analyst's explicit preference), reporting progress per report.

The work root is a FIXED path reused per session and wiped on every assemble:
``builders.dsr`` resolves its data root at IMPORT time, so the path must never
change within one process.

INGEST: a faithful, self-contained subset of scripts/02_ingest_sales.py (sheet
auto-detect, required-column check, date coercion, object->string normalization,
hive partitioning). The full pipeline script remains the authority for the real
warehouse; this one only feeds the throwaway instant root.
"""
from __future__ import annotations

import os
import shutil
import zipfile
from pathlib import Path
from typing import Callable

# ---- layout ------------------------------------------------------------------
WORK_ROOT = Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "USBA_InstantReports" / "work"

# ---- ingest constants (mirrors scripts/pipeline_config.SalesIngestConfig) -----
SHEET_NAME_CANDIDATES = ("Sheet0", "Sheet1", "Sales", "Export")
COL_CUSTOMER_ID = "Customer ID"
COL_DATE = "Date"

# Reports the instant engine can build today. Target Packs need flight-load /
# zenith-pull inputs a manager's machine doesn't have — next phase.
INSTANT_REPORTS: dict[str, str] = {
    "daily": "Daily Report",
    "dsr": "DSR (current month)",
    "sales_person": "Sales-Person Gross",
}


def _read_raw_sales(xlsx: Path):
    """One raw Zenith export -> cleaned DataFrame (date-typed, string-normalized)."""
    import pandas as pd
    from openpyxl import load_workbook

    names = load_workbook(xlsx, read_only=True).sheetnames
    sheet = next((s for s in SHEET_NAME_CANDIDATES if s in names), names[0])
    df = pd.read_excel(xlsx, sheet_name=sheet, header=0)
    for col in (COL_CUSTOMER_ID, COL_DATE):
        if col not in df.columns:
            raise ValueError(f"{xlsx.name}: required column {col!r} missing "
                             f"(is this really a Zenith sales export?)")
    df = df[df[COL_CUSTOMER_ID].notna()].copy()
    df[COL_DATE] = pd.to_datetime(df[COL_DATE], errors="coerce")
    # rows with an unparseable Date keep flowing (year=0 sentinel, same as pipeline)
    df["year"] = df[COL_DATE].dt.year.fillna(0).astype("int32")
    df["month"] = df[COL_DATE].dt.month.fillna(0).astype("int32")
    df["day"] = df[COL_DATE].dt.day.fillna(0).astype("int32")
    df["source_file"] = xlsx.name
    # Some exports lack the per-row segment count; the DSR does
    # COALESCE(seg, 1), but the column must EXIST for the SQL to bind —
    # in the big pipeline union_by_name supplies it from other months.
    if "seg" not in df.columns:
        df["seg"] = pd.array([None] * len(df), dtype="Float64")
    # object -> nullable string so PyArrow never chokes on mixed-type columns
    for c in [c for c in df.columns if df[c].dtype == object]:
        df[c] = df[c].astype("string")
    return df


def assemble_root(raw_files: list[Path], kit_zip: Path,
                  progress: Callable[[str], None] = print) -> Path:
    """Build the synthetic data root from kit + raw files; return its path."""
    import duckdb
    import pandas as pd

    progress(f"work root: {WORK_ROOT}")
    if WORK_ROOT.exists():
        shutil.rmtree(WORK_ROOT, ignore_errors=True)
    WORK_ROOT.mkdir(parents=True, exist_ok=True)

    progress(f"unpacking data kit: {Path(kit_zip).name}")
    with zipfile.ZipFile(kit_zip) as zf:
        for member in zf.infolist():                       # zip-slip guard
            dest = (WORK_ROOT / member.filename).resolve()
            if not dest.is_relative_to(WORK_ROOT.resolve()):
                raise ValueError(f"Unsafe path in data kit: {member.filename!r}")
        zf.extractall(WORK_ROOT)
    dim_parquet = WORK_ROOT / "curated" / "dim_customer" / "dim_customer.parquet"
    if not dim_parquet.is_file():
        raise FileNotFoundError("Data kit is missing dim_customer.parquet — "
                                "re-publish the kit from the pipeline machine.")

    sales_dir = WORK_ROOT / "curated" / "sales"
    sales_dir.mkdir(parents=True, exist_ok=True)
    frames = []
    for f in raw_files:
        progress(f"ingesting {Path(f).name} ...")
        frames.append(_read_raw_sales(Path(f)))
    allf = pd.concat(frames, ignore_index=True)
    progress(f"{len(allf):,} sale rows -> parquet partitions")
    allf.to_parquet(sales_dir, partition_cols=["year", "month", "day"], index=False)

    progress("building mini warehouse (dim_customer)")
    con = duckdb.connect(str(WORK_ROOT / "warehouse.duckdb"))
    try:
        con.execute(f"CREATE OR REPLACE TABLE dim_customer AS "
                    f"SELECT * FROM read_parquet('{dim_parquet.as_posix()}')")
    finally:
        con.close()
    return WORK_ROOT


def build_reports(keys: list[str],
                  progress: Callable[[str], None] = print) -> list[tuple[str, Path | None, str]]:
    """Run the chosen builders ONE BY ONE against the assembled root.

    Returns ``[(key, output_path_or_None, message)]``. ANALYSIS_HOME is pinned to
    WORK_ROOT before the builders are imported (dsr resolves its root at import).
    """
    os.environ["ANALYSIS_HOME"] = str(WORK_ROOT)
    from . import config as _config
    cfg = _config.load_config(validate=True)

    results: list[tuple[str, Path | None, str]] = []
    for key in keys:                                  # sequential by design
        label = INSTANT_REPORTS.get(key, key)
        progress(f"building {label} ...")
        try:
            if key == "daily":
                from .builders import daily_snapshot
                out = daily_snapshot.generate({}, cfg)
            elif key == "dsr":
                from .builders import dsr
                # the DSR is month-scoped: use the newest month present in the
                # uploaded data (a raw export covers one month in practice)
                import duckdb as _duck
                with _duck.connect() as _c:
                    ym = _c.execute(
                        f"SELECT strftime(MAX(\"Date\"::DATE), '%Y-%m') FROM "
                        f"read_parquet('{cfg.sales_glob}', hive_partitioning=1, "
                        f"union_by_name=1)").fetchone()[0]
                out = dsr.generate({"month": ym}, cfg)
            elif key == "sales_person":
                from .builders import salesperson_gross
                out = salesperson_gross.generate({"split_individual": False}, cfg)
            else:
                raise ValueError(f"unknown instant report: {key}")
            progress(f"  [OK] {Path(out).name}")
            results.append((key, Path(out), "OK"))
        except Exception as exc:                       # noqa: BLE001 — surface per report,
            progress(f"  [FAIL] {label}: {exc}")       # keep building the rest (one-by-one)
            results.append((key, None, f"{type(exc).__name__}: {exc}"))
    return results


def output_dir() -> Path:
    """Where finished instant reports land (= the root's logs/ folder)."""
    return WORK_ROOT / "logs"
