"""
reporting.config — the single source of truth for every path the report builders use.

WHY THIS MODULE EXISTS
----------------------
The original scripts derived the project root from ``Path(__file__).parent.parent``
and, in ~22 places, called ``duckdb.connect("warehouse.duckdb")`` with a RELATIVE
path. Both break the moment the code runs anywhere other than ``E:\\Analysis`` as the
current directory — most importantly inside a **PyInstaller-frozen .exe**, where
``__file__`` points into the temporary extraction sandbox (``sys._MEIPASS``), NOT the
real data on disk. (Confirmed by PyInstaller's runtime docs.)

So this module resolves the DATA ROOT *once*, in a frozen-aware way, and every builder
imports its paths from here. No builder should ever hardcode or cwd-relative a path again.

RESOLUTION ORDER (first hit wins)
---------------------------------
1. ``ANALYSIS_HOME`` environment variable  (recommended for the exe + scheduled task).
2. ``settings.json`` next to the module/exe, key ``data_root``.
3. Frozen exe  -> the folder containing the .exe (external data ships beside the app).
4. Dev / CLI   -> the repo root (two levels up from this file), the original behaviour.

Our data is always EXTERNAL on disk (never bundled into the exe), so we deliberately
use ``sys.executable``'s directory when frozen — never ``sys._MEIPASS``.
"""
from __future__ import annotations

import json
import os
import sys
from dataclasses import dataclass
from pathlib import Path


def _is_frozen() -> bool:
    """True when running inside a PyInstaller (or similar) bundle."""
    return bool(getattr(sys, "frozen", False))


def _resolve_data_root() -> Path:
    # 1) explicit override — the clean way to point the exe / scheduled task at the data
    env = os.environ.get("ANALYSIS_HOME")
    if env:
        return Path(env).expanduser().resolve()

    # 2) settings.json beside the executable (frozen) or this module (dev)
    base = Path(sys.executable).resolve().parent if _is_frozen() else Path(__file__).resolve().parent
    settings = base / "settings.json"
    if settings.is_file():
        try:
            root = json.loads(settings.read_text(encoding="utf-8")).get("data_root")
            if root:
                return Path(root).expanduser().resolve()
        except (json.JSONDecodeError, OSError):
            pass  # fall through to the defaults

    # 3) frozen exe with the data folder shipped next to it
    if _is_frozen():
        return Path(sys.executable).resolve().parent

    # 4) dev / CLI fallback: this file is <repo_root>/reporting/config.py
    return Path(__file__).resolve().parent.parent


@dataclass(frozen=True)
class Config:
    """Resolved, immutable set of paths. Build it via :func:`load_config`."""

    data_root: Path

    # --- inputs the builders read --------------------------------------------
    @property
    def warehouse(self) -> Path:
        return self.data_root / "warehouse.duckdb"

    @property
    def curated_sales(self) -> Path:
        return self.data_root / "curated" / "sales"

    @property
    def sales_glob(self) -> str:
        # forward slashes so it works inside DuckDB's read_parquet() on Windows
        return self.curated_sales.as_posix() + "/**/*.parquet"

    @property
    def reference(self) -> Path:
        return self.data_root / "reference"

    @property
    def logs(self) -> Path:
        return self.data_root / "logs"

    # --- outputs --------------------------------------------------------------
    @property
    def output_dir(self) -> Path:
        """Where generated reports are written. Overridable (e.g. the exe 'Save As')."""
        return Path(os.environ.get("REPORT_OUTPUT_DIR", str(self.logs)))

    @property
    def shared_reports(self) -> Path | None:
        """Model-B publish target (the ACL'd \\\\share\\Reports root). None if unset."""
        v = os.environ.get("SHARED_REPORTS_DIR")
        return Path(v) if v else None

    # --- guard ----------------------------------------------------------------
    def validate(self) -> "Config":
        """Fail fast with a clear message if the data root is wrong."""
        if not self.warehouse.is_file():
            raise FileNotFoundError(
                f"warehouse.duckdb not found at {self.warehouse}. "
                f"Set the ANALYSIS_HOME env var (or settings.json data_root) "
                f"to the folder that contains warehouse.duckdb / curated / reference."
            )
        return self


def load_config(validate: bool = False) -> Config:
    """Resolve the data root and return a :class:`Config`. Pass validate=True to check it exists."""
    cfg = Config(data_root=_resolve_data_root())
    return cfg.validate() if validate else cfg
