"""
reporting.excel_merge — copy a generated report's sheets INTO an existing workbook.

Why: the analyst keeps master workbooks (e.g. one file per month/board pack) and
wants a freshly-built report APPENDED as new tabs instead of living in its own
file. openpyxl cannot copy sheets between workbooks natively, so this module does
a faithful cell-by-cell transplant:

  * values + number formats
  * fonts / fills / borders / alignment (via copy() of each style part)
  * merged-cell ranges, column widths, row heights, freeze panes, gridline flag
  * hyperlinks — INTERNAL links ("#'Zone Target'!A5") are REWRITTEN to the
    renamed sheet so click-throughs keep working after the copy

Sheet naming: every incoming sheet gets a ``prefix`` ("DSR 2026-05 — <sheet>"),
then is uniquified against the destination (Excel's 31-char limit respected).

The DESTINATION file is saved in place with the usual lock fallback (*_v2) so an
open-in-Excel master never crashes the run.
"""
from __future__ import annotations

import re
from copy import copy
from pathlib import Path

from openpyxl import load_workbook
from openpyxl.utils import get_column_letter

# matches an internal hyperlink location like  #'Agency Route Targets'!A12  or  #Sheet1!B2
_INTERNAL_LINK_RE = re.compile(r"^#?(?:'(?P<q>[^']+)'|(?P<p>[^'!]+))!(?P<ref>.+)$")


def _unique_title(base: str, taken: set[str]) -> str:
    """Excel-legal (<=31 chars), unique against ``taken`` (case-insensitive)."""
    clean = re.sub(r"[\\/?*\[\]:]", "-", base).strip() or "Sheet"
    clean = clean[:31]
    title, i = clean, 1
    while title.lower() in taken:
        suffix = f" ({i})"
        title = clean[: 31 - len(suffix)] + suffix
        i += 1
    taken.add(title.lower())
    return title


def _copy_sheet(src_ws, dest_wb, title: str):
    """Transplant one worksheet (values, styles, layout) into ``dest_wb``."""
    out = dest_wb.create_sheet(title)
    out.sheet_view.showGridLines = src_ws.sheet_view.showGridLines
    if src_ws.freeze_panes:
        out.freeze_panes = src_ws.freeze_panes
    for letter, dim in src_ws.column_dimensions.items():
        if dim.width is not None:
            out.column_dimensions[letter].width = dim.width
    for idx, dim in src_ws.row_dimensions.items():
        if dim.height is not None:
            out.row_dimensions[idx].height = dim.height
    for row in src_ws.iter_rows():
        for cell in row:
            tgt = out.cell(row=cell.row, column=cell.column, value=cell.value)
            if cell.has_style:
                tgt.font = copy(cell.font)
                tgt.fill = copy(cell.fill)
                tgt.border = copy(cell.border)
                tgt.alignment = copy(cell.alignment)
                tgt.number_format = cell.number_format
            if cell.hyperlink is not None:
                # keep the raw target for now; internal ones are rewritten after
                # all sheets exist (we need the full old->new title map first)
                tgt.hyperlink = copy(cell.hyperlink)
    for rng in src_ws.merged_cells.ranges:
        out.merge_cells(str(rng))
    return out


def _rewrite_internal_links(dest_wb, copied_titles: dict[str, str]) -> None:
    """Point copied internal hyperlinks at the RENAMED sheets so they still work."""
    for title in copied_titles.values():
        ws = dest_wb[title]
        for row in ws.iter_rows():
            for cell in row:
                link = cell.hyperlink
                if link is None or not (link.location or link.target):
                    continue
                loc = link.location or link.target or ""
                m = _INTERNAL_LINK_RE.match(loc)
                if not m:
                    continue
                old_sheet = m.group("q") or m.group("p")
                new_sheet = copied_titles.get(old_sheet)
                if new_sheet:
                    cell.hyperlink.location = None
                    cell.hyperlink.target = f"#'{new_sheet}'!{m.group('ref')}"


def append_workbook(src_path: Path, dest_path: Path, *, prefix: str = "") -> list[str]:
    """Append every sheet of ``src_path`` into ``dest_path``; return the new tab names.

    ``prefix`` (e.g. "DSR 2026-05") namespaces the incoming tabs so repeated
    appends never collide; pass "" to keep the original sheet names (still
    uniquified). The destination is saved in place; if Excel holds it open the
    save falls back to a ``*_v2.xlsx`` sibling (path printed).
    """
    src_path, dest_path = Path(src_path), Path(dest_path)
    if not dest_path.is_file():
        raise FileNotFoundError(f"Destination workbook not found: {dest_path}")
    src = load_workbook(src_path)            # styles needed -> no read_only
    dest = load_workbook(dest_path)

    taken = {n.lower() for n in dest.sheetnames}
    copied: dict[str, str] = {}              # old sheet title -> new title in dest
    for ws in src.worksheets:
        base = f"{prefix} — {ws.title}" if prefix else ws.title
        copied[ws.title] = _copy_sheet(ws, dest, _unique_title(base, taken)).title
    _rewrite_internal_links(dest, copied)

    try:
        dest.save(dest_path)
        saved = dest_path
    except PermissionError:                  # master open in Excel -> sibling copy
        saved = dest_path.with_name(dest_path.stem + "_v2.xlsx")
        dest.save(saved)
        print(f"[WARN] {dest_path.name} is open in Excel — appended copy saved as {saved.name}")
    print(f"appended {len(copied)} sheet(s) -> {saved}")
    return list(copied.values())
