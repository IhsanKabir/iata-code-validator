"""
reporting.builders.salesperson_gross — per-sales-person gross-sales workbook.

"For each sales person, what did each of their agents/agencies sell — GROSS (and
NET) — over the last three completed months plus the June month-to-date?"

  * Index            -> every sales person with totals (sorted), grand total
  * <one tab each>   -> one tab per sales person, their agents listed
  * Unmapped         -> agents/agencies with NO sales person assigned

GROSS = balance of 'Ticket payment' rows (full fare, before commission).
NET   = balance - commission.  Direct channels (WEB/MOBILE/OFFICE/CALL_CENTER) dropped.

Public entry point:  ``generate(params, cfg) -> Path``  (returns the combined workbook).
Optional params: ``split_individual`` (default True), ``individual_dir``, ``individual_zip``.
"""
from __future__ import annotations

import re
import zipfile
from pathlib import Path

import duckdb
import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from ..common import build_rate_sql
from ..config import Config, load_config

# --------------------------------------------------------------------------- #
# Constants
# --------------------------------------------------------------------------- #
PERIODS = [
    ("Mar 2026", "2026-03-01", "2026-03-31"),
    ("Apr 2026", "2026-04-01", "2026-04-30"),
    ("May 2026", "2026-05-01", "2026-05-31"),
    ("Jun 1-6",  "2026-06-01", "2026-06-06"),
]
WIN_LO, WIN_HI = "2026-03-01", "2026-06-06"
DIRECT = ("WEB", "MOBILE", "OFFICE", "CALL_CENTER")   # web / app / mobile / counter — excluded
CR = 1e7

NAVY = "1F3864"; BLUE_MED = "2E5395"; BLUE_LIGHT = "D9E1F2"; GREY_L = "F2F2F2"
GREY_T = "7F7F7F"; WHITE = "FFFFFF"; BLACK = "000000"; AMBER_F = "FFEB9C"; AMBER_T = "9C6500"
THIN = Side(style="thin", color="BFBFBF"); BORDER = Border(THIN, THIN, THIN, THIN)
FMT_BDT = "#,##0;[Red]-#,##0"
FMT_CR = "#,##0.00"

HEADS = ["#", "Customer ID", "Agent / Agency", "Zone", "Type"] + [p[0] for p in PERIODS] + ["Gross total", "Net total"]
WIDTHS = [5, 13, 34, 10, 12, 13, 13, 13, 11, 14, 14]


def cell(ws, r, c, v, *, fmt=None, bold=False, size=10, color=BLACK, fill=None,
         align="left", wrap=False, border=True):
    x = ws.cell(row=r, column=c, value=v)
    x.font = Font(bold=bold, size=size, color=color, name="Calibri")
    x.alignment = Alignment(horizontal=align, vertical="center", wrap_text=wrap)
    if fmt:
        x.number_format = fmt
    if fill:
        x.fill = PatternFill("solid", fgColor=fill)
    if border:
        x.border = BORDER
    return x


def _load(cfg: Config) -> pd.DataFrame:
    """One pass over the sales window -> per (sales_person, customer) gross+net by period."""
    keys = ["mar", "apr", "may", "jun"]
    period_cols = ",\n".join(
        f"SUM(g) FILTER (WHERE d BETWEEN DATE '{lo}' AND DATE '{hi}') {k}"
        for (lab, lo, hi), k in zip(PERIODS, keys)
    )
    rate = build_rate_sql(cfg)
    sql = f"""
        WITH s AS (
            SELECT
                CASE WHEN CAST("Customer ID" AS VARCHAR) = 'BO-1 Central Reservation' THEN '11246131'
                     ELSE regexp_replace(CAST("Customer ID" AS VARCHAR), '[.]0$', '') END AS customer_id,
                "Date"::DATE AS d,
                CASE WHEN CAST("Transaction" AS VARCHAR) = 'Ticket payment'
                     THEN CAST("Balance (base currency)" AS DOUBLE) ELSE 0 END AS g,
                CASE WHEN CAST("Transaction" AS VARCHAR) = 'Ticket payment'
                     THEN CAST("Total without taxe (base currency)" AS DOUBLE) * (1 - ({rate}))
                          + (CAST("Balance (base currency)" AS DOUBLE) - CAST("Total without taxe (base currency)" AS DOUBLE))
                     ELSE 0 END AS n
            FROM read_parquet('{cfg.sales_glob}', hive_partitioning=1, union_by_name=1)
            WHERE "Date"::DATE BETWEEN DATE '{WIN_LO}' AND DATE '{WIN_HI}'
        )
        SELECT
            COALESCE(NULLIF(TRIM(c.sales_person), ''), '(Unmapped)') AS sales_person,
            s.customer_id,
            MAX(c.customer_name) AS "name",
            MAX(c.zone)          AS "zone",
            MAX(c.agent_type)    AS atype,
            {period_cols},
            SUM(n) AS net_total
        FROM s
        LEFT JOIN dim_customer c ON s.customer_id = c.customer_id
        WHERE (c.primary_channel NOT IN {DIRECT} OR c.primary_channel IS NULL)
        GROUP BY 1, 2
        HAVING SUM(g) > 0   -- any ticket sale in the window (FILTER sums are NULL, not 0, for empty periods)
    """
    con = duckdb.connect(str(cfg.warehouse), read_only=True)
    try:
        df = con.execute(sql).df()
    finally:
        con.close()
    for k in keys:
        df[k] = df[k].fillna(0.0)
    df["net_total"] = df["net_total"].fillna(0.0)
    df["total"] = df[["mar", "apr", "may", "jun"]].sum(axis=1)   # gross total
    df["name"] = df["name"].fillna("").replace("", "(no name)")
    df["zone"] = df["zone"].fillna("")
    df["atype"] = df["atype"].fillna("")
    return df


def safe_sheet_name(name: str, used: set[str]) -> str:
    clean = re.sub(r"[\\/?*\[\]:]", "-", str(name)).strip() or "Sheet"
    clean = clean[:31]
    base, i = clean, 1
    while clean.lower() in used:
        suffix = f" ({i})"
        clean = base[:31 - len(suffix)] + suffix
        i += 1
    used.add(clean.lower())
    return clean


def safe_filename(name: str, used: set[str]) -> str:
    clean = re.sub(r'[\\/:*?"<>|]', "-", str(name)).strip().rstrip(".") or "Sheet"
    clean = clean[:90]
    base, i = clean, 1
    while clean.lower() in used:
        clean = f"{base} ({i})"
        i += 1
    used.add(clean.lower())
    return clean


def write_person_sheet(ws, person: str, block: pd.DataFrame) -> None:
    ws.sheet_view.showGridLines = False
    block = block.sort_values("total", ascending=False)
    tot = block["total"].sum()
    ncol = len(HEADS)
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=ncol)
    cell(ws, 1, 1, f"Sales Person:  {person}", bold=True, size=14, color=WHITE, fill=NAVY,
         align="center", border=False)
    ws.row_dimensions[1].height = 26
    ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=ncol)
    net_tot = block["net_total"].sum()
    cell(ws, 2, 1, f"Ticket sales excl. Web / App / Mobile / Counter.  Period columns = GROSS (full fare, before commission); "
                   f"totals show GROSS and NET (after commission).  {len(block):,} agents  ·  "
                   f"gross {tot/CR:,.2f} cr  /  net {net_tot/CR:,.2f} cr.  Last 3 months + June 1-6.",
         size=9.5, color=GREY_T, fill=BLUE_LIGHT, align="center", border=False)
    ws.row_dimensions[2].height = 16
    for j, (h, w) in enumerate(zip(HEADS, WIDTHS), 1):
        cell(ws, 4, j, h, bold=True, size=9.5, color=NAVY, fill=BLUE_LIGHT, align="center", wrap=True)
        ws.column_dimensions[get_column_letter(j)].width = w
    ws.row_dimensions[4].height = 26
    ws.freeze_panes = "A5"
    r = 5
    for i, (_, x) in enumerate(block.iterrows(), 1):
        stripe = GREY_L if i % 2 == 0 else None
        cell(ws, r, 1, i, align="center", size=9, fill=stripe)
        cell(ws, r, 2, str(x["customer_id"]), size=9, fill=stripe)
        cell(ws, r, 3, str(x["name"])[:44], size=9, color=NAVY, fill=stripe, wrap=True)
        cell(ws, r, 4, str(x["zone"]), size=9, fill=stripe)
        cell(ws, r, 5, str(x["atype"]), size=9, fill=stripe)
        for j, k in enumerate(["mar", "apr", "may", "jun"], 6):
            cell(ws, r, j, x[k], fmt=FMT_BDT, align="right", size=9, fill=stripe)
        cell(ws, r, 10, x["total"], fmt=FMT_BDT, align="right", size=9, bold=True, color=NAVY, fill=stripe)
        cell(ws, r, 11, x["net_total"], fmt=FMT_BDT, align="right", size=9, color="2E5395", fill=stripe)
        r += 1
    cell(ws, r, 1, "TOTAL", bold=True, color=WHITE, fill=NAVY)
    for cc in (2, 3, 4, 5):
        cell(ws, r, cc, "", fill=NAVY)
    for j, k in enumerate(["mar", "apr", "may", "jun"], 6):
        cell(ws, r, j, block[k].sum(), fmt=FMT_BDT, align="right", bold=True, color=WHITE, fill=NAVY)
    cell(ws, r, 10, tot, fmt=FMT_BDT, align="right", bold=True, color=WHITE, fill=NAVY)
    cell(ws, r, 11, block["net_total"].sum(), fmt=FMT_BDT, align="right", bold=True, color=WHITE, fill=NAVY)


def write_index(ws, df: pd.DataFrame, order: list[tuple[str, str]]) -> None:
    ws.sheet_view.showGridLines = False
    cell(ws, 1, 1, "Sales-Person Gross Report — Index", bold=True, size=16, color=NAVY, border=False)
    cell(ws, 2, 1, "Gross ticket sales (before commission), excl. Web / App / Mobile / Counter. "
                   "Last 3 months + June 1-6. One tab per sales person; '(Unmapped)' = no sales person assigned.",
         size=9.5, color=GREY_T, border=False)
    heads = ["#", "Sales Person", "Agents", "Mar 2026", "Apr 2026", "May 2026", "Jun 1-6", "Total (BDT)", "Total (cr)"]
    widths = [5, 30, 9, 14, 14, 14, 12, 16, 12]
    for j, (h, w) in enumerate(zip(heads, widths), 1):
        cell(ws, 4, j, h, bold=True, size=9.5, color=NAVY, fill=BLUE_LIGHT, align="center", wrap=True)
        ws.column_dimensions[get_column_letter(j)].width = w
    ws.row_dimensions[4].height = 24
    ws.freeze_panes = "A5"
    r = 5
    for i, (person, sheet) in enumerate(order, 1):
        b = df[df["sales_person"] == person]
        stripe = GREY_L if i % 2 == 0 else None
        cell(ws, r, 1, i, align="center", size=9, fill=stripe)
        link = ws.cell(row=r, column=2, value=person)
        link.hyperlink = f"#'{sheet}'!A1"
        link.font = Font(bold=True, size=10, color="0563C1", underline="single", name="Calibri")
        link.alignment = Alignment(horizontal="left", vertical="center")
        link.fill = PatternFill("solid", fgColor=stripe) if stripe else PatternFill()
        link.border = BORDER
        cell(ws, r, 3, len(b), align="center", size=9, fill=stripe)
        for j, k in enumerate(["mar", "apr", "may", "jun"], 4):
            cell(ws, r, j, b[k].sum(), fmt=FMT_BDT, align="right", size=9, fill=stripe)
        cell(ws, r, 8, b["total"].sum(), fmt=FMT_BDT, align="right", size=9, bold=True, color=NAVY, fill=stripe)
        cell(ws, r, 9, b["total"].sum() / CR, fmt=FMT_CR, align="right", size=9, fill=stripe)
        r += 1
    cell(ws, r, 1, "GRAND TOTAL", bold=True, color=WHITE, fill=NAVY)
    cell(ws, r, 2, "", fill=NAVY)
    cell(ws, r, 3, int(df["customer_id"].nunique()), align="center", bold=True, color=WHITE, fill=NAVY)
    for j, k in enumerate(["mar", "apr", "may", "jun"], 4):
        cell(ws, r, j, df[k].sum(), fmt=FMT_BDT, align="right", bold=True, color=WHITE, fill=NAVY)
    cell(ws, r, 8, df["total"].sum(), fmt=FMT_BDT, align="right", bold=True, color=WHITE, fill=NAVY)
    cell(ws, r, 9, df["total"].sum() / CR, fmt=FMT_CR, align="right", bold=True, color=WHITE, fill=NAVY)


def write_individual_files(df: pd.DataFrame, persons: list[str], indiv_dir: Path, indiv_zip: Path) -> int:
    """One standalone .xlsx per sales person (+ Unmapped), then bundle them into a .zip."""
    indiv_dir.mkdir(parents=True, exist_ok=True)
    used_files: set[str] = set()
    used_sheets: set[str] = set()
    written: list[Path] = []
    skipped: list[str] = []
    for person in persons:
        label = "Unmapped" if person == "(Unmapped)" else person
        stem = safe_filename(label, used_files)
        wb = Workbook()
        ws = wb.active
        ws.title = safe_sheet_name(label, used_sheets)
        write_person_sheet(ws, person, df[df["sales_person"] == person])
        path = indiv_dir / f"{stem}.xlsx"
        try:
            wb.save(path)
        except PermissionError:
            # file is open/locked in Excel -> write a _v2 copy rather than crash the run
            try:
                path = path.with_name(path.stem + "_v2.xlsx")
                wb.save(path)
            except PermissionError:
                skipped.append(path.name)
                continue
        written.append(path)
    try:
        with zipfile.ZipFile(indiv_zip, "w", zipfile.ZIP_DEFLATED) as z:
            for f in written:
                z.write(f, arcname=f.name)
    except PermissionError:
        skipped.append(indiv_zip.name)   # zip locked; the individual files are still written
    if skipped:
        print(f"[WARN] locked, skipped/aliased: {', '.join(skipped)}")
    return len(written)


def _save(wb: Workbook, out: Path) -> Path:
    """Save; on a lock, fall back to *_v2 and return whichever path was written."""
    out.parent.mkdir(parents=True, exist_ok=True)
    try:
        wb.save(out)
        return out
    except PermissionError:
        alt = out.with_name(out.stem + "_v2.xlsx")
        wb.save(alt)
        return alt


def generate(params: dict | None = None, cfg: Config | None = None) -> Path:
    """Build the combined workbook (and, unless disabled, the per-person files + zip). Returns the workbook path."""
    cfg = cfg or load_config(validate=True)
    params = params or {}
    df = _load(cfg)

    totals = df.groupby("sales_person")["total"].sum().sort_values(ascending=False)
    persons = [p for p in totals.index if p != "(Unmapped)"]
    if "(Unmapped)" in totals.index:
        persons.append("(Unmapped)")

    wb = Workbook()
    used: set[str] = {"index"}
    idx_ws = wb.active
    idx_ws.title = "Index"
    order: list[tuple[str, str]] = []
    for person in persons:
        sheet_label = "Unmapped" if person == "(Unmapped)" else person
        sname = safe_sheet_name(sheet_label, used)
        ws = wb.create_sheet(sname)
        write_person_sheet(ws, person, df[df["sales_person"] == person])
        order.append((person, sname))
    write_index(idx_ws, df, order)
    wb.move_sheet("Index", -(len(wb.sheetnames) - 1))   # ensure Index is first

    out = _save(wb, cfg.output_dir / "SalesPerson_Gross_Report.xlsx")

    if params.get("split_individual", True):
        indiv_dir = Path(params.get("individual_dir") or (Path.home() / "Downloads" / "Sales Person"))
        indiv_zip = Path(params.get("individual_zip") or (Path.home() / "Downloads" / "Sales Person.zip"))
        write_individual_files(df, persons, indiv_dir, indiv_zip)

    return out
