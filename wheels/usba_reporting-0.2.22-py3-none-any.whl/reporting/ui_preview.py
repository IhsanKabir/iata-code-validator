"""
reporting/ui_preview.py  —  CLICKABLE MOCKUP of the desktop "Reports" tab.

Run it to SEE how a manager downloads a report (everything here is MOCK — no real
data, no real files are touched):

    .venv\\Scripts\\python.exe reporting\\ui_preview.py

This is the UI spec / demo for the Zenith -> Reports sub-tab. The real version wires
the SAME two screens to the `reporting` package + the ACL'd shared folder:
  * login gate  -> verify the 14-day rotating password (hash from the shared config)
  * report list -> read the freshness manifest, copy the selected file locally, open it.
"""
import sys
import tkinter as tk
from pathlib import Path
from tkinter import messagebox, ttk

# The report list is driven by the real registry (no data access) — fall back to a stub.
try:
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    from reporting import list_reports
    REPORTS = [r.title for r in list_reports()]
except Exception:
    REPORTS = ["June 2026 Target (capacity-aware)", "Sales-Person Gross Report",
               "Daily Sales Report (DSR)", "Zone Underperformers", "IATA Agencies — need name"]

NAVY = "#1F3864"; BLUE = "#2E5395"; LIGHT = "#D9E1F2"; GREY = "#7F7F7F"; WHITE = "#FFFFFF"
DEMO_PASSWORD = "demo"   # MOCK only; real = 14-day rotating, admin-distributed

# MOCK freshness per report: title -> (data_as_of, built, status)
MOCK = {
    "IATA Agencies — need name": ("Jun 5", "Jun 8, 18:30", "stale"),
}
def _fresh(title):
    return MOCK.get(title, ("Jun 6", "Jun 9, 09:12", "ready"))


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("US-Bangla Tools  —  Zenith ▸ Reports  (PREVIEW)")
        self.geometry("780x560"); self.configure(bg=WHITE); self.resizable(False, False)
        self._downloaded = None
        # header bar
        h = tk.Frame(self, bg=NAVY, height=54); h.pack(fill="x"); h.pack_propagate(False)
        tk.Label(h, text="   Zenith ▸ Reports", bg=NAVY, fg=WHITE,
                 font=("Segoe UI", 14, "bold")).pack(side="left", pady=12)
        tk.Label(h, text="Zenith  ✓ signed in     ", bg=NAVY, fg="#9DC3E6",
                 font=("Segoe UI", 9)).pack(side="right", pady=16)
        self.body = tk.Frame(self, bg=WHITE); self.body.pack(fill="both", expand=True)
        self._login()

    def _clear(self):
        for w in self.body.winfo_children():
            w.destroy()

    # ---- screen 1: the second login (after Zenith) ----
    def _login(self):
        self._clear()
        f = tk.Frame(self.body, bg=WHITE); f.place(relx=0.5, rely=0.42, anchor="center")
        tk.Label(f, text="\U0001f512  Reports — sign in", bg=WHITE, fg=NAVY,
                 font=("Segoe UI", 16, "bold")).grid(row=0, column=0, columnspan=2, pady=(0, 18))
        tk.Label(f, text="Username", bg=WHITE, fg=GREY, font=("Segoe UI", 10)).grid(row=1, column=0, sticky="e", padx=8, pady=6)
        self.u = tk.Entry(f, width=26, font=("Segoe UI", 11)); self.u.grid(row=1, column=1, pady=6); self.u.insert(0, "manager01")
        tk.Label(f, text="Password", bg=WHITE, fg=GREY, font=("Segoe UI", 10)).grid(row=2, column=0, sticky="e", padx=8, pady=6)
        self.p = tk.Entry(f, width=26, show="•", font=("Segoe UI", 11)); self.p.grid(row=2, column=1, pady=6)
        self.p.bind("<Return>", lambda e: self._try_login())
        tk.Button(f, text="Unlock Reports", bg=BLUE, fg=WHITE, font=("Segoe UI", 11, "bold"),
                  relief="flat", padx=18, pady=6, command=self._try_login).grid(row=3, column=0, columnspan=2, pady=(18, 8))
        tk.Label(f, text="Password rotates every 14 days · get the current one from your admin\n(demo password: demo)",
                 bg=WHITE, fg=GREY, font=("Segoe UI", 8), justify="center").grid(row=4, column=0, columnspan=2)

    def _try_login(self):
        if self.p.get() == DEMO_PASSWORD:
            self.user = self.u.get().strip() or "manager01"
            self._reports()
        else:
            messagebox.showerror("Reports", "Wrong or expired password.\n\n(Demo password is: demo)")

    # ---- screen 2: report list + download ----
    def _reports(self):
        self._clear()
        # header: title + who's signed in + sign out (per-user scoping is the privacy boundary)
        hdr = tk.Frame(self.body, bg=WHITE); hdr.pack(fill="x", padx=20, pady=(16, 2))
        tk.Label(hdr, text="Available reports", bg=WHITE, fg=NAVY, font=("Segoe UI", 13, "bold")).pack(side="left")
        tk.Button(hdr, text="Sign out", bg=WHITE, fg=GREY, font=("Segoe UI", 9), relief="flat",
                  command=self._login).pack(side="right")
        tk.Label(self.body, text=f"Signed in as {self.user} · showing only the reports shared to you (per-folder access).",
                 bg=WHITE, fg=GREY, font=("Segoe UI", 9)).pack(anchor="w", padx=20, pady=(0, 8))
        cols = ("report", "asof", "built", "status")
        tv = ttk.Treeview(self.body, columns=cols, show="headings", height=8)
        for c, head, w, anchor in [("report", "Report", 320, "w"), ("asof", "Data as of", 90, "center"),
                                    ("built", "Built", 130, "center"), ("status", "Status", 90, "center")]:
            tv.heading(c, text=head); tv.column(c, width=w, anchor=anchor)
        tv.tag_configure("stale", background="#FFF2CC", foreground="#9C6500")   # amber = stale build
        tv.tag_configure("ready", foreground="#006100")
        for title in REPORTS:
            asof, built, st = _fresh(title)
            tv.insert("", "end", values=(title, asof, built, "✅ Ready" if st == "ready" else "⚠ Stale"),
                      tags=(st,))
        tv.pack(fill="x", padx=20)
        if tv.get_children():
            tv.selection_set(tv.get_children()[0])
        self.tv = tv
        bar = tk.Frame(self.body, bg=WHITE); bar.pack(fill="x", padx=20, pady=14)
        tk.Button(bar, text="⤓  Download", bg=BLUE, fg=WHITE, font=("Segoe UI", 11, "bold"),
                  relief="flat", padx=18, pady=6, command=self._download).pack(side="left")
        tk.Button(bar, text="Open", bg=LIGHT, fg=NAVY, font=("Segoe UI", 11),
                  relief="flat", padx=18, pady=6, command=self._open).pack(side="left", padx=10)
        self.prog = ttk.Progressbar(self.body, length=320, mode="determinate"); self.prog.pack(padx=20, anchor="w")
        self.status = tk.Label(self.body, text=f"Download mode  ·  source \\\\share\\Reports\\{self.user}  ·  newest build 2h ago (by the pipeline)",
                               bg=WHITE, fg=GREY, font=("Segoe UI", 9)); self.status.pack(anchor="w", padx=20, pady=(8, 0))
        tk.Label(self.body, text="(Preview — no real files. Download copies YOUR file locally; Open launches it in Excel.)",
                 bg=WHITE, fg=GREY, font=("Segoe UI", 8)).pack(anchor="w", padx=20, pady=(14, 0))

    def _sel(self):
        s = self.tv.selection()
        return self.tv.item(s[0])["values"] if s else None

    def _download(self):
        row = self._sel()
        if not row:
            messagebox.showinfo("Reports", "Select a report first."); return
        title, asof, built, badge = row
        if "Stale" in str(badge) and not messagebox.askyesno(
                "Stale report", f"{title} is STALE (last good build {built}).\nDownload anyway?"):
            return
        self.prog["value"] = 0

        def step(v):
            self.prog["value"] = v
            if v < 100:
                self.after(55, step, v + 10)
            else:
                self._downloaded = title
                self.status.config(text=f"Downloaded: {title}  →  Downloads\\{title}.xlsx   ✓")
        step(0)

    def _open(self):
        row = self._sel()
        if not row:
            messagebox.showinfo("Reports", "Select a report first."); return
        messagebox.showinfo("Open", f"Would open in Excel:\nDownloads\\{row[0]}.xlsx\n\n(Preview only.)")


if __name__ == "__main__":
    App().mainloop()
