"""
reporting — shared report-generation package.

ONE source of truth for report logic, imported by BOTH:
  * the data pipeline / CLI (scripts/_build_*.py become thin shims), and
  * (later) the desktop app's "Reports" tab — via a pinned private-pip install.

Phase 0 ships the foundation: config (frozen-aware paths) + registry (report catalog)
+ all 5 builders migrated. Phase 0.5 adds publish (atomic, lock-safe distribution).
"""
from __future__ import annotations

from .auth import AuthResult, AuthStore, Authenticator, Credential, generate_password
from .config import Config, load_config
from .publish import PublishResult, publish_file, publish_report, write_manifest
from .publish import fan_out_to_managers, write_publish_status
from .registry import REPORTS, Report, list_reports
from .reports_tab import (
    FreshnessSummary, ReportEntry, download_report, freshness_summary, list_versions, load_catalog,
)
from .state import append_audit, last_open, read_audit, record_open

__all__ = [
    "Config", "load_config",
    "REPORTS", "Report", "list_reports",
    "PublishResult", "publish_file", "publish_report", "write_manifest", "write_publish_status",
    "fan_out_to_managers",
    # auth (Phase 2)
    "AuthResult", "AuthStore", "Authenticator", "Credential", "generate_password",
    # reports tab logic (Phase 2 + 3)
    "ReportEntry", "load_catalog", "download_report", "FreshnessSummary", "freshness_summary", "list_versions",
    # client state + audit (Phase 3)
    "record_open", "last_open", "append_audit", "read_audit",
]
# MUST match reporting/pyproject.toml (the wheel's source of truth) — build_wheel.py
# refuses to build on a mismatch. They drifted once (a "0.1.7" string shipped inside
# the 0.2.1 wheel), which is exactly the silent confusion the guard now prevents.
__version__ = "0.2.22"
