"""
reporting.publish — atomic, lock-safe publishing of generated workbooks to the
shared (ACL'd) Reports folder.  Implements §6 item 4 of the integration plan.

WHY THIS MODULE EXISTS
----------------------
Excel takes an exclusive lock on an open ``.xlsx``.  If a manager has last week's
"June Target" workbook open when the scheduled job republishes it, a naive
``save()`` either crashes (``PermissionError``) or — worse — leaves a half-written,
corrupt file in the shared folder.  The industry-standard fix has three parts:

  1. WRITE TO A TEMP FILE IN THE SAME FOLDER as the final target.  ``os.replace``
     is only atomic when source and destination are on the SAME volume; a temp in
     the destination folder guarantees that, so the swap is a single rename, never
     a copy that could be seen half-done.
  2. PUBLISH A TIMESTAMPED FILENAME first (e.g. ``June_Target_20260609_1430.xlsx``).
     A brand-new timestamped name is never already open, so its ``os.replace`` can
     never be blocked.  Only THEN do we refresh the stable ``*_latest.xlsx`` copy;
     if that one happens to be open we just warn — the timestamped file is already
     safely published, so no data is ever lost.
  3. WRITE A MANIFEST row so the desktop "Reports" tab can show freshness
     ("generated 3h ago") and point at the latest file per report.

Nothing here needs admin rights or the network — only write access to the
destination folder (granted to the run-account in §6 item 3).

TEACHING NOTE (for colleagues onboarding onto this code)
--------------------------------------------------------
* ``os.replace`` is the atomic primitive — prefer it over ``shutil.move`` when you
  need "all-or-nothing" file swaps.
* We never write directly to the final name.  "temp in same dir -> replace" is the
  safe pattern for ANY file other processes might be reading.
* Encryption of the workbook (§6 item 5) is a SEPARATE, later step and is marked
  TODO below — it is not done here because the encryption method is still an open
  decision (§8 item 5) and would need a package outside the pinned stack.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

from ._io import atomic_copy, atomic_write_text
from .config import Config, load_config
from .registry import REPORTS

MANIFEST_NAME = "manifest.json"

# Friendly, stable base filenames per report key (drives the timestamped + latest names).
# Kept here (not in the registry) because it is a *publishing* concern, not a report definition.
_BASE_NAME: dict[str, str] = {
    "june_target": "June_Target",
    "salesperson_gross": "Sales_Person",
    "underperformers": "Underperformers",
    "dsr": "DSR",
    "iata_worklist": "IATA_Worklist",
    "daily_snapshot": "Daily_Report",
    "load_report": "Load_Report",
    "salesperson_pack": "Sales_Person_Packs",   # .zip bundle (one xlsx per sales person)
    # monthly DSRs are published by scripts/publish_dsr_months.py with explicit
    # per-month base names (DSR_2026-06, ...) via publish_file — not listed here.
}


@dataclass(frozen=True)
class PublishResult:
    """Immutable record of one published report (one manifest row)."""

    report_key: str
    title: str
    published: Path                       # the timestamped file actually written
    latest: Path | None                   # the refreshed *_latest.xlsx (None if it was locked)
    generated_at: str                     # ISO-ish stamp, local time
    bytes: int
    warnings: tuple[str, ...] = field(default_factory=tuple)

    def manifest_row(self) -> dict:
        """The JSON-serialisable shape the desktop app reads for freshness/links."""
        return {
            "report": self.report_key,
            "title": self.title,
            "file": self.published.name,
            "latest": self.latest.name if self.latest else None,
            "generated_at": self.generated_at,
            "bytes": self.bytes,
            "warnings": list(self.warnings),
        }


def _stamp(now: datetime | None = None) -> str:
    """Filename-safe timestamp, e.g. ``20260609_1430``. ``now`` injectable for tests."""
    return (now or datetime.now()).strftime("%Y%m%d_%H%M")


def _atomic_place(src: Path, final: Path) -> None:
    """Atomic temp-in-dest then replace (shared impl in reporting._io.atomic_copy)."""
    atomic_copy(src, final)


def publish_file(
    src: Path,
    dest_dir: Path,
    *,
    base_name: str,
    report_key: str = "",
    title: str = "",
    keep_latest: bool = True,
    now: datetime | None = None,
) -> PublishResult:
    """Atomically publish an already-generated ``src`` workbook into ``dest_dir``.

    Writes ``<base_name>_<stamp>.xlsx`` (always succeeds — the name is unique), then
    refreshes ``<base_name>_latest.xlsx`` (best-effort — warns if that file is open).
    """
    src = Path(src)
    if not src.is_file():
        raise FileNotFoundError(f"Nothing to publish — source missing: {src}")
    dest_dir = Path(dest_dir)
    stamp = _stamp(now)
    warnings: list[str] = []

    # Keep the artifact's own extension: most reports are .xlsx, but bundle reports
    # (e.g. the per-sales-person Target Packs) publish a .zip of many workbooks.
    ext = src.suffix.lower() or ".xlsx"

    # 1) the timestamped, never-locked file — this is the authoritative published copy
    published = dest_dir / f"{base_name}_{stamp}{ext}"
    _atomic_place(src, published)

    # 2) refresh the stable "latest" pointer (best-effort: a manager may have it open)
    latest: Path | None = None
    if keep_latest:
        latest_path = dest_dir / f"{base_name}_latest{ext}"
        try:
            _atomic_place(published, latest_path)
            latest = latest_path
        except OSError:
            # latest is open/locked, or a write error (disk full, network blip). The
            # timestamped file is already safely published, so warn rather than abort.
            warnings.append(
                f"'{latest_path.name}' could not be refreshed (open/locked or write error) "
                f"- kept timestamped file only; latest will refresh on the next run."
            )

    return PublishResult(
        report_key=report_key or base_name,
        title=title or base_name,
        published=published,
        latest=latest,
        generated_at=(now or datetime.now()).strftime("%Y-%m-%d %H:%M"),
        bytes=published.stat().st_size,
        warnings=tuple(warnings),
    )


def publish_report(
    report_key: str,
    params: dict | None,
    dest_dir: Path,
    cfg: Config | None = None,
    *,
    now: datetime | None = None,
) -> PublishResult:
    """Run a registry builder's ``generate()`` then atomically publish the result.

    This is the single seam Phase 1's scheduled task calls per report.
    """
    cfg = cfg or load_config(validate=True)
    report = REPORTS.get(report_key)
    if report is None:
        raise KeyError(f"Unknown report '{report_key}'. Known: {', '.join(REPORTS)}")
    if report.status != "package" or not report.builder:
        raise RuntimeError(f"Report '{report_key}' is not migrated into the package yet.")

    # Resolve "reporting.builders.x:generate" -> the callable, without importing everything.
    module_path, func_name = report.builder.split(":")
    from importlib import import_module
    generate = getattr(import_module(module_path), func_name)

    src = generate(params or {}, cfg)        # the builder writes to cfg.output_dir
    return publish_file(
        src,
        dest_dir,
        base_name=_BASE_NAME.get(report_key, report_key),
        report_key=report_key,
        title=report.title,
        now=now,
    )


def write_manifest(dest_dir: Path, results: list[PublishResult], *, now: datetime | None = None) -> Path:
    """Merge ``results`` into ``manifest.json`` (one row per report) and write it atomically.

    Existing rows for OTHER reports are preserved, so publishing a subset never drops
    the freshness info for reports built by an earlier run.
    """
    dest_dir = Path(dest_dir)
    manifest_path = dest_dir / MANIFEST_NAME

    # start from whatever is already there, keyed by report so we update-in-place
    rows: dict[str, dict] = {}
    if manifest_path.is_file():
        try:
            for row in json.loads(manifest_path.read_text(encoding="utf-8")).get("reports", []):
                rows[row.get("report", "")] = row
        except (json.JSONDecodeError, OSError):
            pass  # corrupt/locked manifest -> rebuild fresh from this run's results

    for r in results:
        rows[r.report_key] = r.manifest_row()

    payload = {
        "updated_at": (now or datetime.now()).strftime("%Y-%m-%d %H:%M"),
        "reports": sorted(rows.values(), key=lambda x: x.get("report", "")),
    }
    # atomic write: temp-in-dir -> replace (same pattern as the workbooks)
    return atomic_write_text(manifest_path, json.dumps(payload, indent=2))


STATUS_NAME = "publish_status.json"


def write_publish_status(dest_dir: Path, outcomes: list[dict], *, now: datetime | None = None) -> Path:
    """Record the LAST run's per-report outcome (ok / failed + error) for alerting.

    Distinct from the manifest (which only lists successfully-published files): this
    captures FAILURES too, so a manually-run publish never hides an error in scrollback
    — the desktop tab's stale banner + this file together surface a bad build.
    """
    dest_dir = Path(dest_dir)
    stamp = (now or datetime.now()).strftime("%Y-%m-%d %H:%M")
    payload = {
        "updated_at": stamp,
        "ok": sum(1 for o in outcomes if o.get("status") == "ok"),
        "failed": sum(1 for o in outcomes if o.get("status") == "failed"),
        "reports": outcomes,
    }
    return atomic_write_text(dest_dir / STATUS_NAME, json.dumps(payload, indent=2))


def fan_out_to_managers(
    results_by_key: dict[str, PublishResult],
    recipients: dict[str, list[str]],
    staging_dir: Path,
    manager_root: Path,
    *,
    now: datetime | None = None,
) -> dict[str, Path]:
    """Copy each manager's subset of already-published reports into ``<manager_root>/<manager>/``
    (atomically) and write a per-manager manifest. Returns ``{manager: manifest_path}``.

    ``results_by_key`` maps a report key to the PublishResult from building it ONCE into
    ``staging_dir``; ``recipients`` maps each manager to the report keys they should receive.
    A manager's folder gets ONLY their reports — but the real privacy boundary is the
    per-folder NTFS ACL (see scripts/setup_share_acls.ps1), not this slicing.
    """
    staging_dir, manager_root = Path(staging_dir), Path(manager_root)
    out: dict[str, Path] = {}
    for manager, keys in recipients.items():
        mdir = manager_root / manager
        mdir.mkdir(parents=True, exist_ok=True)
        mres: list[PublishResult] = []
        for key in keys:
            r = results_by_key.get(key)
            if r is None:
                continue                       # report not built (e.g. needs params / failed) — skip
            atomic_copy(staging_dir / r.published.name, mdir / r.published.name)
            if r.latest:
                atomic_copy(staging_dir / r.latest.name, mdir / r.latest.name)
            mres.append(r)
        out[manager] = write_manifest(mdir, mres, now=now)
    return out
