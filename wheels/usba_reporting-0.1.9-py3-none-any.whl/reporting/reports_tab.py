"""
reporting.reports_tab — the REAL "Zenith -> Reports" sub-tab (download-only).

Replaces the mockup (ui_preview.py) with working logic, wired to the package:
  * the login gate verifies the **14-day rotating password** via reporting.auth
    (hash read from the ACL-protected auth.json on the share);
  * the report list is read from the publish **manifest.json** (freshness per report);
  * **Download** copies the manager's latest workbook locally; **Open** launches it.

DESIGN: the non-UI logic (catalog, freshness, download) lives in plain functions so it
is unit-testable WITHOUT a display; the Tkinter ``ReportsFrame`` is a thin shell on top.
The host exe embeds it after Zenith sign-in:

    from reporting.reports_tab import ReportsFrame
    ReportsFrame(parent, reports_dir=Path(r"\\\\share\\Reports\\manager01"),
                 auth_path=Path(r"\\\\share\\Reports\\auth.json")).pack(fill="both", expand=True)

Run standalone to try it against the local staging folder:
    .venv/Scripts/python.exe reporting/reports_tab.py
"""
from __future__ import annotations

import json
import calendar
import os
import re
import shutil
import zipfile
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

from . import state
from .auth import AuthResult, AuthStore, Authenticator

STALE_AFTER_HOURS = 24
_MANIFEST = "manifest.json"
_AUTH = "auth.json"
# matches a published build's timestamp suffix, e.g. "June_Target_20260609_1326.xlsx".
# .zip is allowed alongside .xlsx for BUNDLE reports (e.g. the per-sales-person Target
# Packs publish one zip containing all per-person workbooks).
_STAMP_RE = re.compile(r"^(?P<base>.+)_(?P<stamp>\d{8}_\d{4})\.(?:xlsx|zip)$", re.IGNORECASE)
# the only file extensions a manifest row may reference (closed allowlist — security)
_ALLOWED_EXTS = (".xlsx", ".zip")
# month-family publishing (e.g. the DSR): files like "DSR_2026-05_latest.xlsx" — the
# Version dropdown then becomes a MONTH picker instead of a build-timestamp picker.
_MONTH_TAG_RE = re.compile(r"^(?P<root>.+)_(?P<ym>\d{4}-\d{2})$")
_MONTH_LATEST_RE = re.compile(r"^(?P<root>.+)_(?P<ym>\d{4}-\d{2})_latest\.xlsx$", re.IGNORECASE)


def month_label(ym: str) -> str:
    """'2026-05' -> 'May 2026' (dropdown label for month-family versions)."""
    y, m = ym.split("-")
    return f"{calendar.month_name[int(m)]} {y}"


# ---------------------------------------------------------------------------
#  Non-UI logic (unit-testable without Tkinter)
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class ReportEntry:
    """One row from the publish manifest, plus computed freshness."""

    report: str
    title: str
    file: str
    latest: str | None
    generated_at: str
    bytes: int
    warnings: tuple[str, ...] = field(default_factory=tuple)

    def age_hours(self, now: datetime) -> float | None:
        try:
            built = datetime.strptime(self.generated_at, "%Y-%m-%d %H:%M")
        except (ValueError, TypeError):
            return None
        return (now - built).total_seconds() / 3600.0

    def is_stale(self, now: datetime, stale_after_hours: int = STALE_AFTER_HOURS) -> bool:
        # staleness = AGE of the newest build only. Publish warnings (e.g. "latest
        # copy was locked") are operational noise for the admin — the manifest's
        # timestamped file is still fresh and that's what gets downloaded.
        age = self.age_hours(now)
        return age is None or age > stale_after_hours

    def best_file(self) -> str:
        """Prefer the stable 'latest' copy; fall back to the timestamped file."""
        return self.latest or self.file


def _safe_filename(value: str | None) -> bool:
    """True if a manifest-supplied filename is a plain ``*.xlsx``/``*.zip`` name
    (no path traversal).

    The manifest is read from the share; a tampered/corrupt entry like ``..\\..\\auth.json``
    or an absolute path must never be used as a path component for download/open.
    The extension allowlist is CLOSED (xlsx for single workbooks, zip for bundle
    reports like the Sales-Person Target Packs) — anything else is skipped.
    """
    if not value:
        return True                      # absent/empty 'latest' is allowed
    if "\x00" in value:                  # null byte: not a traversal, but raises ValueError downstream
        return False
    p = Path(value)
    return (p.name == value and ".." not in p.parts
            and not p.is_absolute() and value.lower().endswith(_ALLOWED_EXTS))


def load_catalog(reports_dir: Path) -> list[ReportEntry]:
    """Read manifest.json from ``reports_dir`` into ReportEntry rows.

    Returns ``[]`` if the manifest is absent, locked, or corrupt (the GUI must not crash).
    Rows whose ``file``/``latest`` are not plain ``*.xlsx``/``*.zip`` names are SKIPPED —
    this is the single choke point that defends the download/open paths against a
    tampered manifest.
    """
    path = Path(reports_dir) / _MANIFEST
    if not path.is_file():
        return []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return []                        # corrupt/locked manifest -> treat as empty
    rows = []
    for r in data.get("reports", []):
        file_, latest = r.get("file", ""), r.get("latest")
        if not (_safe_filename(file_) and _safe_filename(latest)):
            continue                     # skip rows with unsafe filenames
        rows.append(ReportEntry(
            report=r.get("report", ""), title=r.get("title", r.get("report", "")),
            file=file_, latest=latest,
            generated_at=r.get("generated_at", ""), bytes=int(r.get("bytes", 0)),
            warnings=tuple(r.get("warnings", [])),
        ))
    return rows


def download_report(entry: ReportEntry, reports_dir: Path, dest_dir: Path,
                    *, filename: str | None = None) -> Path:
    """Copy a report file from the share into ``dest_dir``; return the new path.

    ``filename`` selects a specific build (e.g. an older timestamped version); when
    omitted, the report's best ('latest') file is used.
    """
    name = filename or entry.best_file()
    if not _safe_filename(name):         # defense in depth (load_catalog already validates)
        raise ValueError(f"Refusing unsafe report filename: {name!r}")
    src = Path(reports_dir) / name
    if not src.is_file():
        raise FileNotFoundError(f"Report file not found on the share: {src}")
    dest_dir = Path(dest_dir)
    dest_dir.mkdir(parents=True, exist_ok=True)
    # name the local copy without the "_latest" suffix, for tidiness
    dest = dest_dir / name.replace("_latest", "")
    shutil.copy2(src, dest)
    return dest


def extract_bundle(zip_path: Path) -> Path:
    """Extract a downloaded ``.zip`` bundle into a folder beside it; return the folder.

    Bundle reports (e.g. the Sales-Person Target Packs) hold many workbooks —
    managers shouldn't have to unzip by hand, so Open extracts and shows the
    folder instead. Zip-slip safe: any member that would land outside the target
    folder aborts the whole extraction.
    """
    zip_path = Path(zip_path)
    target = zip_path.with_suffix("")           # ".../Sales_Person_Packs/" folder
    target.mkdir(parents=True, exist_ok=True)
    resolved_target = target.resolve()
    with zipfile.ZipFile(zip_path) as zf:
        for member in zf.infolist():
            dest = (target / member.filename).resolve()
            if not dest.is_relative_to(resolved_target):
                raise ValueError(f"Unsafe path in bundle: {member.filename!r}")
        zf.extractall(target)
    return target


def _base_prefix(entry: ReportEntry) -> str:
    """The filename stem shared by all of a report's builds, e.g. 'June_Target'."""
    name = entry.latest or entry.file or ""
    for ext in _ALLOWED_EXTS:            # strip "_latest.<ext>" / bare ".<ext>"
        if name.lower().endswith(f"_latest{ext}"):
            return name[: -len(f"_latest{ext}")]
    m = _STAMP_RE.match(name)
    if m:
        return m.group("base")
    for ext in _ALLOWED_EXTS:
        if name.lower().endswith(ext):
            return name[: -len(ext)]
    return name


def list_versions(entry: ReportEntry, reports_dir: Path) -> list[tuple[str, str]]:
    """Return ``[(label, filename)]`` for a report's available builds, newest first.

    The first entry is ``("Latest", <latest file>)`` when a latest copy exists, followed
    by each timestamped build labelled by its build time. Drives the version dropdown so
    the user can pick WHICH build to download.
    """
    reports_dir = Path(reports_dir)
    base = _base_prefix(entry)

    # MONTH FAMILY: when the entry's base carries a YYYY-MM tag (e.g. 'DSR_2026-06'),
    # sibling months of the same root exist on the share — the dropdown lists THOSE
    # (newest month first), so one row covers every published month/period.
    mt = _MONTH_TAG_RE.match(base)
    if mt:
        root = mt.group("root")
        months: list[tuple[str, str]] = []
        try:
            for p in reports_dir.glob(f"{root}_*_latest.xlsx"):
                m2 = _MONTH_LATEST_RE.match(p.name)
                if m2 and m2.group("root") == root and _safe_filename(p.name):
                    months.append((m2.group("ym"), p.name))
        except OSError:
            pass
        if months:
            return [(month_label(ym), fn) for ym, fn in sorted(months, reverse=True)]

    versions: list[tuple[str, str]] = []
    if entry.latest and (reports_dir / entry.latest).is_file():
        versions.append(("Latest", entry.latest))
    builds: list[tuple[str, str, str]] = []
    try:
        for ext in _ALLOWED_EXTS:            # a report's builds share one extension,
            for p in reports_dir.glob(f"{base}_*{ext}"):   # but support both kinds
                m = _STAMP_RE.match(p.name)
                if not m or m.group("base") != base:
                    continue                 # skip the _latest copy and unrelated names
                s = m.group("stamp")         # YYYYMMDD_HHMM
                label = f"{s[0:4]}-{s[4:6]}-{s[6:8]} {s[9:11]}:{s[11:13]}"
                builds.append((s, label, p.name))
    except OSError:
        pass
    for _s, label, fname in sorted(builds, reverse=True):   # newest first
        versions.append((label, fname))
    return versions


def default_downloads_dir() -> Path:
    return Path.home() / "Downloads"


@dataclass(frozen=True)
class FreshnessSummary:
    """At-a-glance freshness across all reports (drives the banner)."""

    total: int
    stale: int
    newest_age_hours: float | None
    state: str          # "ok" | "stale" | "empty"
    message: str


def human_age(hours: float | None) -> str:
    if hours is None:
        return "unknown"
    if hours < 1:
        return f"{max(0, int(hours * 60))}m ago"
    if hours < 48:
        return f"{hours:.0f}h ago"
    return f"{hours / 24:.0f}d ago"


def freshness_summary(rows: list[ReportEntry], now: datetime,
                      stale_after_hours: int = STALE_AFTER_HOURS) -> FreshnessSummary:
    """Summarise a catalog: how many stale, how old the newest build is."""
    if not rows:
        return FreshnessSummary(0, 0, None, "empty", "No reports published yet.")
    stale = sum(1 for e in rows if e.is_stale(now, stale_after_hours))
    ages = [a for a in (e.age_hours(now) for e in rows) if a is not None]
    newest = min(ages) if ages else None
    if stale == 0:
        return FreshnessSummary(len(rows), 0, newest, "ok",
                                f"All {len(rows)} reports up to date  ·  newest built {human_age(newest)}")
    return FreshnessSummary(len(rows), stale, newest, "stale",
                            f"{stale} of {len(rows)} report(s) may be stale  ·  newest built {human_age(newest)}")


# ---------------------------------------------------------------------------
#  Tkinter UI (thin shell over the logic above)
# ---------------------------------------------------------------------------
def _resolve_dirs(reports_dir: Path | None, auth_path: Path | None):
    """Default to the local staging folder when not told otherwise."""
    if reports_dir is None:
        env = os.environ.get("SHARED_REPORTS_DIR")
        try:
            from .config import load_config
            base = Path(env) if env else load_config().data_root / "shared_reports"
        except Exception:
            base = Path(env) if env else Path.cwd() / "shared_reports"
        reports_dir = base
    if auth_path is None:
        auth_path = Path(reports_dir) / _AUTH
    return Path(reports_dir), Path(auth_path)


NAVY = "#1F3864"; BLUE = "#2E5395"; LIGHT = "#D9E1F2"; GREY = "#7F7F7F"; WHITE = "#FFFFFF"


def ReportsFrame(parent, *, reports_dir: Path | None = None, auth_path: Path | None = None):
    """Build and return the Reports frame (lazy-imports Tk so the module stays headless-safe)."""
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk

    reports_dir, auth_path = _resolve_dirs(reports_dir, auth_path)

    class _Frame(tk.Frame):
        def __init__(self, master):
            super().__init__(master, bg=WHITE)
            self.reports_dir = reports_dir
            self._auth_path = auth_path
            self.auth = Authenticator(AuthStore.load(auth_path))
            self.user = ""
            self.downloaded: dict[str, Path] = {}
            self._login()

        def _clear(self):
            for w in self.winfo_children():
                w.destroy()

        # ---- screen 1: the rotating-password gate ----
        def _login(self):
            self._clear()
            # re-read the credential store every time the login screen shows, so a
            # password the admin just rotated works without restarting the app.
            try:
                self.auth = Authenticator(AuthStore.load(self._auth_path))
            except Exception:
                self.auth = Authenticator(AuthStore())
            f = tk.Frame(self, bg=WHITE); f.place(relx=0.5, rely=0.42, anchor="center")
            tk.Label(f, text="\U0001f512  Reports - sign in", bg=WHITE, fg=NAVY,
                     font=("Segoe UI", 16, "bold")).grid(row=0, column=0, columnspan=2, pady=(0, 18))
            # the #1 sharing pitfall: this computer cannot see the reports folder at
            # all (wrong/unset USBA_REPORTS_DIR, no network access). Say it PLAINLY —
            # otherwise every password "fails" and the user blames the password.
            if not Path(self._auth_path).is_file():
                tk.Label(f, text=("Reports folder is NOT reachable from this computer:\n"
                                  f"{self.reports_dir}\n"
                                  "No password can work until it is. Ask the admin to share the folder\n"
                                  "and set the USBA_REPORTS_DIR environment variable on this PC."),
                         bg="#FFF2CC", fg="#9C6500", font=("Segoe UI", 9), justify="center",
                         padx=10, pady=8).grid(row=5, column=0, columnspan=2, pady=(14, 0))
            tk.Label(f, text="Username", bg=WHITE, fg=GREY).grid(row=1, column=0, sticky="e", padx=8, pady=6)
            self.u = tk.Entry(f, width=26, font=("Segoe UI", 11)); self.u.grid(row=1, column=1, pady=6)
            tk.Label(f, text="Password", bg=WHITE, fg=GREY).grid(row=2, column=0, sticky="e", padx=8, pady=6)
            self.p = tk.Entry(f, width=26, show="•", font=("Segoe UI", 11)); self.p.grid(row=2, column=1, pady=6)
            self.p.bind("<Return>", lambda e: self._try_login())
            tk.Button(f, text="Unlock Reports", bg=BLUE, fg=WHITE, font=("Segoe UI", 11, "bold"),
                      relief="flat", padx=18, pady=6, command=self._try_login).grid(row=3, column=0, columnspan=2, pady=(18, 8))

        def _try_login(self):
            res = self.auth.attempt(self.u.get(), self.p.get())
            if res is AuthResult.OK:
                self.user = self.u.get().strip()
                self._reports()
            else:
                messagebox.showerror("Reports", res.user_message)

        # ---- screen 2: report list + download ----
        def _reports(self):
            self._clear()
            now = datetime.now()
            self.rows = load_catalog(self.reports_dir)

            hdr = tk.Frame(self, bg=WHITE); hdr.pack(fill="x", padx=20, pady=(16, 2))
            tk.Label(hdr, text="Available reports", bg=WHITE, fg=NAVY,
                     font=("Segoe UI", 13, "bold")).pack(side="left")
            tk.Button(hdr, text="Sign out", bg=WHITE, fg=GREY, relief="flat",
                      command=self._sign_out).pack(side="right")
            # re-read the manifest on demand — the analyst may republish while the
            # manager's session is open; without this the list silently goes stale.
            tk.Button(hdr, text="⟳ Refresh", bg=WHITE, fg=NAVY, relief="flat",
                      command=self._reports).pack(side="right", padx=(0, 10))
            tk.Label(self, text=f"Signed in as {self.user} - source: {self.reports_dir}",
                     bg=WHITE, fg=GREY, font=("Segoe UI", 9)).pack(anchor="w", padx=20, pady=(0, 6))

            # freshness banner — at-a-glance status across ALL reports
            fs = freshness_summary(self.rows, now)
            bg, fg = {"ok": ("#E2EFDA", "#375623"), "stale": ("#FFF2CC", "#9C6500"),
                      "empty": ("#F2F2F2", GREY)}[fs.state]
            tk.Label(self, text="  " + fs.message, bg=bg, fg=fg, anchor="w",
                     font=("Segoe UI", 10, "bold")).pack(fill="x", padx=20, pady=(0, 8), ipady=5)

            cols = ("report", "built", "size", "status")
            tv = ttk.Treeview(self, columns=cols, show="headings", height=9)
            for c, head, w, anc in [("report", "Report", 330, "w"), ("built", "Built", 130, "center"),
                                    ("size", "Size", 80, "e"), ("status", "Status", 90, "center")]:
                tv.heading(c, text=head); tv.column(c, width=w, anchor=anc)
            tv.tag_configure("stale", background="#FFF2CC", foreground="#9C6500")
            tv.tag_configure("ready", foreground="#006100")
            for e in self.rows:
                stale = e.is_stale(now)
                tv.insert("", "end", iid=e.report,
                          values=(e.title, e.generated_at or "-", f"{e.bytes/1024:,.0f} KB",
                                  "⚠ Stale" if stale else "✅ Ready"),
                          tags=("stale" if stale else "ready",))
            if not self.rows:
                tk.Label(self, text="No reports published yet. Ask your admin to run the pipeline.",
                         bg=WHITE, fg=GREY).pack(anchor="w", padx=20)
            tv.pack(fill="x", padx=20)
            self.tv = tv

            bar = tk.Frame(self, bg=WHITE); bar.pack(fill="x", padx=20, pady=14)
            tk.Button(bar, text="⤓  Download", bg=BLUE, fg=WHITE, font=("Segoe UI", 11, "bold"),
                      relief="flat", padx=18, pady=6, command=self._download).pack(side="left")
            # version picker — choose WHICH build to download (defaults to Latest)
            tk.Label(bar, text="Version:", bg=WHITE, fg=GREY, font=("Segoe UI", 10)).pack(side="left", padx=(14, 4))
            self.version_cb = ttk.Combobox(bar, state="readonly", width=20, font=("Segoe UI", 10))
            self.version_cb.pack(side="left")
            tk.Button(bar, text="Open", bg=LIGHT, fg=NAVY, font=("Segoe UI", 11),
                      relief="flat", padx=18, pady=6, command=self._open).pack(side="left", padx=10)
            # "open last" — one click to reopen what this user opened most recently (across sessions)
            last = state.last_open(state.state_path(), self.user)
            if last and Path(last.get("path", "")).is_file():
                tk.Button(bar, text=f"Open last  ·  {last.get('at', '')}", bg=WHITE, fg=NAVY,
                          font=("Segoe UI", 10), relief="flat", padx=12, pady=6,
                          command=lambda p=last["path"], r=last.get("report", ""): self._open_path(p, r)
                          ).pack(side="right")
            self.status = tk.Label(self, text="Download mode - your latest copy is saved locally.",
                                   bg=WHITE, fg=GREY, font=("Segoe UI", 9))
            self.status.pack(anchor="w", padx=20, pady=(8, 0))

            # selection -> repopulate the version dropdown (now that version_cb exists)
            tv.bind("<<TreeviewSelect>>", lambda _e: self._refresh_versions())
            if tv.get_children():
                tv.selection_set(tv.get_children()[0])
            self._refresh_versions()

        def _sign_out(self):
            self.auth.reset(self.user)      # clear this user's lockout counter for a clean re-login
            self._login()

        def _selected(self) -> ReportEntry | None:
            sel = self.tv.selection()
            if not sel:
                return None
            return next((e for e in self.rows if e.report == sel[0]), None)

        def _refresh_versions(self):
            """Repopulate the version dropdown for the currently-selected report."""
            e = self._selected()
            self._versions = list_versions(e, self.reports_dir) if e else []
            labels = [lbl for lbl, _ in self._versions] or ["Latest"]
            self.version_cb["values"] = labels
            self.version_cb.set(labels[0])

        def _selected_version_filename(self, e: ReportEntry) -> str:
            label = self.version_cb.get()
            for lbl, fname in getattr(self, "_versions", []):
                if lbl == label:
                    return fname
            return e.best_file()

        def _download(self):
            e = self._selected()
            if e is None:
                messagebox.showinfo("Reports", "Select a report first."); return
            now = datetime.now()
            # only warn about staleness for the Latest build (an old build is "stale" by design)
            is_latest = self.version_cb.get() in ("", "Latest")
            if is_latest and e.is_stale(now) and not messagebox.askyesno(
                    "Stale report", f"{e.title} may be stale (built {e.generated_at}).\nDownload anyway?"):
                return
            dest_dir = filedialog.askdirectory(title="Save report to...",
                                               initialdir=str(default_downloads_dir())) or str(default_downloads_dir())
            fname = self._selected_version_filename(e)
            try:
                path = download_report(e, self.reports_dir, Path(dest_dir), filename=fname)
            except (FileNotFoundError, ValueError, OSError) as exc:
                messagebox.showerror("Reports", str(exc)); return
            self.downloaded[fname] = path
            state.record_open(state.state_path(), self.user, e.report, path)
            state.append_audit(state.audit_path(), self.user, "download", e.report)
            self.status.config(text=f"Downloaded: {e.title} ({self.version_cb.get()})  ->  {path}")

        def _open(self):
            e = self._selected()
            if e is None:
                messagebox.showinfo("Reports", "Select a report first."); return
            fname = self._selected_version_filename(e)
            path = self.downloaded.get(fname)
            if path is None or not Path(path).is_file():
                # Auto-download a LOCAL copy first — NEVER open the share's file
                # directly: Excel would lock it on the share and block the next
                # publish from refreshing it (everyone else then sees it stale).
                try:
                    path = download_report(e, self.reports_dir, default_downloads_dir(),
                                           filename=fname)
                except (FileNotFoundError, ValueError, OSError) as exc:
                    messagebox.showerror("Reports", str(exc)); return
                self.downloaded[fname] = path
                state.append_audit(state.audit_path(), self.user, "download", e.report)
            self._open_path(path, e.report)

        def _open_path(self, path, report):
            if not Path(path).is_file():
                messagebox.showinfo("Reports", "Download it first."); return
            state.record_open(state.state_path(), self.user, report, path)
            state.append_audit(state.audit_path(), self.user, "open", report)
            launch = Path(path)
            if launch.suffix.lower() == ".zip":
                # Bundle report: extract beside the download and open the FOLDER —
                # the workbooks are immediately usable, no manual unzip step.
                try:
                    launch = extract_bundle(launch)
                    self.status.config(text=f"Bundle extracted  ->  {launch}")
                except (OSError, ValueError, zipfile.BadZipFile) as exc:
                    messagebox.showwarning(
                        "Reports", f"Could not extract the bundle: {exc}\nOpening the zip itself instead.")
            if hasattr(os, "startfile"):
                os.startfile(str(launch))          # Windows: Excel file or Explorer folder
            else:
                messagebox.showinfo("Open", f"Open: {launch}")

    return _Frame(parent)


def main() -> int:
    import tkinter as tk
    root = tk.Tk()
    root.title("US-Bangla Tools  -  Zenith ▸ Reports")
    root.geometry("780x560"); root.configure(bg=WHITE)
    h = tk.Frame(root, bg=NAVY, height=54); h.pack(fill="x"); h.pack_propagate(False)
    tk.Label(h, text="   Zenith ▸ Reports", bg=NAVY, fg=WHITE,
             font=("Segoe UI", 14, "bold")).pack(side="left", pady=12)
    tk.Label(h, text="Zenith  ✓ signed in     ", bg=NAVY, fg="#9DC3E6",
             font=("Segoe UI", 9)).pack(side="right", pady=16)
    ReportsFrame(root).pack(fill="both", expand=True)
    root.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
