"""
reporting.builders.salesperson_pack — per-sales-person TARGET PACK (+ bulk-mailer manifest).

"Give every sales person ONE workbook with everything they need for the month:
 what their agents sold, what their zone's June target is and how far along they
 are, and the route-level target for each of their agencies."

Each pack (one .xlsx per sales person) contains:
  * Agent Sales            -> their agents' GROSS/NET, last 3 months + June-to-date
                              (identical engine/layout to the Sales_Person report tab)
  * Zone Target            -> their zone(s): June target (net & gross), achieved so
                              far, achievement %, capacity fill  (same math as the
                              June_Target 'Target vs Achievement' sheet)
  * Agency Route Targets   -> per agency x route: 5-month basis, target tickets,
                              target net & gross  (same cascade as 'Agent Route Target')

Alongside the packs it writes ``Email_Manifest.xlsx`` — the exact mapping sheet the
Bulk Mailer expects (``Email | Name | File | CC | BCC``; File is a bare filename that
the mailer resolves against its picked attachments folder = the pack folder).
Emails come from ``reference/salesperson_emails.xlsx`` (edit THAT file when people
change); CC defaults come from the same file; pairs get both addresses ";"-joined.

Everything is zipped into ONE bundle and the zip is what gets published to the
share/manifest — so the Reports tab in the desktop exe lists a single
"Sales-Person Target Packs" row whose download contains all packs + the manifest.

Public entry point:  ``generate(params, cfg) -> Path``  (returns the .zip).
Optional params: ``pack_dir`` (default ~/Downloads/Sales Person Packs),
``zip_path`` (default ~/Downloads/Sales Person Packs.zip),
``include_unmapped`` (default True — pack for the (Unmapped) bucket, sales sheet only;
it is never added to the email manifest).
"""
from __future__ import annotations

import zipfile
from pathlib import Path

import duckdb
import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import PatternFill
from openpyxl.utils import get_column_letter

from ..config import Config, load_config
from . import june_target as jt
from . import salesperson_gross as sg
from .salesperson_gross import (
    AMBER_F, AMBER_T, BLUE_LIGHT, BLUE_MED, CR, GREY_L, GREY_T, NAVY, WHITE,
    cell, safe_filename, safe_sheet_name,
)

# Achievement-cell traffic lights (same thresholds as the June_Target sheet):
# green when at/over pace, amber when >= 60% of pace, red below.
GREEN_F = "C6EFCE"; RED_F = "FFC7CE"

F_INT = "#,##0"; F_CR = "#,##0.00"; F_PCT = "0%"

EMAILS_XLSX_NAME = "salesperson_emails.xlsx"   # lives in cfg's reference/ folder
MANIFEST_NAME = "Email_Manifest.xlsx"


# --------------------------------------------------------------------------- #
# Inputs
# --------------------------------------------------------------------------- #
def _load_email_map(cfg: Config) -> tuple[dict[str, str], str]:
    """label -> ';'-joined emails, plus the default CC string (blank-safe)."""
    path = cfg.reference / EMAILS_XLSX_NAME
    if not path.is_file():
        print(f"[WARN] {path.name} missing — Email column will be blank (run "
              f"scripts/make_salesperson_emails.py to create it).")
        return {}, ""
    df = pd.read_excel(path, dtype=str).fillna("")
    emails = {r["sales_person_label"].strip(): r["emails"].strip() for _, r in df.iterrows()}
    cc = next((c for c in df.get("default_cc", pd.Series(dtype=str)) if str(c).strip()), "")
    return emails, str(cc).strip()


def _customer_salesperson_map(cfg: Config) -> dict[str, str]:
    """customer_id(str) -> sales-person label, from dim_customer (read-only)."""
    con = duckdb.connect(str(cfg.warehouse), read_only=True)
    try:
        rows = con.execute(
            "SELECT CAST(customer_id AS VARCHAR), "
            "       COALESCE(NULLIF(TRIM(sales_person), ''), '(Unmapped)') "
            "FROM dim_customer"
        ).fetchall()
    finally:
        con.close()
    return {str(cid): sp for cid, sp in rows}


def _norm_label(value: object) -> str:
    """Whitespace/case-tolerant person-label key ('Rabiul Alam Robin ' == 'rabiul alam robin')."""
    return " ".join(str(value or "").split()).casefold()


def _zone_owner_map(cfg: Config) -> dict[str, str]:
    """zone_code -> NORMALISED sales-person label, from dim_sales_person.parquet.

    This is the SAME source 03_build_dim_customer joins to set dim_customer.sales_person,
    so it matches the pack labels exactly.  (The june_target ``zlabels`` dict is NOT
    usable for ownership — its second field is the zone MANAGER from zone_managers.xlsx,
    a different person; using it made every pack say "no zone assigned".)
    """
    path = cfg.reference / "dim_sales_person.parquet"
    if not path.is_file():
        print(f"[WARN] {path.name} missing — Zone Target sheets will be empty.")
        return {}
    con = duckdb.connect()
    try:
        rows = con.execute(
            f"SELECT zone_code, sales_persons FROM read_parquet('{path.as_posix()}')"
        ).fetchall()
    finally:
        con.close()
    return {str(z): _norm_label(sp) for z, sp in rows}


# --------------------------------------------------------------------------- #
# Sheet 2 — Zone Target & Achievement (person's slice of the zone frame)
# --------------------------------------------------------------------------- #
def _write_zone_sheet(ws, person: str, Z: pd.DataFrame, zl: dict,
                      owner_by_zone: dict[str, str], d: dict) -> None:
    """One row per zone OWNED by this person (ownership = dim_sales_person's label
    for the zone == this pack's label, whitespace/case-tolerant), then a TOTAL row.
    Same numbers as the June_Target 'Target vs Achievement' sheet — just filtered.
    ``zl`` (zone_managers.xlsx) supplies the Area text only."""
    ws.sheet_view.showGridLines = False
    jd = int(d.get("june_days", 6) or 6); pace = jd / 30.0
    gr = {s: d["yld_gross"][s] / d["yld"][s] for s in ["Domestic", "International"]}

    key = _norm_label(person)
    zones = [zn for zn in Z.index if owner_by_zone.get(str(zn)) == key]
    ncol = 12
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=ncol)
    cell(ws, 1, 1, f"Zone Target & Achievement — {person}", bold=True, size=14,
         color=WHITE, fill=NAVY, align="center", border=False)
    ws.row_dimensions[1].height = 26
    ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=ncol)
    cell(ws, 2, 1, f"Target = zone share of {d['commit']:,.0f} cr net / {d['commit_gross']:,.0f} cr gross "
                   f"({d['commit_lf']*100:.0f}% LF, +{(jt.GROWTH_UPLIFT-1)*100:.0f}% growth)  ·  "
                   f"Sold = actual Jun 1-{jd}  ·  on pace = {pace*100:.0f}%  ·  "
                   f"NET = balance − commission  ·  GROSS = ticket payment (before commission)",
         size=9.5, color=GREY_T, fill=BLUE_LIGHT, align="center", wrap=True, border=False)
    ws.row_dimensions[2].height = 18

    heads = ["Zone", "Area", "Baseline\n(cr/mo)", "Target Dom\n(cr)", "Target Intl\n(cr)",
             "Target NET\n(cr)", "Target GROSS\n(cr)", "Target\nTickets",
             f"Sold Jun 1-{jd}\n(cr)", "Tickets\nsold", "Ach\n%", "Fill\n%"]
    widths = [10, 26, 10, 11, 11, 11, 12, 10, 12, 9, 8, 8]
    for j, (h, w) in enumerate(zip(heads, widths), 1):
        cell(ws, 4, j, h, bold=True, size=9, color=NAVY, fill=BLUE_LIGHT, align="center", wrap=True)
        ws.column_dimensions[get_column_letter(j)].width = w
    ws.row_dimensions[4].height = 26
    ws.freeze_panes = "A5"

    if not zones:
        cell(ws, 5, 1, "No zone maps to this name in dim_sales_person (zone master).",
             size=10, color=GREY_T, border=False)
        return

    r = 5
    for i, zn in enumerate(zones, 1):
        x = Z.loc[zn]; stripe = GREY_L if i % 2 == 0 else None
        area = zl.get(zn, ("", ""))[0]
        gross = x["td"] * gr["Domestic"] + x["ti"] * gr["International"]
        vals = [zn, area, x["bs"], x["td"], x["ti"], x["tt"], gross, x["ttk"],
                x["sn"], x["stk"], x["ach"], x["cap"]]
        fmts = [None, None, F_CR, F_CR, F_CR, F_CR, F_CR, F_INT, F_CR, F_INT, F_PCT, F_PCT]
        for j, (v, fm) in enumerate(zip(vals, fmts), 1):
            cell(ws, r, j, v, fmt=fm, align=("left" if j <= 2 else "center"), size=9,
                 bold=(j == 6), color=NAVY if j in (1, 6) else "000000", fill=stripe, wrap=(j == 2))
        # traffic-light on achievement vs pace
        ach = float(x["ach"])
        ws.cell(r, 11).fill = PatternFill(
            "solid", fgColor=(GREEN_F if ach >= pace else AMBER_F if ach >= pace * 0.6 else RED_F))
        r += 1

    tot = Z.loc[zones].sum()
    tot_gross = tot["td"] * gr["Domestic"] + tot["ti"] * gr["International"]
    cell(ws, r, 1, "TOTAL", bold=True, color=WHITE, fill=NAVY)
    cell(ws, r, 2, "", fill=NAVY)
    tv = [(3, tot["bs"], F_CR), (4, tot["td"], F_CR), (5, tot["ti"], F_CR), (6, tot["tt"], F_CR),
          (7, tot_gross, F_CR), (8, tot["ttk"], F_INT), (9, tot["sn"], F_CR), (10, tot["stk"], F_INT),
          (11, (tot["sn"] / tot["tt"] if tot["tt"] else 0), F_PCT), (12, tot["cap"], F_PCT)]
    for c0, v, fm in tv:
        cell(ws, r, c0, v, fmt=fm, bold=True, color=WHITE, fill=NAVY, align="center")


# --------------------------------------------------------------------------- #
# Sheet 3 — Agency Route Targets (person's slice of the agent-route cascade)
# --------------------------------------------------------------------------- #
def _write_route_sheet(ws, person: str, ar: pd.DataFrame, agg: pd.DataFrame,
                       dom_f: float, int_f: float, mtd: "pd.DataFrame | None",
                       d: dict) -> dict[str, int]:
    """GRAND TOTAL for the person on top, then each agency (biggest first) as a
    subtotal row followed by its route rows — Domestic first, then International.
    'Sold' columns = real June-to-date sales for that agency/route; Ach % = sold/target.

    Returns ``{customer_id: excel_row}`` of each agency's subtotal row, so the
    Agent Sales sheet can hyperlink straight to an agency's route block."""
    ws.sheet_view.showGridLines = False
    jd = int(d.get("june_days", 6) or 6); pace = jd / 30.0
    ncol = 11
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=ncol)
    cell(ws, 1, 1, f"Agency Route Targets — {person}", bold=True, size=14,
         color=WHITE, fill=NAVY, align="center", border=False)
    ws.row_dimensions[1].height = 26
    ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=ncol)
    cell(ws, 2, 1, f"Route target = 5-mo route sales × sector factor (Dom ×{dom_f:.3f} / "
                   f"Intl ×{int_f:.3f}, +{(jt.GROWTH_UPLIFT-1)*100:.0f}% growth)  ·  "
                   f"Sold = actual Jun 1-{jd}  ·  on pace = {pace*100:.0f}%  ·  "
                   f"NET = balance − commission  ·  GROSS = ticket payment (before commission)",
         size=9.5, color=GREY_T, fill=BLUE_LIGHT, align="center", wrap=True, border=False)
    ws.row_dimensions[2].height = 18

    heads = ["#", "Agency / Route", "Zone", "Sector", "5mo\nTickets", "5mo Sales\n(cr)",
             "Target\nTickets", "Target NET\n(cr)", "Target GROSS\n(cr)",
             f"Sold Jun 1-{jd}\n(cr)", "Ach\n%"]
    widths = [5, 36, 10, 12, 10, 11, 10, 12, 12, 11, 8]
    for j, (h, w) in enumerate(zip(heads, widths), 1):
        cell(ws, 3, j, h, bold=True, size=9, color=NAVY, fill=BLUE_LIGHT, align="center", wrap=True)
        ws.column_dimensions[get_column_letter(j)].width = w
    ws.row_dimensions[3].height = 26
    ws.freeze_panes = "A4"

    if ar is None or not len(ar):
        cell(ws, 4, 1, "No route-target rows for this name (no 5-month sales history).",
             size=10, color=GREY_T, border=False)
        return {}

    # June-to-date actual per (agency, route) and per agency — for the Sold columns.
    route_sold: dict[tuple[str, str], float] = {}
    agency_sold: dict[str, float] = {}
    if mtd is not None and len(mtd):
        for _, m in mtd.iterrows():
            cid = str(m["customer_id"]); rt = str(m["route"] or "")
            net_cr = float(m["net"]) / CR
            route_sold[(cid, rt)] = route_sold.get((cid, rt), 0.0) + net_cr
            agency_sold[cid] = agency_sold.get(cid, 0.0) + net_cr

    def ach_cell(r: int, sold: float, target: float, *, bold: bool = False, fill=None) -> None:
        """Ach% with the same traffic-light as the zone sheet (vs month pace)."""
        ach = (sold / target) if target else 0.0
        cell(ws, r, 11, ach, fmt=F_PCT, align="center", size=9, bold=bold, fill=fill)
        if fill is None:                       # route/agency rows get the traffic light
            ws.cell(r, 11).fill = PatternFill(
                "solid", fgColor=(GREEN_F if ach >= pace else AMBER_F if ach >= pace * 0.6 else RED_F))

    # person's grand total (amber, on top) — share of the company commit
    person_ids = {str(i) for i in agg.index}
    tot_sold = sum(v for k, v in agency_sold.items() if k in person_ids)
    r = 4
    cell(ws, r, 1, "", fill=AMBER_F)
    cell(ws, r, 2, f"TOTAL — {person}", bold=True, size=10.5, color=AMBER_T, fill=AMBER_F)
    for cc0 in (3, 4):
        cell(ws, r, cc0, "", fill=AMBER_F)
    cell(ws, r, 5, int(agg["tk5"].sum()), fmt=F_INT, align="center", bold=True, fill=AMBER_F)
    cell(ws, r, 6, agg["s5"].sum() / CR, fmt=F_CR, align="center", bold=True, fill=AMBER_F)
    cell(ws, r, 7, int(agg["ttk"].sum()), fmt=F_INT, align="center", bold=True, fill=AMBER_F)
    cell(ws, r, 8, agg["tamt"].sum(), fmt=F_CR, align="center", bold=True, color=AMBER_T, fill=AMBER_F)
    cell(ws, r, 9, agg["tgr"].sum(), fmt=F_CR, align="center", bold=True, color=AMBER_T, fill=AMBER_F)
    cell(ws, r, 10, tot_sold, fmt=F_CR, align="center", bold=True, color=AMBER_T, fill=AMBER_F)
    ach_cell(r, tot_sold, float(agg["tamt"].sum()), bold=True, fill=AMBER_F)
    r += 1

    anchors: dict[str, int] = {}     # customer_id -> excel row of its subtotal (for links)
    idx = 1; prev = None
    for _, x in ar.iterrows():
        cid = str(x["customer_id"])
        if cid != prev:          # agency subtotal row
            prev = cid; a = agg.loc[x["customer_id"]]
            sold_a = agency_sold.get(cid, 0.0)
            anchors[cid] = r
            cell(ws, r, 1, idx, align="center", size=9, bold=True, fill=BLUE_LIGHT)
            cell(ws, r, 2, str(a["name"] or "")[:44], bold=True, size=9.5, color=NAVY, fill=BLUE_LIGHT)
            cell(ws, r, 3, str(a["zn"] or ""), size=9, fill=BLUE_LIGHT)
            cell(ws, r, 4, "", fill=BLUE_LIGHT)
            cell(ws, r, 5, int(a["tk5"]), fmt=F_INT, align="center", size=9, bold=True, fill=BLUE_LIGHT)
            cell(ws, r, 6, a["s5"] / CR, fmt=F_CR, align="center", size=9, bold=True, fill=BLUE_LIGHT)
            cell(ws, r, 7, int(a["ttk"]), fmt=F_INT, align="center", size=9, bold=True, fill=BLUE_LIGHT)
            cell(ws, r, 8, a["tamt"], fmt=F_CR, align="center", size=9, bold=True, color=NAVY, fill=BLUE_LIGHT)
            cell(ws, r, 9, a["tgr"], fmt=F_CR, align="center", size=9, bold=True, color=BLUE_MED, fill=BLUE_LIGHT)
            cell(ws, r, 10, sold_a, fmt=F_CR, align="center", size=9, bold=True, fill=BLUE_LIGHT)
            ach_cell(r, sold_a, float(a["tamt"]), bold=True)
            idx += 1; r += 1
        sold_r = route_sold.get((cid, str(x["route"] or "")), 0.0)
        cell(ws, r, 1, "")
        cell(ws, r, 2, "      " + str(x["route"] or ""), size=9, color=NAVY)
        cell(ws, r, 3, "")
        cell(ws, r, 4, x["sector"], size=9)
        cell(ws, r, 5, int(x["tickets"]), fmt=F_INT, align="center", size=9)
        cell(ws, r, 6, x["net"] / CR, fmt=F_CR, align="center", size=9)
        cell(ws, r, 7, int(x["tgt_tkt"]), fmt=F_INT, align="center", size=9)
        cell(ws, r, 8, x["tgt_amt"], fmt=F_CR, align="center", size=9)
        cell(ws, r, 9, x["tgt_gross"], fmt=F_CR, align="center", size=9, color=BLUE_MED)
        cell(ws, r, 10, sold_r, fmt=F_CR, align="center", size=9)
        ach_cell(r, sold_r, float(x["tgt_amt"]))
        r += 1
    return anchors


# --------------------------------------------------------------------------- #
# Save helper (same lock-tolerant behaviour as the other builders)
# --------------------------------------------------------------------------- #
def _save_wb(wb: Workbook, path: Path) -> Path | None:
    """Save; if the file is open in Excel, fall back to *_v2; give up quietly after that."""
    try:
        wb.save(path); return path
    except PermissionError:
        alt = path.with_name(path.stem + "_v2.xlsx")
        try:
            wb.save(alt); return alt
        except PermissionError:
            print(f"[WARN] locked, skipped: {path.name}")
            return None


# --------------------------------------------------------------------------- #
# Entry point
# --------------------------------------------------------------------------- #
def generate(params: dict | None = None, cfg: Config | None = None) -> Path:
    """Build all per-person packs + Email_Manifest, zip them, return the zip path."""
    cfg = cfg or load_config(validate=True)
    params = params or {}
    pack_dir = Path(params.get("pack_dir") or (Path.home() / "Downloads" / "Sales Person Packs"))
    zip_path = Path(params.get("zip_path") or (Path.home() / "Downloads" / "Sales Person Packs.zip"))
    include_unmapped = bool(params.get("include_unmapped", True))

    # ---- engines: sales sheet (Sales_Person report) + target frames (June_Target) ----
    periods, win_lo, win_hi, mtd_label = sg.make_periods(sg._data_max_date(cfg))
    heads = sg.person_heads(periods)
    sales_df = sg._load(cfg, periods, win_lo, win_hi)

    d = jt.gather()                                  # one pass of the target engine
    Z = jt.zone_achievement_frame(d)                 # zone target vs achievement
    ar_all, agg_all, dom_f, int_f = jt.agent_route_frame(d)   # agency x route cascade
    mtd_all = d.get("agent_routes_mtd")              # June-to-date per agency x route
    zl = d.get("zlabels", {})                        # zone -> (area, ZONE MANAGER) — Area text only
    owner_by_zone = _zone_owner_map(cfg)             # zone -> salesperson label (ownership truth)
    cust_sp = _customer_salesperson_map(cfg)         # customer_id -> label

    # person order = same as the Sales_Person report Index (totals desc, Unmapped last)
    totals = sales_df.groupby("sales_person")["total"].sum().sort_values(ascending=False)
    persons = [p for p in totals.index if p != "(Unmapped)"]
    if include_unmapped and "(Unmapped)" in totals.index:
        persons.append("(Unmapped)")

    # ---- write one pack per person ------------------------------------------------
    pack_dir.mkdir(parents=True, exist_ok=True)
    for old in pack_dir.glob("*.xlsx"):              # fresh output dir each run
        try:
            old.unlink()
        except OSError:
            pass                                     # an open file just gets overwritten via _v2

    emails, default_cc = _load_email_map(cfg)
    manifest_rows: list[dict[str, str]] = []
    used_files: set[str] = set()
    written = 0
    for person in persons:
        label = "Unmapped" if person == "(Unmapped)" else person
        wb = Workbook(); used_sheets: set[str] = set()
        # Create the sheets up front so the TAB ORDER is Sales -> Zone -> Routes,
        # but WRITE the route sheet first: its per-agency row anchors are needed to
        # hyperlink the Agent Sales rows ("click an agent -> its route targets").
        ws_sales = wb.active; ws_sales.title = safe_sheet_name("Agent Sales", used_sheets)
        link_map: dict[str, str] | None = None
        if person != "(Unmapped)":
            ws_zone = wb.create_sheet(safe_sheet_name("Zone Target", used_sheets))
            ws_routes = wb.create_sheet(safe_sheet_name("Agency Route Targets", used_sheets))
            _write_zone_sheet(ws_zone, person, Z, zl, owner_by_zone, d)
            if ar_all is not None:
                ids = {cid for cid, sp in cust_sp.items() if sp == person}
                ar_p = ar_all[ar_all["customer_id"].astype(str).isin(ids)]
                agg_p = agg_all[agg_all.index.astype(str).isin(ids)]
                mtd_p = (mtd_all[mtd_all["customer_id"].astype(str).isin(ids)]
                         if mtd_all is not None else None)
            else:
                ar_p, agg_p, mtd_p = None, None, None
            anchors = _write_route_sheet(ws_routes, person, ar_p, agg_p, dom_f, int_f, mtd_p, d)
            link_map = {cid: f"#'{ws_routes.title}'!A{row}" for cid, row in anchors.items()}
        sg.write_person_sheet(ws_sales, person, sales_df[sales_df["sales_person"] == person],
                              heads, mtd_label, link_map=link_map)

        out = _save_wb(wb, pack_dir / f"{safe_filename(label, used_files)}.xlsx")
        if out is None:
            continue
        written += 1
        if person != "(Unmapped)":                   # Unmapped has nobody to email
            manifest_rows.append({
                "Email": emails.get(person, ""),
                "Name": person,
                "File": out.name,                    # bare filename — mailer resolves vs folder
                "CC": default_cc,
                "BCC": "",
            })

    # ---- bulk-mailer manifest -------------------------------------------------------
    mdf = pd.DataFrame(manifest_rows, columns=["Email", "Name", "File", "CC", "BCC"])
    manifest_path = pack_dir / MANIFEST_NAME
    try:
        mdf.to_excel(manifest_path, sheet_name="mapping", index=False)
    except PermissionError:                          # manifest open in Excel -> _v2
        manifest_path = manifest_path.with_name("Email_Manifest_v2.xlsx")
        mdf.to_excel(manifest_path, sheet_name="mapping", index=False)
    missing = [r["Name"] for r in manifest_rows if not r["Email"]]
    if missing:
        print(f"[WARN] no email for: {', '.join(missing)} — rows left blank in {manifest_path.name}")

    # ---- zip everything (packs + manifest) into the single published artifact ------
    try:
        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
            for f in sorted(pack_dir.glob("*.xlsx")):
                z.write(f, arcname=f.name)
    except PermissionError:                          # zip locked -> _v2 alongside
        zip_path = zip_path.with_name(zip_path.stem + "_v2.zip")
        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
            for f in sorted(pack_dir.glob("*.xlsx")):
                z.write(f, arcname=f.name)

    print(f"packs: {written} written -> {pack_dir}  |  manifest: {manifest_path.name}  |  zip: {zip_path}")
    return zip_path
